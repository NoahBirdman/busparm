/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "usbd_core.h"
#include "usbd_cdc_if.h"

#include <stdio.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef enum
{
  APP_MODE_NORMAL_SENSE = 0,
  APP_MODE_UART_SNIFF,
  APP_MODE_I2C_SNIFF,
  APP_MODE_UART_CONTROL,
  APP_MODE_I2C_CONTROL
} AppMode;

typedef enum
{
  UART_DISPLAY_ASCII = 0,
  UART_DISPLAY_HEX
} UartDisplayMode;

typedef enum
{
  UART_FLUSH_LINE = 0,
  UART_FLUSH_TIMEOUT,
  UART_FLUSH_FULL
} UartFlushMode;

typedef enum
{
  UART_OPTION_STATUS_NONE = 0,
  UART_OPTION_STATUS_DISPLAY_ASCII,
  UART_OPTION_STATUS_DISPLAY_HEX,
  UART_OPTION_STATUS_FLUSH_LINE,
  UART_OPTION_STATUS_FLUSH_TIMEOUT,
  UART_OPTION_STATUS_FLUSH_FULL
} UartOptionStatus;

typedef enum
{
  I2C_SNIFF_EVENT_SCL_RISING = 0,
  I2C_SNIFF_EVENT_START,
  I2C_SNIFF_EVENT_STOP
} I2cSniffEventType;

typedef struct
{
  uint8_t type;
  uint8_t scl;
  uint8_t sda;
  uint32_t timestamp_ms;
} I2cSniffEvent;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define MEASUREMENT_PERIOD_MS 1000U
#define INA236_I2C_ADDR_7BIT 0x48U
#define INA236_CONFIG_REG 0x00U
#define INA236_SHUNT_VOLTAGE_REG 0x01U
#define INA236_BUS_VOLTAGE_REG 0x02U
#define INA236_I2C_TIMEOUT_MS 25U
#define INA236_BUS_UV_PER_LSB 1600L
#define INA236_SHUNT_NV_PER_LSB 2500L
#define INA236_DEFAULT_SHUNT_MILLIOHMS 10L
#define MICRO_UNITS_PER_UNIT 1000000L
#define I2C_SNIFF_EVENT_QUEUE_SIZE 256U
#define I2C_SNIFF_EVENT_DRAIN_LIMIT 96U
#define I2C_SNIFF_PACKET_BUFFER_SIZE 160U
#define I2C_SNIFF_OUTPUT_QUEUE_DEPTH 16U
#define I2C_SNIFF_OUTPUT_LINE_SIZE 192U
#define I2C_SNIFF_STALE_TRANSACTION_TIMEOUT_MS 100U
#define I2C_SNIFF_BUS_LOW_TIMEOUT_MS 100U
#define I2C_SNIFF_SWAP_SDA_EDGE_THRESHOLD 12U
#define I2C_SNIFF_SWAP_SCL_FALL_THRESHOLD 2U
#define I2C_SNIFF_SCL_Pin I2C2_EXT_SCL_Pin
#define I2C_SNIFF_SCL_GPIO_Port I2C2_EXT_SCL_GPIO_Port
#define I2C_SNIFF_SDA_Pin I2C2_EXT_SDA_Pin
#define I2C_SNIFF_SDA_GPIO_Port I2C2_EXT_SDA_GPIO_Port
#define UART_SNIFF_RX_BUFFER_SIZE 128U
#define UART_SNIFF_RX_DRAIN_LIMIT 32U
#define UART_SNIFF_PACKET_BUFFER_SIZE 96U
#define UART_SNIFF_BYTE_TIMEOUT_MS 20U
#define SYSTEM_BOOTLOADER_ADDRESS 0x1FFF0000U
#define BOOTLOADER_ENTRY_DELAY_MS 250U
#define BOOTLOADER_ENTRY_MAGIC 0xB00710ADU
#define USB_RX_LED_PULSE_MS 75U

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
extern USBD_HandleTypeDef hUsbDeviceFS;

static uint32_t measurement_last_tick = 0U;
static uint8_t csv_header_sent = 0U;
static AppMode app_mode = APP_MODE_NORMAL_SENSE;
static uint8_t usb_escape_pending = 0U;
static uint8_t mode_transition_pending = 0U;
static uint8_t uart_sniff_rx_buffer[UART_SNIFF_RX_BUFFER_SIZE];
static uint16_t uart_sniff_rx_head = 0U;
static uint16_t uart_sniff_rx_tail = 0U;
static uint32_t uart_sniff_rx_dropped = 0U;
static uint8_t uart_sniff_packet_buffer[UART_SNIFF_PACKET_BUFFER_SIZE];
static uint16_t uart_sniff_packet_len = 0U;
static uint32_t uart_sniff_last_rx_tick = 0U;
static UartDisplayMode uart_display_mode = UART_DISPLAY_ASCII;
static UartFlushMode uart_flush_mode = UART_FLUSH_TIMEOUT;
static UartOptionStatus uart_option_status_pending = UART_OPTION_STATUS_NONE;
static uint8_t usb_tx_buffer[192];
static uint8_t bootloader_entry_pending = 0U;
static uint8_t bootloader_entry_ack_sent = 0U;
static uint32_t bootloader_entry_ack_tick = 0U;
static uint32_t bootloader_entry_magic __attribute__((section(".noinit")));
static volatile uint8_t usb_rx_activity_pending = 0U;
static uint8_t usb_rx_led_active = 0U;
static uint32_t usb_rx_led_until_tick = 0U;
static volatile uint8_t i2c_sniff_capture_enabled = 0U;
static volatile uint8_t i2c_sniff_local_stimulus_active = 0U;
static uint8_t i2c_sniff_local_ina_stimulus_pending = 0U;
static volatile uint16_t i2c_sniff_event_head = 0U;
static volatile uint16_t i2c_sniff_event_tail = 0U;
static volatile uint8_t i2c_sniff_event_overflow = 0U;
static volatile I2cSniffEvent i2c_sniff_events[I2C_SNIFF_EVENT_QUEUE_SIZE];
static volatile uint8_t i2c_sniff_isr_last_scl = 1U;
static volatile uint8_t i2c_sniff_isr_last_sda = 1U;
static volatile uint8_t i2c_sniff_isr_packet_active = 0U;
static volatile uint8_t i2c_sniff_isr_scl_rises_in_packet = 0U;
static volatile uint32_t i2c_sniff_debug_scl_rising_count = 0U;
static volatile uint32_t i2c_sniff_debug_scl_falling_count = 0U;
static volatile uint32_t i2c_sniff_debug_start_count = 0U;
static volatile uint32_t i2c_sniff_debug_stop_count = 0U;
static volatile uint32_t i2c_sniff_debug_ignored_start_count = 0U;
static volatile uint32_t i2c_sniff_debug_ignored_stop_count = 0U;
static volatile uint32_t i2c_sniff_debug_overflow_count = 0U;
static volatile uint32_t i2c_sniff_debug_sda_edges_while_scl_low = 0U;
static volatile uint32_t i2c_sniff_debug_scl_fall_while_sda_high = 0U;
static uint8_t i2c_sniff_swapped_warning_reported = 0U;
static uint8_t i2c_sniff_packet_active = 0U;
static uint8_t i2c_sniff_expect_address = 1U;
static uint8_t i2c_sniff_bit_count = 0U;
static uint8_t i2c_sniff_current_byte = 0U;
static uint8_t i2c_sniff_decoded_byte_count = 0U;
static uint8_t i2c_sniff_transaction_overflow_reported = 0U;
static uint8_t i2c_sniff_bus_low_reported = 0U;
static uint32_t i2c_sniff_last_event_tick = 0U;
static uint32_t i2c_sniff_bus_low_since_tick = 0U;
static char i2c_sniff_packet_buffer[I2C_SNIFF_PACKET_BUFFER_SIZE];
static uint16_t i2c_sniff_packet_len = 0U;
static char i2c_sniff_output_queue[I2C_SNIFF_OUTPUT_QUEUE_DEPTH][I2C_SNIFF_OUTPUT_LINE_SIZE];
static uint8_t i2c_sniff_output_head = 0U;
static uint8_t i2c_sniff_output_tail = 0U;
static uint8_t i2c_sniff_output_count = 0U;
static uint8_t i2c_sniff_output_overflow_pending = 0U;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */
static HAL_StatusTypeDef INA236_ReadRegister(uint8_t reg, uint16_t *value);
static HAL_StatusTypeDef INA236_WriteRegister(uint8_t reg, uint16_t value);
static HAL_StatusTypeDef INA236_ReadMeasurement(int32_t *bus_voltage_uV,
                                                int32_t *current_uA,
                                                int32_t *power_uW,
                                                uint8_t *failed_reg);
static int FormatSignedMicro(char *buffer, size_t buffer_size, int32_t micro_value);
static void ProcessUsbCommands(void);
static void ProcessUartOptionStatus(void);
static void ProcessUartSniffer(void);
static void ProcessI2cSniffer(void);
static void ProcessBootloaderEntry(void);
static void ProcessUsbRxActivityIndicator(uint32_t now);
static void SetAppMode(AppMode new_mode);
static void ExitPassiveSniffing(void);
static void RequestSystemBootloader(void);
static void JumpToSystemBootloader(void);
static const char *AppModeName(AppMode mode);
static void ConfigureI2cSniffPinsHiZ(void);
static void I2cSniffCaptureBlockingFromStart(uint32_t start_idr) __attribute__((optimize("O3")));
static void ResetUartSnifferState(void);
static uint8_t UartSnifferBufferPush(uint8_t byte);
static uint8_t UartSnifferBufferPop(uint8_t *byte);
static void UartSnifferPacketPush(uint8_t byte);
static uint8_t UartSnifferPacketShouldFlush(uint32_t now);
static uint8_t UartSnifferPacketFlush(void);
static void ConfigureI2cSniffCapture(uint8_t enabled);
static void I2cSniffCaptureEvent(I2cSniffEventType type, uint8_t scl, uint8_t sda);
static uint8_t I2cSniffPopEvent(I2cSniffEvent *event);
static void I2cSniffDecodeEvent(const I2cSniffEvent *event);
static void I2cSniffHandleStart(void);
static void I2cSniffHandleStop(void);
static void I2cSniffHandleSclRising(uint8_t sda);
static void I2cSniffCheckStaleTransaction(uint32_t now);
static void I2cSniffCheckBusLow(uint32_t now);
static void I2cSniffRunLocalInaStimulus(void);
static void I2cSniffResetDecoderState(void);
static uint8_t I2cSniffAppendChar(char value);
static uint8_t I2cSniffAppendText(const char *text);
static uint8_t I2cSniffAppendFormattedByte(uint8_t value);
static uint8_t I2cSniffAppendFormattedAddress(uint8_t value);
static uint8_t I2cSniffQueueLine(const char *line);
static void I2cSniffQueueCurrentPacket(void);
static void I2cSniffQueueDiagnostic(const char *reason);
static void I2cSniffQueueShortPacketDiagnostic(void);
static void I2cSniffQueueTimeoutDiagnostic(void);
static void I2cSniffQueueBusLowDiagnostic(uint8_t scl, uint8_t sda);
static void I2cSniffQueueSwappedPinsDiagnostic(void);
static void I2cSniffFlushOutput(void);
static void ResetI2cSnifferState(void);
static uint8_t TrySendUsbText(int len);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  if (bootloader_entry_magic == BOOTLOADER_ENTRY_MAGIC)
  {
    bootloader_entry_magic = 0U;
    JumpToSystemBootloader();
  }

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART2_UART_Init();
  MX_USB_Device_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    ProcessUsbCommands();
    ProcessBootloaderEntry();
    if (bootloader_entry_pending != 0U)
    {
      continue;
    }

    ProcessUartOptionStatus();
    ProcessUartSniffer();
    ProcessI2cSniffer();

    uint32_t now = HAL_GetTick();
    ProcessUsbRxActivityIndicator(now);

    if ((mode_transition_pending != 0U) && (CDC_TransmitReady_FS() != 0U))
    {
      int len = snprintf((char *)usb_tx_buffer,
                         sizeof(usb_tx_buffer),
                         "mode=%s\r\n",
                         AppModeName(app_mode));
      if (TrySendUsbText(len) != 0U)
      {
        mode_transition_pending = 0U;
      }
    }

    if ((now - measurement_last_tick) >= MEASUREMENT_PERIOD_MS)
    {
      measurement_last_tick = now;
      HAL_GPIO_TogglePin(LEF_GREEN_GPIO_Port, LEF_GREEN_Pin);

      if (CDC_TransmitReady_FS() != 0U)
      {
        int len = 0;

        if (app_mode == APP_MODE_NORMAL_SENSE)
        {
          if (csv_header_sent == 0U)
          {
            len = snprintf((char *)usb_tx_buffer,
                           sizeof(usb_tx_buffer),
                           "timestamp_ms,bus_voltage_v,current_a,power_w\r\n");
          }
          else
          {
            int32_t bus_voltage_uV = 0L;
            int32_t current_uA = 0L;
            int32_t power_uW = 0L;
            uint8_t failed_reg = 0U;
            HAL_StatusTypeDef ina236_status = INA236_ReadMeasurement(&bus_voltage_uV,
                                                                     &current_uA,
                                                                     &power_uW,
                                                                     &failed_reg);

            if (ina236_status == HAL_OK)
            {
              char bus_voltage_text[16];
              char current_text[16];
              char power_text[16];

              (void)FormatSignedMicro(bus_voltage_text, sizeof(bus_voltage_text), bus_voltage_uV);
              (void)FormatSignedMicro(current_text, sizeof(current_text), current_uA);
              (void)FormatSignedMicro(power_text, sizeof(power_text), power_uW);

              len = snprintf((char *)usb_tx_buffer,
                             sizeof(usb_tx_buffer),
                             "%lu,%s,%s,%s\r\n",
                             (unsigned long)now,
                             bus_voltage_text,
                             current_text,
                             power_text);
            }
            else
            {
              len = snprintf((char *)usb_tx_buffer,
                             sizeof(usb_tx_buffer),
                             "INA236_CSV_ERR timestamp_ms=%lu addr=0x%02X reg=0x%02X hal=%u i2c_error=0x%08lX\r\n",
                             (unsigned long)now,
                             (unsigned int)INA236_I2C_ADDR_7BIT,
                             (unsigned int)failed_reg,
                             (unsigned int)ina236_status,
                             (unsigned long)HAL_I2C_GetError(&hi2c1));
            }
          }
        }
        else if (app_mode == APP_MODE_UART_SNIFF)
        {
          len = 0;
        }
        else if (app_mode == APP_MODE_I2C_SNIFF)
        {
          len = 0;
        }
        else if (app_mode == APP_MODE_UART_CONTROL)
        {
          len = snprintf((char *)usb_tx_buffer,
                         sizeof(usb_tx_buffer),
                         "status_ms=%lu mode=uart_control_placeholder passive_sniffing_exited\r\n",
                         (unsigned long)now);
        }
        else
        {
          len = snprintf((char *)usb_tx_buffer,
                         sizeof(usb_tx_buffer),
                         "status_ms=%lu mode=i2c_control_placeholder passive_sniffing_exited\r\n",
                         (unsigned long)now);
        }

        if (TrySendUsbText(len) != 0U)
        {
          if ((app_mode == APP_MODE_NORMAL_SENSE) && (csv_header_sent == 0U))
          {
            csv_header_sent = 1U;
          }
        }
      }
    }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_CRSInitTypeDef RCC_CRSInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSI48;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSI48State = RCC_HSI48_ON;
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
  RCC_OscInitStruct.PLL.PLLN = 8;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }

  __HAL_RCC_CRS_CLK_ENABLE();
  RCC_CRSInitStruct.Prescaler = RCC_CRS_SYNC_DIV1;
  RCC_CRSInitStruct.Source = RCC_CRS_SYNC_SOURCE_USB;
  RCC_CRSInitStruct.Polarity = RCC_CRS_SYNC_POLARITY_RISING;
  RCC_CRSInitStruct.ReloadValue = __HAL_RCC_CRS_RELOADVALUE_CALCULATE(48000000U, 1000U);
  RCC_CRSInitStruct.ErrorLimitValue = 34U;
  RCC_CRSInitStruct.HSI48CalibrationValue = 32U;
  HAL_RCCEx_CRSConfig(&RCC_CRSInitStruct);
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x10B17DB5;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LEF_GREEN_Pin|LED_YELLOW_Pin|LED_RED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LEF_GREEN_Pin LED_YELLOW_Pin LED_RED_Pin */
  GPIO_InitStruct.Pin = LEF_GREEN_Pin|LED_YELLOW_Pin|LED_RED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : INA_ALERT_Pin */
  GPIO_InitStruct.Pin = INA_ALERT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(INA_ALERT_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void App_OnUsbHostDataReceived(void)
{
  usb_rx_activity_pending = 1U;
}

void HAL_GPIO_EXTI_Rising_Callback(uint16_t GPIO_Pin)
{
  if (GPIO_Pin == I2C_SNIFF_SCL_Pin)
  {
    i2c_sniff_isr_last_scl = 1U;
    uint8_t sda = (HAL_GPIO_ReadPin(I2C_SNIFF_SDA_GPIO_Port, I2C_SNIFF_SDA_Pin) == GPIO_PIN_SET) ? 1U : 0U;
    I2cSniffCaptureEvent(I2C_SNIFF_EVENT_SCL_RISING, 1U, sda);
  }
  else if (GPIO_Pin == I2C_SNIFF_SDA_Pin)
  {
    uint8_t scl = (HAL_GPIO_ReadPin(I2C_SNIFF_SCL_GPIO_Port, I2C_SNIFF_SCL_Pin) == GPIO_PIN_SET) ? 1U : 0U;
    if (scl != 0U)
    {
      I2cSniffCaptureEvent(I2C_SNIFF_EVENT_STOP, scl, 1U);
    }
    i2c_sniff_isr_last_sda = 1U;
  }
}

void HAL_GPIO_EXTI_Falling_Callback(uint16_t GPIO_Pin)
{
  if (GPIO_Pin == I2C_SNIFF_SCL_Pin)
  {
    i2c_sniff_isr_last_scl = 0U;
    i2c_sniff_debug_scl_falling_count++;
  }
  else if (GPIO_Pin == I2C_SNIFF_SDA_Pin)
  {
    uint8_t scl = (HAL_GPIO_ReadPin(I2C_SNIFF_SCL_GPIO_Port, I2C_SNIFF_SCL_Pin) == GPIO_PIN_SET) ? 1U : 0U;
    if (scl != 0U)
    {
      I2cSniffCaptureEvent(I2C_SNIFF_EVENT_START, scl, 0U);
    }
    i2c_sniff_isr_last_sda = 0U;
  }
}

void App_OnI2cSniffExti(uint32_t rising_mask, uint32_t falling_mask, uint32_t gpio_idr)
{
  uint8_t scl = ((gpio_idr & I2C_SNIFF_SCL_Pin) != 0U) ? 1U : 0U;
  uint8_t sda = ((gpio_idr & I2C_SNIFF_SDA_Pin) != 0U) ? 1U : 0U;

  if (((rising_mask | falling_mask) & I2C_SNIFF_SDA_Pin) != 0U)
  {
    if (scl == 0U)
    {
      i2c_sniff_debug_sda_edges_while_scl_low++;
    }
  }

  if (((falling_mask & I2C_SNIFF_SCL_Pin) != 0U) && (sda != 0U))
  {
    i2c_sniff_debug_scl_fall_while_sda_high++;
  }

  if ((falling_mask & I2C_SNIFF_SDA_Pin) != 0U)
  {
    if (i2c_sniff_local_stimulus_active != 0U)
    {
      i2c_sniff_isr_last_sda = 0U;
      if (i2c_sniff_isr_packet_active == 0U)
      {
        i2c_sniff_isr_packet_active = 1U;
        i2c_sniff_isr_scl_rises_in_packet = 0U;
        I2cSniffCaptureEvent(I2C_SNIFF_EVENT_START, 1U, 0U);
      }
    }
    else if (i2c_sniff_isr_last_scl != 0U)
    {
      i2c_sniff_isr_last_sda = 0U;
      I2cSniffCaptureBlockingFromStart(gpio_idr);
      return;
    }
    else
    {
      i2c_sniff_isr_last_sda = 0U;
    }
  }

  if ((falling_mask & I2C_SNIFF_SCL_Pin) != 0U)
  {
    i2c_sniff_isr_last_scl = 0U;
    i2c_sniff_debug_scl_falling_count++;
  }

  if ((rising_mask & I2C_SNIFF_SCL_Pin) != 0U)
  {
    i2c_sniff_isr_last_scl = 1U;
    if ((i2c_sniff_local_stimulus_active != 0U) && (i2c_sniff_isr_packet_active != 0U) &&
        (i2c_sniff_isr_scl_rises_in_packet < 255U))
    {
      i2c_sniff_isr_scl_rises_in_packet++;
    }
    I2cSniffCaptureEvent(I2C_SNIFF_EVENT_SCL_RISING, 1U, sda);
  }

  if ((rising_mask & I2C_SNIFF_SDA_Pin) != 0U)
  {
    if (((i2c_sniff_local_stimulus_active != 0U) && (i2c_sniff_isr_packet_active != 0U) &&
         (i2c_sniff_isr_scl_rises_in_packet >= 9U) && (scl != 0U)) ||
        ((i2c_sniff_local_stimulus_active == 0U) && (i2c_sniff_isr_last_scl != 0U)))
    {
      i2c_sniff_isr_packet_active = 0U;
      i2c_sniff_isr_scl_rises_in_packet = 0U;
      I2cSniffCaptureEvent(I2C_SNIFF_EVENT_STOP, 1U, 1U);
    }
    i2c_sniff_isr_last_sda = 1U;
  }
}

uint8_t App_OnI2cSniffSdaFallingFast(uint32_t gpio_idr)
{
  if ((i2c_sniff_capture_enabled == 0U) || (i2c_sniff_local_stimulus_active != 0U))
  {
    return 0U;
  }

  if (((gpio_idr & I2C_SNIFF_SCL_Pin) == 0U) && (i2c_sniff_isr_last_scl == 0U))
  {
    i2c_sniff_debug_sda_edges_while_scl_low++;
    return 0U;
  }

  i2c_sniff_isr_last_sda = 0U;
  I2cSniffCaptureBlockingFromStart(I2C_SNIFF_SCL_Pin);
  return 1U;
}

static HAL_StatusTypeDef INA236_ReadRegister(uint8_t reg, uint16_t *value)
{
  uint8_t rx_buffer[2] = {0U, 0U};
  HAL_StatusTypeDef status = HAL_I2C_Mem_Read(&hi2c1,
                                              (uint16_t)(INA236_I2C_ADDR_7BIT << 1),
                                              reg,
                                              I2C_MEMADD_SIZE_8BIT,
                                              rx_buffer,
                                              sizeof(rx_buffer),
                                              INA236_I2C_TIMEOUT_MS);

  if (status == HAL_OK)
  {
    *value = (uint16_t)(((uint16_t)rx_buffer[0] << 8) | rx_buffer[1]);
  }

  return status;
}

static HAL_StatusTypeDef INA236_WriteRegister(uint8_t reg, uint16_t value)
{
  uint8_t tx_buffer[2];
  tx_buffer[0] = (uint8_t)(value >> 8);
  tx_buffer[1] = (uint8_t)(value & 0xFFU);

  return HAL_I2C_Mem_Write(&hi2c1,
                           (uint16_t)(INA236_I2C_ADDR_7BIT << 1),
                           reg,
                           I2C_MEMADD_SIZE_8BIT,
                           tx_buffer,
                           sizeof(tx_buffer),
                           INA236_I2C_TIMEOUT_MS);
}

static HAL_StatusTypeDef INA236_ReadMeasurement(int32_t *bus_voltage_uV,
                                                int32_t *current_uA,
                                                int32_t *power_uW,
                                                uint8_t *failed_reg)
{
  uint16_t bus_raw = 0U;
  uint16_t shunt_raw = 0U;
  HAL_StatusTypeDef status = INA236_ReadRegister(INA236_BUS_VOLTAGE_REG, &bus_raw);

  if (status != HAL_OK)
  {
    *failed_reg = INA236_BUS_VOLTAGE_REG;
    return status;
  }

  status = INA236_ReadRegister(INA236_SHUNT_VOLTAGE_REG, &shunt_raw);
  if (status != HAL_OK)
  {
    *failed_reg = INA236_SHUNT_VOLTAGE_REG;
    return status;
  }

  *bus_voltage_uV = (int32_t)bus_raw * INA236_BUS_UV_PER_LSB;

  int32_t shunt_voltage_nV = (int32_t)((int16_t)shunt_raw) * INA236_SHUNT_NV_PER_LSB;
  *current_uA = shunt_voltage_nV / INA236_DEFAULT_SHUNT_MILLIOHMS;
  *power_uW = (int32_t)(((int64_t)(*bus_voltage_uV) * (int64_t)(*current_uA)) /
                        MICRO_UNITS_PER_UNIT);
  *failed_reg = 0U;

  return HAL_OK;
}

static int FormatSignedMicro(char *buffer, size_t buffer_size, int32_t micro_value)
{
  const char *sign = "";
  uint32_t magnitude;

  if (micro_value < 0)
  {
    sign = "-";
    magnitude = (uint32_t)(-(micro_value + 1L)) + 1U;
  }
  else
  {
    magnitude = (uint32_t)micro_value;
  }

  return snprintf(buffer,
                  buffer_size,
                  "%s%lu.%06lu",
                  sign,
                  (unsigned long)(magnitude / MICRO_UNITS_PER_UNIT),
                  (unsigned long)(magnitude % MICRO_UNITS_PER_UNIT));
}

static void ProcessUsbCommands(void)
{
  uint8_t byte;

  while (CDC_ReadByte_FS(&byte) != 0U)
  {
    if (usb_escape_pending != 0U)
    {
      if (byte == (uint8_t)'1')
      {
        SetAppMode(APP_MODE_NORMAL_SENSE);
        usb_escape_pending = 0U;
      }
      else if (byte == (uint8_t)'2')
      {
        SetAppMode(APP_MODE_I2C_SNIFF);
        usb_escape_pending = 0U;
      }
      else if (byte == (uint8_t)'3')
      {
        SetAppMode(APP_MODE_UART_SNIFF);
        usb_escape_pending = 0U;
      }
      else if (byte == (uint8_t)'U')
      {
        RequestSystemBootloader();
        usb_escape_pending = 0U;
      }
      else if (byte == (uint8_t)'I')
      {
        i2c_sniff_local_ina_stimulus_pending = 1U;
        usb_escape_pending = 0U;
      }
      else if ((byte == 0x0DU) || (byte == 0x0AU))
      {
        ExitPassiveSniffing();
        usb_escape_pending = 0U;
      }
      else if (byte == (uint8_t)'H')
      {
        uart_display_mode = (uart_display_mode == UART_DISPLAY_ASCII) ? UART_DISPLAY_HEX : UART_DISPLAY_ASCII;
        uart_option_status_pending = (uart_display_mode == UART_DISPLAY_ASCII) ? UART_OPTION_STATUS_DISPLAY_ASCII : UART_OPTION_STATUS_DISPLAY_HEX;
        usb_escape_pending = 0U;
      }
      else if (byte == (uint8_t)'L')
      {
        uart_flush_mode = UART_FLUSH_LINE;
        uart_option_status_pending = UART_OPTION_STATUS_FLUSH_LINE;
        usb_escape_pending = 0U;
      }
      else if (byte == (uint8_t)'B')
      {
        uart_flush_mode = UART_FLUSH_TIMEOUT;
        uart_option_status_pending = UART_OPTION_STATUS_FLUSH_TIMEOUT;
        usb_escape_pending = 0U;
      }
      else if (byte == (uint8_t)'F')
      {
        uart_flush_mode = UART_FLUSH_FULL;
        uart_option_status_pending = UART_OPTION_STATUS_FLUSH_FULL;
        usb_escape_pending = 0U;
      }
      else
      {
        usb_escape_pending = (byte == 0x1BU) ? 1U : 0U;
      }
    }
    else if (byte == 0x1BU)
    {
      usb_escape_pending = 1U;
    }
  }
}

static void ProcessBootloaderEntry(void)
{
  if (bootloader_entry_pending == 0U)
  {
    return;
  }

  if (bootloader_entry_ack_sent == 0U)
  {
    if (CDC_TransmitReady_FS() != 0U)
    {
      int len = snprintf((char *)usb_tx_buffer,
                         sizeof(usb_tx_buffer),
                         "mode=bootloader_pending target=system_dfu\r\n");
      if (TrySendUsbText(len) != 0U)
      {
        bootloader_entry_ack_sent = 1U;
        bootloader_entry_ack_tick = HAL_GetTick();
      }
    }
    return;
  }

  if ((HAL_GetTick() - bootloader_entry_ack_tick) >= BOOTLOADER_ENTRY_DELAY_MS)
  {
    bootloader_entry_magic = BOOTLOADER_ENTRY_MAGIC;
    NVIC_SystemReset();
  }
}

static void ProcessUsbRxActivityIndicator(uint32_t now)
{
  if (usb_rx_activity_pending != 0U)
  {
    usb_rx_activity_pending = 0U;
    usb_rx_led_active = 1U;
    usb_rx_led_until_tick = now + USB_RX_LED_PULSE_MS;
    HAL_GPIO_WritePin(LED_YELLOW_GPIO_Port, LED_YELLOW_Pin, GPIO_PIN_SET);
  }

  if ((usb_rx_led_active != 0U) && ((int32_t)(now - usb_rx_led_until_tick) >= 0))
  {
    usb_rx_led_active = 0U;
    HAL_GPIO_WritePin(LED_YELLOW_GPIO_Port, LED_YELLOW_Pin, GPIO_PIN_RESET);
  }
}

static void ProcessUartOptionStatus(void)
{
  int len = 0;

  if ((uart_option_status_pending == UART_OPTION_STATUS_NONE) ||
      (CDC_TransmitReady_FS() == 0U))
  {
    return;
  }

  if (uart_option_status_pending == UART_OPTION_STATUS_DISPLAY_ASCII)
  {
    len = snprintf((char *)usb_tx_buffer,
                   sizeof(usb_tx_buffer),
                   "option=uart_display mode=ascii\r\n");
  }
  else if (uart_option_status_pending == UART_OPTION_STATUS_DISPLAY_HEX)
  {
    len = snprintf((char *)usb_tx_buffer,
                   sizeof(usb_tx_buffer),
                   "option=uart_display mode=hex\r\n");
  }
  else if (uart_option_status_pending == UART_OPTION_STATUS_FLUSH_LINE)
  {
    len = snprintf((char *)usb_tx_buffer,
                   sizeof(usb_tx_buffer),
                   "option=uart_flush mode=line\r\n");
  }
  else if (uart_option_status_pending == UART_OPTION_STATUS_FLUSH_TIMEOUT)
  {
    len = snprintf((char *)usb_tx_buffer,
                   sizeof(usb_tx_buffer),
                   "option=uart_flush mode=timeout\r\n");
  }
  else if (uart_option_status_pending == UART_OPTION_STATUS_FLUSH_FULL)
  {
    len = snprintf((char *)usb_tx_buffer,
                   sizeof(usb_tx_buffer),
                   "option=uart_flush mode=full\r\n");
  }

  if (TrySendUsbText(len) != 0U)
  {
    uart_option_status_pending = UART_OPTION_STATUS_NONE;
  }
}

static void ProcessUartSniffer(void)
{
  uint8_t byte = 0U;
  uint32_t drained = 0U;
  uint32_t now = HAL_GetTick();

  if (app_mode != APP_MODE_UART_SNIFF)
  {
    return;
  }

  while (drained < UART_SNIFF_RX_DRAIN_LIMIT)
  {
    if (HAL_UART_Receive(&huart2, &byte, 1U, 0U) != HAL_OK)
    {
      if (__HAL_UART_GET_FLAG(&huart2, UART_FLAG_ORE) != RESET)
      {
        __HAL_UART_CLEAR_OREFLAG(&huart2);
      }
      break;
    }

    if (UartSnifferBufferPush(byte) == 0U)
    {
      uart_sniff_rx_dropped++;
    }
    else
    {
      uart_sniff_last_rx_tick = now;
    }
    drained++;
  }

  while (UartSnifferBufferPop(&byte) != 0U)
  {
    UartSnifferPacketPush(byte);
  }

  if ((CDC_TransmitReady_FS() != 0U) && (UartSnifferPacketShouldFlush(now) != 0U))
  {
    (void)UartSnifferPacketFlush();
  }
}

static void ProcessI2cSniffer(void)
{
  if (app_mode != APP_MODE_I2C_SNIFF)
  {
    return;
  }

  I2cSniffFlushOutput();

  uint8_t overflow = 0U;
  __disable_irq();
  if (i2c_sniff_event_overflow != 0U)
  {
    overflow = 1U;
    i2c_sniff_event_overflow = 0U;
  }
  __enable_irq();

  if (overflow != 0U)
  {
    I2cSniffResetDecoderState();
    I2cSniffQueueDiagnostic("capture_overflow");
  }

  I2cSniffEvent event;
  for (uint32_t drained = 0U; drained < I2C_SNIFF_EVENT_DRAIN_LIMIT; drained++)
  {
    if (I2cSniffPopEvent(&event) == 0U)
    {
      break;
    }

    I2cSniffDecodeEvent(&event);
  }

  if (i2c_sniff_local_ina_stimulus_pending != 0U)
  {
    I2cSniffRunLocalInaStimulus();
  }

  uint32_t now = HAL_GetTick();
  I2cSniffCheckStaleTransaction(now);
  I2cSniffCheckBusLow(now);
  I2cSniffQueueSwappedPinsDiagnostic();
  I2cSniffFlushOutput();
}

static void SetAppMode(AppMode new_mode)
{
  AppMode previous_mode = app_mode;

  if ((previous_mode == APP_MODE_I2C_SNIFF) && (new_mode != APP_MODE_I2C_SNIFF))
  {
    ConfigureI2cSniffCapture(0U);
  }

  app_mode = new_mode;
  mode_transition_pending = 1U;

  if (new_mode == APP_MODE_NORMAL_SENSE)
  {
    csv_header_sent = 0U;
  }

  if (new_mode != APP_MODE_UART_SNIFF)
  {
    ResetUartSnifferState();
  }

  ResetI2cSnifferState();

  if (new_mode == APP_MODE_I2C_SNIFF)
  {
    ConfigureI2cSniffCapture(1U);
  }
}

static void ExitPassiveSniffing(void)
{
  if (app_mode == APP_MODE_UART_SNIFF)
  {
    SetAppMode(APP_MODE_UART_CONTROL);
  }
  else if (app_mode == APP_MODE_I2C_SNIFF)
  {
    SetAppMode(APP_MODE_I2C_CONTROL);
  }
}

static void RequestSystemBootloader(void)
{
  usb_rx_activity_pending = 0U;
  usb_rx_led_active = 0U;
  HAL_GPIO_WritePin(LED_YELLOW_GPIO_Port, LED_YELLOW_Pin, GPIO_PIN_RESET);
  bootloader_entry_pending = 1U;
  bootloader_entry_ack_sent = 0U;
  bootloader_entry_ack_tick = 0U;
  mode_transition_pending = 0U;
  uart_option_status_pending = UART_OPTION_STATUS_NONE;
  ResetUartSnifferState();
  ResetI2cSnifferState();
}

static void JumpToSystemBootloader(void)
{
  typedef void (*BootloaderEntryPoint)(void);

  const uint32_t bootloader_address = SYSTEM_BOOTLOADER_ADDRESS;
  const uint32_t bootloader_stack = *(__IO uint32_t *)bootloader_address;
  const uint32_t bootloader_reset = *(__IO uint32_t *)(bootloader_address + 4U);
  BootloaderEntryPoint bootloader_entry = (BootloaderEntryPoint)bootloader_reset;

  __disable_irq();

  SysTick->CTRL = 0U;
  SysTick->LOAD = 0U;
  SysTick->VAL = 0U;

  NVIC->ICER[0U] = 0xFFFFFFFFU;
  NVIC->ICPR[0U] = 0xFFFFFFFFU;

  __HAL_RCC_SYSCFG_CLK_ENABLE();
  __HAL_SYSCFG_REMAPMEMORY_SYSTEMFLASH();
  SCB->VTOR = bootloader_address;

  __set_CONTROL(0U);
  __set_MSP(bootloader_stack);
  __DSB();
  __ISB();

  __enable_irq();
  bootloader_entry();

  while (1)
  {
  }
}

static const char *AppModeName(AppMode mode)
{
  if (mode == APP_MODE_UART_SNIFF)
  {
    return "uart_sniff";
  }

  if (mode == APP_MODE_I2C_SNIFF)
  {
    return "i2c_sniff";
  }

  if (mode == APP_MODE_UART_CONTROL)
  {
    return "uart_control_placeholder";
  }

  if (mode == APP_MODE_I2C_CONTROL)
  {
    return "i2c_control_placeholder";
  }

  return "normal_sense";
}

static void ResetUartSnifferState(void)
{
  uart_sniff_rx_head = 0U;
  uart_sniff_rx_tail = 0U;
  uart_sniff_rx_dropped = 0U;
  uart_sniff_packet_len = 0U;
  uart_sniff_last_rx_tick = HAL_GetTick();
}

static uint8_t UartSnifferBufferPush(uint8_t byte)
{
  uint16_t next_head = (uint16_t)((uart_sniff_rx_head + 1U) % UART_SNIFF_RX_BUFFER_SIZE);

  if (next_head == uart_sniff_rx_tail)
  {
    return 0U;
  }

  uart_sniff_rx_buffer[uart_sniff_rx_head] = byte;
  uart_sniff_rx_head = next_head;
  return 1U;
}

static uint8_t UartSnifferBufferPop(uint8_t *byte)
{
  if (uart_sniff_rx_head == uart_sniff_rx_tail)
  {
    return 0U;
  }

  *byte = uart_sniff_rx_buffer[uart_sniff_rx_tail];
  uart_sniff_rx_tail = (uint16_t)((uart_sniff_rx_tail + 1U) % UART_SNIFF_RX_BUFFER_SIZE);
  return 1U;
}

static void UartSnifferPacketPush(uint8_t byte)
{
  if (uart_sniff_packet_len >= UART_SNIFF_PACKET_BUFFER_SIZE)
  {
    return;
  }

  uart_sniff_packet_buffer[uart_sniff_packet_len] = byte;
  uart_sniff_packet_len++;
}

static uint8_t UartSnifferPacketShouldFlush(uint32_t now)
{
  if (uart_sniff_packet_len == 0U)
  {
    return 0U;
  }

  if (uart_sniff_packet_len >= UART_SNIFF_PACKET_BUFFER_SIZE)
  {
    return 1U;
  }

  if (uart_flush_mode == UART_FLUSH_FULL)
  {
    return 0U;
  }

  if (uart_flush_mode == UART_FLUSH_LINE)
  {
    for (uint16_t i = 0U; i < uart_sniff_packet_len; i++)
    {
      if ((uart_sniff_packet_buffer[i] == (uint8_t)'\r') ||
          (uart_sniff_packet_buffer[i] == (uint8_t)'\n'))
      {
        return 1U;
      }
    }
    return 0U;
  }

  return ((now - uart_sniff_last_rx_tick) >= UART_SNIFF_BYTE_TIMEOUT_MS) ? 1U : 0U;
}

static uint8_t UartSnifferPacketFlush(void)
{
  int len = 0;
  uint16_t payload_len = uart_sniff_packet_len;

  if (uart_sniff_packet_len == 0U)
  {
    return 0U;
  }

  len = snprintf((char *)usb_tx_buffer,
                 sizeof(usb_tx_buffer),
                 "RX,");
  if (len <= 0)
  {
    return 0U;
  }

  if (uart_display_mode == UART_DISPLAY_ASCII)
  {
    while ((payload_len > 0U) &&
           ((uart_sniff_packet_buffer[payload_len - 1U] == (uint8_t)'\r') ||
            (uart_sniff_packet_buffer[payload_len - 1U] == (uint8_t)'\n')))
    {
      payload_len--;
    }

    uint16_t copy_len = payload_len;
    if (((uint32_t)copy_len + (uint32_t)len) > (sizeof(usb_tx_buffer) - 3U))
    {
      copy_len = (uint16_t)(sizeof(usb_tx_buffer) - (uint32_t)len - 3U);
    }

    for (uint16_t i = 0U; i < copy_len; i++)
    {
      usb_tx_buffer[len] = uart_sniff_packet_buffer[i];
      len++;
    }
  }
  else
  {
    for (uint16_t i = 0U; i < uart_sniff_packet_len; i++)
    {
      int written = snprintf((char *)&usb_tx_buffer[len],
                             sizeof(usb_tx_buffer) - (uint32_t)len,
                             "%s%02X",
                             (i == 0U) ? "" : " ",
                             (unsigned int)uart_sniff_packet_buffer[i]);
      if (written <= 0)
      {
        break;
      }

      len += written;
      if ((uint32_t)len >= (sizeof(usb_tx_buffer) - 3U))
      {
        break;
      }
    }
  }

  if ((uint32_t)len < (sizeof(usb_tx_buffer) - 2U))
  {
    usb_tx_buffer[len++] = '\r';
    usb_tx_buffer[len++] = '\n';
  }

  if (TrySendUsbText(len) != 0U)
  {
    uart_sniff_packet_len = 0U;
    return 1U;
  }

  return 0U;
}

static void ConfigureI2cSniffCapture(uint8_t enabled)
{
  const uint32_t pins = I2C2_EXT_SCL_Pin | I2C2_EXT_SDA_Pin;
  const uint32_t port_index = GPIO_GET_INDEX(I2C2_EXT_SCL_GPIO_Port);
  uint32_t position = 0U;

  HAL_NVIC_DisableIRQ(EXTI2_3_IRQn);
  HAL_NVIC_DisableIRQ(EXTI4_15_IRQn);
  __HAL_GPIO_EXTI_CLEAR_IT(I2C2_EXT_SCL_Pin);
  __HAL_GPIO_EXTI_CLEAR_IT(I2C2_EXT_SDA_Pin);
  HAL_NVIC_ClearPendingIRQ(EXTI2_3_IRQn);
  HAL_NVIC_ClearPendingIRQ(EXTI4_15_IRQn);

  i2c_sniff_capture_enabled = 0U;

  if (enabled != 0U)
  {
    __HAL_RCC_I2C2_CLK_DISABLE();
    ConfigureI2cSniffPinsHiZ();
  }

  while ((pins >> position) != 0U)
  {
    uint32_t line = pins & (1UL << position);
    if (line != 0U)
    {
      uint32_t temp = EXTI->EXTICR[position >> 2U];
      temp &= ~(0x0FUL << (8U * (position & 0x03U)));
      if (enabled != 0U)
      {
        temp |= (port_index << (8U * (position & 0x03U)));
      }
      EXTI->EXTICR[position >> 2U] = temp;

      EXTI->RTSR1 &= ~line;
      EXTI->FTSR1 &= ~line;
      EXTI->EMR1 &= ~line;
      EXTI->IMR1 &= ~line;

      if (enabled != 0U)
      {
        if (line == I2C2_EXT_SCL_Pin)
        {
          EXTI->RTSR1 |= line;
          EXTI->FTSR1 |= line;
        }
        else
        {
          EXTI->RTSR1 |= line;
          EXTI->FTSR1 |= line;
        }
        EXTI->IMR1 |= line;
      }
    }

    position++;
  }

  if (enabled == 0U)
  {
    __HAL_RCC_I2C2_CLK_DISABLE();
    ConfigureI2cSniffPinsHiZ();
    return;
  }

  ResetI2cSnifferState();
  i2c_sniff_isr_last_scl = (HAL_GPIO_ReadPin(I2C_SNIFF_SCL_GPIO_Port, I2C_SNIFF_SCL_Pin) == GPIO_PIN_SET) ? 1U : 0U;
  i2c_sniff_isr_last_sda = (HAL_GPIO_ReadPin(I2C_SNIFF_SDA_GPIO_Port, I2C_SNIFF_SDA_Pin) == GPIO_PIN_SET) ? 1U : 0U;
  i2c_sniff_capture_enabled = 1U;

  __HAL_GPIO_EXTI_CLEAR_IT(I2C2_EXT_SCL_Pin);
  __HAL_GPIO_EXTI_CLEAR_IT(I2C2_EXT_SDA_Pin);
  HAL_NVIC_ClearPendingIRQ(EXTI2_3_IRQn);
  HAL_NVIC_ClearPendingIRQ(EXTI4_15_IRQn);
  HAL_NVIC_SetPriority(EXTI2_3_IRQn, 1U, 0U);
  HAL_NVIC_SetPriority(EXTI4_15_IRQn, 1U, 0U);
  HAL_NVIC_EnableIRQ(EXTI2_3_IRQn);
  HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);
}

static void ConfigureI2cSniffPinsHiZ(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOB_CLK_ENABLE();

  GPIO_InitStruct.Pin = I2C2_EXT_SCL_Pin | I2C2_EXT_SDA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

static void I2cSniffCaptureBlockingFromStart(uint32_t start_idr)
{
  enum
  {
    CAPTURE_MAX_BYTES = 16,
    CAPTURE_LOOP_LIMIT = 400000
  };

  uint8_t bytes[CAPTURE_MAX_BYTES];
  uint8_t acks[CAPTURE_MAX_BYTES];
  uint8_t byte_count = 0U;
  uint8_t bit_count = 0U;
  uint8_t current_byte = 0U;
  uint8_t overflow = 0U;
  uint8_t complete = 0U;

  volatile uint32_t * const gpio_idr = &I2C_SNIFF_SCL_GPIO_Port->IDR;
  const uint32_t scl_pin = I2C_SNIFF_SCL_Pin;
  const uint32_t sda_pin = I2C_SNIFF_SDA_Pin;
  uint32_t idr = start_idr;
  uint8_t last_scl = ((idr & scl_pin) != 0U) ? 1U : 0U;
  uint8_t last_sda = ((idr & sda_pin) != 0U) ? 1U : 0U;
  uint8_t first_clock_seen = 0U;

  i2c_sniff_debug_start_count++;

  for (uint32_t loops = 0U; loops < CAPTURE_LOOP_LIMIT; loops++)
  {
    idr = *gpio_idr;
    uint8_t scl = ((idr & scl_pin) != 0U) ? 1U : 0U;
    uint8_t sda = ((idr & sda_pin) != 0U) ? 1U : 0U;

    if ((first_clock_seen == 0U) && (last_scl != 0U) && (scl != 0U) &&
        (last_sda == 0U) && (sda != 0U))
    {
      current_byte = 1U;
      bit_count = 1U;
      first_clock_seen = 1U;
    }

    if ((last_scl == 0U) && (scl != 0U))
    {
      first_clock_seen = 1U;
      i2c_sniff_debug_scl_rising_count++;
      if (bit_count < 8U)
      {
        current_byte = (uint8_t)((current_byte << 1) | (sda & 0x01U));
        bit_count++;
      }
      else
      {
        if (byte_count < CAPTURE_MAX_BYTES)
        {
          bytes[byte_count] = current_byte;
          acks[byte_count] = (sda == 0U) ? 1U : 0U;
          byte_count++;
        }
        else
        {
          overflow = 1U;
        }

        bit_count = 0U;
        current_byte = 0U;
        if (sda != 0U)
        {
          complete = 1U;
          break;
        }
      }
    }

    if ((last_sda == 0U) && (sda != 0U) && (scl != 0U) &&
        (byte_count > 0U) && (bit_count == 0U))
    {
      i2c_sniff_debug_stop_count++;
      complete = 1U;
      break;
    }

    last_scl = scl;
    last_sda = sda;
  }

  EXTI->RPR1 = I2C2_EXT_SCL_Pin | I2C2_EXT_SDA_Pin;
  EXTI->FPR1 = I2C2_EXT_SCL_Pin | I2C2_EXT_SDA_Pin;

  if (byte_count == 0U)
  {
    i2c_sniff_bit_count = bit_count;
    i2c_sniff_current_byte = current_byte;
    if (bit_count == 0U)
    {
      I2cSniffResetDecoderState();
      return;
    }
    if (complete != 0U)
    {
      I2cSniffQueueShortPacketDiagnostic();
    }
    else
    {
      I2cSniffQueueTimeoutDiagnostic();
    }
    I2cSniffResetDecoderState();
    return;
  }

  char line[I2C_SNIFF_OUTPUT_LINE_SIZE];
  int len = snprintf(line,
                     sizeof(line),
                     "[0x%02X%c%c",
                     (unsigned int)(bytes[0] >> 1),
                     ((bytes[0] & 0x01U) == 0U) ? 'W' : 'R',
                     (acks[0] != 0U) ? '+' : '-');

  for (uint8_t i = 1U; (i < byte_count) && (len > 0) && ((uint32_t)len < (sizeof(line) - 2U)); i++)
  {
    int written = snprintf(&line[len],
                           sizeof(line) - (uint32_t)len,
                           "0x%02X%c",
                           (unsigned int)bytes[i],
                           (acks[i] != 0U) ? '+' : '-');
    if (written <= 0)
    {
      break;
    }
    len += written;
  }

  if ((len > 0) && ((uint32_t)len < (sizeof(line) - 1U)))
  {
    line[len] = ']';
    len++;
    line[len] = '\0';
  }

  if (overflow != 0U)
  {
    I2cSniffQueueDiagnostic("capture_bytes");
  }
  (void)I2cSniffQueueLine(line);
  I2cSniffResetDecoderState();
}

static void I2cSniffCaptureEvent(I2cSniffEventType type, uint8_t scl, uint8_t sda)
{
  if (i2c_sniff_capture_enabled == 0U)
  {
    return;
  }

  uint16_t next_head = (uint16_t)((i2c_sniff_event_head + 1U) % I2C_SNIFF_EVENT_QUEUE_SIZE);
  if (next_head == i2c_sniff_event_tail)
  {
    i2c_sniff_event_overflow = 1U;
    i2c_sniff_debug_overflow_count++;
    return;
  }

  if (type == I2C_SNIFF_EVENT_SCL_RISING)
  {
    i2c_sniff_debug_scl_rising_count++;
  }
  else if (type == I2C_SNIFF_EVENT_START)
  {
    i2c_sniff_debug_start_count++;
  }
  else if (type == I2C_SNIFF_EVENT_STOP)
  {
    i2c_sniff_debug_stop_count++;
  }

  i2c_sniff_events[i2c_sniff_event_head].type = (uint8_t)type;
  i2c_sniff_events[i2c_sniff_event_head].scl = scl;
  i2c_sniff_events[i2c_sniff_event_head].sda = sda;
  i2c_sniff_events[i2c_sniff_event_head].timestamp_ms = HAL_GetTick();
  i2c_sniff_event_head = next_head;
}

static uint8_t I2cSniffPopEvent(I2cSniffEvent *event)
{
  if (i2c_sniff_event_head == i2c_sniff_event_tail)
  {
    return 0U;
  }

  event->type = i2c_sniff_events[i2c_sniff_event_tail].type;
  event->scl = i2c_sniff_events[i2c_sniff_event_tail].scl;
  event->sda = i2c_sniff_events[i2c_sniff_event_tail].sda;
  event->timestamp_ms = i2c_sniff_events[i2c_sniff_event_tail].timestamp_ms;
  i2c_sniff_event_tail = (uint16_t)((i2c_sniff_event_tail + 1U) % I2C_SNIFF_EVENT_QUEUE_SIZE);
  return 1U;
}

static void I2cSniffDecodeEvent(const I2cSniffEvent *event)
{
  i2c_sniff_last_event_tick = event->timestamp_ms;

  if (event->type == (uint8_t)I2C_SNIFF_EVENT_START)
  {
    I2cSniffHandleStart();
  }
  else if (event->type == (uint8_t)I2C_SNIFF_EVENT_STOP)
  {
    I2cSniffHandleStop();
  }
  else if (event->type == (uint8_t)I2C_SNIFF_EVENT_SCL_RISING)
  {
    I2cSniffHandleSclRising(event->sda);
  }
}

static void I2cSniffHandleStart(void)
{
  if ((i2c_sniff_packet_active != 0U) && (i2c_sniff_bit_count != 0U))
  {
    i2c_sniff_debug_ignored_start_count++;
    return;
  }

  if (I2cSniffAppendChar('[') == 0U)
  {
    return;
  }

  i2c_sniff_packet_active = 1U;
  i2c_sniff_expect_address = 1U;
  i2c_sniff_bit_count = 0U;
  i2c_sniff_current_byte = 0U;
  i2c_sniff_last_event_tick = HAL_GetTick();
}

static void I2cSniffHandleStop(void)
{
  if (i2c_sniff_packet_active == 0U)
  {
    return;
  }

  if (i2c_sniff_bit_count != 0U)
  {
    i2c_sniff_debug_ignored_stop_count++;
    return;
  }

  if (i2c_sniff_decoded_byte_count == 0U)
  {
    I2cSniffQueueShortPacketDiagnostic();
  }

  if (i2c_sniff_decoded_byte_count == 0U)
  {
    I2cSniffResetDecoderState();
    return;
  }

  if (I2cSniffAppendChar(']') != 0U)
  {
    I2cSniffQueueCurrentPacket();
  }

  I2cSniffResetDecoderState();
}

static void I2cSniffHandleSclRising(uint8_t sda)
{
  if (i2c_sniff_packet_active == 0U)
  {
    return;
  }

  if (i2c_sniff_bit_count < 8U)
  {
    i2c_sniff_current_byte = (uint8_t)((i2c_sniff_current_byte << 1) | (sda & 0x01U));
    i2c_sniff_bit_count++;
    return;
  }

  if (i2c_sniff_expect_address != 0U)
  {
    if (I2cSniffAppendFormattedAddress(i2c_sniff_current_byte) == 0U)
    {
      return;
    }
    i2c_sniff_expect_address = 0U;
    i2c_sniff_decoded_byte_count++;
  }
  else
  {
    if (I2cSniffAppendFormattedByte(i2c_sniff_current_byte) == 0U)
    {
      return;
    }
    i2c_sniff_decoded_byte_count++;
  }

  if (I2cSniffAppendChar((sda == 0U) ? '+' : '-') == 0U)
  {
    return;
  }

  i2c_sniff_bit_count = 0U;
  i2c_sniff_current_byte = 0U;
}

static void I2cSniffCheckStaleTransaction(uint32_t now)
{
  if ((i2c_sniff_packet_active == 0U) || (i2c_sniff_last_event_tick == 0U))
  {
    return;
  }

  if ((now - i2c_sniff_last_event_tick) >= I2C_SNIFF_STALE_TRANSACTION_TIMEOUT_MS)
  {
    I2cSniffQueueTimeoutDiagnostic();
    I2cSniffResetDecoderState();
  }
}

static void I2cSniffCheckBusLow(uint32_t now)
{
  uint8_t scl = (HAL_GPIO_ReadPin(I2C_SNIFF_SCL_GPIO_Port, I2C_SNIFF_SCL_Pin) == GPIO_PIN_SET) ? 1U : 0U;
  uint8_t sda = (HAL_GPIO_ReadPin(I2C_SNIFF_SDA_GPIO_Port, I2C_SNIFF_SDA_Pin) == GPIO_PIN_SET) ? 1U : 0U;

  if ((scl != 0U) && (sda != 0U))
  {
    i2c_sniff_bus_low_since_tick = 0U;
    i2c_sniff_bus_low_reported = 0U;
    return;
  }

  if (i2c_sniff_bus_low_since_tick == 0U)
  {
    i2c_sniff_bus_low_since_tick = now;
    return;
  }

  if ((i2c_sniff_bus_low_reported == 0U) &&
      ((now - i2c_sniff_bus_low_since_tick) >= I2C_SNIFF_BUS_LOW_TIMEOUT_MS))
  {
    I2cSniffQueueBusLowDiagnostic(scl, sda);
    i2c_sniff_bus_low_reported = 1U;
  }
}

static void I2cSniffRunLocalInaStimulus(void)
{
  uint8_t rx_byte = 0U;

  i2c_sniff_local_ina_stimulus_pending = 0U;

  (void)HAL_I2C_IsDeviceReady(&hi2c1,
                              (uint16_t)(INA236_I2C_ADDR_7BIT << 1),
                              1U,
                              INA236_I2C_TIMEOUT_MS);
  (void)HAL_I2C_Master_Receive(&hi2c1,
                               (uint16_t)(INA236_I2C_ADDR_7BIT << 1),
                               &rx_byte,
                               1U,
                               INA236_I2C_TIMEOUT_MS);
  (void)HAL_I2C_IsDeviceReady(&hi2c1,
                              (uint16_t)(INA236_I2C_ADDR_7BIT << 1),
                              1U,
                              INA236_I2C_TIMEOUT_MS);
}

static void I2cSniffResetDecoderState(void)
{
  i2c_sniff_packet_active = 0U;
  i2c_sniff_expect_address = 1U;
  i2c_sniff_bit_count = 0U;
  i2c_sniff_current_byte = 0U;
  i2c_sniff_decoded_byte_count = 0U;
  i2c_sniff_transaction_overflow_reported = 0U;
  i2c_sniff_last_event_tick = 0U;
  i2c_sniff_packet_len = 0U;
  i2c_sniff_packet_buffer[0] = '\0';
}

static uint8_t I2cSniffAppendChar(char value)
{
  if (i2c_sniff_packet_len >= (I2C_SNIFF_PACKET_BUFFER_SIZE - 1U))
  {
    if (i2c_sniff_transaction_overflow_reported == 0U)
    {
      I2cSniffQueueDiagnostic("transaction_overflow");
      i2c_sniff_transaction_overflow_reported = 1U;
    }
    I2cSniffResetDecoderState();
    return 0U;
  }

  i2c_sniff_packet_buffer[i2c_sniff_packet_len] = value;
  i2c_sniff_packet_len++;
  i2c_sniff_packet_buffer[i2c_sniff_packet_len] = '\0';
  return 1U;
}

static uint8_t I2cSniffAppendText(const char *text)
{
  while (*text != '\0')
  {
    if (I2cSniffAppendChar(*text) == 0U)
    {
      return 0U;
    }
    text++;
  }

  return 1U;
}

static uint8_t I2cSniffAppendFormattedByte(uint8_t value)
{
  char text[5];
  (void)snprintf(text, sizeof(text), "0x%02X", (unsigned int)value);
  return I2cSniffAppendText(text);
}

static uint8_t I2cSniffAppendFormattedAddress(uint8_t value)
{
  char text[7];
  (void)snprintf(text,
                 sizeof(text),
                 "0x%02X%c",
                 (unsigned int)(value >> 1),
                 ((value & 0x01U) == 0U) ? 'W' : 'R');
  return I2cSniffAppendText(text);
}

static uint8_t I2cSniffQueueLine(const char *line)
{
  if (i2c_sniff_output_count >= I2C_SNIFF_OUTPUT_QUEUE_DEPTH)
  {
    i2c_sniff_output_overflow_pending = 1U;
    return 0U;
  }

  (void)snprintf(i2c_sniff_output_queue[i2c_sniff_output_head],
                 I2C_SNIFF_OUTPUT_LINE_SIZE,
                 "%s\r\n",
                 line);
  i2c_sniff_output_head = (uint8_t)((i2c_sniff_output_head + 1U) % I2C_SNIFF_OUTPUT_QUEUE_DEPTH);
  i2c_sniff_output_count++;
  return 1U;
}

static void I2cSniffQueueCurrentPacket(void)
{
  if (i2c_sniff_packet_len == 0U)
  {
    return;
  }

  (void)I2cSniffQueueLine(i2c_sniff_packet_buffer);
}

static void I2cSniffQueueDiagnostic(const char *reason)
{
  char line[48];
  (void)snprintf(line, sizeof(line), "I2C,OVERFLOW,%s", reason);
  (void)I2cSniffQueueLine(line);
}

static void I2cSniffQueueShortPacketDiagnostic(void)
{
  char line[I2C_SNIFF_OUTPUT_LINE_SIZE];
  uint8_t scl = (HAL_GPIO_ReadPin(I2C_SNIFF_SCL_GPIO_Port, I2C_SNIFF_SCL_Pin) == GPIO_PIN_SET) ? 1U : 0U;
  uint8_t sda = (HAL_GPIO_ReadPin(I2C_SNIFF_SDA_GPIO_Port, I2C_SNIFF_SDA_Pin) == GPIO_PIN_SET) ? 1U : 0U;

  (void)snprintf(line,
                 sizeof(line),
                 "I2C,SHORT,bits=%u,cur=0x%02X,rise=%lu,fall=%lu,start=%lu,stop=%lu,ign_s=%lu,ign_p=%lu,ovf=%lu,scl=%u,sda=%u",
                 (unsigned int)i2c_sniff_bit_count,
                 (unsigned int)i2c_sniff_current_byte,
                 (unsigned long)i2c_sniff_debug_scl_rising_count,
                 (unsigned long)i2c_sniff_debug_scl_falling_count,
                 (unsigned long)i2c_sniff_debug_start_count,
                 (unsigned long)i2c_sniff_debug_stop_count,
                 (unsigned long)i2c_sniff_debug_ignored_start_count,
                 (unsigned long)i2c_sniff_debug_ignored_stop_count,
                 (unsigned long)i2c_sniff_debug_overflow_count,
                 (unsigned int)scl,
                 (unsigned int)sda);
  (void)I2cSniffQueueLine(line);
}

static void I2cSniffQueueTimeoutDiagnostic(void)
{
  char line[I2C_SNIFF_OUTPUT_LINE_SIZE];
  uint8_t scl = (HAL_GPIO_ReadPin(I2C_SNIFF_SCL_GPIO_Port, I2C_SNIFF_SCL_Pin) == GPIO_PIN_SET) ? 1U : 0U;
  uint8_t sda = (HAL_GPIO_ReadPin(I2C_SNIFF_SDA_GPIO_Port, I2C_SNIFF_SDA_Pin) == GPIO_PIN_SET) ? 1U : 0U;

  if (i2c_sniff_packet_len > 1U)
  {
    (void)snprintf(line,
                   sizeof(line),
                   "I2C,TIMEOUT,bits=%u,cur=0x%02X,rise=%lu,fall=%lu,start=%lu,stop=%lu,ign_s=%lu,ign_p=%lu,ovf=%lu,scl=%u,sda=%u",
                   (unsigned int)i2c_sniff_bit_count,
                   (unsigned int)i2c_sniff_current_byte,
                   (unsigned long)i2c_sniff_debug_scl_rising_count,
                   (unsigned long)i2c_sniff_debug_scl_falling_count,
                   (unsigned long)i2c_sniff_debug_start_count,
                   (unsigned long)i2c_sniff_debug_stop_count,
                   (unsigned long)i2c_sniff_debug_ignored_start_count,
                   (unsigned long)i2c_sniff_debug_ignored_stop_count,
                   (unsigned long)i2c_sniff_debug_overflow_count,
                   (unsigned int)scl,
                   (unsigned int)sda);
    (void)I2cSniffQueueLine(line);
    return;
  }

  (void)snprintf(line,
                 sizeof(line),
                 "I2C,TIMEOUT,bits=%u,cur=0x%02X,rise=%lu,fall=%lu,start=%lu,stop=%lu,ign_s=%lu,ign_p=%lu,ovf=%lu,scl=%u,sda=%u",
                 (unsigned int)i2c_sniff_bit_count,
                 (unsigned int)i2c_sniff_current_byte,
                 (unsigned long)i2c_sniff_debug_scl_rising_count,
                 (unsigned long)i2c_sniff_debug_scl_falling_count,
                 (unsigned long)i2c_sniff_debug_start_count,
                 (unsigned long)i2c_sniff_debug_stop_count,
                 (unsigned long)i2c_sniff_debug_ignored_start_count,
                 (unsigned long)i2c_sniff_debug_ignored_stop_count,
                 (unsigned long)i2c_sniff_debug_overflow_count,
                 (unsigned int)scl,
                 (unsigned int)sda);
  (void)I2cSniffQueueLine(line);
}

static void I2cSniffQueueBusLowDiagnostic(uint8_t scl, uint8_t sda)
{
  char line[48];
  (void)snprintf(line,
                 sizeof(line),
                 "I2C,BUS_LOW,scl=%u,sda=%u",
                 (unsigned int)scl,
                 (unsigned int)sda);
  (void)I2cSniffQueueLine(line);
}

static void I2cSniffQueueSwappedPinsDiagnostic(void)
{
  if (i2c_sniff_swapped_warning_reported != 0U)
  {
    return;
  }

  if ((i2c_sniff_debug_sda_edges_while_scl_low < I2C_SNIFF_SWAP_SDA_EDGE_THRESHOLD) ||
      (i2c_sniff_debug_scl_fall_while_sda_high < I2C_SNIFF_SWAP_SCL_FALL_THRESHOLD) ||
      (i2c_sniff_debug_start_count != 0U))
  {
    return;
  }

  char line[I2C_SNIFF_OUTPUT_LINE_SIZE];
  (void)snprintf(line,
                 sizeof(line),
                 "I2C,WIRING,SDA_SCL_SWAPPED?,sda_edges_while_scl_low=%lu,scl_fall_while_sda_high=%lu,start=%lu,stop=%lu",
                 (unsigned long)i2c_sniff_debug_sda_edges_while_scl_low,
                 (unsigned long)i2c_sniff_debug_scl_fall_while_sda_high,
                 (unsigned long)i2c_sniff_debug_start_count,
                 (unsigned long)i2c_sniff_debug_stop_count);
  (void)I2cSniffQueueLine(line);
  i2c_sniff_swapped_warning_reported = 1U;
}

static void I2cSniffFlushOutput(void)
{
  if (i2c_sniff_output_overflow_pending != 0U)
  {
    if (i2c_sniff_output_count < I2C_SNIFF_OUTPUT_QUEUE_DEPTH)
    {
      i2c_sniff_output_overflow_pending = 0U;
      I2cSniffQueueDiagnostic("output_queue");
    }
  }

  if ((i2c_sniff_output_count == 0U) || (CDC_TransmitReady_FS() == 0U))
  {
    return;
  }

  int len = snprintf((char *)usb_tx_buffer,
                     sizeof(usb_tx_buffer),
                     "%s",
                     i2c_sniff_output_queue[i2c_sniff_output_tail]);
  if (TrySendUsbText(len) != 0U)
  {
    i2c_sniff_output_tail = (uint8_t)((i2c_sniff_output_tail + 1U) % I2C_SNIFF_OUTPUT_QUEUE_DEPTH);
    i2c_sniff_output_count--;
  }
}

static void ResetI2cSnifferState(void)
{
  __disable_irq();
  i2c_sniff_event_head = 0U;
  i2c_sniff_event_tail = 0U;
  i2c_sniff_event_overflow = 0U;
  __enable_irq();

  I2cSniffResetDecoderState();
  i2c_sniff_bus_low_since_tick = 0U;
  i2c_sniff_bus_low_reported = 0U;
  i2c_sniff_output_head = 0U;
  i2c_sniff_output_tail = 0U;
  i2c_sniff_output_count = 0U;
  i2c_sniff_output_overflow_pending = 0U;
  i2c_sniff_debug_scl_rising_count = 0U;
  i2c_sniff_debug_scl_falling_count = 0U;
  i2c_sniff_debug_start_count = 0U;
  i2c_sniff_debug_stop_count = 0U;
  i2c_sniff_debug_ignored_start_count = 0U;
  i2c_sniff_debug_ignored_stop_count = 0U;
  i2c_sniff_debug_overflow_count = 0U;
  i2c_sniff_debug_sda_edges_while_scl_low = 0U;
  i2c_sniff_debug_scl_fall_while_sda_high = 0U;
  i2c_sniff_isr_packet_active = 0U;
  i2c_sniff_isr_scl_rises_in_packet = 0U;
  i2c_sniff_swapped_warning_reported = 0U;
}

static uint8_t TrySendUsbText(int len)
{
  if (len <= 0)
  {
    return 0U;
  }

  if ((uint32_t)len >= sizeof(usb_tx_buffer))
  {
    len = (int)sizeof(usb_tx_buffer) - 1;
  }

  return (CDC_Transmit_FS(usb_tx_buffer, (uint16_t)len) == USBD_OK) ? 1U : 0U;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1)
  {
    HAL_GPIO_TogglePin(LED_YELLOW_GPIO_Port, LED_YELLOW_Pin);
    HAL_GPIO_TogglePin(LED_RED_GPIO_Port, LED_RED_Pin);
    for (volatile uint32_t delay = 0U; delay < 4000000U; delay++)
    {
    }
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
