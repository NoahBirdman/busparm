/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
void App_OnUsbHostDataReceived(void);
void App_OnI2cSniffExti(uint32_t rising_mask, uint32_t falling_mask, uint32_t gpio_idr);
uint8_t App_OnI2cSniffSdaFallingFast(uint32_t gpio_idr);

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define I2C1_INA_SDA_Pin GPIO_PIN_9
#define I2C1_INA_SDA_GPIO_Port GPIOB
#define LEF_GREEN_Pin GPIO_PIN_4
#define LEF_GREEN_GPIO_Port GPIOA
#define LED_YELLOW_Pin GPIO_PIN_5
#define LED_YELLOW_GPIO_Port GPIOA
#define LED_RED_Pin GPIO_PIN_6
#define LED_RED_GPIO_Port GPIOA
#define I2C2_EXT_SCL_Pin GPIO_PIN_3
#define I2C2_EXT_SCL_GPIO_Port GPIOB
#define I2C2_EXT_SDA_Pin GPIO_PIN_4
#define I2C2_EXT_SDA_GPIO_Port GPIOB
#define INA_ALERT_Pin GPIO_PIN_7
#define INA_ALERT_GPIO_Port GPIOB
#define I2C1_INA_SCL_Pin GPIO_PIN_8
#define I2C1_INA_SCL_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
