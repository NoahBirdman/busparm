Implement one ticket only.
Do not implement future-ticket features.
Do not refactor unrelated systems.
Do not introduce new architecture unless required.
Avoid unnecessary dependencies.
Use strict TypeScript.
Run build/tests when possible.
Report files changed, commands run, build results, and manual verification steps.

Build rule for this project:
- Never run `cmake` or `ninja` directly; those commands are known to hang in this environment.
- Always use `pwsh -NoProfile -File tools/build_debug.ps1` as the build entrypoint.
- Use `tools/build_debug.ps1 -ManualCompileLink` when the CMake/Ninja wrapper path is expected to hang.
- The build helper always stops stale `cmake`/`ninja`/compiler build processes before starting.

Flashing rule for this project:
- Use the existing USB bootloader/DFU flash flow, not ST-LINK/SWD, when programming firmware.
- Preferred helper: `tools/flash_debug_via_runtime_dfu.ps1`.
- The runtime DFU helper sends `ESC U` over the DUT USB CDC port to enter the STM32 system USB DFU bootloader, then flashes `build/Debug/thesensor_v2.elf` with STM32CubeProgrammer using `port=usb1`.
- Use ST-LINK/STLINK-V3 only for bridge/AUX test stimulus or explicitly requested debug work, not as the normal firmware flashing path.
