Here’s a clean MVP document draft.

# USB Current/Voltage Sensor MVP

## 1. Overview

This project is a USB current/voltage sensing and serial sniffing tool based on the **STM32G0B1KET6**. The device continuously monitors bus voltage and current using an **INA236BIDDFR** over I2C and streams measurements to a host computer over USB as a virtual COM port.

The STM32G0B1 includes USB full-speed support and multiple serial peripherals, while the INA236 is a 16-bit I2C/SMBus current, voltage, and power monitor designed to measure voltage across an external sense resistor and report current, bus voltage, and power. ([datasheets.com][1])

## 2. MVP Goals

The MVP shall provide:

1. Continuous USB streaming of measured bus voltage and current.
2. USB CDC/VCP command-controlled operating modes.
3. I2C transaction sniffing mode.
4. UART RX/TX sniffing mode.
5. Escape sequence to exit passive sniffing and enter active master/control mode.
6. Minimal serial command interface for future VIM-like controls.

## 3. Hardware Summary

### MCU

**STM32G0B1KET6**

Primary responsibilities:

* Poll INA236 over I2C.
* Stream data over USB CDC virtual COM port.
* Select normal sensing, UART sniffing, or I2C sniffing from USB CDC/VCP commands.
* Sniff I2C or UART traffic while in the selected passive sniffing mode.
* Optionally drive I2C/UART lines after exiting sniff mode.

### Sensor

**INA236BIDDFR**

Primary responsibilities:

* Measure shunt voltage across external sense resistor.
* Report bus voltage.
* Report current and/or raw values used by MCU to calculate current.
* Communicate with MCU over I2C.

## 4. Operating Modes

### 4.1 Normal Sense Mode

**Condition:** `ESC 1` received over USB CDC/VCP

In normal sense mode, the MCU continuously polls the INA236 and streams measurements over USB CDC.

Expected output:

```text
timestamp_ms,bus_voltage_v,current_a,power_w
```

MVP output may be CSV or newline-delimited text.

### 4.2 Serial Sniffer Mode

**Condition:** `ESC 2` or `ESC 3` received over USB CDC/VCP

When a sniff mode is selected, the MCU stops normal sensing behavior and enters passive sniffing mode for the selected interface.

#### I2C Sniffer

**Condition:** `ESC 2` received over USB CDC/VCP

The device passively monitors I2C traffic and streams observed transactions over USB.

Example output:

```text
I2C,START,ADDR=0x40,W,DATA=0x01 0x02,STOP
```

#### UART Sniffer

**Condition:** `ESC 3` received over USB CDC/VCP

The device passively monitors UART traffic on RX/TX pins and streams observed bytes over USB.

Example output:

```text
UART,RX,0x48
UART,TX,0x4F
```

## 5. Escape / Control Behavior

Mode selection uses literal USB CDC/VCP byte sequences:

```text
ESC 1     Enter normal sense mode
ESC 2     Enter I2C sniff mode
ESC 3     Enter UART sniff mode
```

`ESC` is byte `0x1B`; `1`, `2`, and `3` are ASCII bytes. No Enter is required for mode selection.

While in sniffer mode, sending:

```text
ESC + ENTER
```

shall exit passive sniffing mode.

After this sequence, the MCU may begin actively driving a supported interface:

* I2C master mode.
* UART transmit/control mode.

MVP requirement: detect the escape sequence reliably and transition to control mode without requiring a reset.

## 6. Future Minimal UI

The serial UI will use VIM-like controls.

Planned commands:

```text
ESC 1     Enter normal sense mode
ESC 2     Enter I2C sniff mode
ESC 3     Enter UART sniff mode
ESC ?     Show help
ESC R     Set measured series resistance
ESC ENTER Exit sniffing mode / enter control mode
```

Potential future commands:

```text
ESC S     Show current settings
ESC C     Calibrate zero offset
ESC M     Show current operating mode
ESC Q     Return to normal streaming mode
```

## 7. MVP Functional Requirements

| ID      | Requirement                                                                                                                   |
| ------- | ----------------------------------------------------------------------------------------------------------------------------- |
| MVP-001 | Firmware shall enumerate as a USB CDC virtual COM port.                                                                       |
| MVP-002 | Firmware shall poll INA236 over I2C in normal sense mode.                                                                     |
| MVP-003 | Firmware shall stream voltage/current data over USB.                                                                          |
| MVP-004 | `ESC 1` over USB CDC/VCP shall select normal sense mode.                                                                      |
| MVP-005 | `ESC 2` and `ESC 3` over USB CDC/VCP shall select I2C and UART sniffer modes, respectively.                                  |
| MVP-006 | Firmware shall not depend on a hardware range/mode selector for MVP behavior while that pin-map decision is deferred.   |
| MVP-007 | In sniffer mode, firmware shall report supported I2C and/or UART observations without requiring a hardware selector. |
| MVP-008 | Firmware shall detect `ESC + ENTER` over USB CDC.                                                                             |
| MVP-009 | Firmware shall exit passive sniffing after the escape sequence.                                                               |
| MVP-010 | Firmware shall support setting the series resistance value through a command path, even if the MVP implementation is minimal. |

## 8. Non-Goals for MVP

The MVP does not need to include:

* Full graphical UI.
* Persistent configuration storage.
* Complex command shell.
* Automatic baud-rate detection.
* Full I2C protocol decoding beyond basic transaction capture.
* Production calibration workflow.
* Multi-board synchronization.
* High-throughput binary logging format.

## 9. Open Questions

1. What sample rate is required for voltage/current streaming?
2. What INA236 averaging/conversion settings should be used?
3. What shunt resistor values are supported?
4. What UART baud rates must be supported?
5. Does I2C sniffing need passive electrical isolation/buffering?
6. Should ESC + ENTER mean literal byte sequence `0x1B 0x0D`, `0x1B 0x0A`, or either CR/LF?
7. Should settings survive reset?
8. Should USB output be human-readable CSV or binary framed packets?
9. Should a later hardware revision add a dedicated pin for mode selection in addition to VCP commands?

## 10. MVP Success Criteria

The MVP is complete when:

* The board enumerates as a USB virtual COM port.
* In normal mode, voltage and current stream continuously.
* VCP commands reliably select sense, UART sniff, and I2C sniff modes.
* Sniffing behavior does not require a hardware selector pin.
* USB output clearly identifies the active mode.
* `ESC + ENTER` exits sniffing mode.
* A basic help command exists or is stubbed for the future UI.

[1]: https://www.datasheets.com/stmicroelectronics/stm32g0b1ket6?utm_source=chatgpt.com "STM32G0B1KET6 Datasheet | Microcontrollers (MCU) | STMicroelectronics"
