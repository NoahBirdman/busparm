# TheSensor Known Issues and Follow-ups

## T0005

- ST-LINK/SWD under-reset connect, mass erase, flash/verify, and reset/run were validated with STM32CubeProgrammer.
- Hot-plug attach to the already-running target was not validated. `STM32_Programmer_CLI -c port=SWD mode=HOTPLUG -score` reported `Unable to get core ID` / `No STM32 target found` after reset/run, while under-reset reconnect and halt still worked.
- Use `mode=UR reset=HWrst` for the known-good programming/debug connection path until a later ticket intentionally investigates hot-plug behavior.

## T0006

- The former hardware selector GPIO assignments on debug-adjacent pins have been removed from the active CubeMX pinout and generated firmware for now.
- Hardware selector validation needs a later pin-map decision before those inputs are reintroduced.
- During T0006 recovery, SWD connected only at the lowest CubeProgrammer frequency (`freq=140`, reported as `50 KHz`). Higher frequencies such as `1000`, `4000`, and `8000` reported `Unable to get core ID`.
- At `50 KHz`, mass erase can report `Mass erase successfully achieved`, but ELF programming can still fail after a long delay with `failed to download Sector[0]`. Option bytes showed RDP level 0 and no write protection. Verify NRST wiring, SWD signal integrity, probe cabling, and target power before treating this as a firmware issue.

## T0008

- The generated software mapping for INA I2C is internally consistent: `PB8 = I2C1_SCL` / `I2C1_INA_SCL` and `PB9 = I2C1_SDA` / `I2C1_INA_SDA`.
- Physical schematic/board wiring still needs manual verification against that mapping.
- The T0008 firmware uses the observed INA236 7-bit I2C address `0x48`.
- T0008 reports raw register `0x00` only. Voltage/current/power scaling and calibration remain future-ticket work.

## T0014

- `cmake --preset Debug` completed successfully during the T0014 pass, but `cmake --build --preset Debug` still timed out after 20 seconds with no stdout/stderr in this Codex shell environment.
- Direct generated compilation of `Core/Src/main.c` and direct generated linking of `build/Debug/thesensor_v2.elf` succeeded, so the current source and link set are buildable despite the preset-build wrapper hang.
- The current Debug ELF flashed, verified, reset, ran, and re-enumerated USB CDC on `COM24`.
- USB CDC verified normal CSV output, VCP mode switching, ordinary text resilience, and ESC+Enter control-placeholder exits from UART and I2C sniff modes.
- External UART stimulus into `PA3` was not connected during T0014, so `UART,RX,0xNN` output still needs a hardware stimulus check.
- External I2C traffic on `PB3/PB4` was not connected during T0014, so `I2C,ACTIVITY,...` output still needs a hardware stimulus check.
- The T0013 I2C sniffer reports aggregate sampled activity only. Full address/data/ACK decode remains outside the current MVP implementation.

## T0015

- The automated harness records the known `cmake --build --preset Debug` 20 second timeout as a failed build step while still continuing to flash an existing ELF when present.
- `Get-CimInstance` COM-port discovery is access-denied in this Codex shell environment.
- The harness falls back to `[System.IO.Ports.SerialPort]::GetPortNames()`, but if multiple COM ports are visible it requires explicit `-Port COMx` instead of guessing.
- T0015 VCP capture was verified with explicit `-Port COM24`.

## T0016

- The automated sensing stage depends on a valid USB CDC/VCP port. Use explicit `-Port COMx` when automatic discovery is ambiguous.
- The T0016 sensing parser validates current strict CSV output only. Tabular output belongs to a later ticket.

## T0017

- The automated UART stage was verified with `COM23` wired to STM32 `PA3`.
- Until UART autobaud is implemented, run the UART stimulus at the current firmware rate: `115200 8N1`.
- `detected_uart_baud` is intentionally `null` in T0017 reports.

## T0017A/T0017B

- The earlier tight-burst failure for `55 48 69` was fixed for short bursts by buffering UART RX before USB CDC formatting.
- T0017B changed UART sniff output to `RX,<payload>` with no leading `UART` prefix, and every packet ends with CRLF for terminal readability.
- `ESC H` toggles ASCII and uppercase ASCII-hex display.
- `ESC L`, `ESC B`, and `ESC F` select line-ending, byte-timeout, and buffer-full flush behavior.
- Each display/flush option change prints an `option=... mode=...` acknowledgement line.
- Verified reports:
  - `build/hardware-verification/t0017b-option-ascii-timeout.json`
  - `build/hardware-verification/t0017b-option-hex-timeout.json`
  - `build/hardware-verification/t0017b-option-line.json`
  - `build/hardware-verification/t0017b-option-full.json`
- Remaining risk: the sniffer is still polling-based and is not proven lossless for sustained high-throughput UART streams.

## T0018

- The automated I2C stage supports observe-only capture and optional `-I2cStimulusCommand`.
- `build/hardware-verification/t0018-i2c-observe-only.json` verified the harness path with `COM24`; build/flash/VCP passed and `i2c_sniff` entered mode.
- The observe-only run recorded `stimulus_status=skipped`, `activity_line_count=0`, and a clear failure because no external I2C activity was connected or observed.
- No local ST-LINK bridge/I2C command-line utility was found in the installed STM32Cube bundles during T0018.
- Positive I2C activity verification still requires an external I2C traffic source wired to `PB3/PB4` with common ground and suitable pull-ups, or a user-provided stimulus command.

## T0027

- I2C sniff mode now uses EXTI-backed capture on `PB3/PB4` and emits decoded Bus Pirate-style transaction lines instead of aggregate `I2C,ACTIVITY,...` output.
- The automated I2C harness parser now expects decoded packet lines and records `decoded_packet_count`, `observed_packets`, `overflow_count`, and `observed_overflows`.
- DMA/timer capture remains a follow-up optimization; the implemented path is interrupt-assisted, with overflow diagnostics and main-loop decoding.
- Positive packet-decode verification still requires an external I2C traffic source wired to `PB3/PB4` with common ground and suitable pull-ups.

## T0026

- The USB bootloader VS Code flash task is configured but not hardware-validated in this Codex shell pass.
- STM32CubeProgrammer 2.22.0 was found at `C:\Users\noah.bergman\AppData\Local\stm32cube\bundles\programmer\2.22.0+st.1\bin\STM32_Programmer_CLI.exe`.
- `STM32_Programmer_CLI -l usb` completed and reported `No STM32 device in DFU mode connected`, so USB bootloader flashing still needs a board placed in STM32 system bootloader/DFU mode.
- The task uses `port=usb1` and the existing Debug ELF. If multiple DFU devices are connected, or if this board enumerates with a different USB index/serial selection, update the task with the discovered `-l usb` details.
