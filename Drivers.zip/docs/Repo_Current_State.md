# TheSensor Current Repository State

Baseline recorded for ticket `T0002` on 2026-05-17. Updated for tickets `T0003`, `T0004`, `T0005`, `T0007`, `T0008`, `T0009`, `T0010`, `T0011`, `T0012`, and `T0013` on 2026-05-18. Updated for `T0014`, `T0015`, `T0016`, `T0017`, `T0017A`, and `T0017B` on 2026-05-19.

This document describes the verified repository, toolchain, and build state only. MVP firmware behavior described in the design and ticket backlog remains planned work unless explicitly listed here as verified.

## Repository Layout

The repository contains a CubeMX-generated STM32/CMake firmware project for `thesensor_v2`.

Current top-level firmware/build inputs:

- `Core/` - CubeMX application and startup-support source tree.
- `Drivers/` - STM32 HAL/CMSIS driver tree.
- `Middlewares/` - STM32 USB device middleware.
- `USB_Device/` - CubeMX USB device application and target support.
- `cmake/` - generated STM32 CMake support, including `cmake/gcc-arm-none-eabi.cmake`.
- `CMakeLists.txt` - root CMake project for target `thesensor_v2`.
- `CMakePresets.json` - defines `Debug` and `Release` configure/build presets.
- `thesensor_v2.ioc` - CubeMX project file.
- `.vscode/` - contains C/C++ IntelliSense settings, CMake/STM32 workspace settings, extension recommendations, Debug preset build tasks, ST-LINK flash/debug tasks, and USB bootloader flash tasks.
- `tools/` - host-side project automation scripts, including the T0015 hardware verification harness.
- `tickets/` - standalone future-ticket handoff files for debug-tool v2 work.

Current docs observed before this ticket:

- `docs/AGENTS.md`
- `docs/Codex_Ticket_Handoff_Template.md`
- `docs/Design_Update_Companion.md`
- `docs/Known_Issues_And_Followups.md`
- `docs/MVP_Technical_Design.md`
- `docs/Prompt_Contex_Pack.md`
- `docs/Repo_Current_State.md`
- `docs/T0001.md`
- `docs/Tickets.md`

## Toolchain Baseline

The following tools were available on the workstation during T0002 verification:

| Tool | Verified version / state |
| --- | --- |
| Visual Studio Code | `1.120.0` from `C:\Users\noah.bergman\AppData\Local\Programs\Microsoft VS Code\Code.exe` |
| STM32 VS Code extension pack | `stmicroelectronics.stm32-vscode-extension@3.9.0` installed |
| CMake Tools extension | `ms-vscode.cmake-tools@1.23.52` installed |
| CMake | `4.3.1` |
| Ninja | `1.13.2` |
| GNU Tools for STM32 GCC | `arm-none-eabi-gcc.exe (GNU Tools for STM32 14.3.rel1.20251027-0700) 14.3.1 20250623` |
| GNU Tools for STM32 GDB | `GNU gdb (GNU Tools for STM32 14.3.rel1.20251027-0700) 15.2.90.20241229-git` |
| STM32CubeProgrammer | `2.22.0` |

Notes:

- `docs/T0001.md` records the baseline tool installation/availability ticket. It does not include exact tool versions, so the versions above were verified during this T0002 baseline pass.
- The VS Code executable reports version `1.120.0`. Running the VS Code CLI also emitted Crashpad/log permission messages in this environment, but the extension list was still printed.

## CMake Build Baseline

The `Debug` preset is configured by `CMakePresets.json`:

- Generator: `Ninja`
- Binary directory: `build/Debug`
- Toolchain file: `cmake/gcc-arm-none-eabi.cmake`
- Build type: `Debug`

The following commands were verified successfully during T0002:

```powershell
cmake --preset Debug
cmake --build --preset Debug
```

Build output linked `thesensor_v2.elf` successfully and reported:

```text
RAM:    8760 B / 144 KB  (5.94%)
FLASH: 27096 B / 512 KB  (5.17%)
```

Primary generated build artifacts:

- `build/Debug/thesensor_v2.elf` - Debug ELF firmware image.
- `build/Debug/thesensor_v2.map` - linker map file.
- `build/Debug/compile_commands.json` - compile database.
- `build/Debug/build.ninja` - generated Ninja build file.

Observed `build/Debug/thesensor_v2.elf` after verification:

- Size: `1185208` bytes.
- Last updated: 2026-05-17 23:01 local time.

## VS Code Workspace Baseline

The T0003 workspace configuration keeps the existing STM32/CMake project structure and uses the existing `Debug` preset from `CMakePresets.json`.

Current `.vscode` files:

- `.vscode/c_cpp_properties.json` points IntelliSense at `build/Debug/compile_commands.json`.
- `.vscode/extensions.json` recommends:
  - `ms-vscode.cmake-tools`
  - `stmicroelectronics.stm32-vscode-extension`
- `.vscode/launch.json` adds `STM32: Debug TheSensor (ST-LINK)` using the STM32Cube ST-LINK GDB Server debug type `stlinkgdbtarget`.
- `.vscode/settings.json` configures CMake Tools to:
  - use `cube-cmake`
  - use CMake presets
  - select `Debug` for configure and build
  - prefer the Ninja generator
  - keep the STM32 clangd/query-driver settings already present
- `.vscode/tasks.json` adds:
  - `CMake: configure Debug preset` resolving CMake from PATH, `cube-cmake`, or the STM32Cube bundled `cmake.exe`, then running `--preset Debug`
  - `CMake: build Debug preset` resolving CMake the same way, then running `--build --preset Debug`
  - `STM32: flash Debug ELF (ST-LINK)` resolving STM32CubeProgrammer from PATH or known install locations, then using SWD under reset
  - `STM32: list USB bootloader devices` using STM32CubeProgrammer `-l usb`
  - `STM32: flash Debug ELF (USB bootloader)` using STM32CubeProgrammer `port=usb1` to program and verify `build/Debug/thesensor_v2.elf`, then `-g 0x08000000` to start the app
  - `STM32: build, enter runtime DFU, flash Debug ELF (USB)` using the app CDC `ESC U` command when DFU is not already visible

The T0004 ST-LINK debug launch configuration:

- Runs the existing `CMake: build Debug preset` task before launch.
- Loads and uses symbols from `build/Debug/thesensor_v2.elf`.
- Targets `STM32G0B1KET6` / `Cortex-M0+` over SWD.
- Uses ST-LINK connect-under-reset behavior and sets a temporary run-to-`main` entry breakpoint for a first smoke debug session.

## Verified Current Behavior

Verified in T0002:

- The CubeMX-generated STM32/CMake project is present.
- The toolchain commands required by T0001 are available.
- `cmake --preset Debug` succeeds.
- `cmake --build --preset Debug` succeeds.
- The Debug build produces `build/Debug/thesensor_v2.elf`.

Verified/configured in T0003:

- VS Code recommends the STM32 VS Code extension and CMake Tools extension.
- VS Code workspace settings select the existing `Debug` CMake preset.
- A default VS Code build task runs the existing Debug configure/build flow.
- Terminal configure/build commands still succeed.

Configured in T0004:

- VS Code shows `STM32: Debug TheSensor (ST-LINK)` in Run and Debug.
- Starting the debug configuration runs the Debug preset build task before the ST-LINK session.
- The launch path points at `build/Debug/thesensor_v2.elf`.
- The launch path is configured to connect over ST-LINK/SWD and halt at or near `main()`.

Configured in T0026:

- VS Code includes `STM32: list USB bootloader devices` for STM32CubeProgrammer DFU discovery.
- VS Code includes `STM32: flash Debug ELF (USB bootloader)`.
- The USB bootloader flash task runs the Debug build task first, runs DFU discovery, then invokes STM32CubeProgrammer with `port=usb1`, `-w build/Debug/thesensor_v2.elf`, `-v`, and `-g 0x08000000`.
- VS Code includes `STM32: build, enter runtime DFU, flash Debug ELF (USB)`, which runs `tools/flash_debug_via_runtime_dfu.ps1` after the Debug build task.
- The runtime DFU helper uses an already-visible DFU device when available, otherwise scans serial ports for TheSensor USB CDC output, sends `ESC U`, waits for DFU enumeration, and flashes the Debug ELF over `port=usb1`.
- The USB bootloader tasks resolve `STM32_Programmer_CLI` from PATH when available, then fall back to known STM32CubeProgrammer install locations including the local STM32Cube bundle path.
- The existing ST-LINK debug and flash tasks remain present.

Verified in T0005:

- `STM32_Programmer_CLI -l stlink` detects one `STLINK-V3PWR` probe.
- Detected ST-LINK serial: `0032001E3432511933363736`.
- Detected ST-LINK firmware: `V4J6B2P6`.
- `STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst` connects to the target.
- Target voltage during verification was `3.24V` to `3.25V`.
- Detected device ID: `0x467`.
- Detected revision ID: `Rev Z`.
- Detected device name: `STM32G0B0xx/B1xx/C1xx`.
- Detected NVM size: `512 KBytes`.
- Detected CPU: `Cortex-M0+`.
- `cmake --build --preset Debug` succeeded before flashing.
- `STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -e all` mass erased successfully.
- `STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -w build/Debug/thesensor_v2.elf -v` programmed and verified the existing Debug ELF successfully.
- The programmed ELF was reported at flash address `0x08000000` with programmed payload size `26.46 KB`.
- `STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -rst -run` reset the target and reported `Core run`.
- Under-reset halt/status check with `-halt -score` succeeded and reported `Core is halted`.

Current GPIO status:

- The former hardware selector input assignments have been removed from the active CubeMX pinout and generated firmware for now.
- `INA_ALERT` remains on `PB7`.
- Normal USB CDC output is the sensing CSV/error stream; hardware selector state is not reported.

Implemented in T0008 and syntax-checked in T0008:

- `Core/Src/main.c` performs a once-per-second raw INA236 register read over `hi2c1`, the configured INA I2C peripheral.
- The INA236 read uses 7-bit I2C address `0x48`, register `0x00`, and a 25 ms HAL timeout so a missing or unresponsive sensor reports an error without hanging the main loop forever.
- USB CDC status output now appends either a raw register value:

```text
INA236_I2C=ok addr=0x48 reg=0x00 raw=0xNNNN
```

- Or a visible failure report:

```text
INA236_I2C=err addr=0x48 reg=0x00 hal=<status> i2c_error=0xNNNNNNNN
```

- The generated INA I2C software mapping is internally consistent across `thesensor_v2.ioc`, `Core/Inc/main.h`, and `Core/Src/stm32g0xx_hal_msp.c`:
  - `PB8 = I2C1_SCL`, label `I2C1_INA_SCL`.
  - `PB9 = I2C1_SDA`, label `I2C1_INA_SDA`.
- No `.ioc` label correction was made because the generated software mapping is not reversed. Physical schematic/board wiring still needs the T0008 manual check.

Implemented in T0009 and hardware-verified in T0009:

- `Core/Src/main.c` now emits a normal-mode CSV header and measurement stream over USB CDC:

```text
timestamp_ms,bus_voltage_v,current_a,power_w
```

- With INA236 reads succeeding, rows use decimal fixed-point values:

```text
<timestamp_ms>,<bus_voltage_v>,<current_a>,<power_w>
```

- On INA236 read failure, firmware emits a visible `INA236_CSV_ERR` line with the failed register, HAL status, and I2C error code, then continues running.
- T0009 uses conservative scaling assumptions until hardware values are confirmed:
  - INA236 7-bit address `0x48`.
  - Bus voltage register `0x02`, `1.6 mV/LSB`.
  - Shunt voltage register `0x01`, `2.5 uV/LSB`.
  - Default shunt value `10 mOhm`.
  - Power computed from scaled bus voltage and current.
- The generated direct compile command for `Core/Src/main.c` completed successfully.
- The generated direct link command for `thesensor_v2.elf` completed successfully and reported:

```text
RAM:    9376 B / 144 KB  (6.36%)
FLASH: 46480 B / 512 KB  (8.87%)
```

- `cmake --build --preset Debug` and direct `ninja -C build/Debug` did not exit within a 20 second wrapper in this Codex shell environment. Direct Ninja metadata commands, the generated compile command, and the generated link command all succeeded, so the observed failure is isolated to the STM32-bundled Ninja build execution loop in this environment rather than the T0009 C source.
- `STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -w build/Debug/thesensor_v2.elf -v` flashed and verified the T0009 ELF successfully at SWD `8000 KHz`.
- `STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -rst -run` reset and ran the target successfully.
- USB CDC output was observed on `COM24`. The T0009 header and measurement rows were captured:

```text
timestamp_ms,bus_voltage_v,current_a,power_w
39000,0.000000,0.000250,0.000000
57000,0.000000,0.000500,0.000000
```

Implemented in T0010 and hardware-verified in T0010:

- `USB_Device/App/usbd_cdc_if.c` now queues received USB CDC bytes in a small non-blocking FIFO for polling from the main loop.
- `Core/Src/main.c` parses literal `ESC` byte `0x1B` followed by ASCII `1`, `2`, or `3`:
  - `ESC 1` selects normal sense mode.
  - `ESC 2` selects I2C sniff mode.
  - `ESC 3` selects UART sniff mode.
- Normal sense mode preserves the T0009 CSV stream.
- UART and I2C sniff modes emit periodic status text only; actual byte/event capture remains future-ticket work.
- Direct compilation of changed files `Core/Src/main.c` and `USB_Device/App/usbd_cdc_if.c` completed successfully.
- The generated direct link command for `thesensor_v2.elf` completed successfully and reported:

```text
RAM:    9504 B / 144 KB  (6.45%)
FLASH: 47292 B / 512 KB  (9.02%)
```

- `cmake --build --preset Debug` still did not exit within a 20 second wrapper in this Codex shell environment, consistent with the T0009 Ninja execution-loop issue.
- `STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -w build/Debug/thesensor_v2.elf -v` flashed and verified the T0010 ELF successfully at SWD `8000 KHz`.
- `STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -rst -run` reset and ran the target successfully.
- USB CDC output was observed on `COM24`. The T0010 mode command sequence was captured:

```text
mode=uart_sniff
status_ms=41000 mode=uart_sniff waiting_for_uart_sniffer_ticket
mode=i2c_sniff
status_ms=44000 mode=i2c_sniff waiting_for_i2c_sniffer_ticket
mode=normal_sense
timestamp_ms,bus_voltage_v,current_a,power_w
49000,0.000000,-0.002000,0.000000
```

Implemented in T0011 and preserved in T0012:

- `Core/Src/main.c` preserves passive sniff escape handling and now uses `ESC 1`, `ESC 2`, and `ESC 3` for normal sense, I2C sniff, and UART sniff modes.
- `Core/Src/main.c` now detects literal `ESC` byte `0x1B` followed by CR `0x0D` or LF `0x0A`.
- `ESC` followed by CR or LF only exits passive sniffing when the active mode is `uart_sniff` or `i2c_sniff`.
- Exiting passive sniffing enters a placeholder control mode and emits a clear mode transition:

```text
mode=uart_control_placeholder
mode=i2c_control_placeholder
```

- Control-placeholder modes emit periodic status text only; active UART/I2C master behavior remains future-ticket work:

```text
status_ms=<ms> mode=uart_control_placeholder passive_sniffing_exited
status_ms=<ms> mode=i2c_control_placeholder passive_sniffing_exited
```

- Ordinary USB CDC input that is not part of an `ESC` command is ignored by the MVP parser.
- Normal sense mode still emits the T0009 CSV header and measurement/error rows.

Implemented in T0012 and build-verified in T0012:

- `Core/Src/main.c` now polls USART2 RX without blocking while the active mode is `uart_sniff`.
- Observed USART2 RX bytes are emitted over USB CDC as one text line per byte:

```text
UART,RX,0xNN
```

- The UART sniffer path uses the existing generated USART2 configuration:
  - `PA3 = USART2_RX`.
  - `PA2 = USART2_TX`.
  - `115200 8N1`.
  - No hardware flow control.
- UART RX polling is inactive outside `uart_sniff` mode, preserving normal-mode CSV output, I2C sniff placeholder output, and T0011 ESC+Enter control-placeholder behavior.

Implemented in T0013, then finalized in T0027:

- `Core/Src/main.c` now reconfigures the external I2C2 SCL/SDA pins into EXTI interrupt inputs while the active mode is `i2c_sniff`.
- The external I2C sniff path uses the existing generated I2C2 pin mapping:
  - `PB3 = I2C2_SCL`, label `I2C2_EXT_SCL`.
  - `PB4 = I2C2_SDA`, label `I2C2_EXT_SDA`.
- EXTI handlers enqueue compact SCL/SDA edge samples, and the main loop decodes complete I2C transactions.
- Decoded transactions are emitted over USB CDC using Bus Pirate-style packet characters:

```text
[0x46W+0x00+0x12-]
[0x46W+0x00[0x46R+0x34+0x00+]
```

- `[` indicates START or repeated START, `]` indicates STOP, `+` indicates ACK, `-` indicates NACK, `0xXXW` / `0xXXR` indicate 7-bit address plus direction, and `0xXX` indicates data.
- I2C sniff mode is quiet while idle. Capture or output overflow is reported as `I2C,OVERFLOW,<reason>`.
- The EXTI capture path is inactive outside `i2c_sniff` mode, preserving normal-mode CSV output, UART sniff output, and T0011 ESC+Enter control-placeholder behavior.

Verified in T0014:

- `cmake --preset Debug` completed successfully and generated build files in `build/Debug`.
- `cmake --build --preset Debug` was run with a 20 second wrapper and timed out with no stdout/stderr, consistent with the known CMake/Ninja execution-loop issue in this shell environment.
- The generated direct compile command for `Core/Src/main.c` completed successfully.
- The generated direct link command for `thesensor_v2.elf` completed successfully and reported:

```text
RAM:    9528 B / 144 KB  (6.46%)
FLASH: 48896 B / 512 KB  (9.33%)
```

- `STM32_Programmer_CLI -l stlink` detected one `STLINK-V3PWR` probe.
- Detected ST-LINK serial: `0032001E3432511933363736`.
- Detected ST-LINK firmware: `V4J6B2P6`.
- `STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -w build/Debug/thesensor_v2.elf -v` flashed and verified the current Debug ELF successfully.
- Target voltage during T0014 flash/run was `3.31V`.
- The programmed ELF was reported at flash address `0x08000000` with programmed payload size `47.75 KB`.
- `STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -rst -run` reset the target and reported `Core run`.
- USB CDC re-enumerated as `COM24` after reset/run.
- USB CDC output on `COM24` verified normal CSV output:

```text
timestamp_ms,bus_voltage_v,current_a,power_w
16000,0.000000,0.000250,0.000000
```

- USB CDC mode/control command capture verified:

```text
mode=uart_sniff
status_ms=20000 mode=uart_sniff waiting_for_uart_sniffer_ticket
mode=uart_control_placeholder
status_ms=22000 mode=uart_control_placeholder passive_sniffing_exited
status_ms=23000 mode=uart_control_placeholder passive_sniffing_exited
mode=i2c_sniff
status_ms=25000 mode=i2c_sniff waiting_for_i2c_sniffer_ticket
mode=i2c_control_placeholder
status_ms=26000 mode=i2c_control_placeholder passive_sniffing_exited
```

- Explicit-byte mode command capture verified return to normal CSV from control/sniff paths:

```text
mode=normal_sense
timestamp_ms,bus_voltage_v,current_a,power_w
44000,0.000000,0.000000,0.000000
mode=uart_sniff
status_ms=45000 mode=uart_sniff waiting_for_uart_sniffer_ticket
mode=normal_sense
timestamp_ms,bus_voltage_v,current_a,power_w
47000,0.000000,0.000000,0.000000
```

- Ordinary USB CDC text input while in a control-placeholder mode did not crash or reset the firmware; periodic status output continued.

Not performed in T0014:

- External UART stimulus into `PA3` was not connected, so `UART,RX,0xNN` runtime output was not observed.
- External I2C traffic on `PB3/PB4` was not connected, so runtime I2C packet output was not observed.
- Measurement accuracy was not compared against a meter or known bench load.

Implemented and verified in T0015:

- Added `tools/run_hardware_verification.ps1`, a Windows PowerShell hardware verification harness.
- The harness supports options for build preset, ELF path, STM32CubeProgrammer CLI path, VCP/COM port, report path, and bounded timeouts.
- The harness writes a JSON report and terminal summary with independent step results for:
  - CMake configure.
  - CMake build.
  - STM32CubeProgrammer CLI discovery.
  - ELF existence.
  - Flash/verify.
  - Reset/run.
  - VCP discovery.
  - VCP capture.
- `pwsh -NoProfile -File tools/run_hardware_verification.ps1 --help` exited successfully.
- A T0015 smoke run wrote `build/hardware-verification/t0015-smoke.json`; configure passed, CMake build timed out after 20 seconds, programmer discovery passed, ELF check passed, flash/verify passed, reset/run passed, and VCP discovery failed because no COM port was provided and CIM discovery was blocked.
- A second smoke run with fallback discovery saw multiple COM ports and did not rely on an ambiguous automatic selection.
- Running with explicit `-Port COM24` wrote `build/hardware-verification/t0015-com24.json`; configure passed, CMake build timed out after 20 seconds, programmer discovery passed, ELF check passed, flash/verify passed, reset/run passed, VCP discovery was skipped by override, and VCP capture passed.
- The explicit COM24 capture included normal CSV output:

```text
timestamp_ms,bus_voltage_v,current_a,power_w
4000,0.000000,0.000000,0.000000
5000,0.000000,-0.000250,0.000000
```

Implemented and verified in T0016:

- Extended `tools/run_hardware_verification.ps1` with a selectable sensing stage.
- Added harness options:
  - `-Stages`, default `base,sensing`.
  - `-SensingTimeoutSec`, default `8`.
- The sensing stage opens the USB CDC/VCP port, sends literal `ESC 1`, captures output, and records a `sensing_normal` step in the JSON report.
- The `sensing_normal` parser detects:
  - `mode=normal_sense` if emitted.
  - CSV header `timestamp_ms,bus_voltage_v,current_a,power_w`.
  - Measurement rows.
  - `INA236_CSV_ERR` lines.
- INA236 error output is treated as visible sensing-path output instead of an automatic harness failure when paired with the CSV header.
- `pwsh -NoProfile -File tools/run_hardware_verification.ps1 --help` exited successfully after adding sensing options.
- Running with explicit `-Port COM24` wrote `build/hardware-verification/t0016-sensing.json`; `sensing_normal` passed with `mode_detected=true`, `csv_header_detected=true`, `measurement_row_count=4`, and `ina236_error_count=0`.
- Running with intentionally invalid `-Port COM99` wrote `build/hardware-verification/t0016-wrong-port.json`; VCP capture and sensing steps failed cleanly with missing-COM-port messages.

Implemented in T0017 and partially hardware-verified in T0017:

- Extended `tools/run_hardware_verification.ps1` with a selectable UART stage.
- Added harness options:
  - `-UartPort`.
  - `-UartBaud`, default `115200`.
  - `-UartPatternHex`, default `55 48 69`.
  - `-UartTimeoutSec`, default `8`.
- The UART stage opens the USB CDC/VCP port, sends literal `ESC 3`, writes the configured pattern to the UART stimulus port, captures USB CDC output, and records a `uart_sniff` step in the JSON report.
- The T0017 parser detected `UART,RX,0xNN` lines and checked whether expected stimulus bytes appeared in order. T0017B updated the parser to check the selected payload display directly.
- The report records `stimulus_port`, `stimulus_baud`, `stimulus_hex`, `display_mode`, `flush_mode`, `expected_payload`, `observed_payload_excerpt`, `expected_pattern_matched`, and placeholder `detected_uart_baud=null`.
- The harness supports `-UartInterByteDelayMs`, default `0`, to test tight host bursts by default.
- `pwsh -NoProfile -File tools/run_hardware_verification.ps1 --help` exited successfully after adding UART options.
- Running without `-UartPort` wrote `build/hardware-verification/t0017-uart-skipped.json`; `uart_sniff` was marked skipped with wiring instructions.
- Running with intentionally invalid `-UartPort COM99` wrote `build/hardware-verification/t0017-uart-bad-port.json`; base flash/VCP steps reported independently and `uart_sniff` failed clearly because the stimulus COM port could not be opened.
- A live UART stimulus source on `COM23` wired to `PA3` verified `UART,RX,0xNN` output.
- With the no-idle UART sniff firmware, `build/hardware-verification/uart-com23-three-byte-delayed.json` captured:

```text
mode=uart_sniff
UART,RX,0x55
UART,RX,0x48
UART,RX,0x69
```

- A tight host burst of `55 48 69` originally captured only `0x55` and `0x48`; T0017A added UART receive and packet buffering, and T0017B verified the same tight burst with no inter-byte delay.
- UART sniff mode no longer emits periodic idle `waiting_for_uart_sniffer_ticket` messages.
- T0017B changed UART sniff payload output to `RX,<payload>\r\n` with no leading `UART` prefix. The `RX,` prefix is kept so later TX capture can use a distinct `TX,` prefix. `ESC H` toggles ASCII-hex output, `ESC L` selects line-ending flush, `ESC B` selects byte-timeout flush, and `ESC F` selects buffer-full flush. Each option change prints an `option=... mode=...` acknowledgement line.
- T0017B verification reports:
  - `build/hardware-verification/t0017b-option-ascii-timeout.json`: default ASCII timeout passed and observed `option=uart_flush mode=timeout` plus `RX,UHi\r\n`.
  - `build/hardware-verification/t0017b-option-hex-timeout.json`: hex timeout passed and observed `option=uart_display mode=hex`, `option=uart_flush mode=timeout`, and `RX,55 48 69\r\n`.
  - `build/hardware-verification/t0017b-option-line.json`: line-ending flush passed with `option=uart_flush mode=line` and `RX,Hi\r\n`.
  - `build/hardware-verification/t0017b-option-full.json`: buffer-full flush passed with `option=uart_flush mode=full` and a 96-byte ASCII `A` packet in one `RX,` line.

Implemented in T0018 and observe-only verified in T0018:

- Extended `tools/run_hardware_verification.ps1` with a selectable I2C stage.
- Added harness options:
  - `-I2cTimeoutSec`, default `8`.
  - `-I2cStimulusCommand`, optional host command run after entering I2C sniff mode.
  - `-I2cStimulusTimeoutSec`, default `10`.
- The I2C stage opens the USB CDC/VCP port, sends literal `ESC 2`, optionally runs the configured stimulus command, captures USB CDC output, and records an `i2c_sniff` step in the JSON report.
- The `i2c_sniff` parser detects decoded Bus Pirate-style packet lines and `I2C,OVERFLOW,<reason>` diagnostics.
- The report records `observe_only`, `stimulus_status`, `decoded_packet_count`, `observed_packets`, `overflow_count`, `observed_overflows`, and placeholder `detected_i2c_speed_hz=null`.
- `pwsh -NoProfile -File tools/run_hardware_verification.ps1 -Help` exited successfully after adding I2C options.
- Running observe-only with explicit `-Port COM24` wrote `build/hardware-verification/t0018-i2c-observe-only.json`; configure/build/flash/reset/VCP passed, `i2c_sniff` entered mode, stimulus generation was marked skipped, and the I2C stage failed clearly because no external I2C activity was observed.
- No local ST-LINK bridge/I2C command-line utility was found in the installed STM32Cube bundles during T0018. Positive activity verification still requires an external I2C traffic source on `PB3/PB4` or a user-provided `-I2cStimulusCommand`.

Observed during T0005 but not validated:

- `STM32_Programmer_CLI -c port=SWD mode=HOTPLUG -score` after reset/run failed to attach to the running target and reported `Unable to get core ID` / `No STM32 target found`.
- The validated workflow uses SWD under reset, not hot-plug attach.

Not verified or not implemented as of T0027:

- INA236 CSV measurement accuracy against a meter or expected bench setup.
- Hardware selector GPIO behavior.
- Lossless sustained high-speed I2C capture beyond the current EXTI-backed decoder.
- Lossless sustained high-throughput UART capture. T0017A/T0017B verified short buffered bursts and one full packet, not unlimited capture.
- Positive I2C decoded packet output with external I2C stimulus after the T0027 firmware change.
- VS Code debug launch workflow on physical hardware.
- Automatic VCP discovery in this shell when multiple COM ports are present and CIM access is denied. Use explicit `-Port COMx`.
- USB bootloader flashing on physical hardware. During T0026, STM32CubeProgrammer 2.22.0 was found locally and `STM32_Programmer_CLI -l usb` ran successfully, but no STM32 DFU-mode device was connected.

## Known Documentation Gaps

The ticket handoff references the following docs that were missing or mismatched before T0002:

- `AGENTS.md` was referenced at the repository root, but the repo currently has `docs/AGENTS.md`.
- `docs/Full_Design_Document.md` was referenced, but no file with that path was present.
- `docs/Manual_Verification_Guide.md` was referenced, but it did not exist before this ticket.
- `docs/Repo_Current_State.md` existed but was empty before this ticket.

Other factual notes:

- The current local Git branch during T0002/T0003/T0004 verification was `restarting`, tracking `origin/restarting`. The ticket text names branches `ticket/t0002-repo-state-verification-docs`, `ticket/t0003-vscode-cmake-workspace`, and `ticket/t0004-vscode-stlink-debug`, but those branches were not present locally.
