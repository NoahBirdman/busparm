# TheSensor Manual Verification Guide

Baseline guide created for ticket `T0002` on 2026-05-17. Updated for tickets `T0003`, `T0004`, `T0005`, `T0007`, `T0008`, `T0009`, `T0010`, `T0011`, `T0012`, and `T0013` on 2026-05-18. Updated for `T0014`, `T0015`, `T0016`, and `T0017` on 2026-05-19.

This guide covers repeatable workstation/toolchain checks, Debug build checks, the first VS Code ST-LINK debug launch path, the STM32CubeProgrammer ST-LINK flash/reset workflow, the STM32 USB bootloader flash workflow, the T0007 USB CDC GPIO status smoke check, the T0008 INA236 raw register read check, the T0009 INA236 CSV measurement stream check, the T0010 VCP operating-mode check, the T0011 ESC+Enter passive-sniff escape check, the T0012 minimal UART sniffer check, the T0013 minimal I2C activity check, the T0014 MVP integration checklist, the T0015 automated hardware verification harness, the T0016 automated sensing check, and the T0017/T0017A/T0017B automated UART checks for the current CubeMX-generated STM32/CMake project.

## Baseline Toolchain Check

Run these commands from the repository root:

```powershell
& "$env:LOCALAPPDATA\Programs\Microsoft VS Code\bin\code.cmd" --version
& "$env:LOCALAPPDATA\Programs\Microsoft VS Code\bin\code.cmd" --list-extensions --show-versions
cmake --version
ninja --version
arm-none-eabi-gcc --version
arm-none-eabi-gdb --version
STM32_Programmer_CLI --version
```

Expected baseline:

- VS Code reports `1.120.0`.
- The extension list includes `stmicroelectronics.stm32-vscode-extension@3.9.0`.
- The extension list includes `ms-vscode.cmake-tools@1.23.52`.
- CMake reports `4.3.1`.
- Ninja reports `1.13.2`.
- `arm-none-eabi-gcc` reports GNU Tools for STM32 `14.3.1`.
- `arm-none-eabi-gdb` reports GNU Tools for STM32 GDB `15.2.90.20241229-git`.
- STM32CubeProgrammer reports `2.22.0`.

Note: in this environment, the VS Code CLI may emit Crashpad/log permission messages while still printing the requested version or extension list.

## Configure the Debug Preset

Run from the repository root:

```powershell
cmake --preset Debug
```

Expected result:

- CMake completes configure and generate without errors.
- Output includes `Build files have been written to: .../build/Debug`.
- Output includes `Build type: Debug`.

The `Debug` preset uses:

- Ninja generator.
- `build/Debug` as the binary directory.
- `cmake/gcc-arm-none-eabi.cmake` as the toolchain file.

## VS Code Workspace Check

Open the repository root in VS Code:

```powershell
& "$env:LOCALAPPDATA\Programs\Microsoft VS Code\bin\code.cmd" .
```

Expected result:

- VS Code opens the repository folder.
- Extension recommendations are present or already satisfied for:
  - CMake Tools
  - STM32CubeIDE for Visual Studio Code
- CMake Tools sees the existing CMake presets.
- The selected configure preset is `Debug`.
- The selected build preset is `Debug`.

To configure from VS Code:

- Open the Command Palette.
- Run `CMake: Configure`.
- Confirm the Debug preset configure completes and writes build files to `build/Debug`.

To build from VS Code:

- Run `Terminal: Run Build Task`.
- Select `CMake: build Debug preset` if prompted.
- Confirm the task runs the Debug configure/build flow and leaves `build/Debug/thesensor_v2.elf` present.

The Run and Debug view should include `STM32: Debug TheSensor (ST-LINK)`. That launch configuration runs `CMake: build Debug preset` before starting the debugger and points the ST-LINK session at `build/Debug/thesensor_v2.elf`.

The Terminal task list should also include:

- `STM32: flash Debug ELF (ST-LINK)`.
- `STM32: list USB bootloader devices`.
- `STM32: flash Debug ELF (USB bootloader)`.
- `STM32: build, enter runtime DFU, flash Debug ELF (USB)`.

The USB bootloader flash task runs the Debug build task first, lists DFU-mode USB bootloader devices, and then invokes STM32CubeProgrammer with `port=usb1` to program and verify `build/Debug/thesensor_v2.elf` before starting the application at `0x08000000`.

The runtime DFU flash task runs the Debug build task first, then runs `tools/flash_debug_via_runtime_dfu.ps1`. That helper uses an already-visible DFU device when present, or finds the running TheSensor USB CDC port, sends literal `ESC U`, waits for STM32 USB DFU enumeration, and flashes the Debug ELF over `port=usb1`.

## VS Code ST-LINK Debug Smoke Check

Required hardware:

- ST-LINK probe connected to the workstation.
- Target board powered.
- SWDIO, SWCLK, GND, and target reference voltage connected between ST-LINK and the target.
- NRST connected if the hardware/debug header supports reset; the launch configuration uses connect-under-reset behavior for a first smoke session.

Open the repository root in VS Code, then:

- Open Run and Debug.
- Select `STM32: Debug TheSensor (ST-LINK)`.
- Start debugging.
- Confirm the pre-launch task runs `CMake: build Debug preset`.
- Confirm the ST-LINK session loads `build/Debug/thesensor_v2.elf`.
- Confirm the debugger halts at `main()` or at the first user breakpoint near startup.
- Stop the debug session cleanly.

Expected outcome:

- The Debug preset build completes successfully.
- The ST-LINK GDB server connects to the target over SWD.
- The firmware image is loaded for the debug session.
- The active debug session stops at or near `main()`.

Common failure modes:

- If no ST-LINK is connected, VS Code/ST-LINK GDB server reports that no ST-LINK probe or debug server device is available.
- If the target is not powered or target voltage is missing, the ST-LINK path may report target voltage, connection, or device-detection failure.
- If SWDIO/SWCLK/GND are miswired, the session may start the GDB server but fail to identify or halt the STM32 target.
- If `build/Debug/thesensor_v2.elf` is missing, rerun `cmake --build --preset Debug` or launch again and confirm the pre-launch task succeeds.

## STM32CubeProgrammer ST-LINK Flash Check

This workflow was validated for T0005 on 2026-05-18 using:

- ST-LINK probe: `STLINK-V3PWR`
- ST-LINK serial: `0032001E3432511933363736`
- ST-LINK firmware: `V4J6B2P6`
- Target voltage observed during commands: `3.24V` to `3.25V`
- Target detected as: `STM32G0B0xx/B1xx/C1xx`
- Device ID: `0x467`
- Revision ID: `Rev Z`
- NVM size: `512 KBytes`
- Device CPU: `Cortex-M0+`
- Connection mode used: SWD under reset with hardware reset

Build the existing Debug ELF before programming:

```powershell
cmake --build --preset Debug
```

Expected result:

- The command succeeds.
- `build/Debug/thesensor_v2.elf` exists.

List connected ST-LINK probes:

```powershell
STM32_Programmer_CLI -l stlink
```

Expected result:

- Output lists at least one ST-LINK probe.
- T0005 observed `STLINK-V3PWR` with serial `0032001E3432511933363736`.

Connect to the target over SWD:

```powershell
STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst
```

Expected result:

- Output reports target voltage near the board supply voltage.
- Output reports `Connect mode: Under Reset`.
- Output reports `Device name : STM32G0B0xx/B1xx/C1xx`.
- Output reports `Device CPU  : Cortex-M0+`.

Erase internal flash:

```powershell
STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -e all
```

Expected result:

- Output reports `Mass erase successfully achieved`.

Program and verify the existing Debug ELF:

```powershell
STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -w build/Debug/thesensor_v2.elf -v
```

Expected result:

- Output opens and parses `thesensor_v2.elf`.
- Output reports `Address       : 0x08000000`.
- Output reports `File download complete`.
- Output reports `Download verified successfully`.

Reset and run the target:

```powershell
STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -rst -run
```

Expected result:

- Output reports `MCU Reset`.
- Output reports `Software reset is performed`.
- Output reports `Core run`.

Optional under-reset halt check:

```powershell
STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -halt -score
```

Expected result:

- Output reconnects under reset.
- Output reports `Core halted` and `Core is halted`.

Observed T0005 note:

- After reset/run, `STM32_Programmer_CLI -c port=SWD mode=HOTPLUG -score` did not attach to the running target and reported `Unable to get core ID` / `No STM32 target found`.
- Under-reset reconnect, halt, and subsequent reset/run succeeded.
- Treat hot-plug attach as not validated; use under-reset mode for this board until a later ticket intentionally investigates hot-plug debug behavior.

## STM32CubeProgrammer USB Bootloader Flash Check

This workflow uses the STM32 system USB bootloader/DFU interface instead of ST-LINK/SWD. It was added in T0026 as a VS Code task path and requires the board to be placed in bootloader mode before flashing.

Required hardware/setup:

- USB data connection from the board to the workstation.
- Board placed into STM32 USB bootloader mode using the board's BOOT0/boot-mode control, then reset or power-cycled.
- STM32CubeProgrammer CLI available on PATH or installed in a known STM32Cube bundle path.

From VS Code:

- Open `Terminal: Run Task`.
- If the application is currently running and USB CDC is visible, run `STM32: build, enter runtime DFU, flash Debug ELF (USB)`.
- Confirm the task sends `ESC U`, reports a DFU device, programs `build/Debug/thesensor_v2.elf`, verifies the download, and starts the application at `0x08000000`.
- Run `STM32: list USB bootloader devices`.
- Confirm STM32CubeProgrammer lists a DFU interface instead of `No STM32 device in DFU mode connected`.
- Run `STM32: flash Debug ELF (USB bootloader)`.
- Confirm the task builds Debug first, lists USB bootloader devices, programs `build/Debug/thesensor_v2.elf`, verifies the download, and starts the application at `0x08000000`.

Equivalent command-line diagnostics:

```powershell
STM32_Programmer_CLI -l usb
STM32_Programmer_CLI -c port=usb1 -w build/Debug/thesensor_v2.elf -v -g 0x08000000
```

Equivalent runtime-entry helper:

```powershell
tools/flash_debug_via_runtime_dfu.ps1
```

Expected result:

- `-l usb` reports a connected STM32 DFU interface.
- The flash command opens and parses `thesensor_v2.elf`.
- Output reports the application flash address, normally `0x08000000`.
- Output reports `File download complete` or equivalent programming success.
- Output reports `Download verified successfully` or equivalent verification success.

Return to application mode:

- Restore the board's normal boot-mode setting so it boots from user flash.
- Reset or power-cycle the board.
- Confirm the application starts and the USB CDC/VCP port enumerates normally.

Common failure modes:

- `No STM32 device in DFU mode connected`: the board is not in system bootloader mode, the USB data cable is not connected, the wrong USB connector is used, or the host driver did not enumerate the DFU device.
- Flash command fails to connect on `port=usb1`: run `STM32_Programmer_CLI -l usb` and adjust the USB port or serial-number selection if multiple DFU devices are present.
- USB CDC port remains visible instead of a DFU device: the application is still running; re-enter bootloader mode and reset or power-cycle.
- Board returns to the bootloader after flashing: restore the normal boot-mode setting before reset or power-cycle.
- Application does not enumerate after flashing: confirm normal boot mode, reset/power-cycle, then fall back to the validated ST-LINK under-reset flash path to verify the firmware image and board state.

## Build the Debug Preset

Run from the repository root:

```powershell
cmake --build --preset Debug
```

Expected result:

- Ninja compiles the STM32 sources and links `thesensor_v2.elf`.
- The command exits successfully.
- Link output reports memory usage. The T0002 baseline observed:

```text
RAM:    8760 B / 144 KB  (5.94%)
FLASH: 27096 B / 512 KB  (5.17%)
```

## USB CDC GPIO Status Check

This T0007-era check is retained for historical context. The former hardware selector inputs are not assigned in the active pinout for now; only currently assigned GPIOs such as `INA_ALERT` should be validated here.

Required hardware:

- Target board running the T0007 firmware.
- USB data connection from the board USB CDC port to the host.
- A serial terminal on the host.

Open the USB CDC virtual COM port in a serial terminal. The firmware does not require a specific baud rate for USB CDC, but `115200 8N1` is a safe terminal setting.

Expected output depends on the firmware ticket being verified. Current normal firmware emits the sensing CSV/error stream rather than a selector-input heartbeat line.

Expected behavior:

- `INA_ALERT` reports the raw `PB7` input level as `0` for reset/low and `1` for set/high.

Manual GPIO observations:

- Record the idle `INA_ALERT` value.

## INA236 Raw I2C Register Check

This T0008 check validates the generated INA236 I2C pin mapping and the minimal raw register read. Build and flash the Debug ELF first using the sections above.

Generated software mapping to verify against the schematic or board wiring:

- `PB8 = I2C1_SCL`, label `I2C1_INA_SCL`.
- `PB9 = I2C1_SDA`, label `I2C1_INA_SDA`.
- The firmware uses `hi2c1` for the INA236 read.
- The firmware currently probes INA236 7-bit address `0x48`.
- The firmware reads raw register `0x00` and does not calculate voltage, current, or power in T0008.

Manual wiring inspection:

- Inspect the schematic or board wiring and confirm INA236 SCL is connected to STM32 `PB8`.
- Inspect the schematic or board wiring and confirm INA236 SDA is connected to STM32 `PB9`.
- Confirm the INA236 address strap matches 7-bit address `0x48`.
- Confirm required I2C pull-ups are present on the INA236 bus.

Open the USB CDC virtual COM port in a serial terminal. Current firmware reports INA236 readings through the CSV measurement stream documented in the next section. A missing or unresponsive INA236 appears as a visible error line:

```text
INA236_CSV_ERR timestamp_ms=<ms> addr=0x48 reg=0xNN hal=<status> i2c_error=0xNNNNNNNN
```

Expected behavior:

- With the INA236 present, powered, wired to `PB8/PB9`, and responding at address `0x48`, the output reports measurement rows in the CSV stream.
- With the INA236 missing, unpowered, miswired, or strapped to a different address, the output reports `INA236_CSV_ERR`.
- On read failure, the firmware should not hang permanently waiting for I2C.

Optional negative check:

- Disconnect or otherwise fault the INA236 path only if it is safe for the board setup.
- Confirm the USB CDC output changes to `INA236_CSV_ERR`.
- Restore the connection and confirm measurement rows return.

## INA236 CSV Measurement Stream Check

This T0009 check validates the minimal normal-mode CSV stream. Build and flash the Debug ELF first using the sections above.

Open the USB CDC virtual COM port in a serial terminal. The firmware should first emit the CSV header:

```text
timestamp_ms,bus_voltage_v,current_a,power_w
```

With INA236 reads succeeding, measurement rows should follow about once per second:

```text
<timestamp_ms>,<bus_voltage_v>,<current_a>,<power_w>
```

Example shape:

```text
12345,5.012800,0.010250,0.051381
```

If an INA236 read fails, the firmware emits a visible error line and continues running:

```text
INA236_CSV_ERR timestamp_ms=<ms> addr=0x48 reg=0xNN hal=<status> i2c_error=0xNNNNNNNN
```

T0009 scaling assumptions:

- INA236 7-bit address remains `0x48`.
- Bus voltage uses register `0x02` with `1.6 mV/LSB`.
- Current uses shunt-voltage register `0x01` with `2.5 uV/LSB`.
- Until the hardware shunt value is confirmed, firmware assumes `10 mOhm`.
- Power is computed from the scaled bus voltage and current values.

Manual measurement check:

- Compare the reported bus voltage against a bench meter or expected supply voltage.
- Compare reported current against a meter or expected load current.
- Record rough agreement, known offset, or that calibration/shunt confirmation is still needed.

## VCP Operating Mode Check

This T0010 check validates USB CDC/VCP mode selection without toggling physical mode pins. Build and flash the Debug ELF first using the sections above.

Open the USB CDC virtual COM port in a serial terminal. The firmware starts in normal sense mode and should stream the T0009 CSV output.

Send literal `ESC` byte `0x1B` followed by ASCII `1` with no Enter:

```text
ESC 1
```

Expected output:

```text
mode=normal_sense
timestamp_ms,bus_voltage_v,current_a,power_w
```

Send literal `ESC` byte `0x1B` followed by ASCII `2` with no Enter:

```text
ESC 2
```

Expected output:

```text
mode=i2c_sniff
status_ms=<ms> mode=i2c_sniff waiting_for_i2c_sniffer_ticket
```

Send literal `ESC` byte `0x1B` followed by ASCII `3` with no Enter:

```text
ESC 3
```

Expected output:

```text
mode=uart_sniff
```

Expected behavior:

- Mode changes happen without resetting the target.
- Normal sense mode preserves the T0009 CSV stream.
- UART and I2C sniff modes emit status text only. Actual UART/I2C capture is not part of T0010.
- `ESC + ENTER` behavior is covered by the T0011 check below.

## VCP ESC+Enter Passive-Sniff Escape Check

This T0011 check validates the control escape sequence added on top of the T0010 mode selector. Build and flash the Debug ELF first using the sections above.

Open the USB CDC virtual COM port in a serial terminal. The firmware starts in normal sense mode and should stream the T0009 CSV output.

Send literal `ESC` byte `0x1B` followed by ASCII `3` with no Enter:

```text
ESC 3
```

Expected output:

```text
mode=uart_sniff
```

Then send literal `ESC` byte `0x1B` followed by Enter. Terminals may send Enter as CR `0x0D`, LF `0x0A`, or CRLF; either CR or LF after ESC should be accepted.

Expected output:

```text
mode=uart_control_placeholder
status_ms=<ms> mode=uart_control_placeholder passive_sniffing_exited
```

Send literal `ESC` byte `0x1B` followed by ASCII `2` with no Enter:

```text
ESC 2
```

Expected output:

```text
mode=i2c_sniff
```

Then send literal `ESC` byte `0x1B` followed by Enter.

Expected output:

```text
mode=i2c_control_placeholder
status_ms=<ms> mode=i2c_control_placeholder passive_sniffing_exited
```

Send ordinary text such as `hello` and confirm the firmware continues running and emitting the current mode/status output. Ordinary input is ignored by the MVP parser.

Send literal `ESC` byte `0x1B` followed by ASCII `1` with no Enter:

```text
ESC 1
```

Expected output:

```text
mode=normal_sense
timestamp_ms,bus_voltage_v,current_a,power_w
```

Expected behavior:

- `ESC 1`, `ESC 2`, and `ESC 3` select normal sense, I2C sniff, and UART sniff modes.
- `ESC` followed by Enter only exits passive sniffing when the current mode is `uart_sniff` or `i2c_sniff`.
- The control modes are placeholders only; active UART/I2C master behavior belongs to later tickets.
- Normal sense mode preserves the T0009 CSV stream.

## Minimal UART Sniffer Check

This T0012 check validates that known USART2 RX bytes are reported over USB CDC while the firmware is in UART sniff mode. Build and flash the Debug ELF first using the sections above.

USART2 configuration used by the current generated firmware:

- USART2 RX: `PA3`.
- USART2 TX: `PA2`.
- Baud rate: `115200`.
- Data format: `8N1`.
- Hardware flow control: none.

Connect a UART traffic source to the board:

- Traffic source TX to STM32 `PA3` / USART2 RX.
- Shared ground between the traffic source and target board.
- Logic levels compatible with the STM32 target I/O voltage.

Open the USB CDC virtual COM port in a serial terminal, then send literal `ESC` byte `0x1B` followed by ASCII `3` with no Enter:

```text
ESC 3
```

Expected output:

```text
mode=uart_sniff
```

Send known bytes from the UART traffic source at `115200 8N1`. For example, sending ASCII `H` should produce:

```text
UART,RX,0x48
```

Expected behavior:

- UART bytes are reported only while the firmware is in `uart_sniff` mode.
- Output is one simple text line per observed byte using `UART,RX,0xNN`.
- Periodic UART sniff status output from T0010 may still appear between byte reports.
- Send `ESC 1` and confirm normal CSV output resumes.
- Send `ESC` followed by Enter from `uart_sniff` and confirm the T0011 control-placeholder message still appears.

## I2C Sniffer Packet Decode Check

This check validates that I2C traffic on the external I2C2 pins is decoded and reported over USB CDC while the firmware is in I2C sniff mode. Build and flash the Debug ELF first using the sections above.

External I2C pins used by the current generated firmware:

- I2C2 SCL: `PB3`, label `I2C2_EXT_SCL`.
- I2C2 SDA: `PB4`, label `I2C2_EXT_SDA`.

Connect an external I2C traffic source to the board:

- Traffic source SCL to STM32 `PB3` / `I2C2_EXT_SCL`.
- Traffic source SDA to STM32 `PB4` / `I2C2_EXT_SDA`.
- Shared ground between the traffic source and target board.
- Pull-ups present on SCL and SDA.
- Logic levels compatible with the STM32 target I/O voltage.

Open the USB CDC virtual COM port in a serial terminal, then send literal `ESC` byte `0x1B` followed by ASCII `2` with no Enter:

```text
ESC 2
```

Expected output:

```text
mode=i2c_sniff
```

Generate known I2C traffic on the external I2C2 pins. Expected output uses Bus Pirate-style packet characters:

```text
[0x46W+0x00+0x12-]
[0x46W+0x00[0x46R+0x34+0x00+]
```

Expected behavior:

- I2C packets are reported only while the firmware is in `i2c_sniff` mode.
- `[` means START or repeated START, `]` means STOP, `+` means ACK, and `-` means NACK.
- `0xXXW` and `0xXXR` are 7-bit addresses plus direction; plain `0xXX` values are data bytes.
- Each full START-to-STOP transaction appears on its own line.
- I2C sniff mode is quiet when idle.
- Capture/output overflow appears as `I2C,OVERFLOW,<reason>` and the decoder recovers on the next START.
- Send `ESC 1` and confirm normal CSV output resumes.
- Send `ESC` followed by Enter from `i2c_sniff` and confirm the T0011 control-placeholder message still appears.

## MVP Integration Checklist

This T0014 checklist verifies the MVP firmware flow end to end. Build and flash the Debug ELF first using the sections above.

Build and programming checks:

- Run `cmake --preset Debug`.
- Run `cmake --build --preset Debug` with a 20 second timeout in this environment.
- If the preset build hits the known Ninja execution-loop timeout, directly compile the generated changed-file command and directly link `thesensor_v2.elf` from the generated Ninja command, then record that fallback result.
- Flash and verify `build/Debug/thesensor_v2.elf` with `STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -w build/Debug/thesensor_v2.elf -v`.
- Reset and run with `STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -rst -run`.
- Confirm the USB CDC virtual COM port enumerates or re-enumerates after reset/run.

USB CDC control-flow checks:

- Open the USB CDC virtual COM port at `115200 8N1`.
- Confirm normal-mode CSV output appears:

```text
timestamp_ms,bus_voltage_v,current_a,power_w
```

- Send `ESC 3` and confirm UART sniff mode:

```text
mode=uart_sniff
status_ms=<ms> mode=uart_sniff waiting_for_uart_sniffer_ticket
```

- From UART sniff mode, send `ESC` followed by Enter and confirm the placeholder exit:

```text
mode=uart_control_placeholder
status_ms=<ms> mode=uart_control_placeholder passive_sniffing_exited
```

- Send ordinary text and confirm the firmware continues reporting status without reset.
- Send `ESC 2` and confirm I2C sniff mode:

```text
mode=i2c_sniff
status_ms=<ms> mode=i2c_sniff waiting_for_i2c_sniffer_ticket
```

- From I2C sniff mode, send `ESC` followed by Enter and confirm the placeholder exit:

```text
mode=i2c_control_placeholder
status_ms=<ms> mode=i2c_control_placeholder passive_sniffing_exited
```

- Send `ESC 1` and confirm normal CSV output resumes:

```text
mode=normal_sense
timestamp_ms,bus_voltage_v,current_a,power_w
```

External stimulus checks:

- In UART sniff mode, drive known UART bytes into `PA3` at `115200 8N1` and confirm `RX,<payload>` output.
- In I2C sniff mode, drive known I2C traffic on `PB3/PB4` and confirm decoded Bus Pirate-style output such as `[0x46W+0x00+0x12-]`.
- If the UART/I2C traffic sources are not connected during the integration pass, record those checks as not performed rather than failing unrelated USB/mode behavior.

T0014 observed on 2026-05-19:

- `cmake --preset Debug` completed successfully.
- `cmake --build --preset Debug` timed out after 20 seconds with no stdout/stderr, matching the known CMake/Ninja hang in this shell environment.
- Direct compilation of `Core/Src/main.c` succeeded.
- Direct linking of `build/Debug/thesensor_v2.elf` succeeded and reported:

```text
RAM:    9528 B / 144 KB  (6.46%)
FLASH: 48896 B / 512 KB  (9.33%)
```

- `STM32_Programmer_CLI -l stlink` detected `STLINK-V3PWR` serial `0032001E3432511933363736`.
- Flash/verify of `build/Debug/thesensor_v2.elf` succeeded at target voltage `3.31V`; STM32CubeProgrammer reported programmed size `47.75 KB`.
- Reset/run succeeded and reported `Core run`.
- USB CDC re-enumerated as `COM24` after reset/run.
- USB CDC capture on `COM24` verified normal CSV output, UART control-placeholder exit, ordinary text resilience, I2C control-placeholder exit, and explicit-byte return to normal CSV.
- External UART byte stimulus and external I2C traffic stimulus were not connected during this T0014 pass, so UART packet output and I2C decoded packet output remain hardware-stimulus follow-ups.

## Automated Hardware Verification Harness

T0015 adds a first host-side automation harness:

```powershell
pwsh -NoProfile -File tools/run_hardware_verification.ps1 -Port COM24 -ReportPath build/hardware-verification/latest.json
```

Useful options:

- `-Preset Debug` selects the CMake preset.
- `-ElfPath build/Debug/thesensor_v2.elf` selects the ELF to flash.
- `-ProgrammerCliPath <path>` overrides STM32CubeProgrammer CLI discovery.
- `-Port COMx` selects the USB CDC/VCP port. Use this when multiple COM ports are present.
- `-ReportPath <path>` selects the JSON report path.
- `-BuildTimeoutSec`, `-FlashTimeoutSec`, `-ResetTimeoutSec`, and `-CaptureTimeoutSec` bound external operations.

The harness performs these steps and records each result as `pass`, `fail`, or `skipped` in the JSON report:

- `cmake_configure`
- `cmake_build`
- `programmer_discovery`
- `elf_check`
- `flash_verify`
- `reset_run`
- `vcp_discovery`
- `vcp_capture`

The flash and reset/run paths intentionally use the validated under-reset STM32CubeProgrammer flow:

```text
STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -w build/Debug/thesensor_v2.elf -v
STM32_Programmer_CLI -c port=SWD mode=UR reset=HWrst -rst -run
```

Run the help path with:

```powershell
pwsh -NoProfile -File tools/run_hardware_verification.ps1 --help
```

T0015 observed on 2026-05-19:

- The help path exited successfully.
- `cmake --preset Debug` completed successfully.
- `cmake --build --preset Debug` timed out after 20 seconds, matching the known CMake/Ninja wrapper timeout in this shell environment.
- STM32CubeProgrammer CLI was found at `C:\Users\noah.bergman\AppData\Local\stm32cube\bundles\programmer\2.22.0+st.1\bin\STM32_Programmer_CLI.exe`.
- Flash/verify of `build/Debug/thesensor_v2.elf` succeeded.
- Reset/run succeeded and reported `Core run`.
- CIM-based COM-port discovery was access-denied in this shell. The harness falls back to .NET serial-port enumeration; because multiple COM ports were visible, use `-Port COMx` for reliable VCP capture.
- Running with `-Port COM24` captured normal CSV output in `build/hardware-verification/t0015-com24.json`.

## Automated Sensing Check

T0016 extends the hardware harness with a sensing stage. The default stage set is `base,sensing`; use `-Stages sensing` to make the requested stage explicit in the report command line:

```powershell
pwsh -NoProfile -File tools/run_hardware_verification.ps1 -Port COM24 -Stages sensing -ReportPath build/hardware-verification/t0016-sensing.json
```

The sensing stage:

- Opens the USB CDC/VCP port.
- Sends literal bytes `ESC 1` to force normal sense mode.
- Captures output for `-SensingTimeoutSec`.
- Checks for `mode=normal_sense` if emitted.
- Checks for the strict CSV header:

```text
timestamp_ms,bus_voltage_v,current_a,power_w
```

- Checks for at least one measurement row or a visible `INA236_CSV_ERR` line.
- Records parsed fields in the JSON report under the `sensing_normal` step:
  - `sent_command`
  - `mode_detected`
  - `csv_header_detected`
  - `measurement_row_count`
  - `ina236_error_count`
  - `captured_chars`

T0016 observed on 2026-05-19:

- The help path exited successfully after adding sensing options.
- Running with explicit `-Port COM24` wrote `build/hardware-verification/t0016-sensing.json`.
- Build/configure, flash/verify, reset/run, VCP capture, and `sensing_normal` passed.
- The `sensing_normal` step sent `ESC 1`, detected `mode=normal_sense`, detected the CSV header, and captured four measurement rows.
- Running with intentionally invalid `-Port COM99` wrote `build/hardware-verification/t0016-wrong-port.json` and recorded clear VCP capture and sensing failures for the missing COM port.

## Automated UART Check

T0017 extends the hardware harness with a UART stage. The UART stage is selected by default, but it is skipped until a stimulus COM port is provided:

```powershell
pwsh -NoProfile -File tools/run_hardware_verification.ps1 -Port COM24 -Stages uart -UartPort COMx -UartBaud 115200 -ReportPath build/hardware-verification/t0017-uart.json
```

Required wiring:

- Stimulus source TX to STM32 `PA3` / `USART2_RX`.
- Common ground between the stimulus source and the board.
- The current firmware expects `115200 8N1` until UART autobaud is implemented in a later ticket.

Useful options:

- `-UartPort COMx` selects the host UART stimulus port.
- `-UartBaud 115200` selects the stimulus baud.
- `-UartPatternHex "55 48 69"` selects the bytes sent to the UART stimulus port.
- `-UartInterByteDelayMs 0` selects a tight host burst. Set a positive value only when intentionally testing spaced bytes.
- `-UartDisplayMode ascii|hex` selects raw ASCII output or uppercase ASCII hex output.
- `-UartFlushMode timeout|line|full` selects byte-timeout, line-ending, or buffer-full flush behavior.
- `-UartTimeoutSec 8` controls the VCP capture window for UART output.

The UART stage:

- Opens the USB CDC/VCP port.
- Sends literal bytes `ESC 3` to enter UART sniff mode.
- Writes the configured hex byte pattern to the UART stimulus port.
- For T0017B and later, checks the configured payload directly in the selected display format. UART sniff packet output uses `RX,` as the channel prefix and ends each packet with CRLF so the terminal cursor advances to the next line.

- Records parsed fields in the JSON report under the `uart_sniff` step:
  - `sent_command`
  - `display_command`
  - `flush_command`
  - `stimulus_port`
  - `stimulus_baud`
  - `stimulus_hex`
  - `expected_payload`
  - `expected_option_messages`
  - `option_messages_matched`
  - `observed_payload_excerpt`
  - `expected_pattern_matched`
  - `detected_uart_baud`

`detected_uart_baud` is intentionally `null` for T0017. UART baud detection is planned for a later ticket.

T0017 observed on 2026-05-19:

- The help path exited successfully after adding UART options.
- Running without `-UartPort` wrote `build/hardware-verification/t0017-uart-skipped.json`; the `uart_sniff` step was marked skipped with wiring instructions.
- Running with intentionally invalid `-UartPort COM99` wrote `build/hardware-verification/t0017-uart-bad-port.json`; the base flash/VCP steps still reported independently and the `uart_sniff` step failed clearly because the stimulus COM port could not be opened.
- A live UART stimulus check using `COM23` wired to `PA3` verified `UART,RX,0xNN` output.
- A tight three-byte burst `55 48 69` reproduced a dropped third byte. Sending the same bytes with the harness default `5 ms` inter-byte delay passed.
- UART sniff mode no longer emits periodic idle status messages; after `mode=uart_sniff`, output is limited to received UART bytes.

T0017A/T0017B observed on 2026-05-19:

- The hardware harness now builds through Ninja's dry-run generated commands when the CMake build wrapper or direct Ninja invocation stalls in this shell. The harness still owns configure, build, flash, reset, and report generation.
- `build/hardware-verification/t0017b-option-ascii-timeout.json` passed with `COM24` VCP and `COM23` UART stimulus. The observed payload excerpt was:

```text
mode=uart_sniff
option=uart_flush mode=timeout
RX,UHi
```

- `build/hardware-verification/t0017b-option-hex-timeout.json` passed after `ESC H`; the observed payload excerpt was:

```text
mode=uart_sniff
option=uart_display mode=hex
option=uart_flush mode=timeout
RX,55 48 69
```

- `build/hardware-verification/t0017b-option-line.json` passed after `ESC L` using stimulus `48 69 0A`; it observed `option=uart_flush mode=line` and `RX,Hi` followed by CRLF.
- `build/hardware-verification/t0017b-option-full.json` passed after `ESC F` using a 96-byte ASCII `A` packet; it observed `option=uart_flush mode=full` and one `RX,` line followed by CRLF.
- The firmware command set for UART sniff display/flush mode is:
  - `ESC H` toggles ASCII and ASCII-hex display, then prints `option=uart_display mode=ascii|hex`.
  - `ESC L` selects line-ending flush, then prints `option=uart_flush mode=line`.
  - `ESC B` selects byte-timeout flush, then prints `option=uart_flush mode=timeout`.
  - `ESC F` selects buffer-full flush, then prints `option=uart_flush mode=full`.

## Automated I2C Check

T0018 extends the hardware harness with an I2C observe stage:

```powershell
pwsh -NoProfile -File tools/run_hardware_verification.ps1 -Port COM24 -Stages i2c -ReportPath build/hardware-verification/t0018-i2c-observe-only.json
```

Required wiring for a positive activity test:

- External I2C traffic source SCL to STM32 `PB3` / `I2C2_EXT_SCL`.
- External I2C traffic source SDA to STM32 `PB4` / `I2C2_EXT_SDA`.
- Common ground between the stimulus source and the board.
- Suitable pull-ups for the connected I2C bus.

Useful options:

- `-I2cTimeoutSec 8` controls the observe-only capture window.
- `-I2cStimulusCommand "<command>"` optionally runs a host command after entering I2C sniff mode.
- `-I2cStimulusTimeoutSec 10` bounds the optional stimulus command.

The I2C stage:

- Opens the USB CDC/VCP port.
- Sends literal bytes `ESC 2` to enter I2C sniff mode.
- Runs the optional stimulus command when provided.
- Captures USB CDC output and parses decoded packet lines shaped like:

```text
[0x46W+0x00+0x12-]
[0x46W+0x00[0x46R+0x34+0x00+]
```

- Records parsed fields in the JSON report under the `i2c_sniff` step:
  - `sent_command`
  - `observe_only`
  - `stimulus_command`
  - `stimulus_status`
  - `decoded_packet_count`
  - `observed_packets`
  - `overflow_count`
  - `observed_overflows`
  - `detected_i2c_speed_hz`

`detected_i2c_speed_hz` is intentionally `null` for T0018. I2C speed detection is planned for a later ticket.

T0018 observed on 2026-05-19:

- `pwsh -NoProfile -File tools/run_hardware_verification.ps1 -Help` exited successfully after adding I2C options.
- Running observe-only with `COM24` wrote `build/hardware-verification/t0018-i2c-observe-only.json`.
- Configure, generated-command Ninja build, programmer discovery, ELF check, flash/verify, reset/run, and VCP capture passed.
- The `i2c_sniff` stage sent `ESC 2`, observed `mode=i2c_sniff`, recorded `stimulus_status=skipped`, and failed clearly because no external I2C activity was connected or observed.
- No local ST-LINK bridge/I2C command-line utility was found in the installed STM32Cube bundles during this ticket. Positive activity verification still requires an external I2C traffic source or a user-provided `-I2cStimulusCommand`.

## Inspect Expected Build Artifacts

Run from the repository root:

```powershell
Get-ChildItem build/Debug -File | Select-Object Name,Length,LastWriteTime
```

Expected baseline artifacts include:

- `build/Debug/thesensor_v2.elf`
- `build/Debug/thesensor_v2.map`
- `build/Debug/compile_commands.json`
- `build/Debug/build.ninja`

The key firmware image for later flash/debug tickets is:

```text
build/Debug/thesensor_v2.elf
```

## Current Scope Boundaries

Verified by this baseline:

- Required workstation commands are available.
- The current Debug CMake configure succeeds.
- The current Debug CMake build succeeds.
- The expected Debug ELF is generated.
- VS Code has extension recommendations for STM32 and CMake Tools.
- VS Code has a default build task for the existing Debug preset.
- VS Code has an ST-LINK debug launch configuration for `build/Debug/thesensor_v2.elf`.
- STM32CubeProgrammer detects the target over ST-LINK/SWD under reset.
- STM32CubeProgrammer can mass erase, flash, verify, reset, and run `build/Debug/thesensor_v2.elf`.
- Firmware source includes a once-per-second normal-mode CSV stream with `timestamp_ms,bus_voltage_v,current_a,power_w`.
- Firmware source includes VCP mode selection using `ESC 1`, `ESC 2`, and `ESC 3`.
- Firmware source includes VCP `ESC` followed by CR or LF handling that exits `uart_sniff` or `i2c_sniff` into a control-placeholder mode.
- Firmware source includes buffered USART2 RX polling in `uart_sniff` mode and reports observed packets as `RX,<payload>` lines over USB CDC.
- Firmware source includes EXTI-backed external I2C2 SCL/SDA capture in `i2c_sniff` mode and reports decoded Bus Pirate-style packet lines over USB CDC.
- The automated harness includes an I2C observe-only stage that enters `i2c_sniff`, parses decoded packet lines and overflow diagnostics, and records skipped stimulus plus clear pass/fail.
- T0014 hardware verification flashed and ran the current Debug ELF, observed USB CDC on `COM24`, verified normal CSV output, verified VCP mode switching, and verified ESC+Enter control-placeholder exits from both sniff modes.
- Direct compilation of `Core/Src/main.c` and direct linking of `thesensor_v2.elf` succeeded during T0009 investigation.
- `cmake --build --preset Debug` and direct `ninja -C build/Debug` hung in the STM32-bundled Ninja execution loop in this Codex shell environment despite the generated compile and link commands succeeding directly. Use an explicit 20 second process timeout around CMake/build calls and record the timeout if it recurs.
- STM32CubeProgrammer flashed and verified the T0009 ELF, reset/running the target succeeded, and USB CDC CSV output was observed on `COM24`.
- STM32CubeProgrammer flashed and verified the T0010 ELF, reset/running the target succeeded, and USB CDC mode switching was observed on `COM24`.

Not verified by this baseline:

- ST-LINK hot-plug attach to the already-running target.
- USB CDC enumeration after the T0007 firmware changes.
- Runtime serial output after the T0007 firmware changes.
- Full `cmake --build --preset Debug` completion after the T0010 firmware changes due to the observed Ninja hang.
- INA236 communication on hardware and measurement accuracy.
- Hardware selector GPIO behavior.
- Sustained high-speed I2C decode beyond the current EXTI-backed capture path.
- Runtime UART sniffer byte output with external UART stimulus after the T0012 firmware change.
- Positive runtime I2C decoded packet output with external I2C stimulus after the T0027 firmware change.
- Full VS Code debug/flash validation across failure modes.

If any baseline command fails, record the exact command, exit status, and relevant output before changing firmware or generated CubeMX files.
