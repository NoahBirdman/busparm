# TheSensor MVP Ticket Backlog

`T0001` lives in `docs/T0001.md` and covers baseline STM32 workstation setup.

This file contains the next MVP tickets as complete Codex handoff blocks. Each ticket is intended to be implemented alone, in order, without pulling in future-ticket behavior.

## Index

- Completed: `T0001` through `T0005`
- Next: `T0006` - Add USB CDC heartbeat smoke test

Completed ticket handoff blocks remain in this file for traceability, but implementation should continue from the next ticket listed above.

- `T0002` - Completed - Document current repo state and manual verification baseline
- `T0003` - Completed - Configure VS Code workspace for CMake STM32 development
- `T0004` - Completed - Add VS Code debug and flash configuration
- `T0005` - Completed - Validate ST-LINK and board connection
- `T0006` - Add USB CDC heartbeat smoke test
- `T0007` - Report GPIO states over USB
- `T0008` - Verify INA236 I2C pin labels and add raw register read
- `T0009` - Stream normal-mode INA236 CSV measurements
- `T0010` - Add VCP-controlled MVP operating-mode state machine
- `T0011` - Extend VCP parser with ESC+ENTER control escape
- `T0012` - Add minimal UART sniffer output
- `T0013` - Add minimal I2C sniffer output
- `T0014` - MVP integration verification and documentation pass

---

We are working on TheSensor.

Before coding, review:
- AGENTS.md
- docs/Full_Design_Document.md
- docs/MVP_Technical_Design.md
- docs/Tickets.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md

Implement this ticket only.

Ticket:
T0002 - Document current repo state and manual verification baseline

Branch:
ticket/t0002-repo-state-verification-docs

Goal:
Document the current repository state and create a baseline manual verification guide for the STM32/CMake project after baseline tool setup.

Dependencies:
- T0001 completed.
- Existing CubeMX-generated project is present in the repository.

Allowed areas:
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- README.md only if a short pointer to the docs is needed

Do not touch:
- Core/
- Drivers/
- Middlewares/
- USB_Device/
- cmake/
- CMakeLists.txt
- CMakePresets.json
- thesensor_v2.ioc
- Firmware behavior or generated CubeMX source

Requirements:
- Record current tool versions known from T0001: VS Code, STM32 VS Code extension pack, CMake, Ninja, GNU Tools for STM32, GDB, and STM32CubeProgrammer.
- Record that `cmake --preset Debug` and `cmake --build --preset Debug` succeeded.
- Record generated build artifact locations, especially `build/Debug/thesensor_v2.elf`.
- Record known documentation gaps, including any referenced docs that were missing before this ticket.
- Add manual verification steps for toolchain checks, configure/build, and expected build artifact inspection.
- Keep documentation factual and limited to current state.

Non-goals:
- Do not change firmware.
- Do not add VS Code workspace configuration.
- Do not add debug configuration.
- Do not document future behavior as already implemented.
- Do not resolve repo structure or git history issues beyond documenting them.

Acceptance criteria:
- `docs/Repo_Current_State.md` is no longer empty and accurately describes the current repo/tool/build state.
- `docs/Manual_Verification_Guide.md` exists and includes repeatable baseline setup/build checks.
- The docs clearly distinguish verified current behavior from planned MVP work.

Manual verification:
- Read `docs/Repo_Current_State.md` and confirm it matches the repository.
- Read `docs/Manual_Verification_Guide.md` and confirm a developer can follow the baseline checks.
- Run `cmake --preset Debug`.
- Run `cmake --build --preset Debug`.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets

---

We are working on TheSensor.

Before coding, review:
- AGENTS.md
- docs/Full_Design_Document.md
- docs/MVP_Technical_Design.md
- docs/Tickets.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md

Implement this ticket only.

Ticket:
T0003 - Configure VS Code workspace for CMake STM32 development

Branch:
ticket/t0003-vscode-cmake-workspace

Goal:
Make the repository open cleanly in VS Code with STM32/CMake tooling and provide standard build tasks for the Debug preset.

Dependencies:
- T0001 completed.
- T0002 completed.

Allowed areas:
- .vscode/extensions.json
- .vscode/settings.json
- .vscode/tasks.json
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md

Do not touch:
- Firmware source files
- CubeMX-generated files outside `.vscode`
- Debug/flash launch configuration; that belongs to T0004
- CI configuration

Requirements:
- Add recommended VS Code extensions for CMake Tools and STM32CubeIDE for Visual Studio Code.
- Configure VS Code/CMake to use the existing `Debug` preset and Ninja generator from `CMakePresets.json`.
- Add a build task that runs the existing Debug build without changing source files.
- Prefer existing STM32 VS Code extension conventions where possible.
- Document how to open the workspace and run configure/build from VS Code.

Non-goals:
- Do not add debug launch configuration.
- Do not add firmware smoke tests.
- Do not alter CMake project structure.
- Do not install tools or change PATH.

Acceptance criteria:
- VS Code recommends the expected STM32 and CMake extensions.
- VS Code can configure the project with the existing Debug preset.
- VS Code can run a Debug build task.
- Terminal builds still work with `cmake --preset Debug` and `cmake --build --preset Debug`.

Manual verification:
- Open the repo in VS Code.
- Confirm extension recommendations appear or are already satisfied.
- Run CMake configure for the Debug preset.
- Run the Debug build task.
- Confirm `build/Debug/thesensor_v2.elf` is produced or remains current.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets

---

We are working on TheSensor.

Before coding, review:
- AGENTS.md
- docs/Full_Design_Document.md
- docs/MVP_Technical_Design.md
- docs/Tickets.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md

Implement this ticket only.

Ticket:
T0004 - Add VS Code debug and flash configuration

Branch:
ticket/t0004-vscode-stlink-debug

Goal:
Add a VS Code debug/flash configuration for the STM32G0 target using ST-LINK and the existing Debug build artifact.

Dependencies:
- T0001 completed.
- T0002 completed.
- T0003 completed.
- ST-LINK hardware available for manual verification.

Allowed areas:
- .vscode/launch.json
- .vscode/tasks.json only if a pre-launch build task needs adjustment
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md

Do not touch:
- Firmware behavior
- CMake source layout
- CubeMX `.ioc` pin/peripheral configuration
- Hardware validation workflow beyond debug launch docs

Requirements:
- Add a launch configuration that builds Debug if needed and launches an ST-LINK debug session.
- Point the debugger at `build/Debug/thesensor_v2.elf`.
- Configure reset/run-to-main behavior appropriate for a first smoke debug session.
- Use STM32 VS Code extension/Cortex-Debug-style settings already supported by installed tools.
- Document required hardware connection and expected outcome.

Non-goals:
- Do not implement flashing scripts beyond the debug launch path.
- Do not validate all ST-LINK operations; T0005 owns that.
- Do not add firmware output or LED blink behavior.
- Do not require a specific SVD unless already available locally.

Acceptance criteria:
- VS Code shows a debug configuration for the STM32 target.
- Starting debug builds the Debug preset if necessary.
- With hardware connected, the session flashes/loads and can halt at or near `main()`.
- Failure modes are documented for missing ST-LINK or missing target power.

Manual verification:
- Connect ST-LINK and target board.
- Open VS Code Run and Debug.
- Select the STM32 debug configuration.
- Launch debug and confirm the debugger reaches `main()` or a first breakpoint.
- Stop the session cleanly.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets

---

We are working on TheSensor.

Before coding, review:
- AGENTS.md
- docs/Full_Design_Document.md
- docs/MVP_Technical_Design.md
- docs/Tickets.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md

Implement this ticket only.

Ticket:
T0005 - Validate ST-LINK and board connection

Branch:
ticket/t0005-stlink-board-validation

Goal:
Verify the physical board debug/programming path using STM32CubeProgrammer and ST-LINK before adding firmware features.

Dependencies:
- T0001 completed.
- T0002 completed.
- T0004 completed if VS Code debug validation is desired.
- ST-LINK and target board available.

Allowed areas:
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md

Do not touch:
- Firmware source files
- CMake files
- VS Code debug configuration unless documenting an observed issue
- CubeMX `.ioc`

Requirements:
- Use `STM32_Programmer_CLI` to detect the connected target over ST-LINK.
- Record target voltage and detected MCU information if available.
- Verify erase, flash of the existing Debug ELF, and reset/run.
- Document exact commands and expected outputs at a practical level.
- Record any hardware connection assumptions or failures.

Non-goals:
- Do not add firmware smoke output.
- Do not debug application behavior.
- Do not modify linker scripts, startup, or clock setup.
- Do not perform production programming workflow design.

Acceptance criteria:
- STM32CubeProgrammer detects the target over ST-LINK.
- Existing `build/Debug/thesensor_v2.elf` flashes successfully.
- Target resets/runs after flash.
- Manual verification guide contains the validated ST-LINK workflow.

Manual verification:
- Connect ST-LINK and target board.
- Run `STM32_Programmer_CLI` connect command for ST-LINK.
- Flash `build/Debug/thesensor_v2.elf`.
- Reset/run the target.
- Record observed command output in the ticket result summary.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets

---

We are working on TheSensor.

Before coding, review:
- AGENTS.md
- docs/Full_Design_Document.md
- docs/MVP_Technical_Design.md
- docs/Tickets.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md

Implement this ticket only.

Ticket:
T0006 - Add USB CDC heartbeat smoke test

Branch:
ticket/t0006-usb-cdc-heartbeat

Goal:
Prove USB CDC enumeration and transmit are working by streaming a simple periodic heartbeat over the virtual COM port.

Dependencies:
- T0001 completed.
- T0002 completed.
- T0005 completed or hardware flashing path otherwise verified.

Allowed areas:
- Core/Src/main.c
- Core/Inc/main.h only if needed for local declarations
- USB_Device/App/usbd_cdc_if.c only if a minimal transmit helper is required
- USB_Device/App/usbd_cdc_if.h only if a helper declaration is required
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md

Do not touch:
- INA236 logic
- Hardware selector behavior
- UART sniffer behavior
- I2C sniffer behavior
- CubeMX peripheral configuration

Requirements:
- After USB initialization, send a periodic human-readable heartbeat line over USB CDC.
- Include a millisecond timestamp or monotonically increasing counter in the heartbeat.
- Avoid blocking forever if USB is not connected or CDC transmit is busy.
- Keep implementation inside CubeMX user-code-safe regions.
- Build with the existing Debug preset.

Non-goals:
- Do not read sensor data.
- Do not read mode switches.
- Do not implement command receive.
- Do not add a general application framework unless necessary.

Acceptance criteria:
- Firmware builds successfully.
- Board enumerates as a USB CDC virtual COM port.
- A host terminal receives periodic heartbeat lines.
- Firmware remains responsive if the terminal is not open.

Manual verification:
- Build Debug firmware.
- Flash the board.
- Connect USB to the host.
- Open the new COM port with a serial terminal.
- Confirm heartbeat text appears periodically.
- Close/reopen the terminal and confirm firmware continues running.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets

---

We are working on TheSensor.

Before coding, review:
- AGENTS.md
- docs/Full_Design_Document.md
- docs/MVP_Technical_Design.md
- docs/Tickets.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md

Implement this ticket only.

Ticket:
T0007 - Report GPIO states over USB

Branch:
ticket/t0007-gpio-state-reporting

Goal:
Read generated GPIO inputs and report hardware state over USB CDC for hardware validation.

Dependencies:
- T0006 completed.
- Board can be flashed and USB CDC output can be observed.

Allowed areas:
- Core/Src/main.c
- Core/Inc/main.h only if needed for pin aliases or local declarations
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md

Do not touch:
- INA236 register reads
- Sniffer implementation
- USB CDC receive path
- CubeMX `.ioc` unless labels are proven wrong and explicitly documented

Requirements:
- Periodically report raw GPIO states over USB CDC.
- Keep the existing heartbeat behavior or fold it into the status line without adding mode routing.
- Clearly label each reported input in the output text.
- Build with the existing Debug preset.

Non-goals:
- Do not switch application behavior based on hardware GPIO input yet.
- Do not implement normal/sniffing mode routing.
- Do not read INA236 registers.
- Do not debounce or calibrate switch behavior beyond basic observable reporting.

Acceptance criteria:
- Firmware builds successfully.
- USB CDC output includes the active hardware GPIO states.
- INA_ALERT reports the current raw input level.

Manual verification:
- Build and flash firmware.
- Open USB CDC terminal.
- Record INA_ALERT idle state.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets

---

We are working on TheSensor.

Before coding, review:
- AGENTS.md
- docs/Full_Design_Document.md
- docs/MVP_Technical_Design.md
- docs/Tickets.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md

Implement this ticket only.

Ticket:
T0008 - Verify INA236 I2C pin labels and add raw register read

Branch:
ticket/t0008-ina236-raw-read

Goal:
Verify the INA236 I2C wiring/configuration and add a minimal raw register read that reports status over USB CDC.

Dependencies:
- T0007 completed.
- Board and INA236 hardware available.
- I2C wiring can be inspected or tested.

Allowed areas:
- Core/Src/main.c
- Core/Inc/main.h only if needed
- thesensor_v2.ioc only if the PB8/PB9 labels are confirmed wrong and corrected
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md

Do not touch:
- Measurement scaling/math beyond raw value formatting
- Mode state machine
- Sniffer behavior
- USB CDC receive path
- Unrelated CubeMX peripheral settings

Requirements:
- Verify and document the current PB8/PB9 INA I2C mapping:
  - CubeMX signal assignment currently uses `PB8 = I2C1_SCL`, `PB9 = I2C1_SDA`.
  - Existing labels may appear reversed and must be confirmed before relying on them.
- Add a minimal INA236 raw register read over the configured INA I2C/SMBus peripheral.
- Report success/failure and at least one raw register value over USB CDC.
- Keep failures visible in text output without hanging the firmware forever.
- Build with the existing Debug preset.

Non-goals:
- Do not calculate voltage/current/power yet.
- Do not add calibration.
- Do not add persistent settings.
- Do not implement operating modes.
- Do not implement I2C sniffing.

Acceptance criteria:
- Firmware builds successfully.
- PB8/PB9 label mismatch is either corrected or documented as verified safe.
- USB CDC output reports INA236 raw read success/failure.
- With INA236 present, at least one raw register value is reported.
- With INA236 missing or unresponsive, firmware continues running and reports an error.

Manual verification:
- Inspect schematic or board wiring for INA236 SCL/SDA.
- Build and flash firmware.
- Open USB CDC terminal.
- Confirm raw INA236 register output or a clear error.
- If possible, disconnect or fault the sensor path and confirm firmware does not hang.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets

---

We are working on TheSensor.

Before coding, review:
- AGENTS.md
- docs/Full_Design_Document.md
- docs/MVP_Technical_Design.md
- docs/Tickets.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md

Implement this ticket only.

Ticket:
T0009 - Stream normal-mode INA236 CSV measurements

Branch:
ticket/t0009-ina236-csv-stream

Goal:
Convert INA236 raw readings into conservative-default measurements and stream normal-mode CSV over USB CDC.

Dependencies:
- T0008 completed.
- INA236 raw register reads verified.

Allowed areas:
- Core/Src/main.c
- Core/Inc/main.h only if needed
- New small application source/header files only if needed to keep `main.c` manageable
- CMakeLists.txt only if new application files are added
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md

Do not touch:
- Sniffer behavior
- USB CDC receive path
- Debug/VS Code config
- CubeMX peripheral configuration unless required by a verified bug

Requirements:
- Stream newline-delimited CSV in normal sensing behavior.
- Use this header/order:
  - `timestamp_ms,bus_voltage_v,current_a,power_w`
- Use conservative documented defaults for shunt/scaling if exact hardware values are not confirmed.
- Report sensor read errors clearly without locking up the main loop.
- Keep output human-readable and terminal-friendly.
- Build with the existing Debug preset.

Non-goals:
- Do not add binary framing.
- Do not add persistent calibration/settings.
- Do not implement VCP mode routing yet beyond normal sensing output.
- Do not implement sniffing.
- Do not add advanced filtering or averaging unless needed for stable basic output.

Acceptance criteria:
- Firmware builds successfully.
- USB CDC output includes CSV measurement lines.
- Values update periodically.
- Output includes timestamp, bus voltage, current, and power fields.
- Manual verification guide documents expected CSV format and known scaling assumptions.

Automated verification:
- Build Debug with the existing preset and a 20 second timeout.
- Flash `build/Debug/thesensor_v2.elf` using the validated ST-LINK/STM32CubeProgrammer under-reset workflow.
- Reset/run the target after flashing.
- Open or capture the USB CDC virtual COM port from the host.
- Confirm the CSV header or clearly documented first line appears.
- Confirm periodic measurement rows appear in normal sensing mode.

Manual verification:
- Build and flash firmware.
- Open USB CDC terminal.
- Confirm CSV header or clearly documented first line appears.
- Confirm periodic measurement rows appear.
- Compare bus voltage/current against a meter or expected bench setup and record rough agreement or known offset.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- cmake and build calls must be bounded with 20 second timeout.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets

---

We are working on TheSensor.

Before coding, review:
- AGENTS.md
- docs/Full_Design_Document.md
- docs/MVP_Technical_Design.md
- docs/Tickets.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md

Implement this ticket only.

Ticket:
T0010 - Add VCP-controlled MVP operating-mode state machine

Branch:
ticket/t0010-mvp-mode-state-machine

Goal:
Route firmware behavior by USB CDC/VCP commands so the device clearly selects normal sense, UART sniff, or I2C sniff mode without requiring physical pin toggles.

Dependencies:
- T0009 completed.
- USB CDC transmit behavior verified in earlier tickets.

Allowed areas:
- Core/Src/main.c
- Core/Inc/main.h only if needed
- USB_Device/App/usbd_cdc_if.c
- USB_Device/App/usbd_cdc_if.h
- New small application source/header files only if needed
- CMakeLists.txt only if new application files are added
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md

Do not touch:
- ESC+ENTER control escape behavior
- UART sniffer byte capture
- I2C sniffer event capture
- INA236 scaling beyond preserving existing normal CSV behavior
- CubeMX `.ioc`

Requirements:
- Add the minimal USB CDC receive path needed to parse MVP mode-selection commands.
- Detect literal `ESC` byte `0x1B` followed by ASCII `1`, `2`, or `3`; no Enter is required.
- Implement a minimal state machine with:
  - `ESC 1`: normal sense mode
  - `ESC 2`: I2C sniff mode
  - `ESC 3`: UART sniff mode
- In normal sense mode, keep streaming the T0009 CSV measurements.
- In UART and I2C sniff modes, output clear periodic mode/status text only; actual sniffed data belongs to later tickets.
- Report mode transitions over USB CDC.
- Avoid blocking and keep the main loop responsive to VCP command changes.

Non-goals:
- Do not implement ESC+ENTER control escape handling.
- Do not capture UART bytes.
- Do not capture I2C events.
- Do not implement active I2C/UART master/control mode.
- Do not add persistent settings.

Acceptance criteria:
- Firmware builds successfully.
- Normal mode streams CSV measurements.
- UART sniff mode reports that UART sniffing is active.
- I2C sniff mode reports that I2C sniffing is active.
- Sending `ESC 1`, `ESC 2`, and `ESC 3` changes the active mode without reset.

Automated verification:
- Build Debug with the existing preset and a 20 second timeout.
- Flash `build/Debug/thesensor_v2.elf` using the validated ST-LINK/STM32CubeProgrammer under-reset workflow.
- Reset/run the target after flashing.
- Open or capture the USB CDC virtual COM port from the host.
- Send `ESC 1` and confirm normal CSV output.
- Send `ESC 2` and confirm an I2C sniff mode transition/status message.
- Send `ESC 3` and confirm a UART sniff mode transition/status message.
- Repeat the command sequence and confirm mode changes do not require a reset.

Manual verification:
- Build and flash firmware.
- Open USB CDC terminal.
- Send `ESC 1` and confirm normal CSV.
- Send `ESC 2` and confirm I2C sniff status output.
- Send `ESC 3` and confirm UART sniff status output.
- Switch between modes several times and confirm no reset is required.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- cmake and build calls must be bounded with 20 second timeout.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets

---

We are working on TheSensor.

Before coding, review:
- AGENTS.md
- docs/Full_Design_Document.md
- docs/MVP_Technical_Design.md
- docs/Tickets.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md

Implement this ticket only.

Ticket:
T0011 - Extend VCP parser with ESC+ENTER control escape

Branch:
ticket/t0011-usb-escape-control

Goal:
Extend the T0010 VCP command parser so `ESC` followed by Enter exits passive sniffing without reset.

Dependencies:
- T0010 completed.

Allowed areas:
- USB_Device/App/usbd_cdc_if.c
- USB_Device/App/usbd_cdc_if.h
- Core/Src/main.c
- Core/Inc/main.h only if needed
- New small application source/header files only if needed
- CMakeLists.txt only if new application files are added
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md

Do not touch:
- UART sniffer data capture
- I2C sniffer data capture
- INA236 measurement math
- CubeMX `.ioc`

Requirements:
- Reuse the USB CDC receive path added in T0010 without blocking the USB receive callback.
- Detect literal `ESC` byte `0x1B` followed by either CR `0x0D` or LF `0x0A`.
- Only use the escape to exit passive sniffing/control-placeholder state when currently in UART or I2C sniff mode.
- Emit clear USB text when the escape is detected.
- Preserve `ESC 1`, `ESC 2`, and `ESC 3` mode selection behavior from T0010.
- Preserve normal CSV behavior in normal mode.
- Keep implementation small and suitable for bare-metal polling.

Non-goals:
- Do not implement a full command shell.
- Do not implement `ESC ?`, `ESC R`, or other VIM-like commands.
- Do not implement active I2C/UART master driving after escape; a placeholder state/message is enough.
- Do not add persistent settings.

Acceptance criteria:
- Firmware builds successfully.
- Sending `ESC 2` or `ESC 3`, then ESC followed by Enter, exits passive sniffing or reports control placeholder.
- Sending ordinary terminal input does not crash or block firmware.
- `ESC 1`, `ESC 2`, and `ESC 3` still select the expected modes.
- Normal mode behavior remains intact.

Automated verification:
- Build Debug with the existing preset and a 20 second timeout.
- Flash `build/Debug/thesensor_v2.elf` using the validated ST-LINK/STM32CubeProgrammer under-reset workflow.
- Reset/run the target after flashing.
- Open or capture the USB CDC virtual COM port from the host.
- Send `ESC 3`, then send `ESC` followed by Enter, and confirm passive sniff exits or reports control placeholder.
- Send `ESC 2`, then send `ESC` followed by Enter, and confirm passive sniff exits or reports control placeholder.
- Send ordinary terminal input and confirm firmware continues running.
- Send `ESC 1` and confirm normal CSV output resumes.

Manual verification:
- Build and flash firmware.
- Send `ESC 2` or `ESC 3` to enter a sniff mode.
- From the USB CDC terminal, send ESC then Enter and confirm output changes.
- Send random text and confirm firmware continues running.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- cmake and build calls must be bounded with 20 second timeout.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets

---

We are working on TheSensor.

Before coding, review:
- AGENTS.md
- docs/Full_Design_Document.md
- docs/MVP_Technical_Design.md
- docs/Tickets.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md

Implement this ticket only.

Ticket:
T0012 - Add minimal UART sniffer output

Branch:
ticket/t0012-minimal-uart-sniffer

Goal:
Add minimal observable UART sniffing output in UART sniff mode so known UART bytes appear over USB CDC.

Dependencies:
- T0010 completed.
- T0011 completed.
- UART pins and expected MVP baud rate are available for test stimulus.

Allowed areas:
- Core/Src/main.c
- Core/Inc/main.h only if needed
- Core/Src/stm32g0xx_it.c only if UART interrupt handling is required
- New small application source/header files only if needed
- CMakeLists.txt only if new application files are added
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md

Do not touch:
- I2C sniffer implementation
- INA236 measurement math
- USB CDC command set beyond preserving ESC+ENTER behavior
- CubeMX `.ioc` unless a verified UART config issue blocks the ticket

Requirements:
- In UART sniff mode only, report observed UART bytes over USB CDC using simple text lines such as `UART,RX,0x48`.
- Use the existing USART2 configuration and fixed MVP baud rate from generated firmware unless a verified issue requires a narrow change.
- Keep normal mode CSV, I2C sniff status behavior, and VCP mode selection intact.
- Keep ESC+ENTER behavior intact.
- Avoid full protocol decoding or automatic baud detection.

Non-goals:
- Do not implement automatic baud detection.
- Do not implement high-throughput binary logging.
- Do not implement UART transmit/control mode after escape.
- Do not add UI commands beyond existing escape behavior.

Acceptance criteria:
- Firmware builds successfully.
- In UART sniff mode, known UART test bytes produce `UART,...` output over USB CDC.
- Normal sense mode still streams CSV.
- I2C sniff mode behavior remains unchanged from T0010/T0011.
- ESC+ENTER still exits passive sniffing behavior.

Automated verification:
- Build Debug with the existing preset and a 20 second timeout.
- Flash `build/Debug/thesensor_v2.elf` using the validated ST-LINK/STM32CubeProgrammer under-reset workflow.
- Reset/run the target after flashing.
- Open or capture the USB CDC virtual COM port from the host.
- Send `ESC 3` to enter UART sniff mode.
- Send known UART bytes into the configured UART input at the fixed MVP baud rate.
- Confirm USB CDC output includes corresponding `UART,...` lines.
- Send `ESC 1` and confirm normal CSV output resumes.

Manual verification:
- Build and flash firmware.
- Send `ESC 3` to enter UART sniff mode.
- Send known UART bytes into the configured UART input at the fixed MVP baud rate.
- Confirm USB CDC terminal shows corresponding `UART,...` lines.
- Switch back to normal mode and confirm CSV resumes.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- cmake and build calls must be bounded with 20 second timeout.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets

---

We are working on TheSensor.

Before coding, review:
- AGENTS.md
- docs/Full_Design_Document.md
- docs/MVP_Technical_Design.md
- docs/Tickets.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md

Implement this ticket only.

Ticket:
T0013 - Add minimal I2C sniffer output

Branch:
ticket/t0013-minimal-i2c-sniffer

Goal:
Add minimal observable I2C sniffing output in I2C sniff mode so known I2C activity appears over USB CDC.

Dependencies:
- T0010 completed.
- T0011 completed.
- External I2C traffic source available for test stimulus.

Allowed areas:
- Core/Src/main.c
- Core/Inc/main.h only if needed
- Core/Src/stm32g0xx_it.c only if interrupt handling is required
- Core/Src/stm32g0xx_hal_msp.c only if a narrow verified interrupt/DMA enablement is required
- New small application source/header files only if needed
- CMakeLists.txt only if new application files are added
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md

Do not touch:
- UART sniffer behavior except preserving it
- INA236 measurement math
- USB CDC command set beyond preserving ESC+ENTER behavior
- Unrelated CubeMX peripheral settings

Requirements:
- In I2C sniff mode only, report observable I2C activity over USB CDC using simple text lines such as `I2C,...`.
- Keep decoding minimal; byte/event visibility is enough for MVP.
- Keep normal mode CSV, UART sniff behavior, and VCP mode selection intact.
- Keep ESC+ENTER behavior intact.
- Clearly document the limits of the MVP I2C sniff output.

Non-goals:
- Do not implement a full I2C protocol analyzer.
- Do not guarantee high-speed or lossless I2C capture.
- Do not implement active I2C master/control mode.
- Do not add binary logging.
- Do not change INA236 measurement behavior.

Acceptance criteria:
- Firmware builds successfully.
- In I2C sniff mode, known I2C traffic produces `I2C,...` output over USB CDC.
- Normal sense mode still streams CSV.
- UART sniff mode still reports UART bytes from T0012.
- ESC+ENTER still exits passive sniffing behavior.

Automated verification:
- Build Debug with the existing preset and a 20 second timeout.
- Flash `build/Debug/thesensor_v2.elf` using the validated ST-LINK/STM32CubeProgrammer under-reset workflow.
- Reset/run the target after flashing.
- Open or capture the USB CDC virtual COM port from the host.
- Send `ESC 2` to enter I2C sniff mode.
- Generate known I2C traffic on the configured external I2C lines.
- Confirm USB CDC output includes corresponding `I2C,...` lines.
- Send `ESC 1` and confirm normal CSV output resumes.

Manual verification:
- Build and flash firmware.
- Send `ESC 2` to enter I2C sniff mode.
- Generate known I2C traffic on the configured external I2C lines.
- Confirm USB CDC terminal shows corresponding `I2C,...` lines.
- Switch back to normal mode and confirm CSV resumes.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- cmake and build calls must be bounded with 20 second timeout.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets

---

We are working on TheSensor.

Before coding, review:
- AGENTS.md
- docs/Full_Design_Document.md
- docs/MVP_Technical_Design.md
- docs/Tickets.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md

Implement this ticket only.

Ticket:
T0014 - MVP integration verification and documentation pass

Branch:
ticket/t0014-mvp-integration-verification

Goal:
Perform an end-to-end MVP verification pass and update documentation with verified behavior, known limits, and follow-up tickets.

Dependencies:
- T0002 through T0013 completed.
- Hardware available for full manual verification.

Allowed areas:
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- docs/Known_Issues_And_Followups.md
- README.md only for a short MVP verification pointer if needed

Do not touch:
- Firmware source files
- CMake files
- VS Code configuration
- CubeMX `.ioc`

Requirements:
- Verify the MVP end to end:
  - USB CDC enumeration
  - Normal-mode CSV streaming
  - VCP mode switching with `ESC 1`, `ESC 2`, and `ESC 3`
  - I2C sniff output
  - UART sniff output
  - ESC+ENTER behavior
- Update manual verification docs with the final MVP flow.
- Update repo current state with what is now implemented and verified.
- Record known limitations and follow-up tickets.
- Do not change firmware during this ticket.

Non-goals:
- Do not fix firmware bugs in this ticket.
- Do not add new features.
- Do not refactor documentation structure beyond what is needed for clarity.
- Do not create production calibration or release documentation.

Acceptance criteria:
- Manual verification guide contains a complete MVP verification checklist.
- Automated verification flow uses VCP commands for mode changes instead of physical pin toggles.
- Repo current state accurately reflects implemented MVP behavior.
- Known issues/follow-ups are recorded.
- The final Debug build still succeeds.
- Any failed hardware checks are documented with clear follow-up recommendations.

Automated verification:
- Build Debug with the existing preset and a 20 second timeout.
- Flash `build/Debug/thesensor_v2.elf` using the validated ST-LINK/STM32CubeProgrammer under-reset workflow.
- Reset/run the target after flashing.
- Open or capture the USB CDC virtual COM port from the host.
- Confirm USB CDC enumeration and normal CSV output after `ESC 1`.
- Send `ESC 3`; generate known UART test bytes and confirm `UART,...` output.
- Send `ESC 2`; generate known I2C traffic and confirm `I2C,...` output.
- In each sniff mode, send `ESC` followed by Enter and confirm passive sniff exits or reports control placeholder.
- Record pass/fail notes and any hardware-only observations that cannot be automated.

Manual verification:
- Build Debug firmware.
- Flash the board.
- Run the full checklist from `docs/Manual_Verification_Guide.md`.
- Record pass/fail notes in the ticket implementation summary.
- Confirm docs match observed behavior.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- cmake and build calls must be bounded with 20 second timeout.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
