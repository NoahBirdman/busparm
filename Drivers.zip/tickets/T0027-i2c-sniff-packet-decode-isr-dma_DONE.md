# T0027 - I2C Sniff Packet Decode with ISR/DMA Capture

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- tools/run_hardware_verification.ps1
- tickets/T0018-automated-i2c-tests_DONE.md
- tickets/T0024-i2c-speed-detection-reporting.md

Implement this ticket only.

Ticket:
T0027 - I2C Sniff Packet Decode with ISR/DMA Capture

Branch:
ticket/t0027-i2c-sniff-packet-decode-isr-dma

Goal:
Replace the current aggregate I2C activity output with decoded I2C transaction lines using Bus Pirate-style packet characters, backed by interrupt-assisted and/or DMA-assisted line capture so the sniffer is not dependent on slow main-loop polling.

Dependencies:
- T0018 automated I2C stage exists.
- External I2C traffic source available, or observe-only manual verification available.
- STM32G0B1 reference manual/pin interrupt/DMA timer capture details reviewed before implementation.

Allowed areas:
- Core/Src/main.c
- Core/Inc/main.h only if needed
- Core/Src/stm32g0xx_it.c if IRQ handlers are required
- Core/Inc/stm32g0xx_it.h if IRQ prototypes are required
- Core/Src/stm32g0xx_hal_msp.c only for narrow timer/DMA/GPIO interrupt init needed by this ticket
- thesensor_v2.ioc only if CubeMX-generated interrupt/DMA/timer configuration is intentionally updated
- tools/run_hardware_verification.ps1
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md
- tickets/T0027-i2c-sniff-packet-decode-isr-dma.md only if recording implementation notes

Do not touch:
- INA236 I2C1 sensing behavior
- UART sniffer behavior except preserving it
- USB CDC low-level driver unless a narrow helper is required
- Normal sensing CSV behavior
- Runtime DFU behavior
- Board pin assignments other than the existing external I2C sniff pins

Requirements:
- In I2C sniff mode, decode external I2C traffic on:
  - `PB3` / `I2C2_EXT_SCL`
  - `PB4` / `I2C2_EXT_SDA`
- Use interrupt-assisted and/or DMA-assisted capture for the sniff input:
  - Minimum acceptable implementation: EXTI/IRQ capture on SCL rising edges and SDA transitions.
  - Preferred implementation when practical: timer input-capture and DMA ring buffer for timestamped SCL/SDA samples, decoded later in the main loop.
  - USB CDC transmission must remain outside ISR/DMA callbacks.
- Format decoded traffic with Bus Pirate-style characters:
  - `[` = START or repeated START
  - `]` = STOP
  - `0xXX` = data byte
  - `+` = ACK
  - `-` = NACK
  - `0xXXW` = 7-bit address plus write
  - `0xXXR` = 7-bit address plus read
- Emit one complete transaction per line, from first START through STOP.
- Repeated START stays on the same transaction line.
- Example outputs:
  - `[0x46W+0x00+0x12-]`
  - `[0x46W+0x00[0x46R+0x34+0x00+]`
- I2C sniff mode should be quiet when idle.
- Preserve mode commands:
  - `ESC 1`: normal sensing
  - `ESC 2`: I2C sniff
  - `ESC 3`: UART sniff
  - ESC+Enter exits passive sniffing
- Keep decode bounded; if a transaction exceeds the output buffer, emit a clear overflow/truncated marker and recover by STOP or next START.

Implementation notes:
- Do not decode directly in the interrupt unless the logic is tiny and bounded.
- Prefer ISR/DMA callbacks that enqueue compact edge/sample events:
  - timestamp
  - SCL level
  - SDA level
  - event type, such as SCL rising, SDA edge, overflow
- Decode queued events from the main loop while in `APP_MODE_I2C_SNIFF`.
- Detect START/STOP from SDA transitions while SCL is high.
- Sample SDA on SCL rising edges.
- Accumulate 8 data bits, then sample the 9th clock as ACK/NACK.
- Treat the first byte after each START/repeated START as address byte:
  - display `(byte >> 1)` as the 7-bit address
  - display `W` when bit 0 is 0
  - display `R` when bit 0 is 1
- Treat later bytes as data bytes.
- Queue complete transaction strings for USB CDC transmission from the main loop.
- Track and report capture overflow clearly. A dropped edge should invalidate the current transaction until the next START.
- Reset the capture/decode state when entering or leaving I2C sniff mode.

Non-goals:
- Do not implement active I2C master/control mode.
- Do not guarantee lossless decode at all I2C speeds until measured.
- Do not implement 10-bit address decode unless it is intentionally designed and tested.
- Do not implement protocol-specific register naming.
- Do not add persistent settings.
- Do not add a full protocol analyzer UI.

Acceptance criteria:
- Firmware builds successfully.
- Entering `ESC 2` enables interrupt/DMA-backed I2C packet sniffing.
- Known write transaction displays like:
  - `[0x46W+0x00+0x12-]`
- Known write-then-read transaction with repeated START displays like:
  - `[0x46W+0x00[0x46R+0x34+0x00+]`
- Each full START-to-STOP transaction ends with CRLF.
- Capture overflow produces a clear diagnostic line or marker and the decoder recovers on the next START.
- Existing normal sensing, UART sniffing, runtime DFU, and mode switching still work.
- Automated/manual I2C verification records decoded packet output.

Automated verification:
- Extend the I2C harness parser to detect decoded transaction lines.
- Keep observe-only mode, but parse Bus Pirate-style packets instead of `I2C,ACTIVITY,...`.
- If `-I2cStimulusCommand` is provided, run it and expect at least one decoded packet line.
- Confirm malformed/no-traffic cases fail clearly without crashing the harness.
- Confirm a capture-overflow diagnostic can be parsed if overflow is intentionally induced or simulated.

Manual verification:
- Wire I2C traffic source to PB3/PB4 with common ground and suitable pull-ups.
- Open USB CDC terminal.
- Send `ESC 2`.
- Generate a known I2C write transaction.
- Confirm one decoded transaction appears per line.
- Generate a write-then-read transaction with repeated START.
- Confirm the repeated START appears as `[` inside the same line.
- Send `ESC 1` and confirm normal sensing resumes.

Risks:
- EXTI edge capture should be much better than main-loop polling, but high-speed or very busy buses may still overflow if formatting/USB output cannot keep up.
- Timer input-capture plus DMA is more robust but may require CubeMX/ioc and MSP changes; keep those changes narrow and documented.
- The STM32G0B1 pin/EXTI/timer channel mapping may constrain whether both SCL and SDA can use the preferred capture method on PB3/PB4.

Implementation notes:
- Implemented the minimum acceptable interrupt-assisted path first:
  - `PB3` / `I2C2_EXT_SCL` and `PB4` / `I2C2_EXT_SDA` are reconfigured from I2C2 alternate-function pins to EXTI inputs only while `APP_MODE_I2C_SNIFF` is active.
  - `EXTI2_3_IRQHandler` handles SCL and `EXTI4_15_IRQHandler` handles SDA.
  - IRQ callbacks enqueue compact edge samples into a ring buffer.
  - Main-loop code decodes START, repeated START, STOP, bytes, ACK, and NACK, then emits Bus Pirate-style transaction lines over USB CDC.
- Implemented overflow diagnostics:
  - `I2C,OVERFLOW,capture_overflow`
  - `I2C,OVERFLOW,transaction_overflow`
  - `I2C,OVERFLOW,output_queue`
- Updated the hardware verification harness I2C stage to parse decoded packet lines and overflow diagnostics.
- Updated docs to describe decoded I2C output and the new report fields.
- Timer/DMA capture remains a follow-up optimization if EXTI capture is not sufficient at the target bus speeds.

Verification:
- Direct compile of `Core/Src/main.c` passed.
- Direct compile of `Core/Src/stm32g0xx_it.c` passed.
- Direct generated link of `build/Debug/thesensor_v2.elf` passed.
- `pwsh -NoProfile -File tools/run_hardware_verification.ps1 -Help` passed.
- Hardware packet decode still needs external I2C traffic connected to `PB3/PB4`.
