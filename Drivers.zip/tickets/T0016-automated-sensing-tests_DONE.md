# T0016 - Automated Sensing Tests

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- tools/ automated test harness from T0015
- tickets/T0016-automated-sensing-tests_DONE.md

Implement this ticket only.

Ticket:
T0016 - Automated Sensing Tests

Branch:
ticket/t0016-automated-sensing-tests

Goal:
Extend the T0015 automated harness with sensing-mode checks so normal measurement output is verified before new debug-tool features are added.

Dependencies:
- T0015 completed.
- T0014 firmware behavior still present.
- USB CDC capture works with the target board.

Allowed areas:
- tools/
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md
- tickets/T0016-automated-sensing-tests_DONE.md only if recording implementation notes

Do not touch:
- Core/
- Drivers/
- Middlewares/
- USB_Device/
- cmake/
- CMakeLists.txt
- CMakePresets.json
- thesensor_v2.ioc
- Firmware behavior

Requirements:
- Add a sensing test stage to the automated harness.
- Send `ESC 0` over USB CDC/VCP to force normal sense mode before validating output.
- Capture enough VCP output to detect:
  - `mode=normal_sense` if emitted.
  - CSV header `timestamp_ms,bus_voltage_v,current_a,power_w`.
  - At least one measurement row or a visible `INA236_CSV_ERR` line.
- Validate that the firmware continues producing output after the normal-mode command.
- Record parsed sensing results in the report.
- Include measured/captured timing in the report when practical.
- Treat INA236 read error output as a sensing-path pass with warning, not as a harness failure, unless the ticket implementation deliberately requires live sensor success.

Non-goals:
- Do not add tabular output firmware support yet.
- Do not change INA236 scaling or calibration.
- Do not compare measurements against an external meter.
- Do not add UART or I2C stimulus checks.
- Do not change VCP commands.

Acceptance criteria:
- The harness has a selectable sensing test stage.
- The report clearly shows whether normal sensing output was detected.
- The report includes captured sensing lines or concise excerpts.
- If INA236 is missing/unresponsive, the test distinguishes firmware-visible error output from total output failure.
- Documentation includes the sensing automation command and expected report fields.

Automated verification:
- Run the harness sensing stage with hardware connected.
- Confirm the harness sends `ESC 0`.
- Confirm the generated report marks sensing output pass when a CSV header and row or `INA236_CSV_ERR` are captured.
- Confirm the report fails the sensing stage if no recognizable normal-mode output is captured within the timeout.
- Run with an intentionally wrong COM port and confirm the report records a VCP failure cleanly.

Manual verification:
- Build and flash the Debug ELF using the harness.
- Observe the generated report.
- Open a terminal after the test and confirm the board still streams normal sensing output.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- All hardware operations must use bounded timeouts.

Completion step:
- After implementation and verification, mark this ticket complete by renaming this file with a `_DONE` suffix before `.md`.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
