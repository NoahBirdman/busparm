# T0020 - VCP Line Coding and Default Baud Reporting

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- tools/ automated test harness
- tickets/T0020-vcp-line-coding-default-baud.md

Implement this ticket only.

Ticket:
T0020 - VCP Line Coding and Default Baud Reporting

Branch:
ticket/t0020-vcp-line-coding-default-baud

Goal:
Increase the USB CDC/VCP default line-coding baud reported to the host and make the firmware report the active host-selected VCP line coding for easier terminal setup and diagnostics.

Dependencies:
- T0019 completed.
- Automated harness can capture VCP output.

Allowed areas:
- USB_Device/App/usbd_cdc_if.c
- USB_Device/App/usbd_cdc_if.h
- Core/Src/main.c
- Core/Inc/main.h only if needed
- Application modules added in T0019
- tools/
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md
- tickets/T0020-vcp-line-coding-default-baud.md only if recording implementation notes

Do not touch:
- Drivers/
- Middlewares/
- cmake/
- CMakePresets.json
- thesensor_v2.ioc
- UART sniffer baud behavior, except reporting VCP line coding separately
- I2C sniffer behavior

Requirements:
- Implement CDC `GET_LINE_CODING` and `SET_LINE_CODING` handling.
- Set the default CDC line coding to a higher host-visible baud rate, recommended `921600 8N1` unless testing shows a better value.
- Store the current host-selected line coding.
- Provide a small getter so application code can report the current VCP line coding.
- Emit VCP line-coding status at startup or in a clear status line without breaking strict CSV mode expectations.
- Update the automated harness to validate the reported default or selected VCP baud when practical.
- Document that USB CDC does not electrically use UART baud, but terminal programs still display/set line coding.

Non-goals:
- Do not change USART2 sniff baud.
- Do not implement UART autobaud.
- Do not use the VCP baud as UART sniffer baud yet.
- Do not add persistent settings.

Acceptance criteria:
- Firmware builds successfully.
- USB CDC still enumerates.
- Host terminal can open the device at the new default/reported baud.
- Firmware reports the active VCP line coding.
- Existing mode commands and output still work.
- Automated harness captures and records VCP line-coding status.

Automated verification:
- Run the harness full suite.
- Confirm USB CDC capture includes VCP line-coding status or the harness can query/set line coding and record it.
- Confirm sensing, UART, and I2C tests are not regressed.
- If the harness can set line coding, set a non-default VCP baud and confirm firmware reports the updated value.

Manual verification:
- Open the USB CDC port in a terminal at the new default baud setting.
- Confirm output appears normally.
- Change terminal baud if supported and confirm firmware reports the updated line coding.
- Send `ESC 1`, `ESC 2`, and `ESC 3` and confirm mode switching still works.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- All build/test commands must be bounded with timeouts.

Completion step:
- After implementation and verification, mark this ticket complete by renaming this file with a `_DONE` suffix before `.md`.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
