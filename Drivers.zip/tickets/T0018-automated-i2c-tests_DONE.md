# T0018 - Automated I2C Tests

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- tools/ automated test harness from T0015 through T0017
- tickets/T0018-automated-i2c-tests.md

Implement this ticket only.

Ticket:
T0018 - Automated I2C Tests

Branch:
ticket/t0018-automated-i2c-tests

Goal:
Extend the automated harness with I2C sniffer verification so known or observed I2C activity can be checked before I2C speed detection and improved reporting are implemented.

Dependencies:
- T0015 completed.
- T0016 completed.
- T0017 completed.
- T0013 I2C activity firmware behavior still present.
- A host-accessible I2C stimulus source is available, or a documented way exists to run the test in observe-only mode.

Allowed areas:
- tools/
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md
- tickets/T0018-automated-i2c-tests.md only if recording implementation notes

Do not touch:
- Core/
- Drivers/
- Middlewares/
- USB_Device/
- cmake/
- CMakeLists.txt
- CMakePresets.json
- thesensor_v2.ioc
- Firmware behavior

Requirements:
- Add an I2C test stage to the automated harness.
- Send `ESC 2` over USB CDC/VCP to enter I2C sniff mode.
- Support an observe-only mode that waits for external I2C activity on `PB3/PB4`.
- If a supported host I2C stimulus tool is available, generate a small known I2C transaction on the external I2C lines.
- Capture and parse USB CDC output for `I2C,ACTIVITY,...` lines.
- Record observed line activity, edge counts, start-like counts, stop-like counts, and pass/fail in the report.
- Include a placeholder report field for detected I2C bus speed so later feature tickets can fill it.
- If no stimulus path is configured, mark stimulus generation skipped but still allow observe-only capture.

Non-goals:
- Do not implement I2C speed detection yet.
- Do not implement full I2C protocol decode.
- Do not change I2C firmware output.
- Do not require the harness to support every possible I2C adapter.
- Do not drive the target board I2C pins from firmware.

Acceptance criteria:
- The harness can run the I2C test independently or as part of the full suite.
- With known external I2C activity on `PB3/PB4`, the report detects at least one `I2C,ACTIVITY,...` line.
- Without configured stimulus, the report clearly states whether observe-only mode saw activity or timed out.
- Documentation describes required wiring and current limitations.

Automated verification:
- Run the I2C stage without configured stimulus and confirm the report marks stimulus skipped and observe-only result pass/fail based on captured activity.
- Wire an I2C traffic source to:
  - SCL to STM32 `PB3` / `I2C2_EXT_SCL`.
  - SDA to STM32 `PB4` / `I2C2_EXT_SDA`.
  - Common ground.
- Run the I2C stage and confirm the report captures `I2C,ACTIVITY,...`.
- Disconnect one I2C line and rerun to confirm the report records a clear I2C observation failure or partial activity note.

Manual verification:
- Confirm external I2C wiring and pull-ups are appropriate for the connected hardware.
- Run the harness I2C stage.
- Inspect the report for observed activity and any skipped stimulus notes.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- All hardware operations must use bounded timeouts.

Completion step:
- After implementation and verification, mark this ticket complete by renaming this file with a `_DONE` suffix before `.md`.

Implementation notes:
- Added an `i2c` stage to `tools/run_hardware_verification.ps1`.
- Added observe-only I2C capture plus optional `-I2cStimulusCommand`.
- The report parses `I2C,ACTIVITY,...` lines and records aggregate edge/start/stop counts plus `detected_i2c_speed_hz=null`.
- Verified observe-only behavior with `COM24` in `build/hardware-verification/t0018-i2c-observe-only.json`.
- Positive activity verification still requires external I2C traffic on `PB3/PB4`; none was connected during this ticket.
- This ticket is complete and has been renamed with `_DONE`.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
