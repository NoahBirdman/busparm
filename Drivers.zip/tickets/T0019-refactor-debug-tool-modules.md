# T0019 - Refactor Debug Tool Modules

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- tools/ automated test harness from T0015 through T0018
- tickets/T0019-refactor-debug-tool-modules.md

Implement this ticket only.

Ticket:
T0019 - Refactor Debug Tool Modules

Branch:
ticket/t0019-refactor-debug-tool-modules

Goal:
Refactor the growing firmware logic into small debug-tool modules so later VCP formatting, UART autobaud, dual-channel sniffing, and I2C speed detection can be implemented without continuing to expand `main.c`.

Dependencies:
- T0015 through T0018 completed.
- Automated sensing, UART, and I2C harness stages available.

Allowed areas:
- Core/Src/main.c
- Core/Inc/main.h only if needed
- New small application source/header files under Core/Src and Core/Inc
- CMakeLists.txt only if needed to add new source files
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md
- tickets/T0019-refactor-debug-tool-modules.md only if recording implementation notes

Do not touch:
- Drivers/
- Middlewares/
- USB_Device/ unless a compile-only include adjustment is required
- cmake/stm32cubemx generated files unless necessary to add sources through the root CMake target
- thesensor_v2.ioc
- Firmware behavior beyond preserving current behavior

Requirements:
- Move user-code logic from `main.c` into focused modules where practical:
  - App mode/parser state.
  - USB text/report formatting helpers.
  - INA236 measurement helpers.
  - UART sniffer helpers.
  - I2C sniffer helpers.
- Keep CubeMX-generated initialization functions in `main.c`.
- Preserve all existing USB CDC command behavior:
  - `ESC 1`, `ESC 2`, `ESC 3`.
  - `ESC` followed by CR/LF exiting passive sniff modes.
- Preserve normal CSV output.
- Preserve current UART and I2C sniffer output shapes.
- Keep changes inside CubeMX user-code-safe regions when touching generated files.
- Build with the existing Debug preset or documented direct build workaround.

Non-goals:
- Do not add new VCP commands.
- Do not change output formatting.
- Do not add autobaud.
- Do not add USART5/PB1.
- Do not add I2C speed detection.
- Do not alter INA236 scaling.

Acceptance criteria:
- Firmware behavior observed by the automated harness remains unchanged.
- `main.c` is smaller and primarily owns initialization and top-level loop orchestration.
- New modules have clear headers and minimal public interfaces.
- Debug build or direct compile/link verification succeeds.
- Automated sensing, UART, and I2C harness stages pass or report the same hardware-dependent skips as before.

Automated verification:
- Run the T0015-T0018 harness full suite after the refactor.
- Confirm sensing output still includes the CSV header and measurement/error rows.
- Confirm UART test behavior is unchanged when stimulus is provided or skipped.
- Confirm I2C test behavior is unchanged when activity is provided or skipped.
- Confirm the generated report shows no regressions compared with the pre-refactor baseline.

Manual verification:
- Inspect `main.c` and new modules for CubeMX-safe boundaries.
- Open USB CDC terminal and manually send `ESC 1`, `ESC 2`, `ESC 3`, and `ESC` plus Enter in sniff modes.
- Confirm output behavior matches T0014 behavior.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- All build/test commands must be bounded with timeouts.

Completion step:
- After implementation and verification, mark this ticket complete by renaming this file with a `_DONE` suffix before `.md`.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
