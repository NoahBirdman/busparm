# T0017A - Fix UART Burst Overrun With RX Buffer

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- docs/Known_Issues_And_Followups.md
- tools/ automated test harness from T0015 through T0017
- tickets/T0017A-uart-burst-buffer_DONE.md

Implement this ticket only.

Ticket:
T0017A - Fix UART Burst Overrun With RX Buffer

Branch:
ticket/t0017a-uart-burst-buffer

Goal:
Fix the current UART sniffer burst-overrun behavior by buffering received UART bytes before formatting and transmitting them over USB CDC.

Dependencies:
- T0017 completed.
- COM23 UART stimulus path verified against STM32 `PA3` / `USART2_RX`.

Allowed areas:
- Core/Src/main.c
- tools/run_hardware_verification.ps1
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md
- tickets/T0017A-uart-burst-buffer_DONE.md only if recording implementation notes

Do not touch:
- CubeMX `.ioc`
- USB CDC low-level driver
- I2C sniffer behavior
- INA236 measurement behavior

Requirements:
- UART sniff mode must not emit idle status messages.
- UART sniff mode must buffer received UART bytes before USB CDC formatting/transmit.
- A tight host-generated `55 48 69` burst at `115200 8N1` must be captured as three `UART,RX,0xNN` lines.
- Keep output limited to mode transition lines and received UART packets.

Non-goals:
- Do not implement interrupt/DMA UART capture in this ticket.
- Do not implement UART autobaud.
- Do not add PB1/USART5_RX.
- Do not guarantee lossless high-throughput capture.

Acceptance criteria:
- Firmware builds successfully.
- `UART,RX` output for tight three-byte COM23 stimulus includes `0x55`, `0x48`, and `0x69`.
- Delayed UART stimulus still passes.
- Normal sensing and VCP mode selection are not regressed.

Automated verification:
- Run the harness with `-Port COM24 -Stages uart -UartPort COM23 -UartInterByteDelayMs 0 -UartPatternHex "55 48 69"`.
- Confirm `uart_sniff` passes and observed bytes match the requested pattern.
- Run the harness with the default `5 ms` inter-byte delay and confirm it still passes.

Manual verification:
- Confirm COM23 TX is wired to STM32 `PA3` / `USART2_RX`.
- Confirm common ground is connected.
- Open USB CDC output and confirm UART sniff mode is quiet until UART bytes arrive.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Avoid unnecessary dependencies.
- Keep changes small and testable.

Completion step:
- This ticket is complete and has been renamed with `_DONE`.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
