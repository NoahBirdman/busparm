# T0021 - Terminal Tabular Formatting While Preserving CSV

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- tools/ automated test harness
- tickets/T0021-terminal-tabular-formatting.md

Implement this ticket only.

Ticket:
T0021 - Terminal Tabular Formatting While Preserving CSV

Branch:
ticket/t0021-terminal-tabular-formatting

Goal:
Make normal sensing output easier to read in a terminal by adding tab-separated/table-friendly formatting while preserving strict CSV output for tools.

Dependencies:
- T0020 completed.
- Automated sensing test stage available.

Allowed areas:
- Core/Src/main.c
- Core/Inc/main.h only if needed
- Application modules added in T0019
- tools/
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md
- tickets/T0021-terminal-tabular-formatting.md only if recording implementation notes

Do not touch:
- USB CDC low-level driver unless a narrow helper is required
- UART sniffer behavior
- I2C sniffer behavior
- INA236 scaling or calibration
- thesensor_v2.ioc

Requirements:
- Preserve strict CSV output mode with the existing header:
  - `timestamp_ms,bus_voltage_v,current_a,power_w`
- Add a terminal-friendly tab-separated mode with aligned or tab-delimited columns.
- Add simple VCP commands to switch formatting modes, recommended:
  - `ESC C` for strict CSV.
  - `ESC T` for tabular/tab-separated terminal output.
- Choose a default that is friendlier for humans without destroying automation. If changing default from CSV, update tests/docs explicitly.
- In tabular mode, include column labels and use tabs between columns.
- Keep error output readable in both modes.
- Update the automated sensing test to validate both CSV and tabular modes.

Non-goals:
- Do not add binary logging.
- Do not add persistent formatting settings.
- Do not change measurement units.
- Do not add a full command shell.
- Do not implement UART/I2C formatting changes beyond preserving existing output.

Acceptance criteria:
- Firmware builds successfully.
- `ESC C` selects strict CSV output.
- `ESC T` selects tabular/tab-separated output.
- Existing `ESC 1`, `ESC 2`, `ESC 3`, and ESC+Enter behavior still works.
- Automated sensing tests validate both output formats.
- Documentation describes the two formats and commands.

Automated verification:
- Run the sensing harness stage.
- Confirm the harness sends `ESC C` and detects the strict CSV header and row/error shape.
- Confirm the harness sends `ESC T` and detects tab-separated headers/rows.
- Confirm switching between formats does not require reset.
- Run UART and I2C harness stages to confirm mode switching is not regressed.

Manual verification:
- Open USB CDC terminal.
- Send `ESC C` and confirm CSV output.
- Send `ESC T` and confirm tab-separated output is easier to read.
- Switch back to `ESC C` and confirm strict CSV resumes.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- All build/test commands must be bounded with timeouts.

Completion step:
- After implementation and verification, mark this ticket complete by renaming this file with a `_DONE` suffix before `.md`.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
