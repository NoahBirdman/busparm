# T0024 - I2C Speed Detection and Improved Activity Reporting

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- tools/ automated test harness
- tickets/T0024-i2c-speed-detection-reporting.md

Implement this ticket only.

Ticket:
T0024 - I2C Speed Detection and Improved Activity Reporting

Branch:
ticket/t0024-i2c-speed-detection-reporting

Goal:
Detect and report observed I2C bus speed in I2C sniff mode, then improve the current aggregate activity output without attempting a full protocol analyzer.

Dependencies:
- T0023 completed.
- Automated I2C test stage available.
- External I2C traffic source or observe-only test path available.

Allowed areas:
- Core/Src/main.c
- Core/Inc/main.h only if needed
- Core/Src/stm32g0xx_it.c only if interrupt/timer capture handling is required
- Core/Src/stm32g0xx_hal_msp.c only if narrow timer/GPIO support is required
- Application modules added in T0019
- thesensor_v2.ioc only if a verified timer/input-capture configuration is needed
- tools/
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md
- tickets/T0024-i2c-speed-detection-reporting.md only if recording implementation notes

Do not touch:
- UART sniffer behavior except preserving it
- INA236 measurement behavior
- USB CDC command behavior except reporting I2C speed/status
- Unrelated CubeMX peripheral settings

Requirements:
- Measure observed SCL timing on the external I2C sniff pins:
  - `PB3` / `I2C2_EXT_SCL`.
  - `PB4` / `I2C2_EXT_SDA`.
- Report detected I2C bus speed using a parseable line, for example:
  - `I2C,BAUD,detected_hz=100000,class=standard`
- Classify common speeds when possible:
  - Standard mode around `100 kHz`.
  - Fast mode around `400 kHz`.
  - Fast mode plus around `1 MHz` only if measurement is reliable.
- Preserve aggregate activity reporting and add speed fields when useful.
- Improve activity output enough to be easier to diagnose, such as reporting observed idle level, start-like count, stop-like count, edge count, and speed estimate.
- Do not claim full address/data decode unless actually implemented and verified.
- Update automated I2C tests to validate speed reporting when a known-speed stimulus source is available.

Non-goals:
- Do not implement full I2C protocol decode.
- Do not guarantee lossless high-speed capture.
- Do not drive I2C as a firmware master.
- Do not change INA236 I2C behavior.
- Do not add persistent settings.

Acceptance criteria:
- Firmware builds successfully.
- In I2C sniff mode, known I2C traffic produces `I2C,BAUD,...` or equivalent speed-report output.
- Activity output remains visible and parseable.
- Automated I2C report includes detected speed or a clear reason speed was not detected.
- Sensing and UART harness stages are not regressed.

Automated verification:
- Run the I2C harness stage in observe-only mode and confirm speed is reported when enough SCL edges are captured, or marked unknown with a clear reason.
- If a known-speed I2C stimulus source is available, run at `100 kHz` and confirm the detected class is standard.
- If supported, run at `400 kHz` and confirm the detected class is fast.
- Confirm the report records detected speed, class, edge counts, and activity lines.
- Run sensing and UART stages to confirm no regressions.

Manual verification:
- Wire I2C traffic source to PB3/PB4 with common ground and appropriate pull-ups.
- Enter I2C sniff mode with `ESC 2`.
- Generate known-speed I2C traffic.
- Confirm USB CDC reports detected speed and activity.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- All build/test commands must be bounded with timeouts.

Completion step:
- After implementation and verification, mark this ticket complete by renaming this file with a `_DONE` suffix before `.md`.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
