# T0023 - UART Dual-Channel Sniffing on PB1 / USART5_RX

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- tools/ automated test harness
- tickets/T0023-uart-dual-channel-pb1-usart5-rx.md

Implement this ticket only.

Ticket:
T0023 - UART Dual-Channel Sniffing on PB1 / USART5_RX

Branch:
ticket/t0023-uart-dual-channel-pb1-usart5-rx

Goal:
Add a second passive UART sniff input on pin 16 / `PB1` / `USART5_RX` so the tool can observe both sides of a UART link by jumpering the target TX line to PB1.

Dependencies:
- T0022 completed.
- Automated UART test stage supports stimulus and baud reporting.
- Pin 16 / PB1 electrical availability has been confirmed for the board.

Allowed areas:
- Core/Src/main.c
- Core/Inc/main.h
- Core/Src/stm32g0xx_hal_msp.c
- Core/Src/stm32g0xx_it.c only if interrupt handling is required
- Application modules added in T0019
- thesensor_v2.ioc only if updating CubeMX pin/peripheral assignment is required and verified
- CMakeLists.txt only if new files are added
- tools/
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md
- tickets/T0023-uart-dual-channel-pb1-usart5-rx.md only if recording implementation notes

Do not touch:
- I2C sniffer behavior except preserving it
- INA236 measurement behavior
- USB CDC command behavior except reporting dual-channel UART status
- Unrelated CubeMX peripheral settings

Requirements:
- Configure `PB1` as `USART5_RX` for passive UART sniff input.
- Add a `UART_HandleTypeDef` or low-level USART5 receive path as appropriate.
- Preserve the existing USART2 RX path on `PA3`.
- Define clear channel names in output. Recommended mapping:
  - `PA3` / `USART2_RX` as `RX`.
  - `PB1` / `USART5_RX` as `TX`.
- In UART sniff mode, report observed bytes with channel and baud, for example:
  - `UART,RX,baud=115200,byte=0x48`
  - `UART,TX,baud=115200,byte=0x4F`
- Preserve or extend UART autobaud reporting for both channels.
- Document wiring:
  - Target RX-side signal to existing `PA3` if needed.
  - Target TX-side signal jumpered to pin 16 / `PB1` / `USART5_RX`.
  - Common ground required.
- Update automated UART tests to validate at least one channel and, when two stimulus sources are configured, both channels.

Non-goals:
- Do not implement UART transmit/control mode.
- Do not decode higher-level protocols.
- Do not guarantee lossless high-speed capture.
- Do not change I2C pins or behavior.

Acceptance criteria:
- Firmware builds successfully.
- PB1/USART5 RX is initialized without breaking USB, ST-LINK, INA236, or I2C2.
- UART sniff output identifies channel direction.
- Existing single-channel UART test still passes.
- Dual-channel UART test passes when both stimulus paths are wired/configured.
- Documentation records pin/peripheral mapping and jumper workflow.

Automated verification:
- Run the UART harness stage with existing single-channel stimulus and confirm no regression.
- If a second stimulus source is available, drive known bytes into PB1 and confirm `UART,TX,...` output.
- If two stimulus sources are available, drive distinct byte patterns into PA3 and PB1 and confirm the report maps them to different channels.
- Run sensing and I2C harness stages to confirm no regressions.

Manual verification:
- Confirm PB1/pin 16 wiring on the board.
- Jumper target TX to PB1 / USART5_RX.
- Enter UART sniff mode with `ESC 3`.
- Send traffic and confirm USB CDC emits direction-tagged `UART,...` lines.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- All build/test commands must be bounded with timeouts.

Completion step:
- After implementation and verification, mark this ticket complete by renaming this file with a `_DONE` suffix before `.md`.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
