# T0022 - UART Autobaud Detection

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- tools/ automated test harness
- tickets/T0022-uart-autobaud-detection.md

Implement this ticket only.

Ticket:
T0022 - UART Autobaud Detection

Branch:
ticket/t0022-uart-autobaud-detection

Goal:
Add UART baud detection for sniff mode and report the detected baud before or alongside observed UART bytes.

Dependencies:
- T0021 completed.
- Automated UART test stage available.
- Current UART sniff path on `PA3` / `USART2_RX` works with fixed baud stimulus.

Allowed areas:
- Core/Src/main.c
- Core/Inc/main.h only if needed
- Application modules added in T0019
- Core/Src/stm32g0xx_it.c only if interrupt handling is required
- Core/Src/stm32g0xx_hal_msp.c only if narrow verified timer/UART support is required
- tools/
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md
- tickets/T0022-uart-autobaud-detection.md only if recording implementation notes

Do not touch:
- I2C sniffer behavior except preserving it
- INA236 measurement behavior
- USB CDC command behavior except adding narrow UART baud status if needed
- thesensor_v2.ioc unless a verified CubeMX setting blocks implementation

Requirements:
- Detect UART baud for the current UART sniff input.
- Prefer STM32 USART autobaud support when the stimulus pattern allows it.
- If hardware autobaud is not reliable for arbitrary traffic, add a conservative edge-timing fallback.
- Support common debug baud rates at minimum:
  - 9600
  - 19200
  - 38400
  - 57600
  - 115200
  - 230400
  - 460800
  - 921600
- Report detected baud over USB CDC using a parseable line, for example:
  - `UART,BAUD,detected=115200,source=edge_timing,confidence=high`
- Configure the UART receiver to the detected baud before reporting bytes when practical.
- Provide a clear failure report if baud cannot be detected.
- Update the automated UART test to verify baud detection at one or more supported rates.

Non-goals:
- Do not add the PB1/USART5_RX second channel yet.
- Do not decode UART protocols.
- Do not implement high-throughput binary logging.
- Do not use VCP line coding as the sole baud source.
- Do not guarantee autobaud for every arbitrary byte pattern.

Acceptance criteria:
- Firmware builds successfully.
- In UART sniff mode, known UART stimulus produces a `UART,BAUD,...` line.
- Detected baud is included in the automated UART report.
- UART byte capture still works after baud detection.
- If detection fails, firmware stays responsive and reports a visible failure.

Automated verification:
- Run the UART harness stage at `115200` and confirm detected baud is reported as `115200` or within an explicitly documented tolerance/classification.
- If the stimulus source supports multiple rates, run at one lower rate and one higher rate and confirm detection.
- Confirm expected UART bytes are still observed after detection.
- Confirm sensing and I2C harness stages are not regressed.

Manual verification:
- Connect UART stimulus TX to STM32 `PA3` and common ground.
- Enter UART sniff mode with `ESC 3`.
- Send a known autobaud-friendly pattern such as `0x55` followed by test bytes.
- Confirm USB CDC reports detected baud and observed bytes.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- All build/test commands must be bounded with timeouts.

Completion step:
- After implementation and verification, mark this ticket complete by renaming this file with a `_DONE` suffix before `.md`.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
