# T0017B - UART Sniff Display and Flush Modes

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- docs/Known_Issues_And_Followups.md
- tools/run_hardware_verification.ps1
- tickets/T0017B-uart-display-flush-modes_DONE.md

Implement this ticket only.

Ticket:
T0017B - UART Sniff Display and Flush Modes

Branch:
ticket/t0017b-uart-display-flush-modes

Goal:
Make UART sniff output easier to read in a terminal by default while keeping a selectable hex view and configurable packet flush policy.

Dependencies:
- T0017 completed.
- T0017A UART receive buffering completed.
- COM23 UART stimulus path verified against STM32 `PA3` / `USART2_RX`.

Allowed areas:
- Core/Src/main.c
- tools/run_hardware_verification.ps1
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md
- tickets/T0017B-uart-display-flush-modes_DONE.md only if recording implementation notes

Do not touch:
- CubeMX `.ioc`
- USB CDC low-level driver
- I2C sniffer behavior
- INA236 measurement behavior

Requirements:
- Remove the leading `UART` packet prefix from UART sniff payload output while keeping the channel prefix `RX,`.
- Make the default UART sniff display output `RX,` followed by the same ASCII characters that were received.
- Add an ESC command sequence to toggle UART character display between ASCII and ASCII hex.
- Add ESC command sequences to set UART send policy between line-ending flush, byte-timeout flush, and buffer-full flush.
- Extend the automated hardware verification harness to exercise the new display and flush modes.

Command sequences:
- `ESC 1`: enter UART sniff mode.
- `ESC H`: toggle display mode between ASCII and ASCII hex.
- `ESC L`: flush when a line ending is received.
- `ESC B`: flush after the byte timeout.
- `ESC F`: flush only when the packet buffer is full.
- Each option command prints an `option=... mode=...` status line after the mode changes.

Non-goals:
- Do not implement UART autobaud detection.
- Do not add PB1/USART5_RX.
- Do not implement interrupt/DMA UART capture.
- Do not change sensing or I2C output formats.

Acceptance criteria:
- Firmware builds successfully.
- Default UART sniff output for `55 48 69` is `RX,UHi` with no `UART` prefix.
- Hex display mode outputs `RX,55 48 69`.
- Line flush mode emits data after a line ending.
- Buffer-full mode emits data after the packet buffer fills.
- Automated verification reports pass/fail for the selected UART display and flush mode.

Automated verification:
- Run the harness with `-Port COM24 -Stages uart -UartPort COM23 -UartDisplayMode ascii -UartFlushMode timeout -UartPatternHex "55 48 69"`.
- Run the harness with `-Port COM24 -Stages uart -UartPort COM23 -UartDisplayMode hex -UartFlushMode timeout -UartPatternHex "55 48 69"`.
- Run the harness with `-Port COM24 -Stages uart -UartPort COM23 -UartDisplayMode ascii -UartFlushMode line -UartPatternHex "48 69 0A"`.
- Run the harness with `-Port COM24 -Stages uart -UartPort COM23 -UartDisplayMode ascii -UartFlushMode full` and a packet-buffer-sized ASCII pattern.

Manual verification:
- Confirm COM23 TX is wired to STM32 `PA3` / `USART2_RX`.
- Confirm common ground is connected.
- Open USB CDC output and confirm UART sniff mode is quiet until UART bytes arrive.
- Send ASCII text and confirm the default terminal output is the same text.
- Toggle hex display with `ESC H` and confirm the same bytes render as uppercase hex pairs.
- Confirm every UART packet ends with CRLF so the terminal cursor advances to the next line.
- Confirm display and flush option changes print a status line such as `option=uart_display mode=hex` or `option=uart_flush mode=line`.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Avoid unnecessary dependencies.
- Keep changes small and testable.

Completion step:
- This ticket is complete and has been renamed with `_DONE`.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
