# T0015 - Automated Test Harness Skeleton

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Tickets.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- docs/Known_Issues_And_Followups.md
- tickets/T0015-automated-test-harness-skeleton_DONE.md

Implement this ticket only.

Ticket:
T0015 - Automated Test Harness Skeleton

Branch:
ticket/t0015-automated-test-harness-skeleton

Goal:
Create the first version of an automated hardware verification harness that can build, flash, reset/run, discover or accept the USB CDC/VCP port, capture firmware output, and produce a clear pass/fail report.

Dependencies:
- T0014 completed.
- STM32CubeProgrammer CLI available.
- ST-LINK and target board available for hardware verification.
- USB CDC connection available for runtime capture.

Allowed areas:
- tools/
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md
- tickets/T0015-automated-test-harness-skeleton_DONE.md only if recording implementation notes

Do not touch:
- Core/
- Drivers/
- Middlewares/
- USB_Device/
- cmake/
- CMakeLists.txt
- CMakePresets.json
- thesensor_v2.ioc
- Firmware behavior

Requirements:
- Add a host-side script under `tools/` for automated hardware verification.
- The script must run from the repository root on Windows PowerShell.
- Support command-line options for:
  - Build preset, default `Debug`.
  - ELF path, default `build/Debug/thesensor_v2.elf`.
  - STM32CubeProgrammer CLI path override.
  - VCP/COM port override.
  - Output report path.
  - Timeouts.
- Build using the existing CMake preset flow.
- Flash using the validated ST-LINK under-reset path:
  - `port=SWD mode=UR reset=HWrst`
- Reset/run the target after flashing.
- Discover the USB CDC COM port if practical; otherwise accept a required `--port COMx` option and report discovery as skipped.
- Capture VCP output for a bounded interval.
- Produce a machine-readable report, preferably JSON, and a concise terminal summary.
- Report each step as pass, fail, or skipped with command output excerpts.
- Handle known build-wrapper timeout behavior without hanging forever.

Non-goals:
- Do not add UART stimulus generation yet.
- Do not add I2C stimulus generation yet.
- Do not change firmware output.
- Do not require new firmware commands.
- Do not solve the known CMake/Ninja shell timeout unless a narrow harness workaround is needed.
- Do not add CI.

Acceptance criteria:
- The script can be invoked from the repo root.
- The script has `--help` output.
- The script writes a report file even if a step fails.
- Build, flash, reset/run, and VCP capture steps are represented in the report.
- Hardware-only steps can fail gracefully with actionable messages.
- Manual docs explain how to run the harness.

Automated verification:
- Run the script with `--help` and confirm it exits successfully.
- Run the script with a short timeout and no hardware, if hardware is unavailable, and confirm it writes a report with clear failed or skipped hardware steps.
- With hardware connected, run the script against the Debug preset and confirm the report includes:
  - Build step result.
  - Flash step result.
  - Reset/run step result.
  - VCP capture step result.
  - Captured output excerpt.
- Confirm the script exits nonzero when required verification fails.

Manual verification:
- Connect ST-LINK and target board.
- Connect USB CDC to the host.
- Run the harness from PowerShell.
- Open the generated report and confirm each step is understandable.
- Compare the flash/reset command path against the T0014 verified workflow.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- All external commands must use bounded timeouts.

Completion step:
- After implementation and verification, mark this ticket complete by renaming this file with a `_DONE` suffix before `.md`.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
