# T0017 - Automated UART Tests

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- tools/ automated test harness from T0015/T0016
- tickets/T0017-automated-uart-tests_DONE.md

Implement this ticket only.

Ticket:
T0017 - Automated UART Tests

Branch:
ticket/t0017-automated-uart-tests

Goal:
Extend the automated harness with UART sniffer verification so known UART stimulus can be generated and checked before UART autobaud and dual-channel sniffing are implemented.

Dependencies:
- T0015 completed.
- T0016 completed.
- T0012 UART sniffer firmware behavior still present.
- A host-accessible UART stimulus source is available, either from an ST-LINK VCP/UART bridge or another serial adapter.

Allowed areas:
- tools/
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md
- tickets/T0017-automated-uart-tests_DONE.md only if recording implementation notes

Do not touch:
- Core/
- Drivers/
- Middlewares/
- USB_Device/
- cmake/
- CMakeLists.txt
- CMakePresets.json
- thesensor_v2.ioc
- Firmware behavior

Requirements:
- Add a UART test stage to the automated harness.
- Support a command-line option for the UART stimulus port.
- Support a UART baud option, defaulting to the current firmware baud `115200`.
- Send `ESC 1` over USB CDC/VCP to enter UART sniff mode.
- Write a known byte pattern to the UART stimulus port.
- Capture and parse USB CDC output for `UART,RX,0xNN` lines matching the stimulus pattern.
- Record stimulus port, baud, bytes sent, bytes observed, and pass/fail in the report.
- If no UART stimulus port is provided, mark the UART test skipped with clear wiring instructions.
- Include a placeholder report field for detected UART baud so later feature tickets can fill it.

Non-goals:
- Do not implement UART autobaud detection yet.
- Do not add PB1/USART5_RX firmware support yet.
- Do not test TX/RX channel separation yet.
- Do not change UART firmware output.
- Do not require a specific external adapter brand if the script can accept a generic COM port.

Acceptance criteria:
- The harness can run the UART test independently or as part of the full suite.
- With a valid UART stimulus port wired to STM32 `PA3` / `USART2_RX`, known bytes are observed as `UART,RX,0xNN`.
- Missing UART stimulus configuration is reported as skipped, not as a cryptic failure.
- Wrong wiring or wrong baud produces a clear UART test failure.
- Documentation describes required wiring and command-line options.

Automated verification:
- Run the UART stage without `--uart-port` and confirm the report marks UART skipped.
- Wire stimulus TX to STM32 `PA3` and common ground.
- Run the UART stage with `--uart-port COMx --uart-baud 115200`.
- Confirm the report lists the transmitted pattern and matching captured `UART,RX,0xNN` lines.
- Disconnect the UART stimulus wire and rerun to confirm the UART test fails while build/flash/VCP steps still report independently.

Manual verification:
- Confirm the physical UART stimulus wiring:
  - Stimulus TX to STM32 `PA3` / `USART2_RX`.
  - Common ground between stimulus source and board.
- Run the harness and inspect the UART section of the report.
- Optionally observe USB CDC output in a terminal after the test.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- All serial operations must use bounded timeouts.

Completion step:
- After implementation and verification, mark this ticket complete by renaming this file with a `_DONE` suffix before `.md`.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
