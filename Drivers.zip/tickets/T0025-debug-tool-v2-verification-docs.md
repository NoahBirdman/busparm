# T0025 - Debug Tool v2 Verification and Documentation

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- docs/Known_Issues_And_Followups.md
- tools/ automated test harness
- tickets/T0025-debug-tool-v2-verification-docs.md

Implement this ticket only.

Ticket:
T0025 - Debug Tool v2 Verification and Documentation

Branch:
ticket/t0025-debug-tool-v2-verification-docs

Goal:
Run the full debug-tool v2 automated verification suite and update documentation with verified behavior, known limits, required wiring, and follow-up work.

Dependencies:
- T0015 through T0024 completed.
- Hardware available for sensing, UART, and I2C verification.
- UART and I2C stimulus paths available or explicitly documented as unavailable.

Allowed areas:
- tools/ only for narrow report-template or usability fixes needed to complete verification
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- docs/Known_Issues_And_Followups.md
- README.md only for a short pointer if useful
- tickets/T0025-debug-tool-v2-verification-docs.md only if recording implementation notes

Do not touch:
- Core/
- Drivers/
- Middlewares/
- USB_Device/
- cmake/
- CMakeLists.txt
- CMakePresets.json
- thesensor_v2.ioc
- Firmware behavior, unless a narrow docs-only ticket is abandoned and a new bugfix ticket is created

Requirements:
- Run the full automated harness suite:
  - Build.
  - Flash.
  - Reset/run.
  - VCP discovery/capture.
  - Sensing checks.
  - CSV and tabular formatting checks.
  - VCP line-coding report check.
  - UART sniff checks.
  - UART baud detection checks.
  - Dual-channel UART checks when hardware is available.
  - I2C activity checks.
  - I2C speed detection checks.
- Save or reference the generated report in documentation if appropriate.
- Update repo current state with verified debug-tool v2 behavior.
- Update manual verification guide with:
  - Harness command examples.
  - Required wiring.
  - Expected output snippets.
  - Report interpretation.
- Update known issues/follow-ups with any failed or skipped checks.
- Clearly distinguish verified behavior from planned/future work.

Non-goals:
- Do not add new firmware features.
- Do not refactor firmware.
- Do not fix feature bugs inside this ticket unless the user explicitly converts this into an implementation ticket.
- Do not claim protocol decode or lossless capture unless verified.

Acceptance criteria:
- Full automated report is generated.
- Documentation records pass/fail/skipped status for sensing, UART, and I2C tests.
- Repo current state reflects the implemented and verified v2 feature set.
- Manual verification guide contains a repeatable debug-tool v2 flow.
- Known limitations and follow-up tickets are documented.

Automated verification:
- Run the harness full suite with all available hardware.
- Confirm the report includes independent result sections for:
  - Build/flash/reset.
  - VCP capture.
  - Sensing.
  - UART.
  - I2C.
- Confirm the report exits nonzero if any required check fails.
- Confirm skipped checks include an explicit reason and are not silently treated as pass.

Manual verification:
- Review the generated report.
- Spot-check USB CDC output in a terminal.
- Confirm physical wiring documented in the manual guide matches the actual test setup.
- Read updated docs and confirm they do not overstate unverified behavior.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- All build/test commands must be bounded with timeouts.

Completion step:
- After implementation and verification, mark this ticket complete by renaming this file with a `_DONE` suffix before `.md`.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
