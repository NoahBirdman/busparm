# T0026 - USB Bootloader Flash Configuration

We are working on TheSensor.

Before coding, review:
- docs/AGENTS.md
- docs/MVP_Technical_Design.md
- docs/Repo_Current_State.md
- docs/Manual_Verification_Guide.md
- docs/Known_Issues_And_Followups.md
- .vscode/tasks.json
- .vscode/launch.json
- tickets/T0026-usb-bootloader-flash-configuration.md

Implement this ticket only.

Ticket:
T0026 - USB Bootloader Flash Configuration

Branch:
ticket/t0026-usb-bootloader-flash-configuration

Goal:
Add a repeatable VS Code flash configuration that programs the board through the STM32 system USB bootloader, so firmware can be flashed without using ST-LINK/SWD.

Dependencies:
- T0004 ST-LINK VS Code flash/debug configuration exists.
- STM32CubeProgrammer CLI is installed and available.
- The board has a known physical workflow for entering the STM32 USB bootloader, such as BOOT0/boot mode plus reset or power-cycle.
- A USB data connection from the host to the board is available.

Allowed areas:
- .vscode/tasks.json
- .vscode/launch.json only if a launch-style configuration is the best local pattern
- docs/Manual_Verification_Guide.md
- docs/Repo_Current_State.md
- docs/Known_Issues_And_Followups.md
- README.md only for a short pointer if useful
- tickets/T0026-usb-bootloader-flash-configuration.md only if recording implementation notes

Do not touch:
- Core/
- Drivers/
- Middlewares/
- USB_Device/
- cmake/ unless a narrow build-artifact conversion task is required
- CMakeLists.txt unless a narrow build-artifact conversion target is required
- CMakePresets.json unless a narrow preset integration is required
- thesensor_v2.ioc
- Firmware behavior
- Existing ST-LINK debug/flash behavior except preserving it

Requirements:
- Add a VS Code task or configuration named clearly, for example:
  - `STM32: flash Debug ELF (USB bootloader)`
- Keep the existing ST-LINK flash/debug workflow intact.
- Build the Debug firmware before flashing.
- Use STM32CubeProgrammer CLI over the USB bootloader interface.
- Include a discovery or diagnostic step for USB bootloader visibility, such as `STM32_Programmer_CLI -l usb`.
- Use the correct CubeProgrammer USB connection syntax for the installed version and discovered device.
- Program and verify the Debug firmware artifact. Prefer the existing `build/Debug/thesensor_v2.elf` if CubeProgrammer supports it reliably over USB bootloader; otherwise add the smallest necessary HEX or BIN conversion step.
- Document how to put the board into USB bootloader mode and how to return it to normal application mode.
- Document expected success output and common failure modes, including no USB bootloader device found, wrong boot mode, stale USB CDC port, and needing reset or power-cycle after flashing.

Non-goals:
- Do not change application firmware to implement a custom bootloader.
- Do not remove or replace ST-LINK/SWD flashing.
- Do not change option bytes unless explicitly required and separately approved.
- Do not automate physical boot-mode switching unless the board already exposes a verified software-controllable path.
- Do not change runtime USB CDC behavior.

Acceptance criteria:
- A user can run a named VS Code command to build and flash the Debug firmware through the STM32 USB bootloader.
- The command fails clearly when the board is not in USB bootloader mode.
- Flash verification is enabled.
- After returning the board to normal boot mode and resetting, the flashed firmware runs and USB CDC enumerates normally.
- Documentation includes the USB bootloader flash workflow and does not regress the existing ST-LINK workflow.

Automated verification:
- Run the Debug configure/build flow.
- Run the USB bootloader discovery command and record whether the bootloader is visible.
- Run the new USB bootloader flash task while the board is in bootloader mode.
- Confirm CubeProgrammer reports successful programming and verification.
- After reset into application mode, confirm the USB CDC/VCP port enumerates or the existing hardware harness can capture normal output.

Manual verification:
- Put the board into STM32 USB bootloader mode using the documented physical workflow.
- Connect the board USB data port to the host.
- Run the new VS Code USB bootloader flash command.
- Return the board to normal application boot mode.
- Reset or power-cycle the board.
- Confirm the expected firmware starts and USB CDC output is visible.

Project rules:
- Implement the requested ticket only.
- Do not implement future-ticket features.
- Do not refactor unrelated code.
- Do not introduce new architecture unless required.
- Avoid unnecessary dependencies.
- Keep changes small and testable.
- All build/test commands must be bounded with timeouts.

Completion step:
- After implementation and verification, mark this ticket complete by renaming this file with a `_DONE` suffix before `.md`.

Implementation notes:
- Added `STM32: list USB bootloader devices` to `.vscode/tasks.json`.
- Added `STM32: flash Debug ELF (USB bootloader)` to `.vscode/tasks.json`.
- The USB bootloader flash task builds Debug first, runs USB/DFU discovery, then programs and verifies `build/Debug/thesensor_v2.elf` using STM32CubeProgrammer `port=usb1`.
- The USB bootloader tasks resolve `STM32_Programmer_CLI` from PATH first, then known STM32CubeProgrammer install locations, including the local STM32Cube bundle path observed during implementation.
- Updated the manual verification guide with the USB bootloader entry, flash, reset, application-return, expected-output, and failure-mode workflow.
- Updated repo-state and known-issues docs to record the configured task and the remaining hardware-validation gap.
- STM32CubeProgrammer 2.22.0 help confirms ELF download and USB connection support.
- `STM32_Programmer_CLI -l usb` ran successfully but reported no STM32 DFU-mode device connected, so physical USB bootloader flashing still needs board-side verification.
- This ticket is complete and has been renamed with `_DONE`.

After implementation, provide:
- Summary of what changed
- Files changed
- Commands run
- Build/test results
- Manual verification steps
- Whether docs need updating
- Any risks or follow-up tickets
