param(
  [string]$Port = "",
  [int]$VcpBaud = 115200,
  [string]$PythonPath = "",
  [string]$ProgrammerCliPath = "",
  [string]$StlinkSerial = "",
  [string[]]$I2cAddresses = @("0x40", "0x41", "0x50"),
  [ValidateSet(100, 400)]
  [int]$I2cBaudKHz = 100,
  [ValidateSet("STANDARD", "FAST")]
  [string]$I2cSpeedMode = "STANDARD",
  [ValidateSet("7bit", "8bit")]
  [string]$I2cAddressMode = "7bit",
  [int]$PacketCount = 1,
  [string]$I2cWriteByte = "0xA5",
  [int]$I2cReadLength = 1,
  [int]$TimeoutSec = 8,
  [int]$StimulusTimeoutSec = 10,
  [int]$InterPacketDelayMs = 250,
  [string]$StimulusCommand = "",
  [switch]$ObserveOnly,
  [switch]$Help
)

if ($Help) {
  @"
TheSensor I2C stimulus and DUT terminal monitor.

Usage:
  pwsh -NoProfile -File tools/i2c_test.ps1 [options]

Common options:
  -Port <COMx>                DUT USB CDC/VCP COM port. If omitted, discovery is attempted.
  -VcpBaud <baud>             DUT USB CDC/VCP baud. Default: 115200
  -PythonPath <path>          Python executable for STLINK-V3 bridge helper.
  -ProgrammerCliPath <path>   Override STM32_Programmer_CLI path.
  -StlinkSerial <serial>      Expected ST-LINK serial. Used as a discovery check only.
  -I2cAddresses <addr[]>      7-bit I2C addresses for built-in stimulus.
                              Default: 0x40, 0x41, 0x50
  -I2cBaudKHz <100|400>       I2C AUX bridge speed. Default: 100
  -I2cSpeedMode <STANDARD|FAST>
                              I2C AUX bridge speed mode. Default: STANDARD
  -I2cAddressMode <7bit|8bit> Address format passed to the STLINK bridge helper.
                              Default: 7bit
  -PacketCount <n>            Number of write/read attempts per address. Default: 1
  -I2cWriteByte <byte>        Byte used by built-in write attempts. Default: 0xA5
  -I2cReadLength <n>          Byte count used by built-in read attempts. Default: 1
  -TimeoutSec <sec>           Overall DUT output capture window. Default: 8
  -StimulusTimeoutSec <sec>   Timeout for each stimulus process. Default: 10
  -StimulusCommand <cmd>      Optional custom command that generates I2C traffic.
  -ObserveOnly                Enter DUT I2C sniff mode and capture output without stimulus.
  -Help                       Show this help.

Examples:
  pwsh -NoProfile -File tools/i2c_test.ps1 -Port COM24 -ObserveOnly
  pwsh -NoProfile -File tools/i2c_test.ps1 -Port COM24
  pwsh -NoProfile -File tools/i2c_test.ps1 -Port COM24 -I2cAddresses 0x40,0x41,0x50 -I2cBaudKHz 400 -I2cSpeedMode FAST
  pwsh -NoProfile -File tools/i2c_test.ps1 -Port COM24 -StimulusCommand "python tools/my_i2c_sender.py"

Wiring for TheSensor I2C sniff check:
  Use the STLINK-V3 AUX/bridge connector, not the SWD/main programming header.
  ST-LINK/STLINK-V3 I2C SCL -> DUT PB3 / I2C2_EXT_SCL
  ST-LINK/STLINK-V3 I2C SDA -> DUT PB4 / I2C2_EXT_SDA
  Common ground between ST-LINK and DUT
  Suitable pull-ups on the I2C bus

Note:
  The built-in sequence uses tools/stlink_v3_aux_i2c.py and the Python stbridge
  package, which talks to STLINK-V3-BRIDGE and drives the AUX bridge I2C pins.
  Install the dependency with: python -m pip install stbridge
"@
  exit 0
}

$ErrorActionPreference = "Stop"

function Resolve-Programmer {
  if (-not [string]::IsNullOrWhiteSpace($ProgrammerCliPath)) {
    if (Test-Path -LiteralPath $ProgrammerCliPath) {
      return (Resolve-Path -LiteralPath $ProgrammerCliPath).Path
    }
    throw "ProgrammerCliPath does not exist: $ProgrammerCliPath"
  }

  $command = Get-Command "STM32_Programmer_CLI" -ErrorAction SilentlyContinue
  $candidates = @(
    $(if ($command) { $command.Source }),
    (Join-Path $env:LOCALAPPDATA "stm32cube\bundles\programmer\2.22.0+st.1\bin\STM32_Programmer_CLI.exe"),
    "C:\Program Files\STMicroelectronics\STM32Cube\STM32CubeProgrammer\bin\STM32_Programmer_CLI.exe",
    "C:\Program Files\STMicroelectronics\STM32Cube\STM32CubeProgrammer\STM32_Programmer_CLI.exe"
  )

  foreach ($candidate in $candidates) {
    if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path -LiteralPath $candidate)) {
      return (Resolve-Path -LiteralPath $candidate).Path
    }
  }

  throw "STM32_Programmer_CLI was not found. Add it to PATH or install STM32CubeProgrammer."
}

function Resolve-Python {
  if (-not [string]::IsNullOrWhiteSpace($PythonPath)) {
    if (Test-Path -LiteralPath $PythonPath) {
      return (Resolve-Path -LiteralPath $PythonPath).Path
    }
    return $PythonPath
  }

  $candidates = @(
    (Get-Command "python" -ErrorAction SilentlyContinue).Source,
    (Get-Command "py" -ErrorAction SilentlyContinue).Source
  )

  foreach ($candidate in $candidates) {
    if (-not [string]::IsNullOrWhiteSpace($candidate)) {
      return $candidate
    }
  }

  throw "Python was not found. Install Python or rerun with -PythonPath <path>."
}

function Find-VcpPort {
  $fallbackPorts = [System.IO.Ports.SerialPort]::GetPortNames() | Sort-Object

  try {
    $ports = Get-CimInstance Win32_PnPEntity |
      Where-Object { $_.Name -match "\(COM\d+\)" } |
      ForEach-Object {
        $match = [regex]::Match($_.Name, "COM\d+")
        [pscustomobject]@{
          Port = $match.Value
          Name = $_.Name
        }
      }

    $preferred = $ports | Where-Object {
      $_.Name -match "STM|STMicroelectronics|Virtual COM|USB Serial|CDC|VCP"
    } | Select-Object -First 1

    if ($preferred) {
      Write-Host "Discovered candidate DUT VCP: $($preferred.Port) ($($preferred.Name))"
      return $preferred.Port
    }

    if ($ports.Count -eq 1) {
      Write-Host "Using the only visible COM port: $($ports[0].Port) ($($ports[0].Name))"
      return $ports[0].Port
    }
  } catch {
    Write-Host "CIM COM-port discovery failed: $($_.Exception.Message)"
  }

  if ($fallbackPorts.Count -eq 1) {
    Write-Host "Using the only visible COM port: $($fallbackPorts[0])"
    return $fallbackPorts[0]
  }

  if ($fallbackPorts.Count -gt 1) {
    throw "Multiple COM ports are visible ($($fallbackPorts -join ', ')). Rerun with -Port COMx."
  }

  throw "No COM ports are visible. Connect the DUT USB CDC/VCP interface or rerun with -Port COMx."
}

function Invoke-BoundedProcess {
  param(
    [string]$Name,
    [string]$FilePath,
    [string[]]$Arguments,
    [int]$TimeoutSec
  )

  $watch = [System.Diagnostics.Stopwatch]::StartNew()
  $process = New-Object System.Diagnostics.Process
  $process.StartInfo = New-Object System.Diagnostics.ProcessStartInfo
  $process.StartInfo.FileName = $FilePath
  $process.StartInfo.UseShellExecute = $false
  $process.StartInfo.CreateNoWindow = $true
  $process.StartInfo.RedirectStandardOutput = $true
  $process.StartInfo.RedirectStandardError = $true

  foreach ($argument in $Arguments) {
    [void]$process.StartInfo.ArgumentList.Add($argument)
  }

  [void]$process.Start()
  $stdoutTask = $process.StandardOutput.ReadToEndAsync()
  $stderrTask = $process.StandardError.ReadToEndAsync()

  if (-not $process.WaitForExit($TimeoutSec * 1000)) {
    try {
      $process.Kill()
    } catch {
    }

    $watch.Stop()
    return [pscustomobject]@{
      Name = $Name
      Status = "fail"
      ExitCode = $null
      DurationSec = $watch.Elapsed.TotalSeconds
      Stdout = $stdoutTask.Result
      Stderr = $stderrTask.Result
      Message = "Timed out after $TimeoutSec seconds."
    }
  }

  $watch.Stop()
  return [pscustomobject]@{
    Name = $Name
    Status = $(if ($process.ExitCode -eq 0) { "pass" } else { "fail" })
    ExitCode = $process.ExitCode
    DurationSec = $watch.Elapsed.TotalSeconds
    Stdout = $stdoutTask.Result
    Stderr = $stderrTask.Result
    Message = "Exited with code $($process.ExitCode)."
  }
}

function Read-DutOutput {
  param(
    [System.IO.Ports.SerialPort]$Serial,
    [System.Text.StringBuilder]$Captured,
    [int]$Milliseconds
  )

  $deadline = [DateTime]::UtcNow.AddMilliseconds($Milliseconds)
  while ([DateTime]::UtcNow -lt $deadline) {
    try {
      $chunk = $Serial.ReadExisting()
      if ($chunk.Length -gt 0) {
        [void]$Captured.Append($chunk)
        Write-Host $chunk -NoNewline
      }
    } catch [TimeoutException] {
    }

    Start-Sleep -Milliseconds 50
  }
}

function Convert-I2cDecodedLines {
  param([string]$Text)

  $packets = @()
  $diagnostics = @()
  foreach ($line in ($Text -split "(`r`n|`n|`r)")) {
    $trimmed = $line.Trim()
    if ($trimmed -match '^\[.*0x[0-9A-Fa-f]{2}.*\]$') {
      $packets += $trimmed
    } elseif ($trimmed -match '^I2C,(OVERFLOW|TIMEOUT|BUS_LOW|SHORT|WIRING),') {
      $diagnostics += $trimmed
    }
  }

  return [pscustomobject]@{
    Packets = @($packets)
    Diagnostics = @($diagnostics)
  }
}

function Test-StlinkVisible {
  param([string]$Programmer)

  Write-Host "Listing ST-LINK probes via STM32CubeProgrammer..."
  $result = Invoke-BoundedProcess -Name "stlink_list" -FilePath $Programmer -Arguments @("-l", "stlink") -TimeoutSec 10
  if (-not [string]::IsNullOrWhiteSpace($result.Stdout)) {
    Write-Host $result.Stdout.TrimEnd()
  }
  if (-not [string]::IsNullOrWhiteSpace($result.Stderr)) {
    Write-Host $result.Stderr.TrimEnd()
  }

  if ($result.Status -ne "pass") {
    throw "Failed to list ST-LINK probes: $($result.Message)"
  }

  if ($result.Stdout -notmatch "ST-LINK|STLINK") {
    throw "No ST-LINK probe was reported by STM32CubeProgrammer."
  }

  if (-not [string]::IsNullOrWhiteSpace($StlinkSerial) -and $result.Stdout -notmatch [regex]::Escape($StlinkSerial)) {
    throw "Expected ST-LINK serial $StlinkSerial was not found in CubeProgrammer output."
  }
}

function Invoke-AuxI2cStimulus {
  $python = Resolve-Python
  $helper = Join-Path $PSScriptRoot "stlink_v3_aux_i2c.py"
  if (-not (Test-Path -LiteralPath $helper)) {
    throw "STLINK-V3 AUX I2C helper not found: $helper"
  }

  $freq = "standard"
  if ($I2cBaudKHz -eq 400 -or $I2cSpeedMode -eq "FAST") {
    $freq = "fast"
  }

  $args = @($helper, "--freq", $freq, "--address-mode", $I2cAddressMode, "--count", "$PacketCount", "--write-bytes", $I2cWriteByte, "--read-length", "$I2cReadLength", "--delay-ms", "$InterPacketDelayMs", "--addresses")
  foreach ($address in $I2cAddresses) {
    $args += $address
  }
  if (-not [string]::IsNullOrWhiteSpace($StlinkSerial)) {
    $args += @("--serial", $StlinkSerial)
  }

  Write-Host ""
  Write-Host "I2C AUX stimulus: $python $($args -join ' ')"
  $result = Invoke-BoundedProcess -Name "stlink_v3_aux_i2c" -FilePath $python -Arguments $args -TimeoutSec $StimulusTimeoutSec

  if (-not [string]::IsNullOrWhiteSpace($result.Stdout)) {
    Write-Host $result.Stdout.TrimEnd()
  }
  if (-not [string]::IsNullOrWhiteSpace($result.Stderr)) {
    Write-Host $result.Stderr.TrimEnd()
  }

  if ($result.Status -ne "pass") {
    Write-Warning "STLINK-V3 AUX I2C stimulus failed: $($result.Message)"
  }
}

function Invoke-CustomStimulus {
  Write-Host ""
  Write-Host "I2C stimulus command: $StimulusCommand"
  $result = Invoke-BoundedProcess -Name "custom_i2c_stimulus" -FilePath "pwsh" -Arguments @("-NoProfile", "-Command", $StimulusCommand) -TimeoutSec $StimulusTimeoutSec

  if (-not [string]::IsNullOrWhiteSpace($result.Stdout)) {
    Write-Host $result.Stdout.TrimEnd()
  }
  if (-not [string]::IsNullOrWhiteSpace($result.Stderr)) {
    Write-Host $result.Stderr.TrimEnd()
  }

  if ($result.Status -ne "pass") {
    Write-Warning "Custom stimulus failed: $($result.Message)"
  }
}

$programmer = Resolve-Programmer
$selectedPort = $Port
if ([string]::IsNullOrWhiteSpace($selectedPort)) {
  $selectedPort = Find-VcpPort
}

Write-Host "TheSensor I2C test"
Write-Host "  DUT VCP: $selectedPort at $VcpBaud baud"
Write-Host "  STM32CubeProgrammer: $programmer"
Write-Host "  I2C addresses: $($I2cAddresses -join ', ')"
Write-Host "  Capture window: $TimeoutSec seconds"
Write-Host ""

Test-StlinkVisible -Programmer $programmer

$serial = New-Object System.IO.Ports.SerialPort($selectedPort, $VcpBaud, [System.IO.Ports.Parity]::None, 8, [System.IO.Ports.StopBits]::One)
$serial.ReadTimeout = 200
$serial.WriteTimeout = 500
$captured = New-Object System.Text.StringBuilder
$watch = [System.Diagnostics.Stopwatch]::StartNew()

try {
  Write-Host ""
  Write-Host "Opening DUT terminal and entering i2c_sniff mode..."
  $serial.Open()
  Start-Sleep -Milliseconds 250
  $serial.DiscardInBuffer()

  [byte[]]$i2cModeCommand = @(0x1B, 0x32)
  $serial.Write($i2cModeCommand, 0, $i2cModeCommand.Length)
  Read-DutOutput -Serial $serial -Captured $captured -Milliseconds 700

  if ($ObserveOnly) {
    Write-Host ""
    Write-Host "Observe-only mode enabled. No I2C stimulus will be sent."
  } elseif (-not [string]::IsNullOrWhiteSpace($StimulusCommand)) {
    Invoke-CustomStimulus
  } else {
    Invoke-AuxI2cStimulus
  }

  $remainingMs = [math]::Max(0, (($TimeoutSec * 1000) - [int]$watch.ElapsedMilliseconds))
  if ($remainingMs -gt 0) {
    Write-Host ""
    Write-Host "DUT output:"
    Read-DutOutput -Serial $serial -Captured $captured -Milliseconds $remainingMs
  }
} finally {
  $watch.Stop()
  if ($serial.IsOpen) {
    $serial.Close()
  }
}

$decoded = Convert-I2cDecodedLines -Text $captured.ToString()
Write-Host ""
Write-Host ""
Write-Host "I2C test summary"
Write-Host "  Captured chars: $($captured.Length)"
Write-Host "  Decoded packets: $($decoded.Packets.Count)"
Write-Host "  Diagnostics: $($decoded.Diagnostics.Count)"

foreach ($packet in $decoded.Packets) {
  Write-Host "  PACKET: $packet"
}
foreach ($diagnostic in $decoded.Diagnostics) {
  Write-Host "  DIAG: $diagnostic"
}

if ($decoded.Packets.Count -gt 0) {
  exit 0
}

if ($ObserveOnly) {
  Write-Warning "No decoded I2C packets were observed."
  exit 1
}

Write-Warning "No decoded I2C packets were observed. Check PB3/PB4 wiring, common ground, pull-ups, and whether STLINK-V3 AUX I2C traffic is reaching the DUT."
exit 1
