param(
  [string]$ElfPath = "build/Debug/thesensor_v2.elf",
  [string]$Port = "",
  [int]$DfuTimeoutSec = 15
)

$ErrorActionPreference = "Stop"

function Resolve-Programmer {
  $candidates = @(
    (Get-Command "STM32_Programmer_CLI" -ErrorAction SilentlyContinue).Source,
    (Join-Path $env:LOCALAPPDATA "stm32cube\bundles\programmer\2.22.0+st.1\bin\STM32_Programmer_CLI.exe"),
    "C:\Program Files\STMicroelectronics\STM32Cube\STM32CubeProgrammer\bin\STM32_Programmer_CLI.exe",
    "C:\Program Files\STMicroelectronics\STM32Cube\STM32CubeProgrammer\STM32_Programmer_CLI.exe"
  )

  foreach ($candidate in $candidates) {
    if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path -LiteralPath $candidate)) {
      return (Resolve-Path -LiteralPath $candidate).Path
    }
  }

  throw "STM32_Programmer_CLI was not found. Add it to PATH or install STM32CubeProgrammer."
}

function Test-DfuVisible {
  param([string]$Programmer)

  $output = & $Programmer -l usb 2>&1
  $text = ($output | Out-String)
  Write-Host $text.TrimEnd()
  [bool]($text -match "Total number of available STM32 device in DFU mode:\s*[1-9]")
}

function Read-PortLines {
  param(
    [System.IO.Ports.SerialPort]$SerialPort,
    [int]$Milliseconds
  )

  $lines = @()
  $deadline = [DateTime]::UtcNow.AddMilliseconds($Milliseconds)
  while ([DateTime]::UtcNow -lt $deadline) {
    try {
      $line = $SerialPort.ReadLine()
      if (-not [string]::IsNullOrWhiteSpace($line)) {
        $lines += $line.Trim()
      }
    } catch [TimeoutException] {
    } catch {
      $lines += "read_error=$($_.Exception.Message)"
      break
    }
  }

  return $lines
}

function Find-AppPort {
  $ports = [System.IO.Ports.SerialPort]::GetPortNames() | Sort-Object
  $attempts = @()

  if ($ports.Count -eq 0) {
    throw "No COM ports are visible. Confirm TheSensor is running or put the board into DFU mode before running this task."
  }

  Write-Output "Scanning COM ports for TheSensor USB CDC output: $($ports -join ', ')"
  foreach ($portName in $ports) {
    $serial = New-Object System.IO.Ports.SerialPort $portName,115200,'None',8,'One'
    $serial.ReadTimeout = 300
    $serial.WriteTimeout = 500

    try {
      $serial.Open()
      $lines = Read-PortLines -SerialPort $serial -Milliseconds 1600
      $joined = $lines -join "`n"
      if ($lines.Count -gt 0) {
        $attempts += "$portName opened; captured: $($lines -join ' | ')"
      } else {
        $attempts += "$portName opened; no TheSensor text captured"
      }
      if (($joined -match "timestamp_ms,bus_voltage_v,current_a,power_w") -or
          ($joined -match "mode=(normal_sense|uart_sniff|i2c_sniff)") -or
          ($joined -match "(^|`n)I2C,(TIMEOUT|OVERFLOW|BUS_LOW),") -or
          ($joined -match "INA236_CSV_ERR")) {
        return $portName
      }
    } catch {
      $attempts += "$portName unavailable: $($_.Exception.Message)"
    } finally {
      if ($serial.IsOpen) {
        $serial.Close()
      }
    }
  }

  $lockingHints = Get-Process -ErrorAction SilentlyContinue |
    Where-Object { $_.ProcessName -match 'putty|teraterm|serial|monitor|python|powershell|pwsh|Code' } |
    Select-Object -ExpandProperty ProcessName -Unique

  $message = "Could not find TheSensor USB CDC port. Tried: $($attempts -join '; ')."
  if ($lockingHints.Count -gt 0) {
    $message += " Close any serial terminal/monitor that may own the port. Possible processes: $($lockingHints -join ', ')."
  }
  $message += " You can also rerun this helper with -Port COMx."
  throw $message
}

function Enter-DfuFromApp {
  param([string]$PortName)

  Write-Output "Opening app CDC port $PortName"
  $serial = New-Object System.IO.Ports.SerialPort $PortName,115200,'None',8,'One'
  $serial.ReadTimeout = 300
  $serial.WriteTimeout = 500

  try {
    $serial.Open()
    $before = Read-PortLines -SerialPort $serial -Milliseconds 800
    foreach ($line in $before) {
      Write-Output "APP: $line"
    }

    Write-Output "Sending ESC U to request STM32 system USB DFU bootloader"
    $bytes = [byte[]](0x1B, 0x55)
    $serial.Write($bytes, 0, $bytes.Length)

    $after = Read-PortLines -SerialPort $serial -Milliseconds 3000
    foreach ($line in $after) {
      Write-Output "APP: $line"
    }
  } finally {
    if ($serial.IsOpen) {
      $serial.Close()
    }
  }
}

$programmer = Resolve-Programmer
$resolvedElf = (Resolve-Path -LiteralPath $ElfPath).Path
Write-Output "Using STM32CubeProgrammer: $programmer"
Write-Output "Using ELF: $resolvedElf"

if (-not (Test-DfuVisible -Programmer $programmer)) {
  if ([string]::IsNullOrWhiteSpace($Port)) {
    $Port = Find-AppPort
  }
  Enter-DfuFromApp -PortName $Port

  $deadline = [DateTime]::UtcNow.AddSeconds($DfuTimeoutSec)
  $dfuVisible = $false
  while ([DateTime]::UtcNow -lt $deadline) {
    Start-Sleep -Milliseconds 500
    if (Test-DfuVisible -Programmer $programmer) {
      $dfuVisible = $true
      break
    }
  }

  if (-not $dfuVisible) {
    throw "Timed out waiting for STM32 USB DFU device. Check DFU driver, USB cable, and BOOT0/boot-mode state."
  }
}

Write-Output "Flashing Debug ELF over USB DFU"
& $programmer -c port=usb1 -w $resolvedElf -v -g 0x08000000
if ($LASTEXITCODE -ne 0) {
  exit $LASTEXITCODE
}
