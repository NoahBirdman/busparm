#!/usr/bin/env python3
"""Send I2C traffic through the STLINK-V3 bridge AUX pins."""

from __future__ import annotations

import argparse
import sys
import time


DEFAULT_ADDRESSES = ("0x40", "0x41", "0x50")


def parse_int(text: str) -> int:
    return int(text, 0)


def parse_bytes(text: str) -> list[int]:
    cleaned = text.replace(",", " ").replace(":", " ")
    values = []
    for part in cleaned.split():
        value = parse_int(part)
        if value < 0 or value > 0xFF:
            raise argparse.ArgumentTypeError(f"byte out of range: {part}")
        values.append(value)
    if not values:
        raise argparse.ArgumentTypeError("at least one byte is required")
    return values


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Send write/read I2C transactions through STLINK-V3-BRIDGE AUX pins.",
    )
    parser.add_argument(
        "--addresses",
        nargs="+",
        default=list(DEFAULT_ADDRESSES),
        help="7-bit I2C addresses. Default: 0x40 0x41 0x50",
    )
    parser.add_argument(
        "--serial",
        default="",
        help="Optional STLINK-V3 serial number. Defaults to the first bridge device.",
    )
    parser.add_argument(
        "--freq",
        choices=("standard", "fast", "fast-plus"),
        default="standard",
        help="I2C frequency preset. Defaults to standard, 100 kHz.",
    )
    parser.add_argument(
        "--address-mode",
        choices=("7bit", "8bit"),
        default="7bit",
        help="Address format to pass to stbridge. Defaults to 7bit.",
    )
    parser.add_argument(
        "--count",
        type=int,
        default=1,
        help="Write/read attempts per address. Default: 1",
    )
    parser.add_argument(
        "--write-bytes",
        type=parse_bytes,
        default=[0xA5],
        help='Bytes to write, for example "0x00 0xA5". Default: 0xA5',
    )
    parser.add_argument(
        "--read-length",
        type=int,
        default=1,
        help="Bytes to read after each write. Default: 1",
    )
    parser.add_argument(
        "--delay-ms",
        type=int,
        default=250,
        help="Delay between transactions. Default: 250",
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.count < 1:
        parser.error("--count must be at least 1")
    if args.read_length < 1:
        parser.error("--read-length must be at least 1")

    addresses = [parse_int(address) for address in args.addresses]
    max_address = 0x7F if args.address_mode == "7bit" else 0xFF
    for address in addresses:
        if address < 0 or address > max_address:
            parser.error(f"I2C address out of {args.address_mode} range: 0x{address:X}")

    try:
        import stbridge as st
    except ImportError:
        print(
            "ERROR: Python package 'stbridge' is required for STLINK-V3 AUX I2C.\n"
            "Install it with: python -m pip install stbridge",
            file=sys.stderr,
        )
        return 2

    freq_map = {
        "standard": st.I2CFreq.STANDARD,
        "fast": st.I2CFreq.FAST,
        "fast-plus": st.I2CFreq.FAST_PLUS,
    }

    try:
        if args.serial:
            dev = st.USBInterface.get_device(args.serial)
        else:
            devices = st.USBInterface.list_devices()
            if not devices:
                print("ERROR: no STLINK-V3 bridge devices found.", file=sys.stderr)
                return 3
            dev = devices[0]

        print(f"STLINK-V3 bridge serial: {dev.serial()}")
        print(f"I2C AUX frequency preset: {args.freq}")
        print(f"I2C address mode: {args.address_mode}")
        dev.i2c_set_freq(freq_map[args.freq])

        delay_s = max(args.delay_ms, 0) / 1000.0
        error_count = 0
        for address in addresses:
            for attempt in range(1, args.count + 1):
                write_text = " ".join(f"0x{byte:02X}" for byte in args.write_bytes)
                print(f"I2C WRITE addr=0x{address:02X} attempt={attempt}/{args.count} data={write_text}")
                try:
                    dev.i2c_write(address, args.write_bytes)
                except Exception as exc:
                    error_count += 1
                    print(f"I2C WRITE addr=0x{address:02X} error={exc}", file=sys.stderr)
                if delay_s:
                    time.sleep(delay_s)

                print(f"I2C READ  addr=0x{address:02X} attempt={attempt}/{args.count} len={args.read_length}")
                try:
                    data = dev.i2c_read(address, args.read_length)
                    read_text = " ".join(f"0x{byte:02X}" for byte in data)
                    print(f"I2C READ  addr=0x{address:02X} data={read_text}")
                except Exception as exc:
                    error_count += 1
                    print(f"I2C READ  addr=0x{address:02X} error={exc}", file=sys.stderr)
                if delay_s:
                    time.sleep(delay_s)
    except Exception as exc:
        print(f"ERROR: STLINK-V3 AUX I2C transaction failed: {exc}", file=sys.stderr)
        return 1

    if error_count:
        print(f"Completed I2C stimulus with {error_count} transaction error(s).", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
