param(
  [string]$Preset = "Debug",
  [string]$BuildDir = "",
  [int]$TimeoutSec = 60,
  [switch]$Configure,
  [switch]$DirectNinja,
  [switch]$ManualCompileLink,
  [switch]$ClearStaleNinjaLock,
  [switch]$Help
)

if ($Help) {
  @"
Bounded Debug build helper for TheSensor.

Usage:
  pwsh -NoProfile -File tools/build_debug.ps1 [options]

Options:
  -Preset <name>          CMake preset to build. Default: Debug
  -BuildDir <path>        Build directory for -DirectNinja. Default: build/<Preset>
  -TimeoutSec <seconds>   Timeout for each build command. Default: 60
  -Configure              Run 'cmake --preset <name>' before the build.
  -DirectNinja            Run 'ninja -C <BuildDir> thesensor_v2.elf -v' directly.
  -ManualCompileLink      Bypass Ninja: compile stale compile_commands entries and link.
  -ClearStaleNinjaLock    Delete <BuildDir>/.ninja_lock if no build process is running.
  -Help                   Show this help.

Output:
  Logs are written under build/tool-logs/build_debug/.
"@
  exit 0
}

$ErrorActionPreference = "Stop"
$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$resolvedBuildDir = $BuildDir
if ([string]::IsNullOrWhiteSpace($resolvedBuildDir)) {
  $resolvedBuildDir = Join-Path "build" $Preset
}
$logRoot = Join-Path $repoRoot "build/tool-logs/build_debug"
New-Item -ItemType Directory -Force -Path $logRoot | Out-Null

function Get-BuildProcess {
  Get-Process cmake,ninja,arm-none-eabi-gcc,arm-none-eabi-g++ -ErrorAction SilentlyContinue |
    Sort-Object ProcessName, Id
}

function Stop-BuildProcess {
  $processes = @(Get-BuildProcess)
  if ($processes.Count -eq 0) {
    return
  }

  Write-Host "Stopping existing build processes:"
  foreach ($process in $processes) {
    Write-Host ("  {0} pid={1}" -f $process.ProcessName, $process.Id)
    Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
  }
}

function Invoke-BoundedProcess {
  param(
    [string]$Name,
    [string]$FilePath,
    [string[]]$Arguments,
    [int]$ProcessTimeoutSec,
    [string]$WorkingDirectory = $repoRoot
  )

  $timestamp = Get-Date -Format "yyyyMMdd-HHmmss-fff"
  $stdoutPath = Join-Path $logRoot "$Name-$timestamp.out"
  $stderrPath = Join-Path $logRoot "$Name-$timestamp.err"
  $watch = [System.Diagnostics.Stopwatch]::StartNew()

  Write-Host ""
  Write-Host "Running: $FilePath $($Arguments -join ' ')"

  $process = Start-Process `
    -FilePath $FilePath `
    -ArgumentList $Arguments `
    -WorkingDirectory $WorkingDirectory `
    -NoNewWindow `
    -PassThru `
    -RedirectStandardOutput $stdoutPath `
    -RedirectStandardError $stderrPath

  if (-not $process.WaitForExit($ProcessTimeoutSec * 1000)) {
    Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
    $watch.Stop()
    Write-Host "Timed out after $ProcessTimeoutSec seconds. Killed pid=$($process.Id)."
    Write-Host "stdout: $stdoutPath"
    Write-Host "stderr: $stderrPath"
    Write-Host ""
    Write-Host "STDOUT tail:"
    Get-Content -LiteralPath $stdoutPath -ErrorAction SilentlyContinue | Select-Object -Last 80
    Write-Host ""
    Write-Host "STDERR tail:"
    Get-Content -LiteralPath $stderrPath -ErrorAction SilentlyContinue | Select-Object -Last 80

    return [pscustomobject]@{
      Status = "timeout"
      ExitCode = $null
      DurationSec = $watch.Elapsed.TotalSeconds
      StdoutPath = $stdoutPath
      StderrPath = $stderrPath
    }
  }

  $process.WaitForExit()
  $watch.Stop()

  Write-Host "Exit code: $($process.ExitCode) in $([math]::Round($watch.Elapsed.TotalSeconds, 2))s"
  Write-Host "stdout: $stdoutPath"
  Write-Host "stderr: $stderrPath"
  Write-Host ""
  Write-Host "STDOUT tail:"
  Get-Content -LiteralPath $stdoutPath -ErrorAction SilentlyContinue | Select-Object -Last 80
  Write-Host ""
  Write-Host "STDERR tail:"
  Get-Content -LiteralPath $stderrPath -ErrorAction SilentlyContinue | Select-Object -Last 80

  return [pscustomobject]@{
    Status = $(if ($process.ExitCode -eq 0) { "pass" } else { "fail" })
    ExitCode = $process.ExitCode
    DurationSec = $watch.Elapsed.TotalSeconds
    StdoutPath = $stdoutPath
    StderrPath = $stderrPath
  }
}

function Split-CommandLineSimple {
  param([string]$Command)

  $matches = [regex]::Matches($Command, '("[^"]*"|\S+)')
  $parts = @()
  foreach ($match in $matches) {
    $part = $match.Value
    if ($part.StartsWith('"') -and $part.EndsWith('"')) {
      $part = $part.Substring(1, $part.Length - 2)
    }
    $parts += $part
  }
  return $parts
}

function Invoke-ManualCompileLink {
  $buildDirFull = Join-Path $repoRoot $resolvedBuildDir
  $compileDb = Join-Path $buildDirFull "compile_commands.json"
  if (-not (Test-Path -LiteralPath $compileDb)) {
    throw "compile_commands.json not found at $compileDb. Run with -Configure first."
  }

  $entries = @(Get-Content -LiteralPath $compileDb -Raw | ConvertFrom-Json)
  if ($entries.Count -eq 0) {
    throw "compile_commands.json contains no compile entries."
  }

  $compiled = 0
  foreach ($entry in $entries) {
    $sourcePath = [string]$entry.file
    $outputPath = Join-Path ([string]$entry.directory) ([string]$entry.output)
    $needsCompile = $true
    if ((Test-Path -LiteralPath $sourcePath) -and (Test-Path -LiteralPath $outputPath)) {
      $needsCompile = ((Get-Item -LiteralPath $sourcePath).LastWriteTimeUtc -gt (Get-Item -LiteralPath $outputPath).LastWriteTimeUtc)
    }

    if (-not $needsCompile) {
      continue
    }

    $leaf = Split-Path -Leaf $sourcePath
    $safeName = "compile_" + ($leaf -replace "[^A-Za-z0-9_.-]", "_")
    $result = Invoke-BoundedProcess -Name $safeName -FilePath "cmd.exe" -Arguments @("/C", [string]$entry.command) -ProcessTimeoutSec $TimeoutSec -WorkingDirectory ([string]$entry.directory)
    if ($result.Status -ne "pass") {
      return $result
    }
    $compiled++
  }

  Write-Host ""
  Write-Host "Manual compile step refreshed $compiled object(s)."

  $firstParts = Split-CommandLineSimple -Command ([string]$entries[0].command)
  $gcc = $firstParts[0]
  $objects = @(Get-ChildItem -LiteralPath $buildDirFull -Recurse -Filter "*.obj" | Select-Object -ExpandProperty FullName | Sort-Object)
  if ($objects.Count -eq 0) {
    throw "No object files found under $buildDirFull."
  }

  $linkerScript = Join-Path $repoRoot "STM32G0B1XX_FLASH.ld"
  $linkArgs = @(
    "-mcpu=cortex-m0plus",
    "-Wall",
    "-fdata-sections",
    "-ffunction-sections",
    "-fstack-usage",
    "-O0",
    "-g3",
    "-mcpu=cortex-m0plus",
    "-T",
    $linkerScript,
    "--specs=nano.specs",
    "-Wl,-Map=thesensor_v2.map",
    "-Wl,--gc-sections",
    "-Wl,--print-memory-usage"
  )
  $linkArgs += $objects
  $linkArgs += @("-o", "thesensor_v2.elf", "-lm")

  return Invoke-BoundedProcess -Name "manual_link" -FilePath $gcc -Arguments $linkArgs -ProcessTimeoutSec $TimeoutSec -WorkingDirectory $buildDirFull
}

Push-Location $repoRoot
try {
  Stop-BuildProcess

  if ($ClearStaleNinjaLock) {
    $lockPath = Join-Path $repoRoot (Join-Path $resolvedBuildDir ".ninja_lock")
    if (Test-Path -LiteralPath $lockPath) {
      $existing = @(Get-BuildProcess)
      if ($existing.Count -gt 0) {
        Write-Host "Refusing to clear .ninja_lock while build processes are running."
        exit 2
      }

      Write-Host "Clearing stale Ninja lock: $lockPath"
      Remove-Item -LiteralPath $lockPath -Force
    }
  }

  if ($Configure) {
    $configureResult = Invoke-BoundedProcess -Name "cmake_configure" -FilePath "cmake" -Arguments @("--preset", $Preset) -ProcessTimeoutSec $TimeoutSec
    if ($configureResult.Status -ne "pass") {
      exit 1
    }
  }

  if ($ManualCompileLink) {
    $buildResult = Invoke-ManualCompileLink
  } elseif ($DirectNinja) {
    $buildResult = Invoke-BoundedProcess -Name "ninja_build" -FilePath "ninja" -Arguments @("-C", $resolvedBuildDir, "thesensor_v2.elf", "-v") -ProcessTimeoutSec $TimeoutSec
  } else {
    $buildResult = Invoke-BoundedProcess -Name "cmake_build" -FilePath "cmake" -Arguments @("--build", "--preset", $Preset) -ProcessTimeoutSec $TimeoutSec
  }
  if ($buildResult.Status -ne "pass") {
    exit 1
  }
} finally {
  Pop-Location
}

exit 0
