param(
  [string]$Preset = "Debug",
  [string]$ElfPath = "build/Debug/thesensor_v2.elf",
  [string]$ProgrammerCliPath = "",
  [string]$Port = "",
  [string]$ReportPath = "build/hardware-verification/t0018-report.json",
  [int]$BuildTimeoutSec = 20,
  [int]$FlashTimeoutSec = 60,
  [int]$ResetTimeoutSec = 20,
  [int]$PostResetDelaySec = 3,
  [int]$CaptureTimeoutSec = 10,
  [int]$SensingTimeoutSec = 8,
  [int]$UartTimeoutSec = 8,
  [int]$I2cTimeoutSec = 8,
  [string]$I2cStimulusCommand = "",
  [int]$I2cStimulusTimeoutSec = 10,
  [int]$VcpBaud = 115200,
  [string]$UartPort = "",
  [int]$UartBaud = 115200,
  [string]$UartPatternHex = "55 48 69",
  [int]$UartInterByteDelayMs = 0,
  [ValidateSet("ascii", "hex")]
  [string]$UartDisplayMode = "ascii",
  [ValidateSet("timeout", "line", "full")]
  [string]$UartFlushMode = "timeout",
  [string]$Stages = "base,sensing,uart",
  [switch]$Help
)

if ($Help) {
  @"
TheSensor automated hardware verification harness.

Usage:
  pwsh -File tools/run_hardware_verification.ps1 [options]

Options:
  -Preset <name>              CMake preset to configure/build. Default: Debug
  -ElfPath <path>             ELF to flash. Default: build/Debug/thesensor_v2.elf
  -ProgrammerCliPath <path>   Override STM32_Programmer_CLI path.
  -Port <COMx>                Override USB CDC/VCP COM port. If omitted, discovery is attempted.
  -ReportPath <path>          JSON report path. Default: build/hardware-verification/t0018-report.json
  -BuildTimeoutSec <sec>      Timeout for configure/build commands. Default: 20
  -FlashTimeoutSec <sec>      Timeout for STM32CubeProgrammer flash/verify. Default: 60
  -ResetTimeoutSec <sec>      Timeout for reset/run. Default: 20
  -PostResetDelaySec <sec>    Delay after reset/run before VCP discovery. Default: 3
  -CaptureTimeoutSec <sec>    USB CDC capture window. Default: 10
  -SensingTimeoutSec <sec>    Sensing test capture window. Default: 8
  -UartTimeoutSec <sec>       UART test capture window. Default: 8
  -I2cTimeoutSec <sec>        I2C observe-only capture window. Default: 8
  -I2cStimulusCommand <cmd>   Optional host command to generate external I2C traffic.
  -I2cStimulusTimeoutSec <s>  Timeout for the optional I2C stimulus command. Default: 10
  -VcpBaud <baud>             Host serial baud for opening VCP. Default: 115200
  -UartPort <COMx>            UART stimulus COM port. If omitted, UART stage is skipped.
  -UartBaud <baud>            UART stimulus baud. Default: 115200
  -UartPatternHex <bytes>     Hex byte pattern to send. Default: "55 48 69"
  -UartInterByteDelayMs <ms>  Delay between stimulus bytes. Default: 0
  -UartDisplayMode <mode>     UART display mode: ascii or hex. Default: ascii
  -UartFlushMode <mode>       UART flush mode: timeout, line, or full. Default: timeout
  -Stages <list>              Comma-separated stages: base, sensing, uart, i2c, all. Default: base,sensing,uart
  -Help                       Show this help.

Examples:
  pwsh -File tools/run_hardware_verification.ps1 -Port COM24
  pwsh -File tools/run_hardware_verification.ps1 -Port COM24 -Stages sensing
  pwsh -File tools/run_hardware_verification.ps1 -Port COM24 -Stages uart -UartPort COM26
  pwsh -File tools/run_hardware_verification.ps1 -Port COM24 -Stages i2c
  pwsh -File tools/run_hardware_verification.ps1 -ReportPath build/hardware-verification/latest.json
"@
  exit 0
}

$ErrorActionPreference = "Stop"
$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$reportFullPath = Join-Path $repoRoot $ReportPath
$reportDir = Split-Path -Parent $reportFullPath
$tmpDir = Join-Path $reportDir "tmp"

New-Item -ItemType Directory -Force -Path $reportDir | Out-Null
New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null

$script:Report = [ordered]@{
  ticket = "T0018"
  name = "Automated I2C Tests"
  started_at = (Get-Date).ToString("o")
  repo_root = $repoRoot
  preset = $Preset
  elf_path = $ElfPath
  report_path = $ReportPath
  stages = $Stages
  steps = @()
  summary = [ordered]@{
    pass = 0
    fail = 0
    skipped = 0
  }
}

function Test-StageEnabled {
  param([string]$StageName)

  $selected = @($Stages.Split(",") | ForEach-Object { $_.Trim().ToLowerInvariant() } | Where-Object { $_.Length -gt 0 })

  return (($selected -contains "all") -or ($selected -contains $StageName.ToLowerInvariant()))
}

function Write-HarnessStatus {
  param(
    [string]$Status,
    [string]$Name,
    [string]$Message = ""
  )

  $timestamp = Get-Date -Format "HH:mm:ss"
  if ([string]::IsNullOrWhiteSpace($Message)) {
    Write-Host ("[{0}] [{1}] {2}" -f $timestamp, $Status.ToUpperInvariant(), $Name)
  } else {
    Write-Host ("[{0}] [{1}] {2}: {3}" -f $timestamp, $Status.ToUpperInvariant(), $Name, $Message)
  }
}

function Convert-Excerpt {
  param([string]$Text, [int]$MaxChars = 4000)

  if ([string]::IsNullOrEmpty($Text)) {
    return ""
  }

  if ($Text.Length -le $MaxChars) {
    return $Text
  }

  return $Text.Substring($Text.Length - $MaxChars, $MaxChars)
}

function Add-Step {
  param(
    [string]$Name,
    [string]$Status,
    [string]$Message,
    [string]$Command = "",
    [Nullable[int]]$ExitCode = $null,
    [double]$DurationSec = 0,
    [string]$Stdout = "",
    [string]$Stderr = "",
    [hashtable]$Data = @{}
  )

  $step = [ordered]@{
    name = $Name
    status = $Status
    message = $Message
    command = $Command
    exit_code = $ExitCode
    duration_sec = [math]::Round($DurationSec, 3)
    stdout_excerpt = (Convert-Excerpt $Stdout)
    stderr_excerpt = (Convert-Excerpt $Stderr)
    data = $Data
  }

  $script:Report.steps += $step
  if ($Status -eq "pass") {
    $script:Report.summary.pass++
  } elseif ($Status -eq "fail") {
    $script:Report.summary.fail++
  } elseif ($Status -eq "skipped") {
    $script:Report.summary.skipped++
  }

  Write-HarnessStatus -Status $Status -Name $Name -Message $Message
}

function Save-Report {
  $script:Report.finished_at = (Get-Date).ToString("o")
  $json = $script:Report | ConvertTo-Json -Depth 8
  Set-Content -Path $reportFullPath -Value $json -Encoding UTF8
}

function Invoke-BoundedProcess {
  param(
    [string]$Name,
    [string]$FilePath,
    [string[]]$Arguments,
    [int]$TimeoutSec,
    [string]$WorkingDirectory = $repoRoot,
    [switch]$InheritOutput
  )

  $safeName = ($Name -replace "[^A-Za-z0-9_.-]", "_")
  $stamp = Get-Date -Format "yyyyMMdd-HHmmss-fff"
  $stdoutPath = Join-Path $tmpDir "$safeName-$stamp.out"
  $stderrPath = Join-Path $tmpDir "$safeName-$stamp.err"
  $commandText = "$FilePath $($Arguments -join ' ')"
  $watch = [System.Diagnostics.Stopwatch]::StartNew()

  try {
    Write-HarnessStatus -Status "running" -Name $Name -Message $commandText
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = $FilePath
    $startInfo.WorkingDirectory = $WorkingDirectory
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = (-not $InheritOutput)
    $startInfo.RedirectStandardError = (-not $InheritOutput)
    foreach ($argument in $Arguments) {
      [void]$startInfo.ArgumentList.Add($argument)
    }

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $startInfo

    [void]$process.Start()
    $stdoutTask = $null
    $stderrTask = $null
    if (-not $InheritOutput) {
      $stdoutTask = $process.StandardOutput.ReadToEndAsync()
      $stderrTask = $process.StandardError.ReadToEndAsync()
    }

    if (-not $process.WaitForExit($TimeoutSec * 1000)) {
      $childSummary = ""
      try {
        $related = Get-CimInstance Win32_Process |
          Where-Object {
            ($_.ProcessId -eq $process.Id) -or
            ($_.ParentProcessId -eq $process.Id) -or
            ($_.Name -match 'ninja|cmake|arm-none-eabi|gcc|ld|collect2|cmd')
          } |
          Select-Object ProcessId,ParentProcessId,Name,CommandLine
        if ($related) {
          $childSummary = ($related | Format-Table -AutoSize | Out-String)
        }
      } catch {
      }
      try {
        $process.Kill($true)
      } catch {
        Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
      }
      try {
        $process.WaitForExit()
      } catch {
      }
      $watch.Stop()
      $stdout = ""
      $stderr = ""
      if (-not $InheritOutput) {
        $stdout = $stdoutTask.GetAwaiter().GetResult()
        $stderr = $stderrTask.GetAwaiter().GetResult()
      }
      if (-not [string]::IsNullOrWhiteSpace($childSummary)) {
        $stderr = "$stderr`nTimed out process tree:`n$childSummary"
      }
      Set-Content -Path $stdoutPath -Value $stdout -Encoding UTF8
      Set-Content -Path $stderrPath -Value $stderr -Encoding UTF8
      return [pscustomobject]@{
        Status = "fail"
        Message = "Timed out after $TimeoutSec seconds."
        Command = $commandText
        ExitCode = $null
        DurationSec = $watch.Elapsed.TotalSeconds
        Stdout = $stdout
        Stderr = $stderr
      }
    }

    $process.WaitForExit()
    $watch.Stop()
    $stdout = ""
    $stderr = ""
    if (-not $InheritOutput) {
      $stdout = $stdoutTask.GetAwaiter().GetResult()
      $stderr = $stderrTask.GetAwaiter().GetResult()
    }
    Set-Content -Path $stdoutPath -Value $stdout -Encoding UTF8
    Set-Content -Path $stderrPath -Value $stderr -Encoding UTF8

    if ($process.ExitCode -eq 0) {
      $status = "pass"
      $message = "Command completed successfully."
    } else {
      $status = "fail"
      $message = "Command exited with code $($process.ExitCode)."
    }

    return [pscustomobject]@{
      Status = $status
      Message = $message
      Command = $commandText
      ExitCode = $process.ExitCode
      DurationSec = $watch.Elapsed.TotalSeconds
      Stdout = $stdout
      Stderr = $stderr
    }
  } catch {
    $watch.Stop()
    return [pscustomobject]@{
      Status = "fail"
      Message = $_.Exception.Message
      Command = $commandText
      ExitCode = $null
      DurationSec = $watch.Elapsed.TotalSeconds
      Stdout = ""
      Stderr = ""
    }
  }
}

function Clear-StaleNinjaLock {
  param([string]$BuildDir)

  $lockPath = Join-Path $BuildDir ".ninja_lock"
  if (-not (Test-Path $lockPath)) {
    return
  }

  $activeBuildProcess = Get-Process -ErrorAction SilentlyContinue |
    Where-Object { $_.ProcessName -match 'ninja|cmake|arm-none-eabi|gcc|ld|collect2' } |
    Select-Object -First 1

  if ($null -eq $activeBuildProcess) {
    Remove-Item -LiteralPath $lockPath -Force -ErrorAction SilentlyContinue
  }
}

function Convert-NinjaDryRunCommand {
  param([string]$Line)

  $command = $Line
  if ($command -match '^\[\d+/\d+\]\s+(.+)$') {
    $command = $Matches[1]
  }

  $cmdPrefixPattern = '^C:\\windows\\system32\\cmd\.exe /C "cd \. && (.+) && cd \."$'
  if ($command -match $cmdPrefixPattern) {
    $command = $Matches[1]
  }

  return $command
}

function Invoke-NinjaPlannedBuild {
  param(
    [string]$BuildDir,
    [int]$TimeoutSec
  )

  $watch = [System.Diagnostics.Stopwatch]::StartNew()
  $plan = Invoke-BoundedProcess -Name "ninja_plan" -FilePath "ninja" -Arguments @("-n", "-v", "-j", "1") -TimeoutSec 10 -WorkingDirectory $BuildDir
  $combinedStdout = $plan.Stdout
  $combinedStderr = $plan.Stderr

  if ($plan.Status -ne "pass") {
    $watch.Stop()
    return [pscustomobject]@{
      Status = "fail"
      Message = "Ninja dry-run planning failed."
      Command = $plan.Command
      ExitCode = $plan.ExitCode
      DurationSec = $watch.Elapsed.TotalSeconds
      Stdout = $combinedStdout
      Stderr = $combinedStderr
    }
  }

  $commands = @()
  foreach ($line in ($plan.Stdout -split "`r?`n")) {
    if ($line -match '^\[\d+/\d+\]\s+') {
      $commands += (Convert-NinjaDryRunCommand -Line $line)
    }
  }

  if ($commands.Count -eq 0) {
    $watch.Stop()
    return [pscustomobject]@{
      Status = "pass"
      Message = "No build work was required."
      Command = "ninja -n -v -j 1"
      ExitCode = 0
      DurationSec = $watch.Elapsed.TotalSeconds
      Stdout = $combinedStdout
      Stderr = $combinedStderr
    }
  }

  $index = 0
  foreach ($command in $commands) {
    $index++
    $cmdPath = Join-Path $tmpDir ("ninja-generated-{0}.cmd" -f $index)
    Set-Content -Path $cmdPath -Value "@echo off`r`n$command`r`n" -Encoding ASCII
    $step = Invoke-BoundedProcess -Name "ninja_generated_$index" -FilePath "cmd.exe" -Arguments @("/d", "/c", $cmdPath) -TimeoutSec $TimeoutSec -WorkingDirectory $BuildDir
    $combinedStdout = "$combinedStdout`n--- generated command $index ---`n$($step.Stdout)"
    $combinedStderr = "$combinedStderr`n--- generated command $index ---`n$($step.Stderr)"
    if ($step.Status -ne "pass") {
      $watch.Stop()
      return [pscustomobject]@{
        Status = "fail"
        Message = "Generated Ninja command $index failed: $($step.Message)"
        Command = $step.Command
        ExitCode = $step.ExitCode
        DurationSec = $watch.Elapsed.TotalSeconds
        Stdout = $combinedStdout
        Stderr = $combinedStderr
      }
    }
  }

  $watch.Stop()
  return [pscustomobject]@{
    Status = "pass"
    Message = "Generated Ninja build commands completed successfully."
    Command = "ninja -n -v -j 1; generated commands x$($commands.Count)"
    ExitCode = 0
    DurationSec = $watch.Elapsed.TotalSeconds
    Stdout = $combinedStdout
    Stderr = $combinedStderr
  }
}

function Resolve-ProgrammerCli {
  if (-not [string]::IsNullOrWhiteSpace($ProgrammerCliPath)) {
    if (Test-Path $ProgrammerCliPath) {
      return (Resolve-Path $ProgrammerCliPath).Path
    }
    return ""
  }

  $cmd = Get-Command "STM32_Programmer_CLI" -ErrorAction SilentlyContinue
  if ($cmd) {
    return $cmd.Source
  }

  $knownPaths = @(
    "C:\Program Files\STMicroelectronics\STM32Cube\STM32CubeProgrammer\bin\STM32_Programmer_CLI.exe",
    "C:\Program Files\STMicroelectronics\STM32Cube\STM32CubeProgrammer\STM32_Programmer_CLI.exe"
  )

  foreach ($path in $knownPaths) {
    if (Test-Path $path) {
      return $path
    }
  }

  return ""
}

function Find-VcpPort {
  $fallbackPorts = [System.IO.Ports.SerialPort]::GetPortNames() | Sort-Object
  $fallbackCandidates = @($fallbackPorts)

  try {
    $ports = Get-CimInstance Win32_PnPEntity |
      Where-Object { $_.Name -match "\(COM\d+\)" } |
      ForEach-Object {
        $match = [regex]::Match($_.Name, "COM\d+")
        [pscustomobject]@{
          Port = $match.Value
          Name = $_.Name
        }
      }

    $preferred = $ports | Where-Object {
      $_.Name -match "STM|STMicroelectronics|Virtual COM|USB Serial|CDC|VCP"
    } | Select-Object -First 1

    if ($preferred) {
      return [pscustomobject]@{
        Status = "pass"
        Port = $preferred.Port
        Name = $preferred.Name
        Candidates = @($ports.Port)
        Message = "Discovered a candidate USB CDC/VCP port."
      }
    }

    $firstNamed = $ports | Select-Object -First 1
    if ($firstNamed) {
      return [pscustomobject]@{
        Status = "pass"
        Port = $firstNamed.Port
        Name = $firstNamed.Name
        Candidates = @($ports.Port)
        Message = "Discovered a candidate COM port."
      }
    }

    if ($fallbackCandidates.Count -eq 1) {
      return [pscustomobject]@{
        Status = "pass"
        Port = $fallbackCandidates[0]
        Name = "SerialPort.GetPortNames fallback"
        Candidates = $fallbackCandidates
        Message = "Discovered the only visible COM port by fallback."
      }
    }

    if ($fallbackCandidates.Count -gt 1) {
      return [pscustomobject]@{
        Status = "fail"
        Port = ""
        Name = "Multiple fallback COM ports visible"
        Candidates = $fallbackCandidates
        Message = "CIM discovery did not identify a VCP and multiple COM ports are visible. Provide -Port COMx."
      }
    }

    return $null
  } catch {
    if ($fallbackCandidates.Count -eq 1) {
      return [pscustomobject]@{
        Status = "pass"
        Port = $fallbackCandidates[0]
        Name = "SerialPort.GetPortNames fallback after CIM error: $($_.Exception.Message)"
        Candidates = $fallbackCandidates
        Message = "Discovered the only visible COM port by fallback."
      }
    }

    if ($fallbackCandidates.Count -gt 1) {
      return [pscustomobject]@{
        Status = "fail"
        Port = ""
        Name = "SerialPort.GetPortNames fallback after CIM error: $($_.Exception.Message)"
        Candidates = $fallbackCandidates
        Message = "CIM discovery failed and multiple COM ports are visible. Provide -Port COMx."
      }
    }

    return $null
  }
}

function Capture-SerialPort {
  param([string]$ComPort, [int]$Baud, [int]$TimeoutSec)

  $watch = [System.Diagnostics.Stopwatch]::StartNew()
  $serial = $null
  $captured = New-Object System.Text.StringBuilder

  try {
    Write-HarnessStatus -Status "running" -Name "vcp_capture" -Message "Opening $ComPort at $Baud baud for $TimeoutSec seconds."
    $serial = New-Object System.IO.Ports.SerialPort($ComPort, $Baud, [System.IO.Ports.Parity]::None, 8, [System.IO.Ports.StopBits]::One)
    $serial.ReadTimeout = 200
    $serial.WriteTimeout = 200
    $serial.Open()

    while ($watch.Elapsed.TotalSeconds -lt $TimeoutSec) {
      $chunk = $serial.ReadExisting()
      if ($chunk.Length -gt 0) {
        [void]$captured.Append($chunk)
      }
      Start-Sleep -Milliseconds 100
    }

    $watch.Stop()
    return [pscustomobject]@{
      Status = "pass"
      Message = "Captured USB CDC/VCP output."
      DurationSec = $watch.Elapsed.TotalSeconds
      Text = $captured.ToString()
    }
  } catch {
    $watch.Stop()
    return [pscustomobject]@{
      Status = "fail"
      Message = $_.Exception.Message
      DurationSec = $watch.Elapsed.TotalSeconds
      Text = $captured.ToString()
    }
  } finally {
    if ($serial -and $serial.IsOpen) {
      $serial.Close()
    }
  }
}

function Convert-HexPattern {
  param([string]$Pattern)

  $bytes = New-Object System.Collections.Generic.List[byte]
  $tokens = @($Pattern -split "[,\s]+" | Where-Object { $_.Trim().Length -gt 0 })

  foreach ($token in $tokens) {
    $clean = $token.Trim()
    if ($clean.StartsWith("0x", [System.StringComparison]::OrdinalIgnoreCase)) {
      $clean = $clean.Substring(2)
    }

    if ($clean.Length -eq 0 -or $clean.Length -gt 2 -or ($clean -notmatch "^[0-9A-Fa-f]+$")) {
      throw "Invalid UART pattern token '$token'. Use hex bytes such as '55 48 69'."
    }

    $bytes.Add([Convert]::ToByte($clean, 16))
  }

  return $bytes.ToArray()
}

function Format-ByteHexList {
  param([byte[]]$Bytes)

  return @($Bytes | ForEach-Object { "0x{0:X2}" -f $_ })
}

function Format-ByteHexText {
  param([byte[]]$Bytes)

  return (($Bytes | ForEach-Object { "{0:X2}" -f $_ }) -join " ")
}

function Format-UartExpectedPayload {
  param(
    [byte[]]$Bytes,
    [string]$DisplayMode
  )

  if ($DisplayMode -eq "hex") {
    return "RX,$(Format-ByteHexText -Bytes $Bytes)`r`n"
  }

  $ascii = [System.Text.Encoding]::ASCII.GetString($Bytes)
  $ascii = $ascii.TrimEnd([char[]]@("`r", "`n"))
  return "RX,$ascii`r`n"
}

function Invoke-SensingStage {
  param([string]$ComPort, [int]$Baud, [int]$TimeoutSec)

  $watch = [System.Diagnostics.Stopwatch]::StartNew()
  $serial = $null
  $captured = New-Object System.Text.StringBuilder

  try {
    Write-HarnessStatus -Status "running" -Name "sensing_normal" -Message "Opening $ComPort, sending ESC 1, and capturing for $TimeoutSec seconds."
    $serial = New-Object System.IO.Ports.SerialPort($ComPort, $Baud, [System.IO.Ports.Parity]::None, 8, [System.IO.Ports.StopBits]::One)
    $serial.ReadTimeout = 200
    $serial.WriteTimeout = 200
    $serial.Open()
    Start-Sleep -Milliseconds 250
    $serial.DiscardInBuffer()

    [byte[]]$normalCommand = @(0x1B, 0x31)
    $serial.Write($normalCommand, 0, $normalCommand.Length)

    while ($watch.Elapsed.TotalSeconds -lt $TimeoutSec) {
      $chunk = $serial.ReadExisting()
      if ($chunk.Length -gt 0) {
        [void]$captured.Append($chunk)
      }
      Start-Sleep -Milliseconds 100
    }

    $watch.Stop()
    $text = $captured.ToString()
    $header = "timestamp_ms,bus_voltage_v,current_a,power_w"
    $hasHeader = $text.Contains($header)
    $hasMode = $text.Contains("mode=normal_sense")
    $rowMatches = [regex]::Matches($text, "(?m)^\d+,-?\d+\.\d{6},-?\d+\.\d{6},-?\d+\.\d{6}\r?$")
    $errorMatches = [regex]::Matches($text, "INA236_CSV_ERR")
    $hasRows = ($rowMatches.Count -gt 0)
    $hasErrors = ($errorMatches.Count -gt 0)
    $status = "fail"
    $message = "Normal sensing output was not recognized."

    if ($hasHeader -and ($hasRows -or $hasErrors)) {
      $status = "pass"
      if ($hasErrors -and -not $hasRows) {
        $message = "Normal sensing emitted CSV header and visible INA236 error output."
      } elseif ($hasErrors) {
        $message = "Normal sensing emitted CSV header, measurement rows, and visible INA236 error output."
      } else {
        $message = "Normal sensing emitted CSV header and measurement rows."
      }
    } elseif (-not $hasHeader -and ($hasRows -or $hasErrors)) {
      $message = "Measurement/error output was captured, but the CSV header was not observed after ESC 1."
    } elseif ($text.Length -eq 0) {
      $message = "No output was captured after ESC 1."
    }

    return [pscustomobject]@{
      Status = $status
      Message = $message
      DurationSec = $watch.Elapsed.TotalSeconds
      Text = $text
      Data = @{
        port = $ComPort
        baud = $Baud
        sent_command = "ESC 1"
        captured_chars = $text.Length
        mode_detected = $hasMode
        csv_header_detected = $hasHeader
        measurement_row_count = $rowMatches.Count
        ina236_error_count = $errorMatches.Count
      }
    }
  } catch {
    $watch.Stop()
    return [pscustomobject]@{
      Status = "fail"
      Message = $_.Exception.Message
      DurationSec = $watch.Elapsed.TotalSeconds
      Text = $captured.ToString()
      Data = @{
        port = $ComPort
        baud = $Baud
        sent_command = "ESC 1"
        captured_chars = $captured.Length
      }
    }
  } finally {
    if ($serial -and $serial.IsOpen) {
      $serial.Close()
    }
  }
}

function Invoke-UartStage {
  param(
    [string]$VcpPort,
    [int]$VcpBaudRate,
    [string]$StimulusPort,
    [int]$StimulusBaud,
    [string]$PatternHex,
    [int]$InterByteDelayMs,
    [string]$DisplayMode,
    [string]$FlushMode,
    [int]$TimeoutSec
  )

  $watch = [System.Diagnostics.Stopwatch]::StartNew()
  $vcp = $null
  $uart = $null
  $captured = New-Object System.Text.StringBuilder

  try {
    $pattern = Convert-HexPattern -Pattern $PatternHex
    if ($pattern.Count -eq 0) {
      throw "UART pattern is empty."
    }

    Write-HarnessStatus -Status "running" -Name "uart_sniff" -Message "Opening VCP $VcpPort, entering UART sniff mode, and writing $PatternHex to $StimulusPort at $StimulusBaud baud."

    $vcp = New-Object System.IO.Ports.SerialPort($VcpPort, $VcpBaudRate, [System.IO.Ports.Parity]::None, 8, [System.IO.Ports.StopBits]::One)
    $vcp.ReadTimeout = 200
    $vcp.WriteTimeout = 200
    $vcp.Open()
    Start-Sleep -Milliseconds 250
    $vcp.DiscardInBuffer()

    [byte[]]$uartModeCommand = @(0x1B, 0x33)
    $vcp.Write($uartModeCommand, 0, $uartModeCommand.Length)
    Start-Sleep -Milliseconds 500

    if ($DisplayMode -eq "hex") {
      [byte[]]$hexModeCommand = @(0x1B, 0x48)
      $vcp.Write($hexModeCommand, 0, $hexModeCommand.Length)
      Start-Sleep -Milliseconds 100
    }

    if ($FlushMode -eq "line") {
      [byte[]]$lineModeCommand = @(0x1B, 0x4C)
      $vcp.Write($lineModeCommand, 0, $lineModeCommand.Length)
      Start-Sleep -Milliseconds 100
    } elseif ($FlushMode -eq "full") {
      [byte[]]$fullModeCommand = @(0x1B, 0x46)
      $vcp.Write($fullModeCommand, 0, $fullModeCommand.Length)
      Start-Sleep -Milliseconds 100
    } else {
      [byte[]]$timeoutModeCommand = @(0x1B, 0x42)
      $vcp.Write($timeoutModeCommand, 0, $timeoutModeCommand.Length)
      Start-Sleep -Milliseconds 100
    }

    $uart = New-Object System.IO.Ports.SerialPort($StimulusPort, $StimulusBaud, [System.IO.Ports.Parity]::None, 8, [System.IO.Ports.StopBits]::One)
    $uart.ReadTimeout = 200
    $uart.WriteTimeout = 200
    $uart.Open()
    if ($InterByteDelayMs -gt 0) {
      foreach ($byte in $pattern) {
        [byte[]]$singleByte = @($byte)
        $uart.Write($singleByte, 0, 1)
        Start-Sleep -Milliseconds $InterByteDelayMs
      }
    } else {
      $uart.Write($pattern, 0, $pattern.Length)
    }

    while ($watch.Elapsed.TotalSeconds -lt $TimeoutSec) {
      $chunk = $vcp.ReadExisting()
      if ($chunk.Length -gt 0) {
        [void]$captured.Append($chunk)
      }
      Start-Sleep -Milliseconds 100
    }

    $watch.Stop()
    $text = $captured.ToString()
    $expectedPayload = Format-UartExpectedPayload -Bytes $pattern -DisplayMode $DisplayMode
    $expectedOptionMessages = @()
    if ($DisplayMode -eq "hex") {
      $expectedOptionMessages += "option=uart_display mode=hex`r`n"
    }

    if ($FlushMode -eq "line") {
      $expectedOptionMessages += "option=uart_flush mode=line`r`n"
    } elseif ($FlushMode -eq "full") {
      $expectedOptionMessages += "option=uart_flush mode=full`r`n"
    } else {
      $expectedOptionMessages += "option=uart_flush mode=timeout`r`n"
    }

    $payloadMatched = $text.Contains($expectedPayload)
    $optionMessagesMatched = $true
    foreach ($expectedOptionMessage in $expectedOptionMessages) {
      if (-not $text.Contains($expectedOptionMessage)) {
        $optionMessagesMatched = $false
      }
    }
    $matched = ($payloadMatched -and $optionMessagesMatched)
    $status = "fail"
    $message = "UART stimulus payload was not observed on USB CDC output."
    $displayCommand = "default ascii"
    $flushCommand = "ESC B"

    if ($DisplayMode -eq "hex") {
      $displayCommand = "ESC H"
    }

    if ($FlushMode -eq "line") {
      $flushCommand = "ESC L"
    } elseif ($FlushMode -eq "full") {
      $flushCommand = "ESC F"
    }

    if ($matched) {
      $status = "pass"
      $message = "UART stimulus payload was observed in UART sniff output."
    } elseif ($payloadMatched -and (-not $optionMessagesMatched)) {
      $message = "UART stimulus payload was observed, but one or more option-change messages were missing."
    } elseif ($text.Length -gt 0) {
      $message = "UART output was observed, but it did not match the requested stimulus payload."
    } elseif ($text.Contains("mode=uart_sniff")) {
      $message = "UART sniff mode was entered, but no payload was observed."
    } elseif ($text.Length -eq 0) {
      $message = "No USB CDC output was captured during the UART test."
    }

    return [pscustomobject]@{
      Status = $status
      Message = $message
      DurationSec = $watch.Elapsed.TotalSeconds
      Text = $text
      Data = @{
        vcp_port = $VcpPort
        stimulus_port = $StimulusPort
        stimulus_baud = $StimulusBaud
        inter_byte_delay_ms = $InterByteDelayMs
        display_mode = $DisplayMode
        flush_mode = $FlushMode
        vcp_baud = $VcpBaudRate
        sent_command = "ESC 3"
        display_command = $displayCommand
        flush_command = $flushCommand
        stimulus_hex = (Format-ByteHexList -Bytes $pattern)
        expected_payload = $expectedPayload
        payload_matched = $payloadMatched
        expected_option_messages = $expectedOptionMessages
        option_messages_matched = $optionMessagesMatched
        observed_payload_excerpt = (Convert-Excerpt $text)
        expected_pattern_matched = $matched
        detected_uart_baud = $null
        captured_chars = $text.Length
      }
    }
  } catch {
    $watch.Stop()
    return [pscustomobject]@{
      Status = "fail"
      Message = $_.Exception.Message
      DurationSec = $watch.Elapsed.TotalSeconds
      Text = $captured.ToString()
      Data = @{
        vcp_port = $VcpPort
        stimulus_port = $StimulusPort
        stimulus_baud = $StimulusBaud
        inter_byte_delay_ms = $InterByteDelayMs
        display_mode = $DisplayMode
        flush_mode = $FlushMode
        vcp_baud = $VcpBaudRate
        sent_command = "ESC 3"
        stimulus_hex = $PatternHex
        expected_payload = ""
        observed_payload_excerpt = (Convert-Excerpt $captured.ToString())
        expected_pattern_matched = $false
        detected_uart_baud = $null
        captured_chars = $captured.Length
      }
    }
  } finally {
    if ($uart -and $uart.IsOpen) {
      $uart.Close()
    }
    if ($vcp -and $vcp.IsOpen) {
      $vcp.Close()
    }
  }
}

function Convert-I2cDecodedLines {
  param([string]$Text)

  $packets = @()
  $overflows = @()
  $timeouts = @()
  $busLow = @()
  foreach ($line in ($Text -split "`r?`n")) {
    if ($line -match '^\[(?:0x[0-9A-F]{2}[WR]?|[\[\]+-])+\]$') {
      $packets += [pscustomobject]@{
        raw = $line
        repeated_start = (($line.ToCharArray() | Where-Object { $_ -eq '[' }).Count -gt 1)
      }
    } elseif ($line -match '^I2C,OVERFLOW,([A-Za-z0-9_]+)$') {
      $overflows += [pscustomobject]@{
        reason = $Matches[1]
        raw = $line
      }
    } elseif ($line -match '^I2C,TIMEOUT,bits=(\d+),partial=(.*)$') {
      $timeouts += [pscustomobject]@{
        bits = [int]$Matches[1]
        partial = $Matches[2]
        raw = $line
      }
    } elseif ($line -match '^I2C,BUS_LOW,scl=(\d+),sda=(\d+)$') {
      $busLow += [pscustomobject]@{
        scl = [int]$Matches[1]
        sda = [int]$Matches[2]
        raw = $line
      }
    }
  }

  return [pscustomobject]@{
    Packets = @($packets)
    Overflows = @($overflows)
    Timeouts = @($timeouts)
    BusLow = @($busLow)
  }
}

function Invoke-I2cStage {
  param(
    [string]$VcpPort,
    [int]$VcpBaudRate,
    [int]$TimeoutSec,
    [string]$StimulusCommand,
    [int]$StimulusTimeoutSec
  )

  $watch = [System.Diagnostics.Stopwatch]::StartNew()
  $vcp = $null
  $captured = New-Object System.Text.StringBuilder
  $stimulusStatus = "skipped"
  $stimulusMessage = "No I2C stimulus command was provided; observe-only capture was used."
  $stimulusResult = $null

  try {
    Write-HarnessStatus -Status "running" -Name "i2c_sniff" -Message "Opening VCP $VcpPort, entering I2C sniff mode, and observing PB3/PB4 for $TimeoutSec seconds."

    $vcp = New-Object System.IO.Ports.SerialPort($VcpPort, $VcpBaudRate, [System.IO.Ports.Parity]::None, 8, [System.IO.Ports.StopBits]::One)
    $vcp.ReadTimeout = 200
    $vcp.WriteTimeout = 200
    $vcp.Open()
    Start-Sleep -Milliseconds 250
    $vcp.DiscardInBuffer()

    [byte[]]$i2cModeCommand = @(0x1B, 0x32)
    $vcp.Write($i2cModeCommand, 0, $i2cModeCommand.Length)
    Start-Sleep -Milliseconds 500

    if (-not [string]::IsNullOrWhiteSpace($StimulusCommand)) {
      $stimulusResult = Invoke-BoundedProcess -Name "i2c_stimulus" -FilePath "pwsh" -Arguments @("-NoProfile", "-Command", $StimulusCommand) -TimeoutSec $StimulusTimeoutSec
      $stimulusStatus = $stimulusResult.Status
      $stimulusMessage = $stimulusResult.Message
    }

    while ($watch.Elapsed.TotalSeconds -lt $TimeoutSec) {
      $chunk = $vcp.ReadExisting()
      if ($chunk.Length -gt 0) {
        [void]$captured.Append($chunk)
      }
      Start-Sleep -Milliseconds 100
    }

    $watch.Stop()
    $text = $captured.ToString()
    $decoded = Convert-I2cDecodedLines -Text $text
    $packets = @($decoded.Packets)
    $overflows = @($decoded.Overflows)
    $timeouts = @($decoded.Timeouts)
    $busLow = @($decoded.BusLow)

    $status = "fail"
    $message = "No decoded I2C packet lines were observed on USB CDC output."
    if ($packets.Count -gt 0) {
      $status = "pass"
      $message = "Decoded I2C packet output was observed."
    } elseif ($timeouts.Count -gt 0) {
      $message = "I2C activity started but timed out before a complete decoded packet was observed."
    } elseif ($busLow.Count -gt 0) {
      $message = "I2C bus-low diagnostic was observed, but no complete decoded packet was observed."
    } elseif ($overflows.Count -gt 0) {
      $message = "I2C capture overflow was reported, but no complete decoded packet was observed."
    } elseif ($text.Contains("mode=i2c_sniff")) {
      $message = "I2C sniff mode was entered, but no decoded packet was observed."
    } elseif ($text.Length -eq 0) {
      $message = "No USB CDC output was captured during the I2C test."
    }

    if (($stimulusStatus -eq "fail") -and ($status -eq "pass")) {
      $status = "fail"
      $message = "Decoded I2C packet output was observed, but the configured I2C stimulus command failed."
    }

    $stimulusStdoutExcerpt = ""
    $stimulusStderrExcerpt = ""
    if ($stimulusResult) {
      $stimulusStdoutExcerpt = Convert-Excerpt $stimulusResult.Stdout
      $stimulusStderrExcerpt = Convert-Excerpt $stimulusResult.Stderr
    }

    return [pscustomobject]@{
      Status = $status
      Message = $message
      DurationSec = $watch.Elapsed.TotalSeconds
      Text = $text
      Data = @{
        vcp_port = $VcpPort
        vcp_baud = $VcpBaudRate
        sent_command = "ESC 2"
        observe_only = [string]::IsNullOrWhiteSpace($StimulusCommand)
        stimulus_command = $StimulusCommand
        stimulus_status = $stimulusStatus
        stimulus_message = $stimulusMessage
        stimulus_stdout_excerpt = $stimulusStdoutExcerpt
        stimulus_stderr_excerpt = $stimulusStderrExcerpt
        decoded_packet_count = $packets.Count
        observed_packets = @($packets)
        overflow_count = $overflows.Count
        observed_overflows = @($overflows)
        timeout_count = $timeouts.Count
        observed_timeouts = @($timeouts)
        bus_low_count = $busLow.Count
        observed_bus_low = @($busLow)
        detected_i2c_speed_hz = $null
        captured_chars = $text.Length
        observed_payload_excerpt = (Convert-Excerpt $text)
      }
    }
  } catch {
    $watch.Stop()
    return [pscustomobject]@{
      Status = "fail"
      Message = $_.Exception.Message
      DurationSec = $watch.Elapsed.TotalSeconds
      Text = $captured.ToString()
      Data = @{
        vcp_port = $VcpPort
        vcp_baud = $VcpBaudRate
        sent_command = "ESC 2"
        observe_only = [string]::IsNullOrWhiteSpace($StimulusCommand)
        stimulus_command = $StimulusCommand
        stimulus_status = $stimulusStatus
        stimulus_message = $stimulusMessage
        decoded_packet_count = 0
        observed_packets = @()
        overflow_count = 0
        observed_overflows = @()
        timeout_count = 0
        observed_timeouts = @()
        bus_low_count = 0
        observed_bus_low = @()
        detected_i2c_speed_hz = $null
        captured_chars = $captured.Length
        observed_payload_excerpt = (Convert-Excerpt $captured.ToString())
      }
    }
  } finally {
    if ($vcp -and $vcp.IsOpen) {
      $vcp.Close()
    }
  }
}

Push-Location $repoRoot
try {
  Write-Host "TheSensor hardware verification"
  Write-Host "  Repo: $repoRoot"
  Write-Host "  Report: $reportFullPath"
  Write-Host "  Preset: $Preset"
  Write-Host "  ELF: $ElfPath"
  Write-Host "  Stages: $Stages"
  if (-not [string]::IsNullOrWhiteSpace($Port)) {
    Write-Host "  VCP override: $Port"
  }
  if (-not [string]::IsNullOrWhiteSpace($UartPort)) {
    Write-Host "  UART stimulus: $UartPort at $UartBaud baud"
  }
  Write-Host ""

  $configure = Invoke-BoundedProcess -Name "cmake_configure" -FilePath "cmake" -Arguments @("--preset", $Preset) -TimeoutSec $BuildTimeoutSec
  Add-Step -Name "cmake_configure" -Status $configure.Status -Message $configure.Message -Command $configure.Command -ExitCode $configure.ExitCode -DurationSec $configure.DurationSec -Stdout $configure.Stdout -Stderr $configure.Stderr

  $build = $null
  if ($configure.Status -eq "pass") {
    $buildDir = Join-Path $repoRoot (Join-Path "build" $Preset)
    Clear-StaleNinjaLock -BuildDir $buildDir
    $build = Invoke-NinjaPlannedBuild -BuildDir $buildDir -TimeoutSec $BuildTimeoutSec
    Add-Step -Name "ninja_build" -Status $build.Status -Message $build.Message -Command $build.Command -ExitCode $build.ExitCode -DurationSec $build.DurationSec -Stdout $build.Stdout -Stderr $build.Stderr -Data @{ build_dir = $buildDir; cmake_build_wrapper_note = "The CMake build wrapper and direct Ninja invocation have timed out in this shell environment, so the harness executes Ninja's generated commands with bounded timeouts." }
  } else {
    Add-Step -Name "ninja_build" -Status "skipped" -Message "Skipped because CMake configure failed."
  }
  $buildReady = (($configure.Status -eq "pass") -and ($build -ne $null) -and ($build.Status -eq "pass"))

  $programmer = Resolve-ProgrammerCli
  if ([string]::IsNullOrWhiteSpace($programmer)) {
    Add-Step -Name "programmer_discovery" -Status "fail" -Message "STM32_Programmer_CLI was not found. Provide -ProgrammerCliPath or add it to PATH."
  } else {
    Add-Step -Name "programmer_discovery" -Status "pass" -Message "Found STM32CubeProgrammer CLI." -Data @{ path = $programmer }
  }

  $resolvedElf = Join-Path $repoRoot $ElfPath
  if (-not (Test-Path $resolvedElf)) {
    Add-Step -Name "elf_check" -Status "fail" -Message "ELF file was not found." -Data @{ path = $resolvedElf }
  } else {
    Add-Step -Name "elf_check" -Status "pass" -Message "ELF file exists." -Data @{ path = $resolvedElf }
  }

  if (-not $buildReady) {
    Add-Step -Name "flash_verify" -Status "skipped" -Message "Skipped because the firmware build did not pass."
    Add-Step -Name "reset_run" -Status "skipped" -Message "Skipped because the firmware build did not pass."
  } elseif (-not [string]::IsNullOrWhiteSpace($programmer) -and (Test-Path $resolvedElf)) {
    $flashArgs = @("-c", "port=SWD", "mode=UR", "reset=HWrst", "-w", $resolvedElf, "-v")
    $flash = Invoke-BoundedProcess -Name "flash_verify" -FilePath $programmer -Arguments $flashArgs -TimeoutSec $FlashTimeoutSec
    Add-Step -Name "flash_verify" -Status $flash.Status -Message $flash.Message -Command $flash.Command -ExitCode $flash.ExitCode -DurationSec $flash.DurationSec -Stdout $flash.Stdout -Stderr $flash.Stderr

    $resetArgs = @("-c", "port=SWD", "mode=UR", "reset=HWrst", "-rst", "-run")
    $reset = Invoke-BoundedProcess -Name "reset_run" -FilePath $programmer -Arguments $resetArgs -TimeoutSec $ResetTimeoutSec
    Add-Step -Name "reset_run" -Status $reset.Status -Message $reset.Message -Command $reset.Command -ExitCode $reset.ExitCode -DurationSec $reset.DurationSec -Stdout $reset.Stdout -Stderr $reset.Stderr
  } else {
    Add-Step -Name "flash_verify" -Status "skipped" -Message "Skipped because programmer CLI or ELF was unavailable."
    Add-Step -Name "reset_run" -Status "skipped" -Message "Skipped because programmer CLI or ELF was unavailable."
  }

  if ($PostResetDelaySec -gt 0) {
    Start-Sleep -Seconds $PostResetDelaySec
  }

  $selectedPort = $Port
  if ([string]::IsNullOrWhiteSpace($selectedPort)) {
    $discovered = Find-VcpPort
    if ($discovered -and $discovered.Status -eq "pass") {
      $selectedPort = $discovered.Port
      Add-Step -Name "vcp_discovery" -Status "pass" -Message $discovered.Message -Data @{ port = $discovered.Port; name = $discovered.Name; candidates = $discovered.Candidates }
    } elseif ($discovered) {
      Add-Step -Name "vcp_discovery" -Status "fail" -Message $discovered.Message -Data @{ name = $discovered.Name; candidates = $discovered.Candidates }
    } else {
      Add-Step -Name "vcp_discovery" -Status "fail" -Message "No COM port candidate found. Provide -Port COMx."
    }
  } else {
    Add-Step -Name "vcp_discovery" -Status "skipped" -Message "Using COM port provided by -Port." -Data @{ port = $selectedPort }
  }

  if (-not [string]::IsNullOrWhiteSpace($selectedPort)) {
    $capture = Capture-SerialPort -ComPort $selectedPort -Baud $VcpBaud -TimeoutSec $CaptureTimeoutSec
    $captureStatus = $capture.Status
    $captureMessage = $capture.Message
    if ($captureStatus -eq "pass" -and [string]::IsNullOrEmpty($capture.Text)) {
      $captureStatus = "fail"
      $captureMessage = "VCP opened but no output was captured within $CaptureTimeoutSec seconds."
    }
    Add-Step -Name "vcp_capture" -Status $captureStatus -Message $captureMessage -DurationSec $capture.DurationSec -Stdout $capture.Text -Data @{ port = $selectedPort; baud = $VcpBaud; captured_chars = $capture.Text.Length }
  } else {
    Add-Step -Name "vcp_capture" -Status "skipped" -Message "Skipped because no VCP COM port was available."
  }

  if (Test-StageEnabled "sensing") {
    if (-not [string]::IsNullOrWhiteSpace($selectedPort)) {
      $sensing = Invoke-SensingStage -ComPort $selectedPort -Baud $VcpBaud -TimeoutSec $SensingTimeoutSec
      Add-Step -Name "sensing_normal" -Status $sensing.Status -Message $sensing.Message -DurationSec $sensing.DurationSec -Stdout $sensing.Text -Data $sensing.Data
    } else {
      Add-Step -Name "sensing_normal" -Status "skipped" -Message "Skipped because no VCP COM port was available."
    }
  } else {
    Add-Step -Name "sensing_normal" -Status "skipped" -Message "Skipped because the sensing stage was not selected."
  }

  if (Test-StageEnabled "uart") {
    if ([string]::IsNullOrWhiteSpace($UartPort)) {
      Add-Step -Name "uart_sniff" -Status "skipped" -Message "Skipped because no UART stimulus port was provided. Wire stimulus TX to STM32 PA3/USART2_RX with common ground and pass -UartPort COMx." -Data @{
        wiring = "Stimulus TX to STM32 PA3/USART2_RX; common ground required."
        stimulus_baud = $UartBaud
        inter_byte_delay_ms = $UartInterByteDelayMs
        display_mode = $UartDisplayMode
        flush_mode = $UartFlushMode
        stimulus_hex = $UartPatternHex
        detected_uart_baud = $null
      }
    } elseif (-not [string]::IsNullOrWhiteSpace($selectedPort)) {
      $uartStage = Invoke-UartStage -VcpPort $selectedPort -VcpBaudRate $VcpBaud -StimulusPort $UartPort -StimulusBaud $UartBaud -PatternHex $UartPatternHex -InterByteDelayMs $UartInterByteDelayMs -DisplayMode $UartDisplayMode -FlushMode $UartFlushMode -TimeoutSec $UartTimeoutSec
      Add-Step -Name "uart_sniff" -Status $uartStage.Status -Message $uartStage.Message -DurationSec $uartStage.DurationSec -Stdout $uartStage.Text -Data $uartStage.Data
    } else {
      Add-Step -Name "uart_sniff" -Status "skipped" -Message "Skipped because no VCP COM port was available." -Data @{
        stimulus_port = $UartPort
        stimulus_baud = $UartBaud
        inter_byte_delay_ms = $UartInterByteDelayMs
        display_mode = $UartDisplayMode
        flush_mode = $UartFlushMode
        stimulus_hex = $UartPatternHex
        detected_uart_baud = $null
      }
    }
  } else {
    Add-Step -Name "uart_sniff" -Status "skipped" -Message "Skipped because the UART stage was not selected."
  }

  if (Test-StageEnabled "i2c") {
    if (-not [string]::IsNullOrWhiteSpace($selectedPort)) {
      $i2cStage = Invoke-I2cStage -VcpPort $selectedPort -VcpBaudRate $VcpBaud -TimeoutSec $I2cTimeoutSec -StimulusCommand $I2cStimulusCommand -StimulusTimeoutSec $I2cStimulusTimeoutSec
      Add-Step -Name "i2c_sniff" -Status $i2cStage.Status -Message $i2cStage.Message -DurationSec $i2cStage.DurationSec -Stdout $i2cStage.Text -Data $i2cStage.Data
    } else {
      Add-Step -Name "i2c_sniff" -Status "skipped" -Message "Skipped because no VCP COM port was available." -Data @{
        wiring = "External I2C SCL to STM32 PB3/I2C2_EXT_SCL; SDA to PB4/I2C2_EXT_SDA; common ground and suitable pull-ups required."
        observe_only = [string]::IsNullOrWhiteSpace($I2cStimulusCommand)
        stimulus_command = $I2cStimulusCommand
        detected_i2c_speed_hz = $null
      }
    }
  } else {
    Add-Step -Name "i2c_sniff" -Status "skipped" -Message "Skipped because the I2C stage was not selected."
  }
} catch {
  Add-Step -Name "harness_unhandled_error" -Status "fail" -Message $_.Exception.Message
} finally {
  Pop-Location
  Save-Report
}

Write-Host "TheSensor hardware verification summary"
Write-Host "  Report: $reportFullPath"
Write-Host "  Pass: $($script:Report.summary.pass)"
Write-Host "  Fail: $($script:Report.summary.fail)"
Write-Host "  Skipped: $($script:Report.summary.skipped)"

foreach ($step in $script:Report.steps) {
  Write-Host ("  [{0}] {1}: {2}" -f $step.status.ToUpperInvariant(), $step.name, $step.message)
}

if ($script:Report.summary.fail -gt 0) {
  exit 1
}

exit 0
