# Picasso

Read-only parsed net color viewer for the focused Altium PCB project.

## What It Does

- Reads the focused project's `.PrjPcb` file into memory.
- Parses `[NetInfos]` and class-like sections using best-effort text parsing.
- Preserves raw project-file text beside every inferred field.
- Shows parsed net/color data in a compact dark form with a copyable memo.
- Provides four report views:
  - `Power`
  - `Net Classes`
  - `Unmatched Nets`
  - `All Nets`

Picasso does not modify, save, close, patch, or reopen any project or schematic
documents in this first version.

## How To Run

1. Open the target PCB project in Altium Designer.
2. Focus that project in the Projects panel.
3. Run:

```text
PICASSO.pas>RunPicasso
```

Or use `Red 6 > Picasso` after running the Red 6 menu installer.

## Views

- `All Nets` shows every parsed row from `[NetInfos]`.
- `Power` shows parsed rows whose inferred net names look like power nets, such
  as `GND`, `AGND`, `DGND`, `VIN`, `VBAT`, `VCC`, `VDD`, `VSS`, `VEE`, `+5V`,
  `-12V`, `3V3`, `5V`, and `1V8`.
- `Net Classes` groups parsed rows by inferred net class. Rows with no detected
  class are grouped under `Unclassified`.
- `Unmatched Nets` shows parsed rows without recognizable color or color-index
  information.

## Required Altium State

- A PCB project must be focused in the Projects panel.
- The focused project must expose `DM_ProjectFullPath`.
- The `.PrjPcb` file must be readable from disk.

If Picasso cannot infer a net name, class, or color field, it reports that in
the memo and includes the raw project-file line for inspection.

Final validation must happen inside Altium Designer.

