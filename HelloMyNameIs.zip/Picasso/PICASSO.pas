{ Altium Designer DelphiScript
  Read-only parsed net color viewer for the focused PCB project.

  Run procedure: RunPicasso
}

uses
    SysUtils,
    Classes,
    Dialogs,
    Forms,
    Controls,
    StdCtrls;

const
    UI_DARK_BACKGROUND = $00302D2B;
    UI_DARK_CONTROL = $002A2725;
    UI_DARK_FIELD = $001E1E1E;
    UI_DARK_TEXT = $00E3DDD7;
    UI_DARK_MUTED_TEXT = $00BFB6AE;

    PICASSO_VIEW_POWER = 101;
    PICASSO_VIEW_CLASSES = 102;
    PICASSO_VIEW_UNMATCHED = 103;
    PICASSO_VIEW_ALL = 104;
    PICASSO_REFRESH = 105;

    PICASSO_COL_NET = 0;
    PICASSO_COL_COLOR_INDEX = 1;
    PICASSO_COL_COLOR_VALUE = 2;
    PICASSO_COL_RGB = 3;
    PICASSO_COL_CLASS = 4;
    PICASSO_COL_SECTION = 5;
    PICASSO_COL_KEY = 6;
    PICASSO_COL_VALUE = 7;
    PICASSO_COL_LINE = 8;
    PICASSO_COL_RAW = 9;

procedure ShowCopyableMessage(Title, MessageText : String);
var
    MessageForm : TForm;
    MessageMemo : TMemo;
    OkButton    : TButton;
begin
    MessageForm := TForm.Create(nil);
    try
        MessageForm.Caption := Title;
        MessageForm.Position := poScreenCenter;
        MessageForm.BorderStyle := bsDialog;
        MessageForm.Width := 720;
        MessageForm.Height := 420;

        MessageMemo := TMemo.Create(MessageForm);
        MessageMemo.Parent := MessageForm;
        MessageMemo.Left := 12;
        MessageMemo.Top := 12;
        MessageMemo.Width := MessageForm.ClientWidth - 24;
        MessageMemo.Height := MessageForm.ClientHeight - 56;
        MessageMemo.ReadOnly := True;
        MessageMemo.WordWrap := False;
        MessageMemo.ScrollBars := ssBoth;
        MessageMemo.Text := MessageText;

        OkButton := TButton.Create(MessageForm);
        OkButton.Parent := MessageForm;
        OkButton.Caption := 'OK';
        OkButton.Width := 88;
        OkButton.Height := 26;
        OkButton.Left := MessageForm.ClientWidth - OkButton.Width - 12;
        OkButton.Top := MessageForm.ClientHeight - OkButton.Height - 10;
        OkButton.ModalResult := mrOK;

        MessageForm.ActiveControl := MessageMemo;
        MessageMemo.SelectAll;
        MessageForm.ShowModal;
    finally
        MessageForm.Free;
    end;
end;

procedure ShowPicassoMessage(MessageText : String);
begin
    ShowCopyableMessage('Picasso', MessageText);
end;

procedure ApplyDarkFormStyle(AForm : TForm);
begin
    AForm.Color := UI_DARK_BACKGROUND;
    AForm.Font.Name := 'Segoe UI';
    AForm.Font.Size := 9;
    AForm.Font.Color := UI_DARK_TEXT;
end;

procedure ApplyDarkLabelStyle(ALabel : TLabel);
begin
    ALabel.Transparent := True;
    ALabel.Font.Color := UI_DARK_MUTED_TEXT;
end;

procedure ApplyDarkMemoStyle(AMemo : TMemo);
begin
    AMemo.Color := UI_DARK_FIELD;
    AMemo.Font.Color := UI_DARK_TEXT;
    AMemo.ReadOnly := True;
    AMemo.WordWrap := False;
    AMemo.ScrollBars := ssBoth;
    AMemo.Ctl3D := False;
end;

procedure ApplyDarkButtonStyle(AButton : TButton);
begin
    AButton.Font.Color := UI_DARK_TEXT;
end;

function BoolText(Value : Boolean) : String;
begin
    if Value then
        Result := 'yes'
    else
        Result := 'no';
end;

function SameTextLocal(A, B : String) : Boolean;
begin
    Result := UpperCase(Trim(A)) = UpperCase(Trim(B));
end;

function ContainsTextLocal(Value, Fragment : String) : Boolean;
begin
    Result := Pos(UpperCase(Fragment), UpperCase(Value)) > 0;
end;

function StartsWithTextLocal(Value, Prefix : String) : Boolean;
begin
    Result := Copy(UpperCase(Trim(Value)), 1, Length(Prefix)) = UpperCase(Prefix);
end;

function EndsWithTextLocal(Value, Suffix : String) : Boolean;
var
    S : String;
begin
    S := Trim(Value);
    if Length(S) < Length(Suffix) then
    begin
        Result := False;
        Exit;
    end;

    Result := Copy(UpperCase(S), Length(S) - Length(Suffix) + 1, Length(Suffix)) = UpperCase(Suffix);
end;

function FileNameOnly(PathText : String) : String;
var
    I : Integer;
begin
    Result := PathText;
    for I := Length(PathText) downto 1 do
    begin
        if Copy(PathText, I, 1) = '\' then
        begin
            Result := Copy(PathText, I + 1, Length(PathText));
            Exit;
        end;
    end;
end;

function PadRightText(Value : String; TargetLength : Integer) : String;
begin
    Result := Value;
    while Length(Result) < TargetLength do
        Result := Result + ' ';
end;

function CleanToken(Value : String) : String;
var
    S : String;
begin
    S := Trim(Value);
    while (Length(S) > 0) and ((Copy(S, 1, 1) = '"') or (Copy(S, 1, 1) = '''')) do
        S := Copy(S, 2, Length(S));
    while (Length(S) > 0) and ((Copy(S, Length(S), 1) = '"') or (Copy(S, Length(S), 1) = '''')) do
        S := Copy(S, 1, Length(S) - 1);
    Result := Trim(S);
end;

function TextBefore(Value, Marker : String) : String;
var
    MarkerAt : Integer;
begin
    Result := Value;
    MarkerAt := Pos(Marker, Value);
    if MarkerAt > 0 then
        Result := Copy(Value, 1, MarkerAt - 1);
end;

function NextSeparatorOffset(Value : String; StartAt : Integer) : Integer;
var
    I : Integer;
    Ch : String;
begin
    Result := 0;
    for I := StartAt to Length(Value) do
    begin
        Ch := Copy(Value, I, 1);
        if (Ch = '|') or (Ch = ';') or (Ch = ',') or (Ch = #9) then
        begin
            Result := I;
            Exit;
        end;
    end;
end;

function ExtractNamedValue(TextValue, FieldName : String) : String;
var
    UpperText  : String;
    UpperField : String;
    MarkerAt   : Integer;
    StartAt    : Integer;
    EndAt      : Integer;
begin
    Result := '';
    UpperText := UpperCase(TextValue);
    UpperField := UpperCase(FieldName) + '=';
    MarkerAt := Pos(UpperField, UpperText);
    if MarkerAt <= 0 then
        Exit;

    StartAt := MarkerAt + Length(UpperField);
    EndAt := NextSeparatorOffset(TextValue, StartAt);
    if EndAt <= 0 then
        Result := Copy(TextValue, StartAt, Length(TextValue))
    else
        Result := Copy(TextValue, StartAt, EndAt - StartAt);
    Result := CleanToken(Result);
end;

function FirstNonBlank(A, B, C, D, E : String) : String;
begin
    Result := Trim(A);
    if Result <> '' then
        Exit;
    Result := Trim(B);
    if Result <> '' then
        Exit;
    Result := Trim(C);
    if Result <> '' then
        Exit;
    Result := Trim(D);
    if Result <> '' then
        Exit;
    Result := Trim(E);
end;

function LooksLikeNumericNetInfoKey(KeyText : String) : Boolean;
var
    I : Integer;
    S : String;
begin
    Result := False;
    S := UpperCase(Trim(KeyText));
    if not StartsWithTextLocal(S, 'NET') then
        Exit;
    if Length(S) <= 3 then
        Exit;

    Result := True;
    for I := 4 to Length(S) do
    begin
        if Pos(Copy(S, I, 1), '0123456789') <= 0 then
        begin
            Result := False;
            Exit;
        end;
    end;
end;

function InferNameFromKeyValue(KeyText, ValueText, RawText : String) : String;
var
    Candidate : String;
begin
    Result := FirstNonBlank(ExtractNamedValue(RawText, 'NetName'),
                            ExtractNamedValue(RawText, 'Net'),
                            ExtractNamedValue(RawText, 'Name'),
                            ExtractNamedValue(RawText, 'Signal'),
                            ExtractNamedValue(RawText, 'Node'));

    if Result <> '' then
        Exit;

    if (not LooksLikeNumericNetInfoKey(KeyText)) and (Trim(KeyText) <> '') then
    begin
        Result := CleanToken(KeyText);
        Exit;
    end;

    Candidate := TextBefore(ValueText, '|');
    Candidate := TextBefore(Candidate, ';');
    Candidate := TextBefore(Candidate, ',');
    Candidate := CleanToken(Candidate);
    if (Candidate <> '') and (Pos('=', Candidate) <= 0) then
        Result := Candidate;
end;

function InferColorIndex(RawText : String) : String;
begin
    Result := FirstNonBlank(ExtractNamedValue(RawText, 'NetColorIndex'),
                            ExtractNamedValue(RawText, 'ColorIndex'),
                            ExtractNamedValue(RawText, 'ColourIndex'),
                            ExtractNamedValue(RawText, 'Index'),
                            '');
end;

function InferColorValue(RawText : String) : String;
begin
    Result := FirstNonBlank(ExtractNamedValue(RawText, 'NetColor'),
                            ExtractNamedValue(RawText, 'Color'),
                            ExtractNamedValue(RawText, 'Colour'),
                            ExtractNamedValue(RawText, 'ColorValue'),
                            ExtractNamedValue(RawText, 'ColourValue'));
end;

function InferRgbValue(RawText : String) : String;
begin
    Result := FirstNonBlank(ExtractNamedValue(RawText, 'RGB'),
                            ExtractNamedValue(RawText, 'TrueColor'),
                            ExtractNamedValue(RawText, 'TrueColour'),
                            ExtractNamedValue(RawText, 'ColorRGB'),
                            ExtractNamedValue(RawText, 'ColourRGB'));
end;

function InferClassValue(RawText : String) : String;
begin
    Result := FirstNonBlank(ExtractNamedValue(RawText, 'NetClass'),
                            ExtractNamedValue(RawText, 'ClassName'),
                            ExtractNamedValue(RawText, 'Class'),
                            ExtractNamedValue(RawText, 'NetClassName'),
                            '');
end;

function MakeParsedRow(NetName, ColorIndex, ColorValue, RgbValue, ClassText,
                       SectionText, KeyText, ValueText : String; LineNumber : Integer; RawText : String) : String;
begin
    Result := NetName + #9 +
              ColorIndex + #9 +
              ColorValue + #9 +
              RgbValue + #9 +
              ClassText + #9 +
              SectionText + #9 +
              KeyText + #9 +
              ValueText + #9 +
              IntToStr(LineNumber) + #9 +
              RawText;
end;

function RowField(RowText : String; WantedIndex : Integer) : String;
var
    I            : Integer;
    CurrentIndex : Integer;
    TokenStart   : Integer;
begin
    Result := '';
    CurrentIndex := 0;
    TokenStart := 1;

    for I := 1 to Length(RowText) do
    begin
        if Copy(RowText, I, 1) = #9 then
        begin
            if CurrentIndex = WantedIndex then
            begin
                Result := Copy(RowText, TokenStart, I - TokenStart);
                Exit;
            end;
            Inc(CurrentIndex);
            TokenStart := I + 1;
        end;
    end;

    if CurrentIndex = WantedIndex then
        Result := Copy(RowText, TokenStart, Length(RowText));
end;

function HasColorData(RowText : String) : Boolean;
begin
    Result := (Trim(RowField(RowText, PICASSO_COL_COLOR_INDEX)) <> '') or
              (Trim(RowField(RowText, PICASSO_COL_COLOR_VALUE)) <> '') or
              (Trim(RowField(RowText, PICASSO_COL_RGB)) <> '');
end;

function IsVoltageStyleNet(NetName : String) : Boolean;
var
    S : String;
begin
    S := UpperCase(Trim(NetName));
    Result := (S = '3V3') or (S = '5V') or (S = '1V8') or
              ContainsTextLocal(S, '3V3') or ContainsTextLocal(S, '1V8') or
              ContainsTextLocal(S, '2V5') or ContainsTextLocal(S, '5V0') or
              ContainsTextLocal(S, '12V') or ContainsTextLocal(S, '24V');
end;

function IsPowerNetName(NetName : String) : Boolean;
var
    S : String;
begin
    S := UpperCase(Trim(NetName));
    Result := False;

    if S = '' then
        Exit;

    if (Copy(S, 1, 1) = '+') or (Copy(S, 1, 1) = '-') then
    begin
        Result := True;
        Exit;
    end;

    Result := (S = 'GND') or (S = 'AGND') or (S = 'DGND') or
              (S = 'PGND') or (S = 'CHASSIS') or
              (S = 'VIN') or (S = 'VBAT') or (S = 'VCC') or
              (S = 'VDD') or (S = 'VSS') or (S = 'VEE') or
              StartsWithTextLocal(S, 'GND_') or EndsWithTextLocal(S, '_GND') or
              StartsWithTextLocal(S, 'VCC_') or StartsWithTextLocal(S, 'VDD_') or
              StartsWithTextLocal(S, 'VIN_') or StartsWithTextLocal(S, 'VBAT_') or
              IsVoltageStyleNet(S);
end;

function SectionLooksClassLike(SectionText : String) : Boolean;
begin
    Result := ContainsTextLocal(SectionText, 'CLASS') and
              ContainsTextLocal(SectionText, 'NET');
end;

function KeyValueLooksClassMember(KeyText, ValueText : String) : Boolean;
begin
    Result := ContainsTextLocal(KeyText, 'NET') or ContainsTextLocal(ValueText, 'NET');
end;

procedure AddClassMapping(ClassMap : TStringList; ClassName, NetName : String);
var
    Existing : String;
begin
    if ClassMap = Nil then
        Exit;

    ClassName := CleanToken(ClassName);
    NetName := CleanToken(NetName);
    if (ClassName = '') or (NetName = '') then
        Exit;

    Existing := ClassMap.Values[NetName];
    if Existing = '' then
        ClassMap.Values[NetName] := ClassName
    else if not ContainsTextLocal(';' + Existing + ';', ';' + ClassName + ';') then
        ClassMap.Values[NetName] := Existing + '; ' + ClassName;
end;

function ClassNameFromSection(SectionText : String) : String;
var
    NextChar : String;
begin
    Result := Trim(SectionText);

    if SameTextLocal(Result, 'NetClasses') or SameTextLocal(Result, 'Net Classes') then
    begin
        Result := '';
        Exit;
    end;

    if StartsWithTextLocal(Result, 'NetClass') and (Length(Result) > Length('NetClass')) then
    begin
        NextChar := Copy(Result, Length('NetClass') + 1, 1);
        if Pos(NextChar, ' _-:') > 0 then
            Result := Trim(Copy(Result, Length('NetClass') + 1, Length(Result)));
    end;

    if StartsWithTextLocal(Result, 'Net Class') and (Length(Result) > Length('Net Class')) then
    begin
        NextChar := Copy(Result, Length('Net Class') + 1, 1);
        if Pos(NextChar, ' _-:') > 0 then
            Result := Trim(Copy(Result, Length('Net Class') + 1, Length(Result)));
    end;

    if StartsWithTextLocal(Result, 'Class') and (Length(Result) > Length('Class')) then
    begin
        NextChar := Copy(Result, Length('Class') + 1, 1);
        if Pos(NextChar, ' _-:') > 0 then
            Result := Trim(Copy(Result, Length('Class') + 1, Length(Result)));
    end;

    if Result = '' then
        Result := SectionText;
end;

procedure ParseClassLikeRow(SectionText, KeyText, ValueText, RawText : String; ClassMap : TStringList);
var
    ClassName : String;
    NetName   : String;
begin
    if not SectionLooksClassLike(SectionText) then
        Exit;
    if not KeyValueLooksClassMember(KeyText, ValueText) then
        Exit;

    ClassName := FirstNonBlank(ExtractNamedValue(RawText, 'ClassName'),
                               ExtractNamedValue(RawText, 'NetClass'),
                               ExtractNamedValue(RawText, 'Class'),
                               ClassNameFromSection(SectionText),
                               '');
    NetName := InferNameFromKeyValue(KeyText, ValueText, RawText);
    AddClassMapping(ClassMap, ClassName, NetName);
end;

procedure ApplyClassMap(Rows, ClassMap : TStringList);
var
    I          : Integer;
    RowText    : String;
    NetName    : String;
    ClassText  : String;
begin
    if (Rows = Nil) or (ClassMap = Nil) then
        Exit;

    for I := 0 to Rows.Count - 1 do
    begin
        RowText := Rows.Strings[I];
        NetName := RowField(RowText, PICASSO_COL_NET);
        ClassText := RowField(RowText, PICASSO_COL_CLASS);
        if (Trim(ClassText) = '') and (Trim(NetName) <> '') then
            ClassText := ClassMap.Values[NetName];

        Rows.Strings[I] := MakeParsedRow(NetName,
                                         RowField(RowText, PICASSO_COL_COLOR_INDEX),
                                         RowField(RowText, PICASSO_COL_COLOR_VALUE),
                                         RowField(RowText, PICASSO_COL_RGB),
                                         ClassText,
                                         RowField(RowText, PICASSO_COL_SECTION),
                                         RowField(RowText, PICASSO_COL_KEY),
                                         RowField(RowText, PICASSO_COL_VALUE),
                                         StrToIntDef(RowField(RowText, PICASSO_COL_LINE), 0),
                                         RowField(RowText, PICASSO_COL_RAW));
    end;
end;

function FocusedProject(var Project : IProject; var ErrorText : String) : Boolean;
var
    WS : IWorkspace;
begin
    Result := False;
    Project := Nil;
    ErrorText := '';

    WS := GetWorkspace;
    if WS = Nil then
    begin
        ErrorText := 'Workspace Manager is not available.';
        Exit;
    end;

    Project := WS.DM_FocusedProject;
    if Project = Nil then
    begin
        ErrorText := 'Focus the target PCB project in the Projects panel, then run Picasso again.';
        Exit;
    end;

    Result := True;
end;

function FocusedProjectPath(Project : IProject; var ProjectPath, ErrorText : String) : Boolean;
begin
    Result := False;
    ProjectPath := '';
    ErrorText := '';

    if Project = Nil then
    begin
        ErrorText := 'No focused project is available.';
        Exit;
    end;

    ProjectPath := Trim(Project.DM_ProjectFullPath);
    if ProjectPath = '' then
    begin
        ErrorText := 'The focused project did not expose DM_ProjectFullPath.' + #13#10 +
                     'Focus a saved PCB project in the Projects panel, then run Picasso again.';
        Exit;
    end;

    if not FileExists(ProjectPath) then
    begin
        ErrorText := 'The focused project file could not be read:' + #13#10 + ProjectPath;
        Exit;
    end;

    Result := True;
end;

function ParseProjectFile(ProjectPath : String; Rows, Warnings : TStringList;
                          var NetInfosSectionCount, NetInfoRowCount, ClassSectionCount, ClassRowCount : Integer;
                          var ErrorText : String) : Boolean;
var
    Lines       : TStringList;
    ClassMap    : TStringList;
    I           : Integer;
    RawLine     : String;
    TrimmedLine : String;
    SectionText : String;
    EqAt        : Integer;
    KeyText     : String;
    ValueText   : String;
    NetName     : String;
    ColorIndex  : String;
    ColorValue  : String;
    RgbValue    : String;
    ClassText   : String;
begin
    Result := False;
    ErrorText := '';
    NetInfosSectionCount := 0;
    NetInfoRowCount := 0;
    ClassSectionCount := 0;
    ClassRowCount := 0;

    if Rows <> Nil then
        Rows.Clear;
    if Warnings <> Nil then
        Warnings.Clear;

    Lines := TStringList.Create;
    ClassMap := TStringList.Create;
    try
        Lines.LoadFromFile(ProjectPath);

        SectionText := '';
        for I := 0 to Lines.Count - 1 do
        begin
            RawLine := Lines.Strings[I];
            TrimmedLine := Trim(RawLine);

            if TrimmedLine = '' then
                Continue;
            if (Copy(TrimmedLine, 1, 1) = ';') or (Copy(TrimmedLine, 1, 1) = '#') then
                Continue;

            if (Copy(TrimmedLine, 1, 1) = '[') and
               (Copy(TrimmedLine, Length(TrimmedLine), 1) = ']') then
            begin
                SectionText := Copy(TrimmedLine, 2, Length(TrimmedLine) - 2);
                if SameTextLocal(SectionText, 'NetInfos') then
                    Inc(NetInfosSectionCount);
                if SectionLooksClassLike(SectionText) then
                    Inc(ClassSectionCount);
                Continue;
            end;

            EqAt := Pos('=', RawLine);
            if EqAt > 0 then
            begin
                KeyText := Trim(Copy(RawLine, 1, EqAt - 1));
                ValueText := Trim(Copy(RawLine, EqAt + 1, Length(RawLine)));
            end
            else
            begin
                KeyText := '';
                ValueText := TrimmedLine;
            end;

            if SameTextLocal(SectionText, 'NetInfos') then
            begin
                NetName := InferNameFromKeyValue(KeyText, ValueText, RawLine);
                ColorIndex := InferColorIndex(RawLine);
                ColorValue := InferColorValue(RawLine);
                RgbValue := InferRgbValue(RawLine);
                ClassText := InferClassValue(RawLine);

                Rows.Add(MakeParsedRow(NetName, ColorIndex, ColorValue, RgbValue,
                                        ClassText, SectionText, KeyText, ValueText,
                                        I + 1, RawLine));
                Inc(NetInfoRowCount);

                if (Warnings <> Nil) and (Trim(NetName) = '') then
                    Warnings.Add('Line ' + IntToStr(I + 1) + ': could not infer net name from [NetInfos] row.');
            end
            else if SectionLooksClassLike(SectionText) then
            begin
                ParseClassLikeRow(SectionText, KeyText, ValueText, RawLine, ClassMap);
                Inc(ClassRowCount);
            end;
        end;

        if NetInfosSectionCount = 0 then
            Warnings.Add('No [NetInfos] section was found in the project file.');
        if Rows.Count = 0 then
            Warnings.Add('No parseable [NetInfos] rows were found.');

        ApplyClassMap(Rows, ClassMap);
        Result := True;
    finally
        ClassMap.Free;
        Lines.Free;
    end;
end;

function ViewTitle(ViewMode : Integer) : String;
begin
    case ViewMode of
        PICASSO_VIEW_POWER: Result := 'Power';
        PICASSO_VIEW_CLASSES: Result := 'Net Classes';
        PICASSO_VIEW_UNMATCHED: Result := 'Unmatched Nets';
    else
        Result := 'All Nets';
    end;
end;

function RowIncludedInView(RowText : String; ViewMode : Integer) : Boolean;
begin
    case ViewMode of
        PICASSO_VIEW_POWER:
            Result := IsPowerNetName(RowField(RowText, PICASSO_COL_NET));
        PICASSO_VIEW_UNMATCHED:
            Result := not HasColorData(RowText);
    else
        Result := True;
    end;
end;

procedure AddReportRow(Report : TStringList; RowText : String);
var
    NetName    : String;
    ColorIndex : String;
    ColorValue : String;
    RgbValue   : String;
    ClassText  : String;
    LineText   : String;
begin
    NetName := RowField(RowText, PICASSO_COL_NET);
    ColorIndex := RowField(RowText, PICASSO_COL_COLOR_INDEX);
    ColorValue := RowField(RowText, PICASSO_COL_COLOR_VALUE);
    RgbValue := RowField(RowText, PICASSO_COL_RGB);
    ClassText := RowField(RowText, PICASSO_COL_CLASS);
    LineText := RowField(RowText, PICASSO_COL_LINE);

    if NetName = '' then
        NetName := '(unknown)';
    if ColorIndex = '' then
        ColorIndex := '-';
    if ColorValue = '' then
        ColorValue := '-';
    if RgbValue = '' then
        RgbValue := '-';
    if ClassText = '' then
        ClassText := 'Unclassified';

    Report.Add(PadRightText(NetName, 34) +
               PadRightText(ColorIndex, 14) +
               PadRightText(ColorValue, 18) +
               PadRightText(RgbValue, 18) +
               PadRightText(ClassText, 24) +
               PadRightText(LineText, 8) +
               RowField(RowText, PICASSO_COL_RAW));
end;

function ClassSortKey(RowText : String) : String;
var
    ClassText : String;
begin
    ClassText := RowField(RowText, PICASSO_COL_CLASS);
    if Trim(ClassText) = '' then
        ClassText := 'Unclassified';
    Result := UpperCase(ClassText) + #9 +
              UpperCase(RowField(RowText, PICASSO_COL_NET)) + #9 +
              RowField(RowText, PICASSO_COL_LINE) + #1 +
              RowText;
end;

procedure AddClassReportRows(Report, Rows : TStringList);
var
    SortedRows : TStringList;
    I          : Integer;
    SeparatorAt: Integer;
    RowText    : String;
    ClassText  : String;
    CurrentClass : String;
begin
    SortedRows := TStringList.Create;
    try
        SortedRows.Sorted := True;
        for I := 0 to Rows.Count - 1 do
            SortedRows.Add(ClassSortKey(Rows.Strings[I]));

        CurrentClass := '';
        for I := 0 to SortedRows.Count - 1 do
        begin
            SeparatorAt := Pos(#1, SortedRows.Strings[I]);
            if SeparatorAt > 0 then
                RowText := Copy(SortedRows.Strings[I], SeparatorAt + 1, Length(SortedRows.Strings[I]))
            else
                RowText := SortedRows.Strings[I];

            ClassText := RowField(RowText, PICASSO_COL_CLASS);
            if Trim(ClassText) = '' then
                ClassText := 'Unclassified';

            if not SameTextLocal(ClassText, CurrentClass) then
            begin
                if CurrentClass <> '' then
                    Report.Add('');
                CurrentClass := ClassText;
                Report.Add('Class: ' + CurrentClass);
                Report.Add(PadRightText('Net', 34) +
                           PadRightText('ColorIndex', 14) +
                           PadRightText('ColorValue', 18) +
                           PadRightText('RGB/TrueColor', 18) +
                           PadRightText('Class', 24) +
                           PadRightText('Line', 8) +
                           'Raw');
                Report.Add(PadRightText(StringOfChar('-', 30), 34) +
                           PadRightText(StringOfChar('-', 10), 14) +
                           PadRightText(StringOfChar('-', 14), 18) +
                           PadRightText(StringOfChar('-', 14), 18) +
                           PadRightText(StringOfChar('-', 20), 24) +
                           PadRightText(StringOfChar('-', 4), 8) +
                           StringOfChar('-', 20));
            end;

            AddReportRow(Report, RowText);
        end;
    finally
        SortedRows.Free;
    end;
end;

function BuildReport(ProjectPath : String; ViewMode : Integer; Rows, Warnings : TStringList;
                     NetInfosSectionCount, NetInfoRowCount, ClassSectionCount, ClassRowCount : Integer) : String;
var
    Report       : TStringList;
    FilteredRows : TStringList;
    I            : Integer;
begin
    Report := TStringList.Create;
    FilteredRows := TStringList.Create;
    try
        for I := 0 to Rows.Count - 1 do
        begin
            if RowIncludedInView(Rows.Strings[I], ViewMode) then
                FilteredRows.Add(Rows.Strings[I]);
        end;

        Report.Add('Picasso Parsed Net Color Viewer');
        Report.Add('================================');
        Report.Add('');
        Report.Add('Project: ' + FileNameOnly(ProjectPath));
        Report.Add('Path:    ' + ProjectPath);
        Report.Add('View:    ' + ViewTitle(ViewMode));
        Report.Add('');
        Report.Add('Parsed [NetInfos] sections: ' + IntToStr(NetInfosSectionCount));
        Report.Add('Parsed [NetInfos] rows:     ' + IntToStr(NetInfoRowCount));
        Report.Add('Class-like sections:        ' + IntToStr(ClassSectionCount));
        Report.Add('Class-like rows scanned:    ' + IntToStr(ClassRowCount));
        Report.Add('Rows shown in this view:    ' + IntToStr(FilteredRows.Count));
        Report.Add('');

        if ViewMode = PICASSO_VIEW_CLASSES then
            AddClassReportRows(Report, FilteredRows)
        else
        begin
            Report.Add(PadRightText('Net', 34) +
                       PadRightText('ColorIndex', 14) +
                       PadRightText('ColorValue', 18) +
                       PadRightText('RGB/TrueColor', 18) +
                       PadRightText('Class', 24) +
                       PadRightText('Line', 8) +
                       'Raw');
            Report.Add(PadRightText(StringOfChar('-', 30), 34) +
                       PadRightText(StringOfChar('-', 10), 14) +
                       PadRightText(StringOfChar('-', 14), 18) +
                       PadRightText(StringOfChar('-', 14), 18) +
                       PadRightText(StringOfChar('-', 20), 24) +
                       PadRightText(StringOfChar('-', 4), 8) +
                       StringOfChar('-', 20));

            for I := 0 to FilteredRows.Count - 1 do
                AddReportRow(Report, FilteredRows.Strings[I]);
        end;

        Report.Add('');
        Report.Add('Parser warnings');
        Report.Add('---------------');
        if Warnings.Count = 0 then
            Report.Add('None.')
        else
        begin
            for I := 0 to Warnings.Count - 1 do
                Report.Add('- ' + Warnings.Strings[I]);
        end;

        Report.Add('');
        Report.Add('Read-only mode: no project or schematic files were modified.');
        Result := Report.Text;
    finally
        FilteredRows.Free;
        Report.Free;
    end;
end;

function LoadPicassoReport(ProjectPath : String; ViewMode : Integer; var ErrorText : String) : String;
var
    Rows       : TStringList;
    Warnings   : TStringList;
    NetInfosSectionCount : Integer;
    NetInfoRowCount      : Integer;
    ClassSectionCount    : Integer;
    ClassRowCount        : Integer;
begin
    Result := '';
    ErrorText := '';
    Rows := TStringList.Create;
    Warnings := TStringList.Create;
    try
        if not ParseProjectFile(ProjectPath, Rows, Warnings,
                                NetInfosSectionCount, NetInfoRowCount,
                                ClassSectionCount, ClassRowCount,
                                ErrorText) then
            Exit;

        Result := BuildReport(ProjectPath, ViewMode, Rows, Warnings,
                              NetInfosSectionCount, NetInfoRowCount,
                              ClassSectionCount, ClassRowCount);
    finally
        Warnings.Free;
        Rows.Free;
    end;
end;

function ShowPicassoForm(ProjectPath : String) : Integer;
var
    PicassoForm : TForm;
    ViewLabel   : TLabel;
    ReportMemo  : TMemo;
    PowerButton : TButton;
    ClassesButton : TButton;
    UnmatchedButton : TButton;
    AllButton   : TButton;
    RefreshButton : TButton;
    CloseButton : TButton;
    FormResult  : Integer;
    ViewMode    : Integer;
    ReportText  : String;
    ErrorText   : String;
begin
    Result := mrCancel;
    ViewMode := PICASSO_VIEW_ALL;

    repeat
        ReportText := LoadPicassoReport(ProjectPath, ViewMode, ErrorText);
        if ErrorText <> '' then
        begin
            ShowPicassoMessage(ErrorText);
            Exit;
        end;

        PicassoForm := TForm.Create(nil);
        try
            PicassoForm.Caption := 'Picasso';
            PicassoForm.Position := poScreenCenter;
            PicassoForm.BorderStyle := bsDialog;
            PicassoForm.Width := 1040;
            PicassoForm.Height := 650;
            ApplyDarkFormStyle(PicassoForm);

            ViewLabel := TLabel.Create(PicassoForm);
            ViewLabel.Parent := PicassoForm;
            ViewLabel.Left := 16;
            ViewLabel.Top := 14;
            ViewLabel.Width := 180;
            ViewLabel.Caption := 'View: ' + ViewTitle(ViewMode);
            ApplyDarkLabelStyle(ViewLabel);

            PowerButton := TButton.Create(PicassoForm);
            PowerButton.Parent := PicassoForm;
            PowerButton.Left := 16;
            PowerButton.Top := 38;
            PowerButton.Width := 110;
            PowerButton.Height := 28;
            PowerButton.Caption := 'Power';
            PowerButton.ModalResult := PICASSO_VIEW_POWER;
            ApplyDarkButtonStyle(PowerButton);

            ClassesButton := TButton.Create(PicassoForm);
            ClassesButton.Parent := PicassoForm;
            ClassesButton.Left := 134;
            ClassesButton.Top := 38;
            ClassesButton.Width := 110;
            ClassesButton.Height := 28;
            ClassesButton.Caption := 'Net Classes';
            ClassesButton.ModalResult := PICASSO_VIEW_CLASSES;
            ApplyDarkButtonStyle(ClassesButton);

            UnmatchedButton := TButton.Create(PicassoForm);
            UnmatchedButton.Parent := PicassoForm;
            UnmatchedButton.Left := 252;
            UnmatchedButton.Top := 38;
            UnmatchedButton.Width := 124;
            UnmatchedButton.Height := 28;
            UnmatchedButton.Caption := 'Unmatched Nets';
            UnmatchedButton.ModalResult := PICASSO_VIEW_UNMATCHED;
            ApplyDarkButtonStyle(UnmatchedButton);

            AllButton := TButton.Create(PicassoForm);
            AllButton.Parent := PicassoForm;
            AllButton.Left := 384;
            AllButton.Top := 38;
            AllButton.Width := 110;
            AllButton.Height := 28;
            AllButton.Caption := 'All Nets';
            AllButton.ModalResult := PICASSO_VIEW_ALL;
            ApplyDarkButtonStyle(AllButton);

            RefreshButton := TButton.Create(PicassoForm);
            RefreshButton.Parent := PicassoForm;
            RefreshButton.Left := 766;
            RefreshButton.Top := 38;
            RefreshButton.Width := 100;
            RefreshButton.Height := 28;
            RefreshButton.Caption := 'Refresh';
            RefreshButton.ModalResult := PICASSO_REFRESH;
            ApplyDarkButtonStyle(RefreshButton);

            CloseButton := TButton.Create(PicassoForm);
            CloseButton.Parent := PicassoForm;
            CloseButton.Left := 874;
            CloseButton.Top := 38;
            CloseButton.Width := 100;
            CloseButton.Height := 28;
            CloseButton.Caption := 'Close';
            CloseButton.ModalResult := mrCancel;
            ApplyDarkButtonStyle(CloseButton);

            ReportMemo := TMemo.Create(PicassoForm);
            ReportMemo.Parent := PicassoForm;
            ReportMemo.Left := 16;
            ReportMemo.Top := 82;
            ReportMemo.Width := 982;
            ReportMemo.Height := 520;
            ReportMemo.Text := ReportText;
            ApplyDarkMemoStyle(ReportMemo);
            ReportMemo.Font.Name := 'Consolas';

            PicassoForm.ActiveControl := ReportMemo;
            ReportMemo.SelectAll;
            FormResult := PicassoForm.ShowModal;
        finally
            PicassoForm.Free;
        end;

        if FormResult = PICASSO_VIEW_POWER then
            ViewMode := PICASSO_VIEW_POWER
        else if FormResult = PICASSO_VIEW_CLASSES then
            ViewMode := PICASSO_VIEW_CLASSES
        else if FormResult = PICASSO_VIEW_UNMATCHED then
            ViewMode := PICASSO_VIEW_UNMATCHED
        else if FormResult = PICASSO_VIEW_ALL then
            ViewMode := PICASSO_VIEW_ALL
        else if FormResult = PICASSO_REFRESH then
            ViewMode := ViewMode
        else
        begin
            Result := FormResult;
            Exit;
        end;
    until False;
end;

procedure RunPicasso;
var
    Project     : IProject;
    ProjectPath : String;
    ErrorText   : String;
begin
    if not FocusedProject(Project, ErrorText) then
    begin
        ShowPicassoMessage(ErrorText);
        Exit;
    end;

    if not FocusedProjectPath(Project, ProjectPath, ErrorText) then
    begin
        ShowPicassoMessage(ErrorText);
        Exit;
    end;

    ShowPicassoForm(ProjectPath);
end;
