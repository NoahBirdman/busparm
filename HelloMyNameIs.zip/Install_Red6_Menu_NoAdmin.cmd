@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install_Red6_Menu_NoAdmin.ps1"
pause
