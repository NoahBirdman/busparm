# Altium Internal Scripts

This folder contains shared Altium Designer scripts and the installer for the internal `Red 6` menu.

## Menu Installer

Run this installer after Altium Designer is fully closed:

```powershell
C:\Users\Public\Documents\Altium\altiumscripts\Install_Red6_Menu_NoAdmin.cmd
```

The installer does not require Windows administrator rights. It updates each Altium Designer user profile found under:

```text
%APPDATA%\Altium\Altium Designer *\DXP.RCS
```

It creates timestamped `.red6-user-*.bak` backups beside changed `DXP.RCS` files and can be run again safely.

## Red 6 Menu

The installer adds a top-level `Red 6` menu to the no-document, PCB editor, schematic editor, schematic symbol editor, and footprint editor menu bars. Current menu entries:

- `Six Degrees of Variation`
- `Import Mech Layers`
- `ICEBERG`
- `NextRev`
- `Hello My Name Is`
- `Picasso`
- `About Info`

## Updating Scripts

Use `Red 6 > About Info > Update` inside Altium Designer to launch the updater. After the updater starts, close Altium Designer. The updater waits for Altium to close, checks for local repository changes, pulls the latest scripts with `git pull --ff-only`, and reruns the Red 6 menu installer.

The updater will stop if local uncommitted changes are present.

## Adding Scripts

Add new internal scripts as sibling folders under this directory, then register each script in the `$menuItems` list in:

```text
C:\Users\Public\Documents\Altium\altiumscripts\Install_Red6_Menu_NoAdmin.ps1
```

Each entry needs:

- `Id`: stable identifier used in Altium resource IDs.
- `Caption`: text shown under the `Red 6` menu.
- `ProjectPath`: path to the `.PrjScr` file, usually built with `Join-Path $scriptRoot`.
- `ProcName`: script unit and procedure, such as `VARIATE_ME.pas>ShowVariantParameterEditor`.
- `Description`: short command description.

After adding an entry, close Altium Designer and rerun `Install_Red6_Menu_NoAdmin.cmd`.
