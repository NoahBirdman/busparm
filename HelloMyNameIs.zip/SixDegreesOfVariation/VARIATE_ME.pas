







































{ Altium Designer v26 DelphiScript
  Creates or updates a project variant and its standard release parameters
  in the focused PCB project.

  Run procedure: ShowVariantParameterEditor
}

uses
    SysUtils,
    Classes,
    Forms,
    Controls,
    StdCtrls;

const
    REQUIRED_PARAMETER_COUNT = 23;
    CREATE_NEW_TEXT = 'Create New...';
    PREVIEW_MODAL_RESULT = 102;
    UI_DARK_BACKGROUND = $00302D2B;
    UI_DARK_CONTROL = $002A2725;
    UI_DARK_FIELD = $001E1E1E;
    UI_DARK_COMBO = $00403B36;
    UI_DARK_TEXT = $00E3DDD7;
    UI_DARK_MUTED_TEXT = $00BFB6AE;
    UI_LIGHT_FIELD = $00FFFFFF;
    UI_LIGHT_TEXT = $00000000;

var
    VariantForm        : TForm;
    VariantSelectCombo : TComboBox;
    TypeCombo          : TComboBox;
    ClassCombo         : TComboBox;
    CageCodeCombo      : TComboBox;
    ItarCombo          : TComboBox;
    ConfCoatCombo      : TComboBox;
    PartNumberEdit     : TEdit;
    RevisionEdit       : TEdit;
    ProjectNameEdit    : TEdit;
    VariantNameEdit    : TEdit;
    LeadedSolderCheck  : TCheckBox;
    AlteredItemCheck   : TCheckBox;
    PreviewSchDocNoEdit     : TEdit;
    PreviewSchTitle1Edit    : TEdit;
    PreviewSchRevEdit       : TEdit;
    PreviewPcbPartNoEdit    : TEdit;
    PreviewPcbTitle1Edit    : TEdit;
    PreviewPcbDocNoEdit     : TEdit;
    PreviewPcbRevEdit       : TEdit;
    PreviewPcbClassEdit     : TEdit;
    PreviewPcbaPartNoEdit   : TEdit;
    PreviewPcbaTitle1Edit   : TEdit;
    PreviewPcbaDocNoEdit    : TEdit;
    PreviewPcbaRevEdit      : TEdit;
    PreviewPcbaClassEdit    : TEdit;
    PreviewPcbaSolderEdit   : TEdit;
    PreviewConfPartNoEdit   : TEdit;
    PreviewConfCoatEdit     : TEdit;
    PreviewConfTitle1Edit   : TEdit;
    PreviewConfDocNoEdit    : TEdit;
    PreviewConfRevEdit      : TEdit;
    PreviewEcadDocNoEdit    : TEdit;
    PreviewEcadRevEdit      : TEdit;
    PreviewCbddDocNoEdit    : TEdit;
    PreviewCbddRevEdit      : TEdit;
    PreviewAltPartNoEdit    : TEdit;

function SameTextLocal(A, B : String) : Boolean;
begin
    Result := UpperCase(Trim(A)) = UpperCase(Trim(B));
end;

function IsSectionHeader(Line : String) : Boolean;
var
    S : String;
begin
    S := Trim(Line);
    Result := (Length(S) > 2) and (Copy(S, 1, 1) = '[') and (Copy(S, Length(S), 1) = ']');
end;

function GetSectionName(Line : String) : String;
var
    S : String;
begin
    S := Trim(Line);
    if IsSectionHeader(S) then
        Result := Copy(S, 2, Length(S) - 2)
    else
        Result := '';
end;

function StartsWithLocal(Value, Prefix : String) : Boolean;
begin
    Result := Copy(UpperCase(Value), 1, Length(Prefix)) = UpperCase(Prefix);
end;

function EndsWithLocal(Value, Suffix : String) : Boolean;
begin
    if Length(Value) < Length(Suffix) then
        Result := False
    else
        Result := SameTextLocal(Copy(Value, Length(Value) - Length(Suffix) + 1, Length(Suffix)), Suffix);
end;

function IntFromText(Value : String) : Integer;
var
    S        : String;
    I        : Integer;
    DigitPos : Integer;
begin
    Result := 0;

    S := Trim(Value);
    if S = '' then
        Exit;

    for I := 1 to Length(S) do
    begin
        DigitPos := Pos(Copy(S, I, 1), '0123456789');
        if DigitPos = 0 then
        begin
            Result := 0;
            Exit;
        end;

        Result := (Result * 10) + DigitPos - 1;
    end;
end;

function ProjectVariantIndexFromHeader(Line : String) : Integer;
var
    Name   : String;
    Number : String;
begin
    Result := 0;
    Name := GetSectionName(Line);
    if StartsWithLocal(Name, 'ProjectVariant') then
    begin
        Number := Copy(Name, Length('ProjectVariant') + 1, Length(Name));
        Result := IntFromText(Number);
    end;
end;

function ProjectVariantParameterGroup(VariantIndex : Integer) : Integer;
begin
    { Altium stores variant-level parameter sections as Parameter<N>_<M>,
      where N is one greater than the ProjectVariant index. }
    Result := VariantIndex + 1;
end;

function ParameterGroupFromHeader(Line : String) : Integer;
var
    Name         : String;
    Number       : String;
    UnderscoreAt : Integer;
begin
    Result := 0;
    Name := GetSectionName(Line);

    if not StartsWithLocal(Name, 'Parameter') then
        Exit;

    UnderscoreAt := Pos('_', Name);
    if UnderscoreAt <= Length('Parameter') + 1 then
        Exit;

    Number := Copy(Name, Length('Parameter') + 1, UnderscoreAt - Length('Parameter') - 1);
    Result := IntFromText(Number);
end;

function ProjectParameterIndexFromHeader(Line : String) : Integer;
var
    Name   : String;
    Number : String;
begin
    Result := 0;
    Name := GetSectionName(Line);

    if StartsWithLocal(Name, 'Parameter') and (Pos('_', Name) = 0) then
    begin
        Number := Copy(Name, Length('Parameter') + 1, Length(Name));
        Result := IntFromText(Number);
    end;
end;

function FindSectionEnd(Lines : TStringList; SectionStart : Integer) : Integer;
var
    I : Integer;
begin
    Result := Lines.Count;
    for I := SectionStart + 1 to Lines.Count - 1 do
    begin
        if IsSectionHeader(Lines[I]) then
        begin
            Result := I;
            Exit;
        end;
    end;
end;

function ReadSectionValue(Lines : TStringList; SectionStart : Integer; Key : String) : String;
var
    I       : Integer;
    S       : String;
    EqPos   : Integer;
    ThisKey : String;
begin
    Result := '';

    for I := SectionStart + 1 to Lines.Count - 1 do
    begin
        S := Trim(Lines[I]);
        if IsSectionHeader(S) then
            Exit;

        EqPos := Pos('=', S);
        if EqPos > 0 then
        begin
            ThisKey := Trim(Copy(S, 1, EqPos - 1));
            if SameTextLocal(ThisKey, Key) then
            begin
                Result := Copy(S, EqPos + 1, Length(S));
                Exit;
            end;
        end;
    end;
end;

procedure SetSectionValue(Lines : TStringList; SectionStart : Integer; Key, Value : String);
var
    I       : Integer;
    S       : String;
    EqPos   : Integer;
    ThisKey : String;
    InsertAt: Integer;
begin
    InsertAt := Lines.Count;

    for I := SectionStart + 1 to Lines.Count - 1 do
    begin
        S := Trim(Lines[I]);
        if IsSectionHeader(S) then
        begin
            InsertAt := I;
            Break;
        end;

        EqPos := Pos('=', S);
        if EqPos > 0 then
        begin
            ThisKey := Trim(Copy(S, 1, EqPos - 1));
            if SameTextLocal(ThisKey, Key) then
            begin
                Lines[I] := Key + '=' + Value;
                Exit;
            end;
        end;
    end;

    Lines.Insert(InsertAt, Key + '=' + Value);
end;

function FindVariantByName(Lines : TStringList; VariantName : String; var VariantIndex : Integer) : Integer;
var
    I           : Integer;
    CandidateIx : Integer;
    StoredName  : String;
begin
    Result := -1;
    VariantIndex := 0;

    for I := 0 to Lines.Count - 1 do
    begin
        CandidateIx := ProjectVariantIndexFromHeader(Lines[I]);
        if CandidateIx > 0 then
        begin
            StoredName := ReadSectionValue(Lines, I, 'Description');
            if SameTextLocal(StoredName, VariantName) then
            begin
                Result := I;
                VariantIndex := CandidateIx;
                Exit;
            end;
        end;
    end;
end;

function FindVariantByIndex(Lines : TStringList; VariantIndex : Integer) : Integer;
var
    I : Integer;
begin
    Result := -1;

    for I := 0 to Lines.Count - 1 do
    begin
        if ProjectVariantIndexFromHeader(Lines[I]) = VariantIndex then
        begin
            Result := I;
            Exit;
        end;
    end;
end;

function GetMaxVariantIndex(Lines : TStringList) : Integer;
var
    I  : Integer;
    Ix : Integer;
begin
    Result := 0;

    for I := 0 to Lines.Count - 1 do
    begin
        Ix := ProjectVariantIndexFromHeader(Lines[I]);
        if Ix > Result then
            Result := Ix;
    end;
end;

function FindNewVariantInsertIndex(Lines : TStringList) : Integer;
var
    I       : Integer;
    Name    : String;
    SeenAny : Boolean;
begin
    Result := Lines.Count;
    SeenAny := False;

    for I := 0 to Lines.Count - 1 do
    begin
        if ProjectVariantIndexFromHeader(Lines[I]) > 0 then
            SeenAny := True;

        if IsSectionHeader(Lines[I]) then
        begin
            Name := GetSectionName(Lines[I]);

            if StartsWithLocal(Name, 'GeneratedDocument') or
               StartsWithLocal(Name, 'Configuration') or
               StartsWithLocal(Name, 'Generic_') or
               StartsWithLocal(Name, 'OutputGroup') or
               SameTextLocal(Name, 'Modification Levels') or
               SameTextLocal(Name, 'Difference Levels') or
               SameTextLocal(Name, 'Electrical Rules Check') or
               SameTextLocal(Name, 'LibraryUpdateOptions') or
               SameTextLocal(Name, 'DatabaseUpdateOptions') or
               SameTextLocal(Name, 'NetInfos') then
            begin
                Result := I;
                Exit;
            end;
        end;
    end;

    if SeenAny then
        Result := Lines.Count;
end;

function RandomHex(Digits : Integer) : String;
var
    I : Integer;
begin
    Result := '';
    for I := 1 to Digits do
        Result := Result + Copy('0123456789ABCDEF', Random(16) + 1, 1);
end;

function NewGuidText : String;
begin
    Randomize;
    Result := RandomHex(8) + '-' +
              RandomHex(4) + '-' +
              RandomHex(4) + '-' +
              RandomHex(4) + '-' +
              RandomHex(12);
end;

procedure DeleteParameterSectionsForVariant(Lines : TStringList; VariantIndex : Integer);
var
    I       : Integer;
    J       : Integer;
    GroupIx : Integer;
begin
    GroupIx := ProjectVariantParameterGroup(VariantIndex);
    I := 0;

    while I < Lines.Count do
    begin
        if IsSectionHeader(Lines[I]) then
        begin
            if ParameterGroupFromHeader(Lines[I]) = GroupIx then
            begin
                J := I + 1;
                while (J < Lines.Count) and not IsSectionHeader(Lines[J]) do
                    Inc(J);

                while J > I do
                begin
                    Dec(J);
                    Lines.Delete(J);
                end;
                Continue;
            end;
        end;

        Inc(I);
    end;
end;

procedure AddParam(Names, Values : TStringList; ParamName, ParamValue : String);
begin
    Names.Add(ParamName);
    Values.Add(ParamValue);
end;

procedure UpsertParam(Names, Values : TStringList; ParamName, ParamValue : String);
var
    I             : Integer;
    ExistingIndex : Integer;
begin
    ExistingIndex := -1;
    I := 0;

    while I < Names.Count do
    begin
        if SameTextLocal(Names[I], ParamName) then
        begin
            if ExistingIndex < 0 then
            begin
                ExistingIndex := I;
                Names[I] := ParamName;
                Values[I] := ParamValue;
                Inc(I);
            end
            else
            begin
                Names.Delete(I);
                Values.Delete(I);
            end;
        end
        else
            Inc(I);
    end;

    if ExistingIndex < 0 then
        AddParam(Names, Values, ParamName, ParamValue);
end;

procedure DeleteParam(Names, Values : TStringList; ParamName : String);
var
    I : Integer;
begin
    I := 0;
    while I < Names.Count do
    begin
        if SameTextLocal(Names[I], ParamName) then
        begin
            Names.Delete(I);
            Values.Delete(I);
        end
        else
            Inc(I);
    end;
end;

procedure ReadParameterSectionsForVariant(Lines : TStringList; VariantIndex : Integer;
                                          Names, Values : TStringList);
var
    I         : Integer;
    GroupIx   : Integer;
    ParamName : String;
    ParamValue: String;
begin
    Names.Clear;
    Values.Clear;
    GroupIx := ProjectVariantParameterGroup(VariantIndex);

    for I := 0 to Lines.Count - 1 do
    begin
        if IsSectionHeader(Lines[I]) and (ParameterGroupFromHeader(Lines[I]) = GroupIx) then
        begin
            ParamName := Trim(ReadSectionValue(Lines, I, 'Name'));
            ParamValue := ReadSectionValue(Lines, I, 'Value');

            if ParamName <> '' then
                AddParam(Names, Values, ParamName, ParamValue);
        end;
    end;
end;

function FindParamIndex(Names : TStringList; ParamName : String) : Integer;
var
    I : Integer;
begin
    Result := -1;

    for I := 0 to Names.Count - 1 do
    begin
        if SameTextLocal(Names[I], ParamName) then
        begin
            Result := I;
            Exit;
        end;
    end;
end;

function ParamValueByName(Names, Values : TStringList; ParamName : String) : String;
var
    I : Integer;
begin
    Result := '';
    I := FindParamIndex(Names, ParamName);
    if I >= 0 then
        Result := Values[I];
end;

function ReadProjectParameter(Lines : TStringList; ParamName : String) : String;
var
    I         : Integer;
    ThisName  : String;
begin
    Result := '';

    for I := 0 to Lines.Count - 1 do
    begin
        if IsSectionHeader(Lines[I]) and (ProjectParameterIndexFromHeader(Lines[I]) > 0) then
        begin
            ThisName := Trim(ReadSectionValue(Lines, I, 'Name'));
            if SameTextLocal(ThisName, ParamName) then
            begin
                Result := ReadSectionValue(Lines, I, 'Value');
                Exit;
            end;
        end;
    end;
end;

function FindProjectParameterByName(Lines : TStringList; ParamName : String) : Integer;
var
    I        : Integer;
    ThisName : String;
begin
    Result := -1;

    for I := 0 to Lines.Count - 1 do
    begin
        if IsSectionHeader(Lines[I]) and (ProjectParameterIndexFromHeader(Lines[I]) > 0) then
        begin
            ThisName := Trim(ReadSectionValue(Lines, I, 'Name'));
            if SameTextLocal(ThisName, ParamName) then
            begin
                Result := I;
                Exit;
            end;
        end;
    end;
end;

function GetMaxProjectParameterIndex(Lines : TStringList) : Integer;
var
    I  : Integer;
    Ix : Integer;
begin
    Result := 0;

    for I := 0 to Lines.Count - 1 do
    begin
        Ix := ProjectParameterIndexFromHeader(Lines[I]);
        if Ix > Result then
            Result := Ix;
    end;
end;

function FindProjectParameterInsertIndex(Lines : TStringList) : Integer;
var
    I               : Integer;
    LastParamStart  : Integer;
begin
    Result := Lines.Count;
    LastParamStart := -1;

    for I := 0 to Lines.Count - 1 do
    begin
        if IsSectionHeader(Lines[I]) and (ProjectParameterIndexFromHeader(Lines[I]) > 0) then
            LastParamStart := I;
    end;

    if LastParamStart >= 0 then
        Result := FindSectionEnd(Lines, LastParamStart);
end;

procedure SetProjectParameter(Lines : TStringList; ParamName, ParamValue : String);
var
    SectionStart : Integer;
    InsertAt     : Integer;
    NewIndex     : Integer;
begin
    SectionStart := FindProjectParameterByName(Lines, ParamName);
    if SectionStart >= 0 then
    begin
        SetSectionValue(Lines, SectionStart, 'Name', ParamName);
        SetSectionValue(Lines, SectionStart, 'Value', ParamValue);
        Exit;
    end;

    NewIndex := GetMaxProjectParameterIndex(Lines) + 1;
    InsertAt := FindProjectParameterInsertIndex(Lines);
    if (InsertAt > 0) and (Trim(Lines[InsertAt - 1]) <> '') then
    begin
        Lines.Insert(InsertAt, '');
        Inc(InsertAt);
    end;

    Lines.Insert(InsertAt, '[Parameter' + IntToStr(NewIndex) + ']');
    Inc(InsertAt);
    Lines.Insert(InsertAt, 'Name=' + ParamName);
    Inc(InsertAt);
    Lines.Insert(InsertAt, 'Value=' + ParamValue);
    Inc(InsertAt);
    Lines.Insert(InsertAt, '');
end;

procedure SetProjectNameParameter(Lines : TStringList; ProjectName : String);
var
    WroteValue : Boolean;
begin
    WroteValue := False;

    if FindProjectParameterByName(Lines, 'PROJ_TITLE') >= 0 then
    begin
        SetProjectParameter(Lines, 'PROJ_TITLE', ProjectName);
        WroteValue := True;
    end;

    if FindProjectParameterByName(Lines, 'PROJ_NAME') >= 0 then
    begin
        SetProjectParameter(Lines, 'PROJ_NAME', ProjectName);
        WroteValue := True;
    end;

    if not WroteValue then
        SetProjectParameter(Lines, 'PROJ_TITLE', ProjectName);
end;

function ProjectNameParameterKey(Lines : TStringList) : String;
begin
    if FindProjectParameterByName(Lines, 'PROJ_TITLE') >= 0 then
        Result := 'PROJ_TITLE'
    else if FindProjectParameterByName(Lines, 'PROJ_NAME') >= 0 then
        Result := 'PROJ_NAME'
    else
        Result := 'PROJ_TITLE';
end;

function DefaultProjectName(Lines : TStringList; ProjectPath : String) : String;
begin
    Result := Trim(ReadProjectParameter(Lines, ProjectNameParameterKey(Lines)));
    if Result = '' then
        Result := Trim(ReadProjectParameter(Lines, 'PROJ_TITLE'));
    if Result = '' then
        Result := Trim(ReadProjectParameter(Lines, 'PROJ_NAME'));
    if Result = '' then
        Result := ChangeFileExt(ExtractFileName(ProjectPath), '');
end;

function CageCodeFromComboText(Value : String) : String;
var
    DashPos : Integer;
begin
    Result := Trim(Value);
    DashPos := Pos(' - ', Result);
    if DashPos > 0 then
        Result := Trim(Copy(Result, 1, DashPos - 1));
end;

function CageCodeDisplayForValue(Value : String) : String;
var
    CageCode : String;
begin
    CageCode := CageCodeFromComboText(Value);

    if SameTextLocal(CageCode, '14BW4') then
        Result := '14BW4 - (DEN) ADV PRJ'
    else if SameTextLocal(CageCode, '840Y3') then
        Result := '840Y3 - (ORL) AEROSPACE'
    else if SameTextLocal(CageCode, '9EKV8') then
        Result := '9EKV8 - (ORL) DEFENSE'
    else
        Result := Value;
end;

function DefaultCageCodeDisplay(Lines : TStringList) : String;
var
    CageCode : String;
begin
    CageCode := Trim(ReadProjectParameter(Lines, 'CAGE_CODE'));
    if CageCode = '' then
        CageCode := '14BW4';

    Result := CageCodeDisplayForValue(CageCode);
end;

function ItarChoiceFromComboText(Value : String) : String;
begin
    Result := Trim(Value);

    if SameTextLocal(Result, 'ITAR') then
        Result := 'ITAR'
    else if SameTextLocal(Result, 'NON-ITAR') then
        Result := 'NON-ITAR';
end;

function ItarStatementForChoice(ItarChoice : String) : String;
begin
    if SameTextLocal(ItarChoice, 'ITAR') then
    begin
        Result := 'THIS INFORMATION MAY BE SUBJECT TO THE EXPORT ADMINISTRATION REGULATIONS (EAR) PURSUANT TO 15 C.F.R. PARTS 730-774. ' +
                  'TRANSFER OF THIS DATA BY ANY MEANS TO A NON-U.S. PERSON, WHETHER IN THE UNITED STATES OR ABROAD WITHOUT THE PROPER U.S. GOVERNMENT AUTHORIZATION IS STRICTLY PROHIBITED. ' +
                  'VIOLATIONS OF THE EAR MAY BE SUBJECT TO BOTH CRIMINAL AND ADMINISTRATIVE PENALTIES UNDER THE EXPORT CONTROL REFORM ACT OF 2018 (50 U.S.C. ' + #167 + #167 + ' 4801-4852).';
    end
    else
        Result := 'NOT SUBJECT TO EXPORT CONTROLS';
end;

function ItarHeaderForChoice(ItarChoice : String) : String;
begin
    if SameTextLocal(ItarChoice, 'ITAR') then
        Result := 'EXPORT CONTROLLED'
    else
        Result := 'NOT EXPORT CONTROLLED';
end;

function DefaultItarChoice(Lines : TStringList) : String;
var
    ItarHeader    : String;
    ItarStatement : String;
begin
    Result := 'NON-ITAR';

    ItarHeader := Trim(ReadProjectParameter(Lines, 'ITAR_HEADER'));
    ItarStatement := Trim(ReadProjectParameter(Lines, 'ITAR_STATEMENT'));

    if SameTextLocal(ItarHeader, 'EXPORT CONTROLLED') or
       StartsWithLocal(ItarStatement, 'THIS INFORMATION MAY BE SUBJECT TO THE EXPORT ADMINISTRATION REGULATIONS') then
        Result := 'ITAR';
end;

function FirstNonBlankParam(Names, Values : TStringList; ParamA, ParamB, ParamC : String) : String;
begin
    Result := Trim(ParamValueByName(Names, Values, ParamA));
    if Result = '' then
        Result := Trim(ParamValueByName(Names, Values, ParamB));
    if Result = '' then
        Result := Trim(ParamValueByName(Names, Values, ParamC));
end;

function PartNumberFromValue(Value, Prefix : String) : String;
var
    WorkValue : String;
begin
    Result := '';
    WorkValue := Trim(Value);

    if StartsWithLocal(WorkValue, Prefix + '-') then
    begin
        Result := Copy(WorkValue, Length(Prefix) + 2, Length(WorkValue));
        if (Length(Result) > 3) and (Copy(Result, Length(Result) - 2, 3) = '-01') then
            Result := Copy(Result, 1, Length(Result) - 3);
    end;
end;

function InferredPartNumber(Names, Values : TStringList) : String;
begin
    Result := PartNumberFromValue(ParamValueByName(Names, Values, 'PCB_DOC_NO'), '602');
    if Result = '' then
        Result := PartNumberFromValue(ParamValueByName(Names, Values, 'PCB_PART_NO'), '602');
    if Result = '' then
        Result := PartNumberFromValue(ParamValueByName(Names, Values, 'PCBA_DOC_NO'), '600');
    if Result = '' then
        Result := PartNumberFromValue(ParamValueByName(Names, Values, 'SCH_DOC_NO'), '604');
    if Result = '' then
        Result := PartNumberFromValue(ParamValueByName(Names, Values, 'ECAD_DOC_NO'), '605');
end;

function ProjectNameFromTitle(TitleText : String) : String;
var
    FirstComma  : Integer;
    SecondComma : Integer;
    Remainder   : String;
begin
    Result := '';
    FirstComma := Pos(',', TitleText);
    if FirstComma <= 0 then
        Exit;

    Remainder := Copy(TitleText, FirstComma + 1, Length(TitleText));
    SecondComma := Pos(',', Remainder);
    if SecondComma <= 0 then
        Exit;

    Result := Trim(Copy(Remainder, 1, SecondComma - 1));
end;

function InferredProjectName(Names, Values : TStringList; FallbackName : String) : String;
begin
    Result := ProjectNameFromTitle(ParamValueByName(Names, Values, 'PCB_TITLE_1'));
    if Result = '' then
        Result := ProjectNameFromTitle(ParamValueByName(Names, Values, 'PCBA_TITLE_1'));
    if Result = '' then
        Result := ProjectNameFromTitle(ParamValueByName(Names, Values, 'SCH_TITLE_1'));
    if Result = '' then
        Result := FallbackName;
end;

function FormatDocNumber(Prefix, PartNumber : String) : String;
begin
    Result := Prefix + '-' + PartNumber;
end;

function FormatPartNumber(Prefix, PartNumber : String) : String;
begin
    Result := Prefix + '-' + PartNumber + '-01';
end;

function FormatTitle(DocumentKind, ProjectName, VariantName : String) : String;
begin
    Result := DocumentKind + ', ' + ProjectName + ', ' + VariantName;
end;

function SolderValueFromCheckbox : String;
begin
    if LeadedSolderCheck.Checked then
        Result := 'TIN/LEAD (SN63/PB37)'
    else
        Result := 'LEAD FREE (SAC305 OR EQUIVALENT)';
end;

function NormalizeConformalCoatValue(Value : String) : String;
begin
    Result := '';

    if SameTextLocal(Value, 'NONE') or SameTextLocal(Value, 'N/A') then
        Result := 'NONE'
    else if SameTextLocal(Value, 'ACRYLIC') or SameTextLocal(Value, 'ACRYLIC (-02)') then
        Result := 'ACRYLIC'
    else if SameTextLocal(Value, 'URETHANE') or SameTextLocal(Value, 'URETHANE (-03)') then
        Result := 'URETHANE';
end;

function ConformalCoatValueFromComboText(Value : String) : String;
begin
    Result := NormalizeConformalCoatValue(Value);
    if Result = '' then
        Result := Trim(Value);
end;

function ConformalCoatDisplayForValue(Value : String) : String;
begin
    Result := NormalizeConformalCoatValue(Value);

    if Result = 'ACRYLIC' then
        Result := 'ACRYLIC (-02)'
    else if Result = 'URETHANE' then
        Result := 'URETHANE (-03)'
    else
        Result := 'NONE';
end;

function ConformalCoatValueFromParameters(Names, Values : TStringList) : String;
var
    CoatValue  : String;
    ConfPartNo : String;
begin
    CoatValue := NormalizeConformalCoatValue(ParamValueByName(Names, Values, 'CONF_COAT'));
    if CoatValue <> '' then
    begin
        Result := CoatValue;
        Exit;
    end;

    ConfPartNo := Trim(ParamValueByName(Names, Values, 'CONF_PART_NO'));
    if SameTextLocal(ConfPartNo, 'NONE') then
        Result := 'NONE'
    else if EndsWithLocal(ConfPartNo, '-02') then
        Result := 'ACRYLIC'
    else if EndsWithLocal(ConfPartNo, '-03') then
        Result := 'URETHANE'
    else
        Result := 'NONE';
end;

function FormatConfPartNumber(PartNumber, CoatValue : String) : String;
begin
    if SameTextLocal(CoatValue, 'ACRYLIC') then
        Result := '601-' + PartNumber + '-02'
    else if SameTextLocal(CoatValue, 'URETHANE') then
        Result := '601-' + PartNumber + '-03'
    else
        Result := 'N/A';
end;

function FormatAltPartNumber(PartNumber, CoatValue : String) : String;
begin
    if SameTextLocal(CoatValue, 'ACRYLIC') then
        Result := '620-' + PartNumber + '-02'
    else if SameTextLocal(CoatValue, 'URETHANE') then
        Result := '620-' + PartNumber + '-03'
    else
        Result := '620-' + PartNumber + '-01';
end;

procedure SetLeadedSolderFromValue(SolderValue : String);
begin
    LeadedSolderCheck.Checked := SameTextLocal(SolderValue, 'TIN/LEAD (SN63/PB37)') or
                                 SameTextLocal(SolderValue, 'TIN/LEAD') or
                                 SameTextLocal(SolderValue, 'Tin / Lead');
end;

procedure ApplyRequiredVariantParameters(Names, Values : TStringList;
                                         PartNumber, Revision, ProjectName,
                                         VariantName, ClassValue, SolderValue,
                                         CoatValue : String;
                                         AlteredItem : Boolean);
begin
    UpsertParam(Names, Values, 'SCH_DOC_NO',      FormatDocNumber('604', PartNumber));
    UpsertParam(Names, Values, 'SCH_TITLE_1',     FormatTitle('SCHEMATIC', ProjectName, VariantName));
    UpsertParam(Names, Values, 'SCH_REV',         Revision);
    UpsertParam(Names, Values, 'PCB_PART_NO',     FormatPartNumber('602', PartNumber));
    UpsertParam(Names, Values, 'PCB_TITLE_1',     FormatTitle('PCB', ProjectName, VariantName));
    UpsertParam(Names, Values, 'PCB_DOC_NO',      FormatDocNumber('602', PartNumber));
    UpsertParam(Names, Values, 'PCB_REV',         Revision);
    UpsertParam(Names, Values, 'PCB_CLASS',       ClassValue);
    UpsertParam(Names, Values, 'PCBA_PART_NO',    FormatPartNumber('600', PartNumber));
    UpsertParam(Names, Values, 'PCBA_TITLE_1',    FormatTitle('PCBA', ProjectName, VariantName));
    UpsertParam(Names, Values, 'PCBA_DOC_NO',     FormatDocNumber('600', PartNumber));
    UpsertParam(Names, Values, 'PCBA_REV',        Revision);
    UpsertParam(Names, Values, 'PCBA_CLASS',      ClassValue);
    UpsertParam(Names, Values, 'PCBA_SOLDER',     SolderValue);
    UpsertParam(Names, Values, 'CONF_PART_NO',    FormatConfPartNumber(PartNumber, CoatValue));
    if SameTextLocal(CoatValue, 'NONE') then
        UpsertParam(Names, Values, 'CONF_COAT',   'N/A')
    else
        UpsertParam(Names, Values, 'CONF_COAT',   CoatValue);
    if SameTextLocal(CoatValue, 'NONE') then
    begin
        UpsertParam(Names, Values, 'CONF_TITLE_1', 'N/A');
        UpsertParam(Names, Values, 'CONF_DOC_NO', 'N/A');
        UpsertParam(Names, Values, 'CONF_REV',    'N/A');
    end
    else
    begin
        UpsertParam(Names, Values, 'CONF_TITLE_1', FormatTitle('COATED PCBA', ProjectName, VariantName));
        UpsertParam(Names, Values, 'CONF_DOC_NO', FormatDocNumber('601', PartNumber));
        UpsertParam(Names, Values, 'CONF_REV',    Revision);
    end;
    UpsertParam(Names, Values, 'ECAD_DOC_NO',     FormatDocNumber('605', PartNumber));
    UpsertParam(Names, Values, 'ECAD_REV',        Revision);
    UpsertParam(Names, Values, 'CBDD_DOC_NO',     FormatDocNumber('610', PartNumber));
    UpsertParam(Names, Values, 'CBDD_REV',        Revision);
    if AlteredItem then
        UpsertParam(Names, Values, 'ALT_PART_NO', FormatAltPartNumber(PartNumber, CoatValue))
    else
        DeleteParam(Names, Values, 'ALT_PART_NO');
end;

procedure SetPreviewEdit(EditRef : TEdit; Names, Values : TStringList; ParamName : String);
var
    I          : Integer;
    ParamValue : String;
begin
    ParamValue := 'N/A';
    I := FindParamIndex(Names, ParamName);
    if I >= 0 then
        ParamValue := Values[I];

    EditRef.Text := ParamValue;
end;

procedure RefreshParameterPreview(Names, Values : TStringList);
begin
    SetPreviewEdit(PreviewSchDocNoEdit, Names, Values, 'SCH_DOC_NO');
    SetPreviewEdit(PreviewSchTitle1Edit, Names, Values, 'SCH_TITLE_1');
    SetPreviewEdit(PreviewSchRevEdit, Names, Values, 'SCH_REV');
    SetPreviewEdit(PreviewPcbPartNoEdit, Names, Values, 'PCB_PART_NO');
    SetPreviewEdit(PreviewPcbTitle1Edit, Names, Values, 'PCB_TITLE_1');
    SetPreviewEdit(PreviewPcbDocNoEdit, Names, Values, 'PCB_DOC_NO');
    SetPreviewEdit(PreviewPcbRevEdit, Names, Values, 'PCB_REV');
    SetPreviewEdit(PreviewPcbClassEdit, Names, Values, 'PCB_CLASS');
    SetPreviewEdit(PreviewPcbaPartNoEdit, Names, Values, 'PCBA_PART_NO');
    SetPreviewEdit(PreviewPcbaTitle1Edit, Names, Values, 'PCBA_TITLE_1');
    SetPreviewEdit(PreviewPcbaDocNoEdit, Names, Values, 'PCBA_DOC_NO');
    SetPreviewEdit(PreviewPcbaRevEdit, Names, Values, 'PCBA_REV');
    SetPreviewEdit(PreviewPcbaClassEdit, Names, Values, 'PCBA_CLASS');
    SetPreviewEdit(PreviewPcbaSolderEdit, Names, Values, 'PCBA_SOLDER');
    SetPreviewEdit(PreviewConfPartNoEdit, Names, Values, 'CONF_PART_NO');
    SetPreviewEdit(PreviewConfCoatEdit, Names, Values, 'CONF_COAT');
    SetPreviewEdit(PreviewConfTitle1Edit, Names, Values, 'CONF_TITLE_1');
    SetPreviewEdit(PreviewConfDocNoEdit, Names, Values, 'CONF_DOC_NO');
    SetPreviewEdit(PreviewConfRevEdit, Names, Values, 'CONF_REV');
    SetPreviewEdit(PreviewEcadDocNoEdit, Names, Values, 'ECAD_DOC_NO');
    SetPreviewEdit(PreviewEcadRevEdit, Names, Values, 'ECAD_REV');
    SetPreviewEdit(PreviewCbddDocNoEdit, Names, Values, 'CBDD_DOC_NO');
    SetPreviewEdit(PreviewCbddRevEdit, Names, Values, 'CBDD_REV');
    SetPreviewEdit(PreviewAltPartNoEdit, Names, Values, 'ALT_PART_NO');
end;

procedure AddValidationError(Errors : TStringList; ErrorText : String);
begin
    Errors.Add('- ' + ErrorText);
end;

procedure RequireGeneratedParameter(Names, Values, Errors : TStringList; ParamName : String);
var
    ValueText : String;
begin
    if FindParamIndex(Names, ParamName) < 0 then
    begin
        AddValidationError(Errors, ParamName + ' was not generated.');
        Exit;
    end;

    ValueText := Trim(ParamValueByName(Names, Values, ParamName));
    if ValueText = '' then
        AddValidationError(Errors, ParamName + ' generated a blank value.');
end;

procedure ValidateGeneratedParameters(Names, Values, Errors : TStringList);
begin
    RequireGeneratedParameter(Names, Values, Errors, 'SCH_DOC_NO');
    RequireGeneratedParameter(Names, Values, Errors, 'SCH_TITLE_1');
    RequireGeneratedParameter(Names, Values, Errors, 'SCH_REV');
    RequireGeneratedParameter(Names, Values, Errors, 'PCB_PART_NO');
    RequireGeneratedParameter(Names, Values, Errors, 'PCB_TITLE_1');
    RequireGeneratedParameter(Names, Values, Errors, 'PCB_DOC_NO');
    RequireGeneratedParameter(Names, Values, Errors, 'PCB_REV');
    RequireGeneratedParameter(Names, Values, Errors, 'PCB_CLASS');
    RequireGeneratedParameter(Names, Values, Errors, 'PCBA_PART_NO');
    RequireGeneratedParameter(Names, Values, Errors, 'PCBA_TITLE_1');
    RequireGeneratedParameter(Names, Values, Errors, 'PCBA_DOC_NO');
    RequireGeneratedParameter(Names, Values, Errors, 'PCBA_REV');
    RequireGeneratedParameter(Names, Values, Errors, 'PCBA_CLASS');
    RequireGeneratedParameter(Names, Values, Errors, 'PCBA_SOLDER');
    RequireGeneratedParameter(Names, Values, Errors, 'CONF_PART_NO');
    RequireGeneratedParameter(Names, Values, Errors, 'CONF_COAT');
    RequireGeneratedParameter(Names, Values, Errors, 'CONF_TITLE_1');
    RequireGeneratedParameter(Names, Values, Errors, 'CONF_DOC_NO');
    RequireGeneratedParameter(Names, Values, Errors, 'CONF_REV');
    RequireGeneratedParameter(Names, Values, Errors, 'ECAD_DOC_NO');
    RequireGeneratedParameter(Names, Values, Errors, 'ECAD_REV');
    RequireGeneratedParameter(Names, Values, Errors, 'CBDD_DOC_NO');
    RequireGeneratedParameter(Names, Values, Errors, 'CBDD_REV');
end;

procedure ShowValidationErrors(Errors : TStringList);
begin
    ShowMessage('Apply was not run. Fix these fields or parameters first:' + #13#10 + #13#10 +
                Errors.Text);
end;

procedure InsertParameterSections(Lines : TStringList; VariantIndex : Integer;
                                  Names, Values : TStringList);
var
    VariantStart : Integer;
    InsertAt     : Integer;
    I            : Integer;
begin
    VariantStart := FindVariantByIndex(Lines, VariantIndex);
    if VariantStart < 0 then
        Exit;

    InsertAt := FindSectionEnd(Lines, VariantStart);
    if (InsertAt > 0) and (Trim(Lines[InsertAt - 1]) <> '') then
    begin
        Lines.Insert(InsertAt, '');
        Inc(InsertAt);
    end;

    for I := 0 to Names.Count - 1 do
    begin
        Lines.Insert(InsertAt, '[Parameter' + IntToStr(ProjectVariantParameterGroup(VariantIndex)) + '_' + IntToStr(I + 1) + ']');
        Inc(InsertAt);
        Lines.Insert(InsertAt, 'Name=' + Names[I]);
        Inc(InsertAt);
        Lines.Insert(InsertAt, 'Value=' + Values[I]);
        Inc(InsertAt);
        Lines.Insert(InsertAt, '');
        Inc(InsertAt);
    end;
end;

procedure CreateVariantSection(Lines : TStringList; VariantIndex : Integer; VariantName : String);
var
    InsertAt : Integer;
begin
    InsertAt := FindNewVariantInsertIndex(Lines);
    if (InsertAt > 0) and (Trim(Lines[InsertAt - 1]) <> '') then
    begin
        Lines.Insert(InsertAt, '');
        Inc(InsertAt);
    end;

    Lines.Insert(InsertAt, '[ProjectVariant' + IntToStr(VariantIndex) + ']');
    Inc(InsertAt);
    Lines.Insert(InsertAt, 'UniqueId=' + NewGuidText);
    Inc(InsertAt);
    Lines.Insert(InsertAt, 'Description=' + VariantName);
    Inc(InsertAt);
    Lines.Insert(InsertAt, 'AllowFabrication=0');
    Inc(InsertAt);
    Lines.Insert(InsertAt, 'ParameterCount=' + IntToStr(REQUIRED_PARAMETER_COUNT));
    Inc(InsertAt);
    Lines.Insert(InsertAt, 'VariationCount=0');
    Inc(InsertAt);
    Lines.Insert(InsertAt, 'ParamVariationCount=0');
    Inc(InsertAt);
    Lines.Insert(InsertAt, '');
end;

function LoadFocusedProjectLines(Lines : TStringList; var ProjectPath : String) : Boolean;
var
    Workspace : IWorkspace;
    Project   : IProject;
begin
    Result := False;

    Workspace := GetWorkspace;
    if Workspace = Nil then
    begin
        ShowMessage('Could not access the Altium workspace.');
        Exit;
    end;

    Project := Workspace.DM_FocusedProject;
    if Project = Nil then
    begin
        ShowMessage('Focus a PCB project in the Projects panel, then run this script again.');
        Exit;
    end;

    ProjectPath := Project.DM_ProjectFullPath;
    if ProjectPath = '' then
    begin
        ShowMessage('The focused project does not have a saved .PrjPcb path.');
        Exit;
    end;

    Lines.LoadFromFile(ProjectPath);
    Result := True;
end;

procedure SetComboSelection(ACombo : TComboBox; Value : String);
var
    I : Integer;
begin
    for I := 0 to ACombo.Items.Count - 1 do
    begin
        if SameTextLocal(ACombo.Items.Strings[I], Value) then
        begin
            ACombo.ItemIndex := I;
            Exit;
        end;
    end;

    ACombo.Text := Value;
end;

procedure SetConformalCoatFromValue(CoatValue : String);
begin
    SetComboSelection(ConfCoatCombo, ConformalCoatDisplayForValue(CoatValue));
end;

function SelectedVariantChoice : String;
begin
    Result := Trim(VariantSelectCombo.Text);
    if Result = '' then
        Result := CREATE_NEW_TEXT;
end;

function SelectedTypeChoice : String;
begin
    Result := Trim(TypeCombo.Text);
    if Result = '' then
        Result := 'OTHER';
end;

function IsFixedVariantType(TypeName : String) : Boolean;
begin
    Result := SameTextLocal(TypeName, 'PROTOTYPE') or
              SameTextLocal(TypeName, 'NON-FLIGHT') or
              SameTextLocal(TypeName, 'FLIGHT');
end;

function VariantTypeForName(VariantName : String) : String;
begin
    if IsFixedVariantType(VariantName) then
        Result := Trim(VariantName)
    else
        Result := 'OTHER';
end;

procedure SyncVariantNameFromType;
var
    TypeName : String;
begin
    TypeName := SelectedTypeChoice;
    if IsFixedVariantType(TypeName) then
    begin
        VariantNameEdit.Text := TypeName;
        VariantNameEdit.ReadOnly := True;
    end
    else if SameTextLocal(TypeName, 'OTHER') then
        VariantNameEdit.ReadOnly := False
    else
    begin
        SetComboSelection(TypeCombo, 'OTHER');
        VariantNameEdit.ReadOnly := False;
    end;
end;

procedure SetVariantTypeFromName(VariantName : String);
begin
    SetComboSelection(TypeCombo, VariantTypeForName(VariantName));
    VariantNameEdit.Text := VariantName;
    SyncVariantNameFromType;
end;

function EffectiveVariantName : String;
begin
    if IsFixedVariantType(SelectedTypeChoice) then
        Result := SelectedTypeChoice
    else
        Result := Trim(VariantNameEdit.Text);
end;

procedure PopulateVariantSelector(Lines : TStringList);
var
    I           : Integer;
    VariantIx   : Integer;
    VariantName : String;
begin
    VariantSelectCombo.Items.Clear;

    for I := 0 to Lines.Count - 1 do
    begin
        VariantIx := ProjectVariantIndexFromHeader(Lines[I]);
        if VariantIx > 0 then
        begin
            VariantName := Trim(ReadSectionValue(Lines, I, 'Description'));
            if VariantName = '' then
                VariantName := 'ProjectVariant' + IntToStr(VariantIx);
            VariantSelectCombo.Items.Add(VariantName);
        end;
    end;

    VariantSelectCombo.Items.Add(CREATE_NEW_TEXT);
    VariantSelectCombo.ItemIndex := 0;
end;

procedure PopulateCageCodeSelector(Lines : TStringList);
begin
    CageCodeCombo.Items.Clear;
    CageCodeCombo.Items.Add('14BW4 - (DEN) ADV PRJ');
    CageCodeCombo.Items.Add('840Y3 - (ORL) AEROSPACE');
    CageCodeCombo.Items.Add('9EKV8 - (ORL) DEFENSE');

    SetComboSelection(CageCodeCombo, DefaultCageCodeDisplay(Lines));
end;

procedure PopulateItarSelector(Lines : TStringList);
begin
    ItarCombo.Items.Clear;
    ItarCombo.Items.Add('ITAR');
    ItarCombo.Items.Add('NON-ITAR');

    SetComboSelection(ItarCombo, DefaultItarChoice(Lines));
end;

procedure LoadProjectParametersIntoForm(Lines : TStringList; ProjectPath : String);
begin
    ProjectNameEdit.Text := DefaultProjectName(Lines, ProjectPath);
    SetComboSelection(CageCodeCombo, DefaultCageCodeDisplay(Lines));
    SetComboSelection(ItarCombo, DefaultItarChoice(Lines));
end;

procedure PumpApplicationMessages(Count : Integer);
var
    I : Integer;
begin
    for I := 1 to Count do
        Application.HandleMessage;
end;

procedure RefreshWorkspacePanel;
begin
    ResetParameters;
    AddStringParameter('ObjectKind', 'Workspace');
    AddStringParameter('Action', 'Refresh');
    RunProcess('WorkspaceManager:Refresh');
    PumpApplicationMessages(5);
end;

procedure RefreshProjectAfterParameterUpdate(Workspace : IWorkspace; var Project : IProject;
                                             ProjectPath : String);
begin
    if Workspace <> Nil then
    begin
        Project := Workspace.DM_OpenProject(ProjectPath, True);
        if Project = Nil then
            Project := Workspace.DM_GetProjectFromPath(ProjectPath);
    end;

    if Project <> Nil then
    begin
        Project.DM_SetAsCurrentProject;
        Project.DM_RefreshInWorkspaceForm;
    end;

    PumpApplicationMessages(2);
end;

procedure RefreshProjectAfterApply(Workspace : IWorkspace; var Project : IProject;
                                   ProjectPath : String; NeedsFullProjectRefresh : Boolean);
begin
    if not NeedsFullProjectRefresh then
    begin
        RefreshProjectAfterParameterUpdate(Workspace, Project, ProjectPath);
        Exit;
    end;

    if Workspace <> Nil then
    begin
        Project := Workspace.DM_OpenProject(ProjectPath, True);
        if Project = Nil then
            Project := Workspace.DM_GetProjectFromPath(ProjectPath);
    end;

    if Project <> Nil then
    begin
        Project.DM_SetAsCurrentProject;
        Project.DM_Compile;
        Project.DM_RefreshInWorkspaceForm;
    end;

    RefreshWorkspacePanel;
end;

function TrySetProjectParameterViaApi(Project : IProject; ParamName, ParamValue : String) : Boolean;
var
    Parameter : IParameter;
begin
    Result := False;

    if Project = Nil then
        Exit;

    try
        Parameter := Project.DM_GetParameterByName(ParamName);
        if Parameter <> Nil then
            Parameter.DM_SetValue(ParamValue)
        else
            Project.DM_AddParameter(ParamName, ParamValue);

        Result := True;
    except
        Result := False;
    end;
end;

function TrySetProjectNameParametersViaApi(Project : IProject; Lines : TStringList;
                                           ProjectName : String) : Boolean;
var
    WroteValue : Boolean;
begin
    Result := False;
    WroteValue := False;

    if FindProjectParameterByName(Lines, 'PROJ_TITLE') >= 0 then
    begin
        if not TrySetProjectParameterViaApi(Project, 'PROJ_TITLE', ProjectName) then
            Exit;
        WroteValue := True;
    end;

    if FindProjectParameterByName(Lines, 'PROJ_NAME') >= 0 then
    begin
        if not TrySetProjectParameterViaApi(Project, 'PROJ_NAME', ProjectName) then
            Exit;
        WroteValue := True;
    end;

    if not WroteValue then
    begin
        if not TrySetProjectParameterViaApi(Project, 'PROJ_TITLE', ProjectName) then
            Exit;
    end;

    Result := True;
end;

function TryApplyProjectParametersViaApi(Project : IProject; Lines : TStringList;
                                         ProjectName, CageCode, ItarChoice : String) : Boolean;
begin
    Result := False;

    if not TrySetProjectNameParametersViaApi(Project, Lines, ProjectName) then
        Exit;
    if not TrySetProjectParameterViaApi(Project, 'CAGE_CODE', CageCode) then
        Exit;
    if not TrySetProjectParameterViaApi(Project, 'ITAR_STATEMENT', ItarStatementForChoice(ItarChoice)) then
        Exit;
    if not TrySetProjectParameterViaApi(Project, 'ITAR_HEADER', ItarHeaderForChoice(ItarChoice)) then
        Exit;

    try
        Project.DM_SetModified;
        Result := True;
    except
        Result := False;
    end;
end;

function TryGetVariantForApiApply(Project : IProject; SelectedVariant, VariantName : String;
                                  CreateIfMissing : Boolean;
                                  var Variant : IProjectVariant) : Boolean;
begin
    Result := False;
    Variant := Nil;

    if Project = Nil then
        Exit;

    try
        if CreateIfMissing then
            Variant := Project.DM_FindProjectVariant(VariantName)
        else
        begin
            Variant := Project.DM_FindProjectVariant(SelectedVariant);
            if Variant = Nil then
                Variant := Project.DM_FindProjectVariant(VariantName);
        end;

        if (Variant = Nil) and CreateIfMissing then
        begin
            Variant := Project.DM_AddProjectVariant;
            if Variant = Nil then
                Exit;

            Variant.DM_SetUniqueId(NewGuidText);
        end;

        if Variant = Nil then
            Exit;

        Result := True;
    except
        Result := False;
    end;
end;

function TryApplyVariantParametersViaApi(Project : IProject; SelectedVariant, VariantName : String;
                                         CreateIfMissing : Boolean;
                                         Names, Values : TStringList) : Boolean;
var
    Variant : IProjectVariant;
    I       : Integer;
begin
    Result := False;

    if not TryGetVariantForApiApply(Project, SelectedVariant, VariantName,
                                    CreateIfMissing, Variant) then
        Exit;

    try
        Variant.DM_SetDescription(VariantName);
        Variant.DM_RemoveAllParameters;

        for I := 0 to Names.Count - 1 do
            Variant.DM_AddParameter(Names[I], Values[I]);

        Project.DM_ProjectVariantChanged;
        Project.DM_SetModified;
        Result := True;
    except
        Result := False;
    end;
end;

function TrySaveFocusedProject(Project : IProject) : Boolean;
begin
    Result := False;

    if Project = Nil then
        Exit;

    try
        Project.DM_SetAsCurrentProject;
        ResetParameters;
        AddStringParameter('ObjectKind', 'FocusedProject');
        AddStringParameter('SaveMode', 'Standard');
        RunProcess('WorkspaceManager:SaveObject');
        Project.DM_RefreshInWorkspaceForm;
        PumpApplicationMessages(5);
        Result := True;
    except
        Result := False;
    end;
end;

function ParameterListsMatch(ExpectedNames, ExpectedValues, ActualNames, ActualValues : TStringList) : Boolean;
var
    I : Integer;
begin
    Result := False;

    if ActualNames.Count <> ExpectedNames.Count then
        Exit;

    for I := 0 to ExpectedNames.Count - 1 do
    begin
        if ParamValueByName(ActualNames, ActualValues, ExpectedNames[I]) <> ExpectedValues[I] then
            Exit;
    end;

    Result := True;
end;

function ProjectFileHasAppliedUpdate(ProjectPath, VariantName, ProjectName, CageCode,
                                     ItarChoice : String; Names, Values : TStringList) : Boolean;
var
    Lines          : TStringList;
    ActualNames    : TStringList;
    ActualValues   : TStringList;
    VariantIndex   : Integer;
    VariantStart   : Integer;
    HasNameParam   : Boolean;
begin
    Result := False;

    Lines := TStringList.Create;
    ActualNames := TStringList.Create;
    ActualValues := TStringList.Create;

    try
        Lines.LoadFromFile(ProjectPath);

        HasNameParam := False;
        if FindProjectParameterByName(Lines, 'PROJ_TITLE') >= 0 then
        begin
            HasNameParam := True;
            if ReadProjectParameter(Lines, 'PROJ_TITLE') <> ProjectName then
                Exit;
        end;

        if FindProjectParameterByName(Lines, 'PROJ_NAME') >= 0 then
        begin
            HasNameParam := True;
            if ReadProjectParameter(Lines, 'PROJ_NAME') <> ProjectName then
                Exit;
        end;

        if not HasNameParam then
            Exit;

        if ReadProjectParameter(Lines, 'CAGE_CODE') <> CageCode then
            Exit;
        if ReadProjectParameter(Lines, 'ITAR_STATEMENT') <> ItarStatementForChoice(ItarChoice) then
            Exit;
        if ReadProjectParameter(Lines, 'ITAR_HEADER') <> ItarHeaderForChoice(ItarChoice) then
            Exit;

        VariantStart := FindVariantByName(Lines, VariantName, VariantIndex);
        if VariantStart < 0 then
            Exit;

        ReadParameterSectionsForVariant(Lines, VariantIndex, ActualNames, ActualValues);
        if not ParameterListsMatch(Names, Values, ActualNames, ActualValues) then
            Exit;

        Result := True;
    finally
        Lines.Free;
        ActualNames.Free;
        ActualValues.Free;
    end;
end;

function TryApplyVariantParameterUpdateViaApi(Project : IProject; ProjectPath : String;
                                              Lines : TStringList; SelectedVariant,
                                              VariantName, ProjectName, CageCode,
                                              ItarChoice : String;
                                              Names, Values : TStringList) : Boolean;
var
    CreateIfMissing : Boolean;
begin
    Result := False;
    CreateIfMissing := SameTextLocal(SelectedVariant, CREATE_NEW_TEXT);

    if (not CreateIfMissing) and (Trim(SelectedVariant) <> Trim(VariantName)) then
        Exit;

    if not TryApplyVariantParametersViaApi(Project, SelectedVariant, VariantName,
                                           CreateIfMissing, Names, Values) then
        Exit;
    if not TryApplyProjectParametersViaApi(Project, Lines, ProjectName, CageCode, ItarChoice) then
        Exit;
    if not TrySaveFocusedProject(Project) then
        Exit;
    if not ProjectFileHasAppliedUpdate(ProjectPath, VariantName, ProjectName, CageCode,
                                       ItarChoice, Names, Values) then
        Exit;

    Result := True;
end;

procedure LoadSelectedVariantIntoForm;
var
    ProjectPath      : String;
    SelectedVariant  : String;
    DefaultProjName  : String;
    VariantIndex     : Integer;
    VariantStart     : Integer;
    PartNumber       : String;
    Revision         : String;
    ClassValue       : String;
    Lines            : TStringList;
    Names            : TStringList;
    Values           : TStringList;
begin
    Lines := TStringList.Create;
    Names := TStringList.Create;
    Values := TStringList.Create;

    try
        if not LoadFocusedProjectLines(Lines, ProjectPath) then
            Exit;

        DefaultProjName := DefaultProjectName(Lines, ProjectPath);
        LoadProjectParametersIntoForm(Lines, ProjectPath);

        SelectedVariant := SelectedVariantChoice;
        if SameTextLocal(SelectedVariant, CREATE_NEW_TEXT) then
        begin
            PartNumberEdit.Text := '';
            RevisionEdit.Text := '';
            ProjectNameEdit.Text := DefaultProjName;
            SetVariantTypeFromName('');
            ClassCombo.ItemIndex := 0;
            SetConformalCoatFromValue('NONE');
            LeadedSolderCheck.Checked := False;
            AlteredItemCheck.Checked := False;
            RefreshParameterPreview(Names, Values);
            Exit;
        end;

        VariantStart := FindVariantByName(Lines, SelectedVariant, VariantIndex);
        if VariantStart < 0 then
        begin
            ShowMessage('Could not find variant "' + SelectedVariant + '".');
            RefreshParameterPreview(Names, Values);
            Exit;
        end;

        ReadParameterSectionsForVariant(Lines, VariantIndex, Names, Values);
        SetVariantTypeFromName(ReadSectionValue(Lines, VariantStart, 'Description'));

        PartNumber := InferredPartNumber(Names, Values);
        if PartNumber <> '' then
            PartNumberEdit.Text := PartNumber;

        Revision := FirstNonBlankParam(Names, Values, 'PCB_REV', 'PCBA_REV', 'SCH_REV');
        if Revision <> '' then
            RevisionEdit.Text := Revision;

        ProjectNameEdit.Text := DefaultProjName;

        ClassValue := FirstNonBlankParam(Names, Values, 'PCB_CLASS', 'PCBA_CLASS', '');
        if ClassValue <> '' then
            SetComboSelection(ClassCombo, ClassValue);

        SetLeadedSolderFromValue(ParamValueByName(Names, Values, 'PCBA_SOLDER'));
        SetConformalCoatFromValue(ConformalCoatValueFromParameters(Names, Values));
        AlteredItemCheck.Checked := FindParamIndex(Names, 'ALT_PART_NO') >= 0;

        RefreshParameterPreview(Names, Values);
    finally
        Lines.Free;
        Names.Free;
        Values.Free;
    end;
end;

procedure PreviewEnteredParameters;
var
    Names       : TStringList;
    Values      : TStringList;
    VariantName : String;
    ClassValue  : String;
    SolderValue : String;
    CoatValue   : String;
begin
    Names := TStringList.Create;
    Values := TStringList.Create;

    try
        SyncVariantNameFromType;
        VariantName := EffectiveVariantName;
        if (VariantName = '') and not SameTextLocal(SelectedVariantChoice, CREATE_NEW_TEXT) then
            VariantName := SelectedVariantChoice;

        ClassValue := Trim(ClassCombo.Text);
        if ClassValue = '' then
            ClassValue := '2';

        SolderValue := SolderValueFromCheckbox;
        CoatValue := ConformalCoatValueFromComboText(ConfCoatCombo.Text);
        if CoatValue = '' then
            CoatValue := 'NONE';

        ApplyRequiredVariantParameters(Names, Values,
                                       Trim(PartNumberEdit.Text),
                                       Trim(RevisionEdit.Text),
                                       Trim(ProjectNameEdit.Text),
                                       VariantName,
                                       ClassValue,
                                       SolderValue,
                                       CoatValue,
                                       AlteredItemCheck.Checked);
        RefreshParameterPreview(Names, Values);
    finally
        Names.Free;
        Values.Free;
    end;
end;

function ApplyVariantParameters : Boolean;
var
    Workspace      : IWorkspace;
    Project        : IProject;
    ProjectPath    : String;
    BackupPath     : String;
    Lines          : TStringList;
    Names          : TStringList;
    Values         : TStringList;
    ValidationNames : TStringList;
    ValidationValues: TStringList;
    ValidationErrors: TStringList;
    SelectedVariant: String;
    PartNumber     : String;
    Revision       : String;
    ProjectName    : String;
    ClassValue     : String;
    SolderValue    : String;
    CoatValue      : String;
    CageCode       : String;
    ItarChoice     : String;
    VariantName    : String;
    VariantIndex   : Integer;
    VariantStart   : Integer;
    CreatedVariant : Boolean;
    NeedsFullProjectRefresh : Boolean;
begin
    Result := False;

    ValidationNames := TStringList.Create;
    ValidationValues := TStringList.Create;
    ValidationErrors := TStringList.Create;
    SelectedVariant := SelectedVariantChoice;
    SyncVariantNameFromType;
    VariantName := EffectiveVariantName;

    try
        if VariantName = '' then
            AddValidationError(ValidationErrors, 'Variant Name is required for ProjectVariant.Description and title parameters.');

        PartNumber := Trim(PartNumberEdit.Text);
        if PartNumber = '' then
            AddValidationError(ValidationErrors, 'Part Number is required for SCH_DOC_NO, PCB_PART_NO, PCB_DOC_NO, PCBA_PART_NO, PCBA_DOC_NO, CONF_PART_NO, CONF_DOC_NO, ECAD_DOC_NO, CBDD_DOC_NO, and ALT_PART_NO when Altered Item is checked.');

        ProjectName := Trim(ProjectNameEdit.Text);
        if ProjectName = '' then
            AddValidationError(ValidationErrors, 'Project Name is required for SCH_TITLE_1, PCB_TITLE_1, PCBA_TITLE_1, and CONF_TITLE_1.');

        Revision := Trim(RevisionEdit.Text);
        if Revision = '' then
            AddValidationError(ValidationErrors, 'Revision is required for SCH_REV, PCB_REV, PCBA_REV, CONF_REV, ECAD_REV, and CBDD_REV.');

        ClassValue := Trim(ClassCombo.Text);
        if (ClassValue <> '2') and (ClassValue <> '3') then
            AddValidationError(ValidationErrors, 'Class must be 2 or 3 for PCB_CLASS and PCBA_CLASS.');

        SolderValue := SolderValueFromCheckbox;

        CoatValue := ConformalCoatValueFromComboText(ConfCoatCombo.Text);
        if (CoatValue <> 'NONE') and (CoatValue <> 'ACRYLIC') and (CoatValue <> 'URETHANE') then
            AddValidationError(ValidationErrors, 'Conformal Coat must be NONE, ACRYLIC, or URETHANE.');

        CageCode := CageCodeFromComboText(CageCodeCombo.Text);
        if CageCode = '' then
            AddValidationError(ValidationErrors, 'CAGE_CODE is required as a project parameter.');

        ItarChoice := ItarChoiceFromComboText(ItarCombo.Text);
        if (ItarChoice <> 'ITAR') and (ItarChoice <> 'NON-ITAR') then
            AddValidationError(ValidationErrors, 'ITAR selection must be ITAR or NON-ITAR.');

        if ValidationErrors.Count = 0 then
        begin
            ApplyRequiredVariantParameters(ValidationNames, ValidationValues,
                                           PartNumber, Revision, ProjectName,
                                           VariantName, ClassValue, SolderValue,
                                           CoatValue,
                                           AlteredItemCheck.Checked);
            ValidateGeneratedParameters(ValidationNames, ValidationValues, ValidationErrors);
            if AlteredItemCheck.Checked then
                RequireGeneratedParameter(ValidationNames, ValidationValues, ValidationErrors, 'ALT_PART_NO');
        end;

        if ValidationErrors.Count > 0 then
        begin
            ShowValidationErrors(ValidationErrors);
            Exit;
        end;
    finally
        ValidationNames.Free;
        ValidationValues.Free;
        ValidationErrors.Free;
    end;

    Workspace := GetWorkspace;
    if Workspace = Nil then
    begin
        ShowMessage('Could not access the Altium workspace.');
        Exit;
    end;

    Project := Workspace.DM_FocusedProject;
    if Project = Nil then
    begin
        ShowMessage('Focus a PCB project in the Projects panel, then run this script again.');
        Exit;
    end;

    ProjectPath := Project.DM_ProjectFullPath;
    if ProjectPath = '' then
    begin
        ShowMessage('The focused project does not have a saved .PrjPcb path.');
        Exit;
    end;

    Lines := TStringList.Create;
    Names := TStringList.Create;
    Values := TStringList.Create;

    try
        Lines.LoadFromFile(ProjectPath);
        BackupPath := ProjectPath + '.variant-parameter-editor.bak';
        Lines.SaveToFile(BackupPath);

        if SameTextLocal(SelectedVariant, CREATE_NEW_TEXT) then
        begin
            VariantStart := FindVariantByName(Lines, VariantName, VariantIndex);
            CreatedVariant := VariantStart < 0;
        end
        else
        begin
            VariantStart := FindVariantByName(Lines, SelectedVariant, VariantIndex);
            CreatedVariant := False;
        end;

        if CreatedVariant then
        begin
            VariantIndex := GetMaxVariantIndex(Lines) + 1;
            CreateVariantSection(Lines, VariantIndex, VariantName);
            VariantStart := FindVariantByIndex(Lines, VariantIndex);
        end;

        NeedsFullProjectRefresh := CreatedVariant;
        if (not NeedsFullProjectRefresh) and
           (not SameTextLocal(SelectedVariant, CREATE_NEW_TEXT)) and
           (Trim(SelectedVariant) <> Trim(VariantName)) then
            NeedsFullProjectRefresh := True;

        if VariantStart < 0 then
        begin
            ShowMessage('Could not create or locate the project variant section.');
            Exit;
        end;

        ReadParameterSectionsForVariant(Lines, VariantIndex, Names, Values);
        ApplyRequiredVariantParameters(Names, Values, PartNumber, Revision, ProjectName,
                                       VariantName, ClassValue, SolderValue,
                                       CoatValue,
                                       AlteredItemCheck.Checked);

        if ((not NeedsFullProjectRefresh) or SameTextLocal(SelectedVariant, CREATE_NEW_TEXT)) and
           TryApplyVariantParameterUpdateViaApi(Project, ProjectPath, Lines,
                                                SelectedVariant, VariantName,
                                                ProjectName, CageCode, ItarChoice,
                                                Names, Values) then
        begin
            VariantForm.Hide;
            Result := True;
            Exit;
        end;

        DeleteParameterSectionsForVariant(Lines, VariantIndex);
        SetProjectNameParameter(Lines, ProjectName);
        SetProjectParameter(Lines, 'CAGE_CODE', CageCode);
        SetProjectParameter(Lines, 'ITAR_STATEMENT', ItarStatementForChoice(ItarChoice));
        SetProjectParameter(Lines, 'ITAR_HEADER', ItarHeaderForChoice(ItarChoice));

        VariantStart := FindVariantByIndex(Lines, VariantIndex);
        SetSectionValue(Lines, VariantStart, 'Description', VariantName);
        SetSectionValue(Lines, VariantStart, 'ParameterCount', IntToStr(Names.Count));

        InsertParameterSections(Lines, VariantIndex, Names, Values);
        Lines.SaveToFile(ProjectPath);

        RefreshProjectAfterApply(Workspace, Project, ProjectPath, NeedsFullProjectRefresh);

        VariantForm.Hide;

        Result := True;
    finally
        Lines.Free;
        Names.Free;
        Values.Free;
    end;
end;

procedure ApplyDarkFormStyle(AForm : TForm);
begin
    AForm.Color := UI_DARK_BACKGROUND;
    AForm.Font.Name := 'Segoe UI';
    AForm.Font.Size := 9;
    AForm.Font.Color := UI_DARK_TEXT;
end;

procedure ApplyDarkLabelStyle(ALabel : TLabel);
begin
    ALabel.Transparent := True;
    ALabel.Font.Color := UI_DARK_MUTED_TEXT;
end;

procedure ApplyDarkEditStyle(AEdit : TEdit; IsPreviewField : Boolean);
begin
    if IsPreviewField then
    begin
        AEdit.Color := UI_DARK_CONTROL;
        AEdit.Font.Color := UI_DARK_TEXT;
    end
    else
    begin
        AEdit.Color := UI_LIGHT_FIELD;
        AEdit.Font.Color := UI_LIGHT_TEXT;
    end;

    AEdit.Ctl3D := False;
end;

procedure ApplyDarkComboStyle(ACombo : TComboBox);
begin
    ACombo.Style := csDropDownList;
    ACombo.Color := UI_DARK_COMBO;
    ACombo.Font.Color := UI_DARK_TEXT;
    ACombo.ParentCtl3D := False;
    ACombo.Ctl3D := False;
end;

procedure SetComboWidth(ACombo : TComboBox; WidthValue : Integer);
begin
    ACombo.Width := WidthValue;
end;

procedure ApplyDarkButtonStyle(AButton : TButton);
begin
    AButton.Font.Color := UI_DARK_TEXT;
end;

procedure ApplyDarkCheckBoxStyle(ACheckBox : TCheckBox);
begin
    ACheckBox.Color := UI_DARK_BACKGROUND;
    ACheckBox.Font.Color := UI_DARK_MUTED_TEXT;
end;

procedure AddSectionHeader(AOwner : TForm; CaptionText : String; TopValue : Integer);
var
    LabelRef : TLabel;
begin
    LabelRef := TLabel.Create(AOwner);
    LabelRef.Parent := AOwner;
    LabelRef.Left := 16;
    LabelRef.Top := TopValue;
    LabelRef.Width := 888;
    LabelRef.AutoSize := False;
    LabelRef.Caption := CaptionText;
    LabelRef.Alignment := taCenter;
    LabelRef.Transparent := True;
    LabelRef.Font.Color := UI_DARK_TEXT;
end;

procedure AddLabelAndEditAt(AOwner : TForm; CaptionText : String;
                            LabelLeft, TopValue, EditLeft, EditWidth : Integer;
                            var EditRef : TEdit);
var
    LabelRef : TLabel;
begin
    LabelRef := TLabel.Create(AOwner);
    LabelRef.Parent := AOwner;
    LabelRef.Left := LabelLeft;
    LabelRef.Top := TopValue + 4;
    LabelRef.Width := EditLeft - LabelLeft - 8;
    LabelRef.Caption := CaptionText;
    ApplyDarkLabelStyle(LabelRef);

    EditRef := TEdit.Create(AOwner);
    EditRef.Parent := AOwner;
    EditRef.Left := EditLeft;
    EditRef.Top := TopValue;
    EditRef.Width := EditWidth;
    ApplyDarkEditStyle(EditRef, False);
end;

procedure AddLabelAndEdit(AOwner : TForm; CaptionText : String; TopValue : Integer; var EditRef : TEdit);
begin
    AddLabelAndEditAt(AOwner, CaptionText, 16, TopValue, 148, 320, EditRef);
end;

procedure AddLabelAndComboAt(AOwner : TForm; CaptionText : String;
                             LabelLeft, TopValue, ComboLeft, ComboWidth : Integer;
                             var ComboRef : TComboBox);
var
    LabelRef : TLabel;
begin
    LabelRef := TLabel.Create(AOwner);
    LabelRef.Parent := AOwner;
    LabelRef.Left := LabelLeft;
    LabelRef.Top := TopValue + 4;
    LabelRef.Width := ComboLeft - LabelLeft - 8;
    LabelRef.Caption := CaptionText;
    ApplyDarkLabelStyle(LabelRef);

    ComboRef := TComboBox.Create(AOwner);
    ComboRef.Parent := AOwner;
    ComboRef.Left := ComboLeft;
    ComboRef.Top := TopValue;
    ComboRef.Width := ComboWidth;
    ApplyDarkComboStyle(ComboRef);
end;

procedure AddLabelAndCombo(AOwner : TForm; CaptionText : String; TopValue : Integer; var ComboRef : TComboBox);
begin
    AddLabelAndComboAt(AOwner, CaptionText, 16, TopValue, 148, 360, ComboRef);
end;

procedure AddParameterPreviewField(AOwner : TForm; ParamName : String;
                                   LabelLeft, TopValue, EditLeft, EditWidth : Integer;
                                   var EditRef : TEdit);
var
    LabelRef : TLabel;
begin
    LabelRef := TLabel.Create(AOwner);
    LabelRef.Parent := AOwner;
    LabelRef.Left := LabelLeft;
    LabelRef.Top := TopValue + 4;
    LabelRef.Width := EditLeft - LabelLeft - 8;
    LabelRef.Caption := ParamName + ':';
    ApplyDarkLabelStyle(LabelRef);

    EditRef := TEdit.Create(AOwner);
    EditRef.Parent := AOwner;
    EditRef.Left := EditLeft;
    EditRef.Top := TopValue;
    EditRef.Width := EditWidth;
    EditRef.ReadOnly := True;
    EditRef.Text := 'N/A';
    ApplyDarkEditStyle(EditRef, True);
end;

procedure ShowVariantParameterEditor;
var
    ApplyButton  : TButton;
    PreviewButton: TButton;
    CancelButton : TButton;
    PreviewLabel : TLabel;
    SolderLabel  : TLabel;
    SolderChoiceLabel : TLabel;
    AlteredItemLabel : TLabel;
    Lines        : TStringList;
    Names        : TStringList;
    Values       : TStringList;
    ProjectPath  : String;
    FormResult   : Integer;
    LastVariantChoice    : String;
    CurrentVariantChoice : String;
    LastTypeChoice       : String;
    CurrentTypeChoice    : String;
begin
    Lines := TStringList.Create;
    Names := TStringList.Create;
    Values := TStringList.Create;

    try
        Lines.Clear;
        Names.Clear;
        Values.Clear;

        if not LoadFocusedProjectLines(Lines, ProjectPath) then
            Exit;

        VariantForm := TForm.Create(nil);
        try
        VariantForm.Caption := 'Six Degrees of Variation';
        VariantForm.BorderStyle := bsDialog;
        VariantForm.Position := poScreenCenter;
        VariantForm.Width := 920;
        VariantForm.Height := 820;
        ApplyDarkFormStyle(VariantForm);

        AddLabelAndComboAt(VariantForm, 'Variant', 16, 16, 148, 450, VariantSelectCombo);
        PopulateVariantSelector(Lines);

        AddSectionHeader(VariantForm, 'PROJECT PARAMETERS', 56);

        AddLabelAndEditAt(VariantForm, 'Name', 16, 80, 148, 290, ProjectNameEdit);
        AddLabelAndComboAt(VariantForm, 'Cage Code', 470, 80, 600, 290, CageCodeCombo);
        PopulateCageCodeSelector(Lines);

        AddLabelAndComboAt(VariantForm, 'ITAR', 16, 116, 148, 290, ItarCombo);
        PopulateItarSelector(Lines);
        LoadProjectParametersIntoForm(Lines, ProjectPath);

        AddSectionHeader(VariantForm, 'VARIANT PARAMETERS', 160);

        AddLabelAndEditAt(VariantForm, 'Part Number', 16, 184, 148, 290, PartNumberEdit);
        AddLabelAndEditAt(VariantForm, 'Revision', 470, 184, 600, 290, RevisionEdit);

        AddLabelAndComboAt(VariantForm, 'Variant Type', 16, 220, 148, 290, TypeCombo);
        TypeCombo.Items.Add('PROTOTYPE');
        TypeCombo.Items.Add('NON-FLIGHT');
        TypeCombo.Items.Add('FLIGHT');
        TypeCombo.Items.Add('OTHER');
        TypeCombo.ItemIndex := 3;

        AddLabelAndEditAt(VariantForm, 'Variant Name', 470, 220, 600, 290, VariantNameEdit);
        SyncVariantNameFromType;

        AddLabelAndComboAt(VariantForm, 'Class', 16, 256, 148, 290, ClassCombo);
        ClassCombo.Items.Add('2');
        ClassCombo.Items.Add('3');
        ClassCombo.ItemIndex := 0;

        SolderLabel := TLabel.Create(VariantForm);
        SolderLabel.Parent := VariantForm;
        SolderLabel.Left := 470;
        SolderLabel.Top := 260;
        SolderLabel.Width := 116;
        SolderLabel.Caption := 'Leaded Solder';
        ApplyDarkLabelStyle(SolderLabel);

        LeadedSolderCheck := TCheckBox.Create(VariantForm);
        LeadedSolderCheck.Parent := VariantForm;
        LeadedSolderCheck.Left := 600;
        LeadedSolderCheck.Top := 256;
        LeadedSolderCheck.Width := 20;
        LeadedSolderCheck.Caption := '';
        LeadedSolderCheck.Checked := False;
        ApplyDarkCheckBoxStyle(LeadedSolderCheck);

        SolderChoiceLabel := TLabel.Create(VariantForm);
        SolderChoiceLabel.Parent := VariantForm;
        SolderChoiceLabel.Left := 624;
        SolderChoiceLabel.Top := 260;
        SolderChoiceLabel.Width := 266;
        SolderChoiceLabel.Caption := 'TIN/LEAD (SN63/PB37)';
        ApplyDarkLabelStyle(SolderChoiceLabel);

        AddLabelAndComboAt(VariantForm, 'Conformal Coat', 16, 292, 148, 290, ConfCoatCombo);
        ConfCoatCombo.Items.Add('NONE');
        ConfCoatCombo.Items.Add('ACRYLIC (-02)');
        ConfCoatCombo.Items.Add('URETHANE (-03)');
        ConfCoatCombo.ItemIndex := 0;

        AlteredItemLabel := TLabel.Create(VariantForm);
        AlteredItemLabel.Parent := VariantForm;
        AlteredItemLabel.Left := 470;
        AlteredItemLabel.Top := 296;
        AlteredItemLabel.Width := 116;
        AlteredItemLabel.Caption := 'Altered Item';
        ApplyDarkLabelStyle(AlteredItemLabel);

        AlteredItemCheck := TCheckBox.Create(VariantForm);
        AlteredItemCheck.Parent := VariantForm;
        AlteredItemCheck.Left := 600;
        AlteredItemCheck.Top := 292;
        AlteredItemCheck.Width := 20;
        AlteredItemCheck.Caption := '';
        AlteredItemCheck.Checked := False;
        ApplyDarkCheckBoxStyle(AlteredItemCheck);

        PreviewLabel := TLabel.Create(VariantForm);
        PreviewLabel.Parent := VariantForm;
        PreviewLabel.Left := 16;
        PreviewLabel.Top := 332;
        PreviewLabel.Width := 888;
        PreviewLabel.AutoSize := False;
        PreviewLabel.Caption := 'CURRENT PARAMETER VALUES';
        PreviewLabel.Alignment := taCenter;
        ApplyDarkLabelStyle(PreviewLabel);

        AddParameterPreviewField(VariantForm, 'SCH_DOC_NO',     16, 352, 148, 290, PreviewSchDocNoEdit);
        AddParameterPreviewField(VariantForm, 'SCH_TITLE_1',    16, 376, 148, 290, PreviewSchTitle1Edit);
        AddParameterPreviewField(VariantForm, 'SCH_REV',        16, 400, 148, 290, PreviewSchRevEdit);
        AddParameterPreviewField(VariantForm, 'CONF_PART_NO',   16, 424, 148, 290, PreviewConfPartNoEdit);
        AddParameterPreviewField(VariantForm, 'CONF_COAT',      16, 448, 148, 290, PreviewConfCoatEdit);
        AddParameterPreviewField(VariantForm, 'CONF_TITLE_1',   16, 472, 148, 290, PreviewConfTitle1Edit);
        AddParameterPreviewField(VariantForm, 'CONF_DOC_NO',    16, 496, 148, 290, PreviewConfDocNoEdit);
        AddParameterPreviewField(VariantForm, 'CONF_REV',       16, 520, 148, 290, PreviewConfRevEdit);
        AddParameterPreviewField(VariantForm, 'ECAD_DOC_NO',    16, 544, 148, 290, PreviewEcadDocNoEdit);
        AddParameterPreviewField(VariantForm, 'ECAD_REV',       16, 568, 148, 290, PreviewEcadRevEdit);
        AddParameterPreviewField(VariantForm, 'CBDD_DOC_NO',    16, 592, 148, 290, PreviewCbddDocNoEdit);
        AddParameterPreviewField(VariantForm, 'CBDD_REV',       16, 616, 148, 290, PreviewCbddRevEdit);

        AddParameterPreviewField(VariantForm, 'PCB_PART_NO',    470, 352, 600, 290, PreviewPcbPartNoEdit);
        AddParameterPreviewField(VariantForm, 'PCB_TITLE_1',    470, 376, 600, 290, PreviewPcbTitle1Edit);
        AddParameterPreviewField(VariantForm, 'PCB_DOC_NO',     470, 400, 600, 290, PreviewPcbDocNoEdit);
        AddParameterPreviewField(VariantForm, 'PCB_REV',        470, 424, 600, 290, PreviewPcbRevEdit);
        AddParameterPreviewField(VariantForm, 'PCB_CLASS',      470, 448, 600, 290, PreviewPcbClassEdit);
        AddParameterPreviewField(VariantForm, 'PCBA_PART_NO',   470, 472, 600, 290, PreviewPcbaPartNoEdit);
        AddParameterPreviewField(VariantForm, 'PCBA_TITLE_1',   470, 496, 600, 290, PreviewPcbaTitle1Edit);
        AddParameterPreviewField(VariantForm, 'PCBA_DOC_NO',    470, 520, 600, 290, PreviewPcbaDocNoEdit);
        AddParameterPreviewField(VariantForm, 'PCBA_REV',       470, 544, 600, 290, PreviewPcbaRevEdit);
        AddParameterPreviewField(VariantForm, 'PCBA_CLASS',     470, 568, 600, 290, PreviewPcbaClassEdit);
        AddParameterPreviewField(VariantForm, 'PCBA_SOLDER',    470, 592, 600, 290, PreviewPcbaSolderEdit);
        AddParameterPreviewField(VariantForm, 'ALT_PART_NO',    470, 616, 600, 290, PreviewAltPartNoEdit);
        RefreshParameterPreview(Names, Values);
        LoadSelectedVariantIntoForm;

        PreviewButton := TButton.Create(VariantForm);
        PreviewButton.Parent := VariantForm;
        PreviewButton.Left := 610;
        PreviewButton.Top := 690;
        PreviewButton.Width := 80;
        PreviewButton.Caption := 'Preview';
        PreviewButton.ModalResult := PREVIEW_MODAL_RESULT;
        ApplyDarkButtonStyle(PreviewButton);

        ApplyButton := TButton.Create(VariantForm);
        ApplyButton.Parent := VariantForm;
        ApplyButton.Left := 706;
        ApplyButton.Top := 690;
        ApplyButton.Width := 80;
        ApplyButton.Caption := 'Apply';
        ApplyButton.ModalResult := mrOk;
        ApplyDarkButtonStyle(ApplyButton);

        CancelButton := TButton.Create(VariantForm);
        CancelButton.Parent := VariantForm;
        CancelButton.Left := 802;
        CancelButton.Top := 690;
        CancelButton.Width := 80;
        CancelButton.Caption := 'Cancel';
        CancelButton.ModalResult := mrCancel;
        ApplyDarkButtonStyle(CancelButton);

        LastVariantChoice := SelectedVariantChoice;
        LastTypeChoice := SelectedTypeChoice;
        VariantForm.Show;

        while VariantForm.Visible do
        begin
            Application.HandleMessage;

            CurrentVariantChoice := SelectedVariantChoice;
            if not SameTextLocal(CurrentVariantChoice, LastVariantChoice) then
            begin
                LastVariantChoice := CurrentVariantChoice;
                LoadSelectedVariantIntoForm;
                LastTypeChoice := SelectedTypeChoice;
            end;

            CurrentTypeChoice := SelectedTypeChoice;
            if not SameTextLocal(CurrentTypeChoice, LastTypeChoice) then
            begin
                LastTypeChoice := CurrentTypeChoice;
                SyncVariantNameFromType;
            end;

            FormResult := VariantForm.ModalResult;
            if FormResult = 0 then
                Continue;

            VariantForm.ModalResult := 0;

            if FormResult = PREVIEW_MODAL_RESULT then
            begin
                PreviewEnteredParameters;
                Continue;
            end;

            if FormResult <> mrOk then
                Break;

            if ApplyVariantParameters then
                Break;
        end;
        finally
            VariantForm.Free;
        end;
    finally
        Lines.Free;
        Names.Free;
        Values.Free;
    end;
end;

