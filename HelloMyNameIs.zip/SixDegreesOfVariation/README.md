# Altium Variant Parameter Editor

This folder contains an Altium Designer v26 DelphiScript:

- `VARIATE_ME.pas`
- `INSTALL_MENU.pas`

Run `ShowVariantParameterEditor` from Altium's script runner while the target PCB project is focused in the Projects panel.

To install a persistent menu shortcut without administrator rights, fully close Altium Designer and run `C:\Users\Public\Documents\Altium\altiumscripts\Install_Red6_Menu_NoAdmin.cmd`. It updates your per-user Altium profile and adds:

- `No document menu bar > Red 6 > Six Degrees of Variation`
- `PCB editor menu bar > Red 6 > Six Degrees of Variation`
- `Schematic editor menu bar > Red 6 > Six Degrees of Variation`
- `Schematic symbol editor menu bar > Red 6 > Six Degrees of Variation`
- `Footprint editor menu bar > Red 6 > Six Degrees of Variation`

The no-admin installer lives one folder above this script project so the same `Red 6` menu can collect multiple internal scripts. To add another item later, add it to the `$menuItems` list in `C:\Users\Public\Documents\Altium\altiumscripts\Install_Red6_Menu_NoAdmin.ps1`.

The no-admin installer updates each `DXP.RCS` file found under `%APPDATA%\Altium\Altium Designer *`, writes timestamped `.red6-user-*.bak` backups beside changed files, removes older Red 6 install blocks, and can be run again safely. It refuses to run while Altium is open because Altium rewrites the active `DXP.RCS` file from memory when it exits.

If your Altium installation ignores per-user top-level menu insertions, the fallback is `Install_Red6_Menu.cmd`. That version requests administrator rights and patches Altium's installed `dxp.rcs`, `AdvPcb.rcs`, and `AdvSch.rcs` files under `C:\Program Files\Altium\AD*\System\Resources\*`.

The script creates or updates a `[ProjectVariantN]` entry in the focused `.PrjPcb` file and adds or updates the standard SCH, PCB, PCBA, coated assembly, ECAD, and CBDD parameters.

Existing unrelated variant parameters are preserved. The form has:

- A `Variant` drop-down with `Create New...` plus existing variants.
- Automatic loading of entry fields and current-parameter values when an existing variant is selected.
- A `Type` drop-down with `PROTOTYPE`, `NON-FLIGHT`, `FLIGHT`, and `OTHER`. Selecting `PROTOTYPE`, `NON-FLIGHT`, or `FLIGHT` copies that value into `Variant Name` and locks the field; selecting `OTHER` unlocks `Variant Name` for a custom value.
- Entry fields for `Part Number`, `Revision`, project title/name parameter, `Variant Name`, and `Class`, plus `Leaded Solder` and `Altered Item` checkboxes and a `Conformal Coat` dropdown. Checked solder writes `PCBA_SOLDER=TIN/LEAD (SN63/PB37)`; unchecked writes `PCBA_SOLDER=LEAD FREE (SAC305 OR EQUIVALENT)`. Conformal coat sets `CONF_PART_NO`, `CONF_COAT`, `CONF_TITLE_1`, `CONF_DOC_NO`, and `CONF_REV` to `N/A` when `NONE` is selected, or writes the coated assembly values when `ACRYLIC` or `URETHANE` is selected. Checked altered item writes `ALT_PART_NO=620-<part>-01` for uncoated boards, or uses the conformal coating suffix for coated boards.
- Project parameter drop-downs for `CAGE_CODE` and export control status. Export status writes `ITAR_STATEMENT` and `ITAR_HEADER` as project parameters.
- A `Preview` button that regenerates all displayed parameter values from the current entry fields without saving.

On Apply, the script validates all required entry fields and generated parameters before touching the project file. If anything is missing or invalid, a message box lists the specific fields or parameters to fix and no project update is run.

When Apply succeeds, the script writes the existing project title/name parameter (`PROJ_TITLE` and/or `PROJ_NAME`, creating `PROJ_TITLE` when neither exists), `CAGE_CODE`, `ITAR_STATEMENT`, and `ITAR_HEADER` as project parameters, updates the selected variant parameters, then closes the form. Parameter-only updates to an existing variant and new variant creation first try Altium's in-memory project/variant parameter APIs and use Altium's own focused-project save, which avoids the external `.PrjPcb` rewrite/reload path when the API save verifies cleanly. Variant renames or API-update failures still fall back to the direct `.PrjPcb` rewrite and project refresh path.

The parameter formatting is isolated in `ApplyRequiredVariantParameters` in `VARIATE_ME.pas`. It writes:

`SCH_DOC_NO`, `SCH_TITLE_1`, `SCH_REV`, `PCB_PART_NO`, `PCB_TITLE_1`, `PCB_DOC_NO`, `PCB_REV`, `PCB_CLASS`, `PCBA_PART_NO`, `PCBA_TITLE_1`, `PCBA_DOC_NO`, `PCBA_REV`, `PCBA_CLASS`, `PCBA_SOLDER`, `CONF_PART_NO`, `CONF_COAT`, `CONF_TITLE_1`, `CONF_DOC_NO`, `CONF_REV`, `ECAD_DOC_NO`, `ECAD_REV`, `CBDD_DOC_NO`, `CBDD_REV`, and optional `ALT_PART_NO`.

The script writes a backup beside the project file using this suffix:

`.variant-parameter-editor.bak`
