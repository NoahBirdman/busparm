# Import Mech Layers

This folder contains an Altium Designer DelphiScript:

- `IMPORT_MECH_LAYERS.pas`

Keep `R6_ComponentMechanicals_2026_04.stackup` in this folder, then run `ImportMechanicalLayersFromStackup` from Altium's script runner while the target PCB document is open and focused.

The script first checks for `R6_ComponentMechanicals_2026_04.stackup` by exact path, then falls back to finding a single `.stackup` file in this folder. If this folder has no `.stackup` file, or more than one fallback `.stackup` file, the script shows an error and does not run the import. The native command imports the mechanical layer structure and component layer pairs. It does not import objects or primitives placed on those layers.

To install a persistent menu shortcut, fully close Altium Designer and run `C:\Users\Public\Documents\Altium\altiumscripts\Install_Red6_Menu_NoAdmin.cmd`. It adds:

- `PCB editor menu bar > Red 6 > Import Mech Layers`
- `Footprint editor menu bar > Red 6 > Import Mech Layers`
