{ Altium Designer DelphiScript
  Imports mechanical layer structure and component layer pairs from a
  .stackup file in this script folder into the active PCB document.

  Run procedure: ImportMechanicalLayersFromStackup
}

uses
    SysUtils,
    Dialogs;

const
    STACKUP_FOLDER = 'C:\Users\Public\Documents\Altium\altiumscripts\Import Mech Layers';
    STACKUP_FILE_NAME = 'R6_ComponentMechanicals_2026_04.stackup';

function SameTextLocal(A, B : String) : Boolean;
begin
    Result := UpperCase(Trim(A)) = UpperCase(Trim(B));
end;

function IsStackupFile(FileName : String) : Boolean;
begin
    Result := SameTextLocal(ExtractFileExt(FileName), '.stackup');
end;

function FolderWithTrailingSlash(FolderName : String) : String;
begin
    Result := Trim(FolderName);
    if Result = '' then
        Exit;

    if Copy(Result, Length(Result), 1) <> '\' then
        Result := Result + '\';
end;

function FindStackupFile(var StackupFile, ErrorText : String) : Boolean;
var
    SearchRec   : TSearchRec;
    SearchResult: Integer;
    SearchOpen  : Boolean;
    StackupCount: Integer;
    FolderName  : String;
begin
    Result := False;
    StackupFile := '';
    ErrorText := '';
    SearchOpen := False;
    StackupCount := 0;

    FolderName := FolderWithTrailingSlash(STACKUP_FOLDER);
    if not DirectoryExists(FolderName) then
    begin
        ErrorText := 'Stackup folder not found:' + #13#10 + FolderName;
        Exit;
    end;

    StackupFile := FolderName + STACKUP_FILE_NAME;
    if FileExists(StackupFile) then
    begin
        Result := True;
        Exit;
    end;

    StackupFile := '';

    SearchResult := FindFirst(FolderName + '*.stackup', faAnyFile, SearchRec);
    try
        SearchOpen := SearchResult = 0;
        while SearchResult = 0 do
        begin
            if (SearchRec.Attr and faDirectory) = 0 then
            begin
                Inc(StackupCount);
                if StackupCount = 1 then
                    StackupFile := FolderName + SearchRec.Name;
            end;

            SearchResult := FindNext(SearchRec);
        end;
    finally
        if SearchOpen then
            FindClose(SearchRec);
    end;

    if StackupCount = 0 then
    begin
        ErrorText := 'No .stackup file was found in:' + #13#10 +
                     FolderName + #13#10 + #13#10 +
                     'The script also checked for:' + #13#10 +
                     FolderName + STACKUP_FILE_NAME;
        Exit;
    end;

    if StackupCount > 1 then
    begin
        ErrorText := 'Found ' + IntToStr(StackupCount) + ' .stackup files in:' + #13#10 +
                     FolderName + #13#10 + #13#10 +
                     'Leave exactly one .stackup file in this folder, then run the script again.';
        StackupFile := '';
        Exit;
    end;

    Result := True;
end;

procedure ImportMechanicalLayersFromStackup;
var
    Board       : IPCB_Board;
    StackupFile : String;
    ErrorText   : String;
begin
    Board := PCBServer.GetCurrentPCBBoard;
    if Board = Nil then
    begin
        ShowMessage('Open and focus the target PCB document, then run Import Mech Layers again.');
        Exit;
    end;

    if not FindStackupFile(StackupFile, ErrorText) then
    begin
        ShowMessage(ErrorText);
        Exit;
    end;

    if not FileExists(StackupFile) then
    begin
        ShowMessage('The stackup file no longer exists:' + #13#10 + StackupFile);
        Exit;
    end;

    if not IsStackupFile(StackupFile) then
    begin
        ShowMessage('The file found in the script folder is not an Altium .stackup file:' + #13#10 + StackupFile);
        Exit;
    end;

    ResetParameters;
    AddStringParameter('FileName', StackupFile);
    RunProcess('PCB:ImportMechLayers');

    ShowMessage('Mechanical layer import command completed for:' + #13#10 + StackupFile);
end;
