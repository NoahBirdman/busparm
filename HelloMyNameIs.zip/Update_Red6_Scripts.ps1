$ErrorActionPreference = 'Stop'

$scriptRoot = Split-Path -Parent $PSCommandPath
$logRoot = Join-Path $scriptRoot 'logs'
if (-not (Test-Path -LiteralPath $logRoot)) {
    New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
}
$logPath = Join-Path $logRoot ("Red6_Update_{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))

function Write-Step {
    param([string]$Message)
    Write-Host ''
    Write-Host "== $Message"
}

function Wait-ForAltiumToClose {
    $names = @('X2', 'AltiumDesigner', 'DXP')

    while ($true) {
        $running = Get-Process -Name $names -ErrorAction SilentlyContinue
        if (-not $running) {
            return
        }

        Write-Host 'Altium Designer is still running. Close Altium to continue the Red 6 scripts update.'
        Start-Sleep -Seconds 5
    }
}

try {
    Start-Transcript -Path $logPath -Force | Out-Null

    Write-Step 'Red 6 scripts updater'
    Write-Host "Script folder: $scriptRoot"
    Write-Host "Log file:      $logPath"

    Write-Step 'Waiting for Altium Designer to close'
    Wait-ForAltiumToClose

    Write-Step 'Checking local repository state'
    $status = git -C $scriptRoot status --porcelain
    if ($LASTEXITCODE -ne 0) {
        throw 'git status failed. Confirm Git is installed and this folder is a Git repository.'
    }

    if ($status) {
        Write-Host 'Local changes are present. The updater will not pull over uncommitted work.'
        Write-Host ''
        Write-Host $status
        throw 'Commit, stash, or discard local changes, then run the updater again.'
    }

    Write-Step 'Pulling latest scripts'
    git -C $scriptRoot pull --ff-only
    if ($LASTEXITCODE -ne 0) {
        throw 'git pull --ff-only failed.'
    }

    Write-Step 'Running Red 6 menu installer'
    $installer = Join-Path $scriptRoot 'Install_Red6_Menu_NoAdmin.ps1'
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer
    if ($LASTEXITCODE -ne 0) {
        throw 'Menu installer failed.'
    }

    Write-Step 'Complete'
    Write-Host 'Red 6 scripts were updated and the menu installer was run.'
}
catch {
    Write-Host ''
    Write-Host 'Update failed:'
    Write-Host $_.Exception.Message
    Write-Host ''
    Write-Host "Log file: $logPath"
}
finally {
    try {
        Stop-Transcript | Out-Null
    }
    catch {
    }

    Write-Host ''
    Read-Host 'Press Enter to close this updater window'
}
