# Red 6 Altium Scripts Agent Guide

This repository contains Red 6 internal Altium Designer script projects. Work in
`C:\Users\Public\Documents\Altium\altiumscripts` and inspect the nearest existing
script before editing. Use `rg` for search and `apply_patch` for manual edits.

## Project Shape

Each script should live in its own folder with these files:

- `<ScriptName>\<ScriptName>.PrjScr`
- `<ScriptName>\<SCRIPT_FILE>.pas`
- `<ScriptName>\README.md`

Use the existing folders as examples:

- `SixDegreesOfVariation`: mature dark form and modal-result UI patterns.
- `NextRev`: Messages panel filtering, cross-probing, copyable debug output, and
  compact dark form layout.
- `Import Mech Layers`: focused Altium automation script.
- `ICEBERG`: external command launch and workbook/export workflow patterns.
- `AboutInfo`: README viewer and updater launcher.

## Creating A New Script

1. Create a new sibling folder for the script.
2. Add a `.PrjScr` file that includes the `.pas` file and points to the public
   run procedure.
3. Add the DelphiScript `.pas` file with a single clear run procedure, for
   example `RunToolName` or `ShowToolName`.
4. Add a `README.md` that explains what the script does, how to run it, and any
   required Altium state.
5. Prefer existing Red 6 UI conventions:
   - Dark, compact forms.
   - Copyable `TMemo` output for diagnostics.
   - Modal-result buttons for actions.
   - Avoid direct `OnClick := ...` assignment; Altium DelphiScript has rejected
     direct event assignment in this workspace.
6. Prefer built-in Altium commands and process launch patterns when they already
   exist in the repo.

## Adding To The Installer

Update `Install_Red6_Menu_NoAdmin.ps1`.

Add a new object to `$menuItems`:

```powershell
[PSCustomObject]@{
    Id = 'ToolName'
    Caption = '&Tool Name'
    ProjectPath = Join-Path $scriptRoot 'ToolName\ToolName.PrjScr'
    ProcName = 'TOOL_NAME.pas>RunToolName'
    Description = 'Short menu description'
}
```

Use `&` in `Caption` to define the menu accelerator key. Current accelerators:

- Top menu: `Red &6` with `Popup='6'`
- `Six Degrees of &Variation`: `V`
- `Import &Mech Layers`: `M`
- `&ICEBERG`: `I`
- `&NextRev`: `N`
- `&About Info`: `A`

Pick a unique accelerator for new entries. The installer generates Red 6 menu
entries for each Altium menu context, so do not hand-edit generated DXP.RCS
blocks. After installer changes, Altium must be closed before running
`Install_Red6_Menu_NoAdmin.cmd` or `Install_Red6_Menu_NoAdmin.ps1`.

## Adding To About Info

Update `AboutInfo\ABOUT_INFO.pas` and `AboutInfo\README.md`.

In `ABOUT_INFO.pas`:

1. Add the script README path in `ReadmePathForIndex`.
2. Add the display title in `ReadmeTitleForIndex`.
3. Add a script button in `ShowAboutInfoForm`.
4. Set the button `ModalResult` to
   `ABOUT_SCRIPT_RESULT_BASE + <new index>`.
5. Update the selected-index bounds:
   - `(SelectedIndex < 0) or (SelectedIndex > <max index>)`
   - `FormResult <= ABOUT_SCRIPT_RESULT_BASE + <max index>`
   - `FormResult > ABOUT_SCRIPT_RESULT_BASE + <max index>`

The About Info form intentionally uses buttons for script selection instead of a
list plus View button.

## Validation

PowerShell syntax can be checked locally:

```powershell
[scriptblock]::Create((Get-Content -Raw -LiteralPath 'Install_Red6_Menu_NoAdmin.ps1')) | Out-Null
```

Run the same check for any changed `.ps1` file. DelphiScript cannot usually be
compiled from this environment, so report that final runtime validation must
happen inside Altium Designer.

When a script edits project-file net color information such as the `[NetInfos]`
section, prefer the stable Altium workflow proven in `HelloMyNameIs`: save the
touched schematic sheets, close those sheets before editing the project file,
patch the project file, then reopen the touched sheets. Warn users to commit or
otherwise save all pending project changes before running this kind of update.

## Altium Document Access

Always work through Altium APIs and normal Altium document rules when possible.
Before changing a search or analysis workflow to iterate through documents by
opening every schematic sheet, explicitly ask the user first. Before parsing raw
Altium project or schematic files directly as a fallback, explicitly ask the user
first. When Altium does not expose a document through the script APIs, report the
limitation clearly, explain the likely Altium state issue, and troubleshoot that
state before proposing broader fallback behavior.

For faster project schematic iteration without opening sheets, prefer the
`HelloMyNameIs` pattern: use `SchServer.GetSchDocumentByPath` on the project
schematic paths and iterate returned `ISch_Document` objects directly. If some
project sheets return `Nil` after the user explicitly closed sheets, first try
hydrating Altium's schematic-server document cache through normal Altium UI
paths that can enumerate all project schematic documents. Two proven candidates
are opening/toggling the SCH List panel with `Client:CustomizeResources`
parameters such as `Action=Show`, `ObjectKind=Panel`, `ID=List` (or the
documented Shift+F12 toggle with `Action=Toggle`). The SCH List document
selection must be set to `All Project Documents` for this to hydrate closed
project sheets. Another candidate is running a normal SCH Filter operation in
project/whole-project scope, such as `Sch:FilterSelect` with an `Expr` like
`IsNetLabel And (Text = '<known net label>')`. These can make closed project
sheets available to `SchServer` again without script-opening every schematic
document. For user-facing tools, the preferred workflow is to run the normal
scan first, open/show SCH List only if sheets are skipped, show a
`Compiling Schematic Documents...` / `Rescanning...` status, rerun the scan, and
then tell the user to set SCH List to `All Project Documents` if sheets still
skip. Report any still-skipped sheet names in the tool output.

## Repo Hygiene

- Do not revert unrelated local changes.
- Keep generated logs under `logs\`; files there are ignored by git.
- Avoid broad refactors when adding a script entry.
- If a script launches external tools, follow the existing `ICEBERG` or
  `AboutInfo` launch patterns.
- If menus changed, rerun the installer with Altium closed.
