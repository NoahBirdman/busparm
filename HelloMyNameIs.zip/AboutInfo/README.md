# About Info

Red 6 Altium script information and update launcher.

## What It Does

- Displays README files for the shared Altium scripts using script-specific buttons.
- Provides a single place to review installed script behavior.
- Includes the Hello My Name Is net/port/sheet-entry rename helper.
- Includes the Picasso parsed net color viewer.
- Launches the external Red 6 scripts updater.

## Update Flow

The `Update` button starts a separate PowerShell updater. After the updater starts:

1. Close Altium Designer.
2. The updater waits until Altium is fully closed.
3. The updater checks for local repository changes.
4. If the working tree is clean, it runs `git pull --ff-only`.
5. It runs the Red 6 menu installer.

The updater will not pull over uncommitted local changes.

Run procedure:

```text
ABOUT_INFO.pas>ShowAboutInfo
```
