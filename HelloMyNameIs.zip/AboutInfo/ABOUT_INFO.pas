{ Altium Designer DelphiScript
  Displays Red 6 script README files and launches the external updater.

  Run procedure: ShowAboutInfo
}

uses
    SysUtils,
    Classes,
    Dialogs,
    Forms,
    Controls,
    StdCtrls;

const
    ABOUT_SCRIPT_ROOT = 'C:\Users\Public\Documents\Altium\altiumscripts';
    UI_DARK_BACKGROUND = $00302D2B;
    UI_DARK_CONTROL = $002A2725;
    UI_DARK_FIELD = $001E1E1E;
    UI_DARK_TEXT = $00E3DDD7;
    UI_DARK_MUTED_TEXT = $00BFB6AE;
    ABOUT_UPDATE_RESULT = 101;
    ABOUT_SCRIPT_RESULT_BASE = 200;

procedure ApplyDarkFormStyle(AForm : TForm);
begin
    AForm.Color := UI_DARK_BACKGROUND;
    AForm.Font.Name := 'Segoe UI';
    AForm.Font.Size := 9;
    AForm.Font.Color := UI_DARK_TEXT;
end;

procedure ApplyDarkLabelStyle(ALabel : TLabel);
begin
    ALabel.Transparent := True;
    ALabel.Font.Color := UI_DARK_MUTED_TEXT;
end;

procedure ApplyDarkMemoStyle(AMemo : TMemo);
begin
    AMemo.Color := UI_DARK_FIELD;
    AMemo.Font.Color := UI_DARK_TEXT;
    AMemo.ReadOnly := True;
    AMemo.WordWrap := False;
    AMemo.ScrollBars := ssBoth;
    AMemo.Ctl3D := False;
end;

procedure ApplyDarkButtonStyle(AButton : TButton);
begin
    AButton.Font.Color := UI_DARK_TEXT;
end;

function ReadTextFileOrMissing(Path : String) : String;
var
    Lines : TStringList;
begin
    if not FileExists(Path) then
    begin
        Result := 'README file not found:' + #13#10 + Path;
        Exit;
    end;

    Lines := TStringList.Create;
    try
        Lines.LoadFromFile(Path);
        Result := Lines.Text;
    finally
        Lines.Free;
    end;
end;

function ReadmePathForIndex(Index : Integer) : String;
begin
    case Index of
        0: Result := ABOUT_SCRIPT_ROOT + '\README.md';
        1: Result := ABOUT_SCRIPT_ROOT + '\SixDegreesOfVariation\README.md';
        2: Result := ABOUT_SCRIPT_ROOT + '\Import Mech Layers\README.md';
        3: Result := ABOUT_SCRIPT_ROOT + '\ICEBERG\README.md';
        4: Result := ABOUT_SCRIPT_ROOT + '\NextRev\README.md';
        5: Result := ABOUT_SCRIPT_ROOT + '\AboutInfo\README.md';
        6: Result := ABOUT_SCRIPT_ROOT + '\HelloMyNameIs\README.md';
        7: Result := ABOUT_SCRIPT_ROOT + '\Picasso\README.md';
    else
        Result := ABOUT_SCRIPT_ROOT + '\README.md';
    end;
end;

function ReadmeTitleForIndex(Index : Integer) : String;
begin
    case Index of
        0: Result := 'Altium Internal Scripts';
        1: Result := 'Six Degrees of Variation';
        2: Result := 'Import Mech Layers';
        3: Result := 'ICEBERG';
        4: Result := 'NextRev';
        5: Result := 'About Info';
        6: Result := 'Hello My Name Is';
        7: Result := 'Picasso';
    else
        Result := 'Altium Internal Scripts';
    end;
end;

function ReadmeDisplayText(Index : Integer) : String;
var
    Path : String;
begin
    Path := ReadmePathForIndex(Index);
    Result := ReadmeTitleForIndex(Index) + #13#10 +
              '==============================' + #13#10 + #13#10 +
              'Path: ' + Path + #13#10 + #13#10 +
              ReadTextFileOrMissing(Path);
end;

function ConfirmUpdate : Boolean;
var
    ConfirmForm : TForm;
    ConfirmMemo : TMemo;
    OkButton    : TButton;
    CancelButton: TButton;
begin
    Result := False;

    ConfirmForm := TForm.Create(nil);
    try
        ConfirmForm.Caption := 'Update Red 6 Scripts';
        ConfirmForm.Position := poScreenCenter;
        ConfirmForm.BorderStyle := bsDialog;
        ConfirmForm.Width := 560;
        ConfirmForm.Height := 260;
        ApplyDarkFormStyle(ConfirmForm);

        ConfirmMemo := TMemo.Create(ConfirmForm);
        ConfirmMemo.Parent := ConfirmForm;
        ConfirmMemo.Left := 16;
        ConfirmMemo.Top := 16;
        ConfirmMemo.Width := 520;
        ConfirmMemo.Height := 140;
        ConfirmMemo.Text := 'This will launch the Red 6 scripts updater.' + #13#10 + #13#10 +
                            'After clicking OK, close Altium Designer. The updater will wait for Altium to close, pull the latest repository changes, and run the Red 6 menu installer.' + #13#10 + #13#10 +
                            'The updater will stop if local uncommitted changes are present.';
        ApplyDarkMemoStyle(ConfirmMemo);

        OkButton := TButton.Create(ConfirmForm);
        OkButton.Parent := ConfirmForm;
        OkButton.Left := 296;
        OkButton.Top := 174;
        OkButton.Width := 100;
        OkButton.Height := 28;
        OkButton.Caption := 'OK';
        OkButton.ModalResult := mrOK;
        ApplyDarkButtonStyle(OkButton);

        CancelButton := TButton.Create(ConfirmForm);
        CancelButton.Parent := ConfirmForm;
        CancelButton.Left := 408;
        CancelButton.Top := 174;
        CancelButton.Width := 100;
        CancelButton.Height := 28;
        CancelButton.Caption := 'Cancel';
        CancelButton.ModalResult := mrCancel;
        ApplyDarkButtonStyle(CancelButton);

        Result := ConfirmForm.ShowModal = mrOK;
    finally
        ConfirmForm.Free;
    end;
end;

function WriteUpdateCommand(CommandPath : String) : Boolean;
var
    Lines      : TStringList;
    UpdaterPath: String;
begin
    Result := False;
    UpdaterPath := ABOUT_SCRIPT_ROOT + '\Update_Red6_Scripts.ps1';

    if not FileExists(UpdaterPath) then
    begin
        ShowMessage('Red 6 updater not found:' + #13#10 + UpdaterPath);
        Exit;
    end;

    Lines := TStringList.Create;
    try
        Lines.Add('@echo off');
        Lines.Add('start "Red 6 Scripts Updater" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' + UpdaterPath + '"');
        Lines.Add('del /q "%~f0"');
        Lines.SaveToFile(CommandPath);
        Result := True;
    finally
        Lines.Free;
    end;
end;

procedure StartUpdater;
var
    CommandPath : String;
begin
    CommandPath := ABOUT_SCRIPT_ROOT + '\AboutInfo\ABOUT_INFO_UPDATE.cmd';
    if WriteUpdateCommand(CommandPath) then
        RunApplication(CommandPath);
end;

function ShowAboutInfoForm(var SelectedIndex : Integer) : Integer;
var
    AboutForm   : TForm;
    ListLabel   : TLabel;
    ReadmeLabel : TLabel;
    ReadmeMemo  : TMemo;
    RootButton  : TButton;
    VariationButton : TButton;
    MechButton  : TButton;
    IcebergButton : TButton;
    NextRevButton : TButton;
    AboutButton : TButton;
    HelloButton : TButton;
    PicassoButton : TButton;
    UpdateButton: TButton;
    CloseButton : TButton;
begin
    Result := mrCancel;

    AboutForm := TForm.Create(nil);
    try
        AboutForm.Caption := 'Red 6 About Info';
        AboutForm.Position := poScreenCenter;
        AboutForm.BorderStyle := bsDialog;
        AboutForm.Width := 900;
        AboutForm.Height := 620;
        ApplyDarkFormStyle(AboutForm);

        ListLabel := TLabel.Create(AboutForm);
        ListLabel.Parent := AboutForm;
        ListLabel.Left := 16;
        ListLabel.Top := 14;
        ListLabel.Width := 120;
        ListLabel.Caption := 'Scripts';
        ApplyDarkLabelStyle(ListLabel);

        if (SelectedIndex < 0) or (SelectedIndex > 7) then
            SelectedIndex := 0;

        RootButton := TButton.Create(AboutForm);
        RootButton.Parent := AboutForm;
        RootButton.Left := 16;
        RootButton.Top := 34;
        RootButton.Width := 220;
        RootButton.Height := 30;
        RootButton.Caption := 'Altium Internal Scripts';
        RootButton.ModalResult := ABOUT_SCRIPT_RESULT_BASE + 0;
        ApplyDarkButtonStyle(RootButton);

        VariationButton := TButton.Create(AboutForm);
        VariationButton.Parent := AboutForm;
        VariationButton.Left := 16;
        VariationButton.Top := 72;
        VariationButton.Width := 220;
        VariationButton.Height := 30;
        VariationButton.Caption := 'Six Degrees of Variation';
        VariationButton.ModalResult := ABOUT_SCRIPT_RESULT_BASE + 1;
        ApplyDarkButtonStyle(VariationButton);

        MechButton := TButton.Create(AboutForm);
        MechButton.Parent := AboutForm;
        MechButton.Left := 16;
        MechButton.Top := 110;
        MechButton.Width := 220;
        MechButton.Height := 30;
        MechButton.Caption := 'Import Mech Layers';
        MechButton.ModalResult := ABOUT_SCRIPT_RESULT_BASE + 2;
        ApplyDarkButtonStyle(MechButton);

        IcebergButton := TButton.Create(AboutForm);
        IcebergButton.Parent := AboutForm;
        IcebergButton.Left := 16;
        IcebergButton.Top := 148;
        IcebergButton.Width := 220;
        IcebergButton.Height := 30;
        IcebergButton.Caption := 'ICEBERG';
        IcebergButton.ModalResult := ABOUT_SCRIPT_RESULT_BASE + 3;
        ApplyDarkButtonStyle(IcebergButton);

        NextRevButton := TButton.Create(AboutForm);
        NextRevButton.Parent := AboutForm;
        NextRevButton.Left := 16;
        NextRevButton.Top := 186;
        NextRevButton.Width := 220;
        NextRevButton.Height := 30;
        NextRevButton.Caption := 'NextRev';
        NextRevButton.ModalResult := ABOUT_SCRIPT_RESULT_BASE + 4;
        ApplyDarkButtonStyle(NextRevButton);

        AboutButton := TButton.Create(AboutForm);
        AboutButton.Parent := AboutForm;
        AboutButton.Left := 16;
        AboutButton.Top := 224;
        AboutButton.Width := 220;
        AboutButton.Height := 30;
        AboutButton.Caption := 'About Info';
        AboutButton.ModalResult := ABOUT_SCRIPT_RESULT_BASE + 5;
        ApplyDarkButtonStyle(AboutButton);

        HelloButton := TButton.Create(AboutForm);
        HelloButton.Parent := AboutForm;
        HelloButton.Left := 16;
        HelloButton.Top := 262;
        HelloButton.Width := 220;
        HelloButton.Height := 30;
        HelloButton.Caption := 'Hello My Name Is';
        HelloButton.ModalResult := ABOUT_SCRIPT_RESULT_BASE + 6;
        ApplyDarkButtonStyle(HelloButton);

        PicassoButton := TButton.Create(AboutForm);
        PicassoButton.Parent := AboutForm;
        PicassoButton.Left := 16;
        PicassoButton.Top := 300;
        PicassoButton.Width := 220;
        PicassoButton.Height := 30;
        PicassoButton.Caption := 'Picasso';
        PicassoButton.ModalResult := ABOUT_SCRIPT_RESULT_BASE + 7;
        ApplyDarkButtonStyle(PicassoButton);

        ReadmeLabel := TLabel.Create(AboutForm);
        ReadmeLabel.Parent := AboutForm;
        ReadmeLabel.Left := 252;
        ReadmeLabel.Top := 14;
        ReadmeLabel.Width := 160;
        ReadmeLabel.Caption := 'README';
        ApplyDarkLabelStyle(ReadmeLabel);

        ReadmeMemo := TMemo.Create(AboutForm);
        ReadmeMemo.Parent := AboutForm;
        ReadmeMemo.Left := 252;
        ReadmeMemo.Top := 34;
        ReadmeMemo.Width := 610;
        ReadmeMemo.Height := 480;
        ReadmeMemo.Text := ReadmeDisplayText(SelectedIndex);
        ApplyDarkMemoStyle(ReadmeMemo);

        UpdateButton := TButton.Create(AboutForm);
        UpdateButton.Parent := AboutForm;
        UpdateButton.Left := 604;
        UpdateButton.Top := 532;
        UpdateButton.Width := 120;
        UpdateButton.Height := 28;
        UpdateButton.Caption := 'Update';
        UpdateButton.ModalResult := ABOUT_UPDATE_RESULT;
        ApplyDarkButtonStyle(UpdateButton);

        CloseButton := TButton.Create(AboutForm);
        CloseButton.Parent := AboutForm;
        CloseButton.Left := 732;
        CloseButton.Top := 532;
        CloseButton.Width := 120;
        CloseButton.Height := 28;
        CloseButton.Caption := 'Close';
        CloseButton.ModalResult := mrCancel;
        ApplyDarkButtonStyle(CloseButton);

        AboutForm.ActiveControl := RootButton;
        Result := AboutForm.ShowModal;
    finally
        AboutForm.Free;
    end;
end;

procedure ShowAboutInfo;
var
    SelectedIndex : Integer;
    FormResult    : Integer;
begin
    SelectedIndex := 0;

    repeat
        FormResult := ShowAboutInfoForm(SelectedIndex);

        if FormResult = ABOUT_UPDATE_RESULT then
        begin
            if ConfirmUpdate then
            begin
                StartUpdater;
                Exit;
            end;
        end;

        if (FormResult >= ABOUT_SCRIPT_RESULT_BASE) and (FormResult <= ABOUT_SCRIPT_RESULT_BASE + 7) then
            SelectedIndex := FormResult - ABOUT_SCRIPT_RESULT_BASE;
    until (FormResult <> ABOUT_UPDATE_RESULT) and
          ((FormResult < ABOUT_SCRIPT_RESULT_BASE) or (FormResult > ABOUT_SCRIPT_RESULT_BASE + 7));
end;
