{ Altium Designer DelphiScript
  Color test helpers for Hello My Name Is.
}

uses
    SysUtils,
    Classes,
    Dialogs,
    Controls,
    Forms;

const
    HMNI_COLOR_TEST_NET_PREFIX = 'HMNI_COLOR_TEST_';
    HMNI_BLUE_NET_COLOR_INDEX = 1;
    HMNI_RED_NET_COLOR_INDEX = 4;
    HMNI_YELLOW_NET_COLOR_INDEX = 6;
    HMNI_COLOR_TEST_LABEL_SPACING_MILS = 100;
    HMNI_DELAYED_PICK_SCRIPT_PATH = 'C:\Users\Public\Documents\Altium\altiumscripts\HelloMyNameIs\HMNI_DELAYED_PICK.vbs';

function HmniColorStartsWithText(Value, Prefix : String) : Boolean;
begin
    Result := UpperCase(Copy(Value, 1, Length(Prefix))) = UpperCase(Prefix);
end;

procedure HmniColorFocusSelectedSchematicObject;
begin
    ResetParameters;
    AddStringParameter('Source', 'Custom');
    AddStringParameter('Expr', 'IsSelected');
    AddStringParameter('Select', 'True');
    AddStringParameter('Mask', 'True');
    AddStringParameter('Zoom', 'True');
    RunProcess('Sch:FilterSelect');
    ResetParameters;

    ResetParameters;
    AddStringParameter('Object', 'Selected');
    RunProcess('Sch:Zoom');
    ResetParameters;
end;

procedure HmniColorRunNetColorCommand(ColorParamName, ColorParamValue : String);
begin
    ResetParameters;
    if ColorParamName <> '' then
        AddStringParameter(ColorParamName, ColorParamValue);
    RunProcess('Sch:NetColors');
    ResetParameters;
end;

procedure HmniColorStartDelayedPickKey;
begin
    RunApplication('wscript.exe "' + HMNI_DELAYED_PICK_SCRIPT_PATH + '"');
end;

procedure HmniColorJumpCursorToLabel(LabelXMils, LabelYMils : Integer);
begin
    ResetParameters;
    AddStringParameter('Object', 'Location');
    AddStringParameter('Location.X', IntToStr(MilsToCoord(LabelXMils)));
    AddStringParameter('Location.Y', IntToStr(MilsToCoord(LabelYMils)));
    RunProcess('Sch:Jump');
    ResetParameters;
end;

procedure HmniColorSetWindowsCursorToScreenCenter;
var
    CursorX : Integer;
    CursorY : Integer;
begin
    CursorX := Screen.Width div 2;
    CursorY := Screen.Height div 2;
    Mouse.CursorPos := Point(CursorX, CursorY);
end;

function HmniColorExistingTestNetCount(SchDoc : ISch_Document) : Integer;
var
    Iterator : ISch_Iterator;
    LabelObj : ISch_Label;
begin
    Result := 0;
    if SchDoc = Nil then
        Exit;

    Iterator := SchDoc.SchIterator_Create;
    if Iterator = Nil then
        Exit;

    try
        Iterator.AddFilter_ObjectSet(MkSet(eNetLabel));
        LabelObj := Iterator.FirstSchObject;
        while LabelObj <> Nil do
        begin
            if HmniColorStartsWithText(LabelObj.Text, HMNI_COLOR_TEST_NET_PREFIX) then
                Inc(Result);
            LabelObj := Iterator.NextSchObject;
        end;
    finally
        SchDoc.SchIterator_Destroy(Iterator);
    end;
end;

procedure HmniColorClearNetLabelSelections(SchDoc : ISch_Document);
var
    Iterator : ISch_Iterator;
    LabelObj : ISch_Label;
begin
    if SchDoc = Nil then
        Exit;

    Iterator := SchDoc.SchIterator_Create;
    if Iterator = Nil then
        Exit;

    try
        Iterator.AddFilter_ObjectSet(MkSet(eNetLabel));
        LabelObj := Iterator.FirstSchObject;
        while LabelObj <> Nil do
        begin
            LabelObj.Selection := False;
            LabelObj := Iterator.NextSchObject;
        end;
    finally
        SchDoc.SchIterator_Destroy(Iterator);
    end;
end;

function HmniColorCreateTestNet(SchDoc : ISch_Document; TestIndex : Integer; var TestNetName : String; var LabelXMils, LabelYMils : Integer; var ErrorText : String) : Boolean;
var
    WireObj     : Variant;
    LabelObj    : ISch_Label;
    BaseX       : Integer;
    BaseY       : Integer;
    OffsetY     : Integer;
begin
    Result := False;
    TestNetName := HMNI_COLOR_TEST_NET_PREFIX + IntToStr(TestIndex);
    LabelXMils := 1100;
    LabelYMils := 1000 + ((TestIndex - 1) * HMNI_COLOR_TEST_LABEL_SPACING_MILS);
    BaseX := MilsToCoord(1000);
    BaseY := MilsToCoord(1000);
    OffsetY := MilsToCoord((TestIndex - 1) * HMNI_COLOR_TEST_LABEL_SPACING_MILS);

    HmniColorClearNetLabelSelections(SchDoc);

    SchServer.ProcessControl.PreProcess(SchDoc, '');
    try
        WireObj := SchServer.SchObjectFactory(eWire, eCreate_GlobalCopy);
        if WireObj = Nil then
        begin
            ErrorText := 'Could not create a schematic wire object.';
            Exit;
        end;

        WireObj.Location := Point(BaseX, BaseY + OffsetY);
        WireObj.InsertVertex := 1;
        WireObj.SetState_Vertex(1, Point(BaseX, BaseY + OffsetY));
        WireObj.InsertVertex := 2;
        WireObj.SetState_Vertex(2, Point(BaseX + MilsToCoord(500), BaseY + OffsetY));
        WireObj.Selection := False;
        SchDoc.RegisterSchObjectInContainer(WireObj);
        SchServer.RobotManager.SendMessage(SchDoc.I_ObjectAddress, c_BroadCast, SCHM_PrimitiveRegistration, WireObj.I_ObjectAddress);

        LabelObj := SchServer.SchObjectFactory(eNetLabel, eCreate_GlobalCopy);
        if LabelObj = Nil then
        begin
            ErrorText := 'Could not create a schematic net label object.';
            Exit;
        end;

        LabelObj.Text := TestNetName;
        LabelObj.Location := Point(MilsToCoord(LabelXMils), MilsToCoord(LabelYMils));
        LabelObj.Orientation := eRotate0;
        LabelObj.Selection := True;
        SchDoc.RegisterSchObjectInContainer(LabelObj);
        SchServer.RobotManager.SendMessage(SchDoc.I_ObjectAddress, c_BroadCast, SCHM_PrimitiveRegistration, LabelObj.I_ObjectAddress);
    finally
        SchServer.ProcessControl.PostProcess(SchDoc, '');
    end;

    SchDoc.GraphicallyInvalidate;
    Result := True;
end;

procedure HmniColorApplyAtLabel(LabelXMils, LabelYMils : Integer; ColorParamName, ColorParamValue : String);
begin
    HmniColorFocusSelectedSchematicObject;
    HmniColorJumpCursorToLabel(LabelXMils, LabelYMils);
    HmniColorSetWindowsCursorToScreenCenter;
    HmniColorStartDelayedPickKey;
    HmniColorRunNetColorCommand(ColorParamName, ColorParamValue);
end;

function HelloMyNameIsRunBlueColorTest(var TestNetName : String; var ErrorText : String) : Boolean;
var
    SchDoc        : ISch_Document;
    StartIndex    : Integer;
    CurrentName   : String;
    LabelXMils    : Integer;
    LabelYMils    : Integer;
begin
    Result := False;
    TestNetName := '';
    ErrorText := '';

    if SchServer = Nil then
    begin
        ErrorText := 'Schematic server is not available.';
        Exit;
    end;

    SchDoc := SchServer.GetCurrentSchDocument;
    if SchDoc = Nil then
    begin
        ErrorText := 'Open a schematic sheet, then run the color test again.';
        Exit;
    end;

    StartIndex := HmniColorExistingTestNetCount(SchDoc) + 1;

    if not HmniColorCreateTestNet(SchDoc, StartIndex, CurrentName, LabelXMils, LabelYMils, ErrorText) then
        Exit;
    TestNetName := CurrentName;
    HmniColorApplyAtLabel(LabelXMils, LabelYMils, 'NetColorIndex', IntToStr(HMNI_BLUE_NET_COLOR_INDEX));

    if not HmniColorCreateTestNet(SchDoc, StartIndex + 1, CurrentName, LabelXMils, LabelYMils, ErrorText) then
        Exit;
    TestNetName := TestNetName + ', ' + CurrentName;
    HmniColorApplyAtLabel(LabelXMils, LabelYMils, 'NetColorIndex', IntToStr(HMNI_RED_NET_COLOR_INDEX));

    if not HmniColorCreateTestNet(SchDoc, StartIndex + 2, CurrentName, LabelXMils, LabelYMils, ErrorText) then
        Exit;
    TestNetName := TestNetName + ', ' + CurrentName;
    HmniColorApplyAtLabel(LabelXMils, LabelYMils, 'NetColorIndex', IntToStr(HMNI_YELLOW_NET_COLOR_INDEX));

    Result := True;
end;

procedure RunHelloMyNameIsColorTest;
var
    TestNetName : String;
    ErrorText   : String;
begin
    if not HelloMyNameIsRunBlueColorTest(TestNetName, ErrorText) then
        ShowMessage(ErrorText);
end;
