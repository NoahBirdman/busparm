# Hello My Name Is Testing

This folder holds temporary debugging and experiment scripts that are no longer
part of the production rename workflow.

## Archived Color Test

`HELLO_MY_NAME_IS_COLOR_TEST.pas` is the old color-command experiment. It can be
used as a reference for future debugging work, but it is intentionally not wired
into `HelloMyNameIs.PrjScr` or the main `HELLO_MY_NAME_IS.pas` rename tool.

Run it manually from Altium's scripting system only when deliberately testing
schematic color behavior.
