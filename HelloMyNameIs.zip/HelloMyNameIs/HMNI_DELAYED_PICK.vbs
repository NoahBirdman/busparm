WScript.Sleep 5

Set Shell = CreateObject("WScript.Shell")
Shell.SendKeys "{ENTER}"
WScript.Sleep 25
Shell.SendKeys "{ESC}"
