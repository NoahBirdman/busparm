{ Altium Designer DelphiScript
  Project-wide helper for renaming schematic net labels, ports, and sheet entries.

  Run procedure: RunHelloMyNameIs
}

uses
    SysUtils,
    Classes,
    Dialogs,
    Forms,
    Controls,
    StdCtrls,
    ComCtrls;

const
    UI_DARK_BACKGROUND = $00302D2B;
    UI_DARK_CONTROL = $002A2725;
    UI_DARK_FIELD = $001E1E1E;
    UI_DARK_TEXT = $00E3DDD7;
    UI_DARK_MUTED_TEXT = $00BFB6AE;
    UI_RED_TEXT = $000000FF;

    HMNI_FIND_NEXT_RESULT = 101;
    HMNI_REPLACE_RESULT = 102;
    HMNI_REPLACE_ALL_RESULT = 103;
    HMNI_FIND_PREFIXES_RESULT = 104;
    HMNI_DEBUG_TOGGLE_RESULT = 105;
    HMNI_MATCHES_NOT_SCANNED = -2;
    HMNI_FORM_COLLAPSED_HEIGHT = 360;
    HMNI_FORM_EXPANDED_HEIGHT = 560;
    HMNI_RENAME_FORM_WIDTH = 1270;
    HMNI_RENAME_FORM_HEIGHT = 740;
    HMNI_FIELD_HEIGHT = 22;
    HMNI_LABEL_HEIGHT = 24;
    HMNI_LABEL_FIELD_GAP = 14;
    HMNI_TOP_LABEL_EDIT_GAP = 30;
    HMNI_FORM_LEFT = 20;
    HMNI_PREFIX_LEFT = 20;
    HMNI_PREFIX_WIDTH = 320;
    HMNI_SIGNAL_LEFT = 368;
    HMNI_SIGNAL_WIDTH = 520;
    HMNI_SUFFIX_LEFT = 916;
    HMNI_SUFFIX_WIDTH = 100;
    HMNI_DIFF_PAIR_LEFT = 1044;
    HMNI_DIFF_PAIR_WIDTH = 90;
    HMNI_PREVIEW_WIDTH = 1210;
    HMNI_SCOPE_TOP = 196;
    HMNI_MATCH_COUNT_TOP = 254;
    HMNI_PREVIEW_TOP = 284;
    HMNI_PREVIEW_HEIGHT = 332;
    HMNI_SHEET_NAME_COLUMN_WIDTH = 22;
    HMNI_BUTTON_TOP = 630;
    HMNI_HINT_TOP = 680;

var
    HmniDebugExpanded : Boolean;
    HmniDebugLabel    : TLabel;
    HmniDebugMemo     : TMemo;
    HmniDebugButton   : TButton;
    HmniDebugForm     : TForm;

procedure ShowCopyableMessage(Title, MessageText : String);
var
    MessageForm : TForm;
    MessageMemo : TMemo;
    OkButton    : TButton;
begin
    MessageForm := TForm.Create(nil);
    try
        MessageForm.Caption := Title;
        MessageForm.Position := poScreenCenter;
        MessageForm.BorderStyle := bsDialog;
        MessageForm.Width := 720;
        MessageForm.Height := 420;

        MessageMemo := TMemo.Create(MessageForm);
        MessageMemo.Parent := MessageForm;
        MessageMemo.Left := 12;
        MessageMemo.Top := 12;
        MessageMemo.Width := MessageForm.ClientWidth - 24;
        MessageMemo.Height := MessageForm.ClientHeight - 56;
        MessageMemo.ReadOnly := True;
        MessageMemo.WordWrap := False;
        MessageMemo.ScrollBars := ssBoth;
        MessageMemo.Text := MessageText;

        OkButton := TButton.Create(MessageForm);
        OkButton.Parent := MessageForm;
        OkButton.Caption := 'OK';
        OkButton.Width := 88;
        OkButton.Height := 26;
        OkButton.Left := MessageForm.ClientWidth - OkButton.Width - 12;
        OkButton.Top := MessageForm.ClientHeight - OkButton.Height - 10;
        OkButton.ModalResult := mrOK;

        MessageForm.ActiveControl := MessageMemo;
        MessageMemo.SelectAll;
        MessageForm.ShowModal;
    finally
        MessageForm.Free;
    end;
end;

procedure ShowHmniMessage(MessageText : String);
begin
    ShowCopyableMessage('Hello My Name Is', MessageText);
end;

procedure ApplyDarkFormStyle(AForm : TForm);
begin
    AForm.Color := UI_DARK_BACKGROUND;
    AForm.Font.Name := 'Segoe UI';
    AForm.Font.Size := 9;
    AForm.Font.Color := UI_DARK_TEXT;
end;

procedure ApplyDarkLabelStyle(ALabel : TLabel);
begin
    ALabel.Transparent := True;
    ALabel.Font.Color := UI_DARK_MUTED_TEXT;
end;

procedure ApplyDarkEditStyle(AEdit : TEdit; ReadOnlyValue : Boolean);
begin
    AEdit.Color := UI_DARK_CONTROL;
    AEdit.Font.Color := UI_DARK_TEXT;
    AEdit.ReadOnly := ReadOnlyValue;
    AEdit.Ctl3D := False;
end;

procedure ApplyDarkMemoStyle(AMemo : TMemo);
begin
    AMemo.Color := UI_DARK_FIELD;
    AMemo.Font.Color := UI_DARK_TEXT;
    AMemo.ReadOnly := True;
    AMemo.WordWrap := False;
    AMemo.ScrollBars := ssBoth;
    AMemo.Ctl3D := False;
end;

procedure ApplyDarkReplacementRichEditStyle(ARichEdit : TRichEdit);
begin
    ARichEdit.Color := UI_DARK_FIELD;
    ARichEdit.Font.Name := 'Consolas';
    ARichEdit.Font.Color := UI_DARK_TEXT;
    ARichEdit.ReadOnly := False;
    ARichEdit.WordWrap := False;
    ARichEdit.ScrollBars := ssVertical;
    ARichEdit.Ctl3D := False;
    ARichEdit.HideSelection := False;
end;

procedure ApplyDarkButtonStyle(AButton : TButton);
begin
    AButton.Font.Color := UI_DARK_TEXT;
end;

function BoolText(Value : Boolean) : String;
begin
    if Value then
        Result := 'yes'
    else
        Result := 'no';
end;

procedure ApplyDarkCheckBoxStyle(ACheckBox : TCheckBox);
begin
    ACheckBox.Color := UI_DARK_BACKGROUND;
    ACheckBox.Font.Color := UI_DARK_MUTED_TEXT;
end;

procedure AddLabel(AOwner : TWinControl; CaptionText : String; LeftValue, TopValue, WidthValue : Integer);
var
    LabelRef : TLabel;
begin
    LabelRef := TLabel.Create(AOwner);
    LabelRef.Parent := AOwner;
    LabelRef.Left := LeftValue;
    LabelRef.Top := TopValue;
    LabelRef.Width := WidthValue;
    LabelRef.Height := HMNI_LABEL_HEIGHT;
    LabelRef.AutoSize := False;
    LabelRef.Caption := CaptionText;
    ApplyDarkLabelStyle(LabelRef);
end;

procedure AddReadOnlyFieldAt(AOwner : TWinControl; CaptionText, ValueText : String; LeftValue, TopValue, LabelWidthValue, EditWidthValue : Integer; var EditRef : TEdit);
begin
    AddLabel(AOwner, CaptionText, LeftValue, TopValue + 4, LabelWidthValue);

    EditRef := TEdit.Create(AOwner);
    EditRef.Parent := AOwner;
    EditRef.Left := LeftValue + LabelWidthValue + HMNI_LABEL_FIELD_GAP;
    EditRef.Top := TopValue;
    EditRef.Width := EditWidthValue;
    EditRef.Height := HMNI_FIELD_HEIGHT;
    EditRef.Text := ValueText;
    ApplyDarkEditStyle(EditRef, True);
end;

procedure AddEditFieldAt(AOwner : TWinControl; CaptionText, ValueText : String; LeftValue, TopValue, LabelWidthValue, EditWidthValue : Integer; var EditRef : TEdit);
begin
    AddLabel(AOwner, CaptionText, LeftValue, TopValue + 4, LabelWidthValue);

    EditRef := TEdit.Create(AOwner);
    EditRef.Parent := AOwner;
    EditRef.Left := LeftValue + LabelWidthValue + HMNI_LABEL_FIELD_GAP;
    EditRef.Top := TopValue;
    EditRef.Width := EditWidthValue;
    EditRef.Height := HMNI_FIELD_HEIGHT;
    EditRef.Text := ValueText;
    ApplyDarkEditStyle(EditRef, False);
end;

procedure AddScopeCheckBoxAt(AOwner : TWinControl; CaptionText : String; LeftValue, TopValue, WidthValue : Integer; IsChecked : Boolean; var CheckRef : TCheckBox);
var
    LabelRef : TLabel;
begin
    CheckRef := TCheckBox.Create(AOwner);
    CheckRef.Parent := AOwner;
    CheckRef.Left := LeftValue;
    CheckRef.Top := TopValue;
    CheckRef.Width := 18;
    CheckRef.Height := 22;
    CheckRef.Caption := '';
    CheckRef.Checked := IsChecked;
    ApplyDarkCheckBoxStyle(CheckRef);

    LabelRef := TLabel.Create(AOwner);
    LabelRef.Parent := AOwner;
    LabelRef.Left := LeftValue + 24;
    LabelRef.Top := TopValue + 3;
    LabelRef.Width := WidthValue - 24;
    LabelRef.Height := HMNI_LABEL_HEIGHT;
    LabelRef.AutoSize := False;
    LabelRef.Caption := CaptionText;
    ApplyDarkLabelStyle(LabelRef);
end;

procedure AddTopLabelEditAt(AOwner : TWinControl; CaptionText, ValueText : String; LeftValue, TopValue, EditWidthValue : Integer; var EditRef : TEdit);
begin
    AddLabel(AOwner, CaptionText, LeftValue, TopValue, EditWidthValue);

    EditRef := TEdit.Create(AOwner);
    EditRef.Parent := AOwner;
    EditRef.Left := LeftValue;
    EditRef.Top := TopValue + HMNI_TOP_LABEL_EDIT_GAP;
    EditRef.Width := EditWidthValue;
    EditRef.Height := HMNI_FIELD_HEIGHT;
    EditRef.Text := ValueText;
    ApplyDarkEditStyle(EditRef, False);
end;

procedure ApplyHmniDebugVisibility;
begin
    if HmniDebugForm = Nil then
        Exit;

    if HmniDebugLabel <> Nil then
        HmniDebugLabel.Visible := HmniDebugExpanded;

    if HmniDebugMemo <> Nil then
    begin
        HmniDebugMemo.Visible := HmniDebugExpanded;
        if HmniDebugExpanded then
            HmniDebugMemo.SelectAll;
    end;

    if HmniDebugButton <> Nil then
    begin
        if HmniDebugExpanded then
            HmniDebugButton.Caption := 'Hide Debug'
        else
            HmniDebugButton.Caption := 'Show Debug';
    end;

    if HmniDebugExpanded then
        HmniDebugForm.Height := HMNI_FORM_EXPANDED_HEIGHT
    else
        HmniDebugForm.Height := HMNI_FORM_COLLAPSED_HEIGHT;
end;

function SameTextLocal(A, B : String) : Boolean;
begin
    Result := UpperCase(Trim(A)) = UpperCase(Trim(B));
end;

function StartsWithTextLocal(Value, Prefix : String) : Boolean;
begin
    Result := Copy(UpperCase(Trim(Value)), 1, Length(Prefix)) = UpperCase(Prefix);
end;

function EndsWithTextLocal(Value, Suffix : String) : Boolean;
var
    S : String;
begin
    S := Trim(Value);
    if Length(S) < Length(Suffix) then
    begin
        Result := False;
        Exit;
    end;

    Result := Copy(UpperCase(S), Length(S) - Length(Suffix) + 1, Length(Suffix)) = UpperCase(Suffix);
end;

function LastDelimiterPos(Value, Delimiters : String) : Integer;
var
    I : Integer;
begin
    Result := 0;
    for I := Length(Value) downto 1 do
    begin
        if Pos(Copy(Value, I, 1), Delimiters) > 0 then
        begin
            Result := I;
            Exit;
        end;
    end;
end;

function InferPrefix(Value : String) : String;
var
    MarkerAt : Integer;
begin
    Result := Trim(Value);
    MarkerAt := LastDelimiterPos(Result, '_-');
    if MarkerAt > 0 then
        Result := Copy(Result, 1, MarkerAt);
end;

function InferredDiffPrefix(Value : String) : String;
begin
    Result := InferPrefix(Value);
    if (not EndsWithTextLocal(Value, '_P')) and
       (not EndsWithTextLocal(Value, '_N')) and
       (not EndsWithTextLocal(Value, '+')) and
       (not EndsWithTextLocal(Value, '-')) then
        Result := Trim(Value);
end;

function DiffSuffix(Value : String) : String;
begin
    Result := '';
    if EndsWithTextLocal(Value, '_P') then
        Result := 'P'
    else if EndsWithTextLocal(Value, '_N') then
        Result := 'N'
    else if EndsWithTextLocal(Value, '+') then
        Result := '+'
    else if EndsWithTextLocal(Value, '-') then
        Result := '-';
end;

function NormalizeDiffPairText(Value : String) : String;
begin
    Result := UpperCase(Trim(Value));
    if (Result = 'PN') or (Result = 'P N') or (Result = 'P\N') then
        Result := 'P/N';
end;

function HasDiffPairValue(Value : String) : Boolean;
begin
    Result := NormalizeDiffPairText(Value) = 'P/N';
end;

function BaseWithoutDiffPair(Value : String; var PairSide : String) : String;
begin
    Result := Trim(Value);
    PairSide := '';

    if EndsWithTextLocal(Result, '_P') then
    begin
        PairSide := 'P';
        Result := Copy(Result, 1, Length(Result) - 2);
    end
    else if EndsWithTextLocal(Result, '_N') then
    begin
        PairSide := 'N';
        Result := Copy(Result, 1, Length(Result) - 2);
    end;
end;

function HasNameInList(Names : TStringList; Value : String) : Boolean;
var
    I : Integer;
begin
    Result := False;
    if Names = Nil then
        Exit;

    for I := 0 to Names.Count - 1 do
    begin
        if SameTextLocal(Names.Strings[I], Value) then
        begin
            Result := True;
            Exit;
        end;
    end;
end;

function NameIndexInList(Names : TStringList; Value : String) : Integer;
var
    I : Integer;
begin
    Result := -1;
    if Names = Nil then
        Exit;

    for I := 0 to Names.Count - 1 do
    begin
        if SameTextLocal(Names.Strings[I], Value) then
        begin
            Result := I;
            Exit;
        end;
    end;
end;

procedure AddNameIfMissing(Names : TStringList; Value : String);
begin
    if Trim(Value) = '' then
        Exit;

    if not HasNameInList(Names, Value) then
        Names.Add(Trim(Value));
end;

function SignalDelimiterText : String;
begin
    Result := ' \ ';
end;

function SplitSignalAt(SignalText : String; WantedIndex : Integer) : String;
var
    I            : Integer;
    CurrentIndex : Integer;
    TokenStart   : Integer;
    S            : String;
begin
    Result := '';
    S := SignalText;
    CurrentIndex := 0;
    TokenStart := 1;

    for I := 1 to Length(S) do
    begin
        if Copy(S, I, 1) = '\' then
        begin
            if CurrentIndex = WantedIndex then
            begin
                Result := Trim(Copy(S, TokenStart, I - TokenStart));
                Exit;
            end;
            Inc(CurrentIndex);
            TokenStart := I + 1;
        end;
    end;

    if CurrentIndex = WantedIndex then
        Result := Trim(Copy(S, TokenStart, Length(S)));
end;

function SignalListCount(SignalText : String) : Integer;
var
    I : Integer;
begin
    if Trim(SignalText) = '' then
    begin
        Result := 0;
        Exit;
    end;

    Result := 1;
    for I := 1 to Length(SignalText) do
    begin
        if Copy(SignalText, I, 1) = '\' then
            Inc(Result);
    end;
end;

function SignalIndexInList(SignalText, SignalValue : String) : Integer;
var
    I     : Integer;
    Token : String;
    Count : Integer;
begin
    Result := -1;
    Count := SignalListCount(SignalText);
    for I := 0 to Count - 1 do
    begin
        Token := SplitSignalAt(SignalText, I);
        if SameTextLocal(Token, SignalValue) then
        begin
            Result := I;
            Exit;
        end;
    end;
end;

function PrefixIndexForValue(PrefixText, BaseValue : String; var PrefixValue : String) : Integer;
var
    I     : Integer;
    Token : String;
    Count : Integer;
begin
    Result := -1;
    PrefixValue := '';

    if Trim(PrefixText) = '' then
        Exit;

    Count := SignalListCount(PrefixText);
    for I := 0 to Count - 1 do
    begin
        Token := SplitSignalAt(PrefixText, I);
        if (Token <> '') and StartsWithTextLocal(BaseValue, Token) then
        begin
            PrefixValue := Token;
            Result := I;
            Exit;
        end;
    end;
end;

function JoinSignals(Names : TStringList) : String;
var
    I : Integer;
begin
    Result := '';
    if Names = Nil then
        Exit;

    for I := 0 to Names.Count - 1 do
    begin
        if Result <> '' then
            Result := Result + SignalDelimiterText;
        Result := Result + Names.Strings[I];
    end;
end;

function LongestCommonPrefix(Names : TStringList) : String;
var
    I, J : Integer;
    FirstName : String;
begin
    Result := '';
    if (Names = Nil) or (Names.Count = 0) then
        Exit;

    FirstName := Names.Strings[0];
    Result := FirstName;
    for I := 1 to Names.Count - 1 do
    begin
        J := 1;
        while (J <= Length(Result)) and
              (J <= Length(Names.Strings[I])) and
              SameTextLocal(Copy(Result, J, 1), Copy(Names.Strings[I], J, 1)) do
            Inc(J);

        Result := Copy(Result, 1, J - 1);
    end;
end;

function LongestCommonSuffix(Names : TStringList) : String;
var
    I, J : Integer;
    FirstName : String;
begin
    Result := '';
    if (Names = Nil) or (Names.Count = 0) then
        Exit;

    FirstName := Names.Strings[0];
    Result := FirstName;
    for I := 1 to Names.Count - 1 do
    begin
        J := 0;
        while (J < Length(Result)) and
              (J < Length(Names.Strings[I])) and
              SameTextLocal(Copy(Result, Length(Result) - J, 1), Copy(Names.Strings[I], Length(Names.Strings[I]) - J, 1)) do
            Inc(J);

        Result := Copy(Result, Length(Result) - J + 1, J);
    end;
end;

function TrimPrefixToDelimiter(Value : String) : String;
var
    MarkerAt : Integer;
begin
    Result := Value;
    MarkerAt := LastDelimiterPos(Result, '_-/');
    if MarkerAt > 0 then
        Result := Copy(Result, 1, MarkerAt)
    else
        Result := '';
end;

function TrimSuffixToDelimiter(Value : String) : String;
var
    I : Integer;
begin
    Result := '';
    for I := 1 to Length(Value) do
    begin
        if Pos(Copy(Value, I, 1), '_-/') > 0 then
        begin
            Result := Copy(Value, I, Length(Value));
            Exit;
        end;
    end;
end;

function ExtractBusSignal(BaseValue, MatchedPrefix, FindSuffix : String) : String;
begin
    Result := BaseValue;
    if (MatchedPrefix <> '') and StartsWithTextLocal(Result, MatchedPrefix) then
        Result := Copy(Result, Length(MatchedPrefix) + 1, Length(Result));

    if (FindSuffix <> '') and EndsWithTextLocal(Result, FindSuffix) then
        Result := Copy(Result, 1, Length(Result) - Length(FindSuffix));
end;

function MatchesBusQuery(CurrentValue, FindPrefix, FindSignal, FindSuffix, FindDiffPair : String; var PrefixValue, SignalValue, PairSide : String) : Boolean;
var
    BaseValue   : String;
    PrefixIndex : Integer;
begin
    Result := False;
    PrefixValue := '';
    SignalValue := '';
    PairSide := '';

    if (Trim(FindPrefix) = '') and (Trim(FindSignal) = '') and (Trim(FindSuffix) = '') then
        Exit;

    if HasDiffPairValue(FindDiffPair) then
    begin
        BaseValue := BaseWithoutDiffPair(CurrentValue, PairSide);
        if PairSide = '' then
            Exit;
    end
    else
        BaseValue := Trim(CurrentValue);

    if Trim(FindPrefix) <> '' then
    begin
        PrefixIndex := PrefixIndexForValue(FindPrefix, BaseValue, PrefixValue);
        if PrefixIndex < 0 then
            Exit;
    end;

    if (FindSuffix <> '') and (not EndsWithTextLocal(BaseValue, FindSuffix)) then
        Exit;

    SignalValue := ExtractBusSignal(BaseValue, PrefixValue, FindSuffix);
    if Trim(FindSignal) = '' then
        Result := True
    else
        Result := SignalIndexInList(FindSignal, SignalValue) >= 0;
end;

function BuildBusReplacement(PrefixValue, SignalValue, PairSide, FindPrefix, FindSignal, ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair : String) : String;
var
    PrefixIndex       : Integer;
    SignalIndex       : Integer;
    ReplacementPrefix : String;
    ReplacementSignal : String;
begin
    ReplacementPrefix := ReplacePrefix;
    ReplacementSignal := SignalValue;
    PrefixIndex := SignalIndexInList(FindPrefix, PrefixValue);
    SignalIndex := SignalIndexInList(FindSignal, SignalValue);

    if Trim(ReplacePrefix) <> '' then
    begin
        if (PrefixIndex >= 0) and (PrefixIndex < SignalListCount(ReplacePrefix)) then
            ReplacementPrefix := SplitSignalAt(ReplacePrefix, PrefixIndex)
        else if SignalListCount(ReplacePrefix) = 1 then
            ReplacementPrefix := SplitSignalAt(ReplacePrefix, 0);
    end;

    if Trim(ReplaceSignal) <> '' then
    begin
        if (SignalIndex >= 0) and (SignalIndex < SignalListCount(ReplaceSignal)) then
            ReplacementSignal := SplitSignalAt(ReplaceSignal, SignalIndex)
        else if SignalListCount(ReplaceSignal) = 1 then
            ReplacementSignal := SplitSignalAt(ReplaceSignal, 0);
    end;

    Result := ReplacementPrefix + ReplacementSignal + ReplaceSuffix;
    if HasDiffPairValue(ReplaceDiffPair) and (PairSide <> '') then
        Result := Result + '_' + PairSide;
end;

function MatchObjectKindName(ObjectKind : String) : String;
begin
    if ObjectKind = 'N' then
        Result := 'Net Label'
    else if ObjectKind = 'P' then
        Result := 'Port'
    else if ObjectKind = 'S' then
        Result := 'Sheet Entry'
    else if ObjectKind = 'D' then
        Result := 'Debug'
    else
        Result := 'Unknown';
end;

function PadRightText(Value : String; TargetLength : Integer) : String;
begin
    Result := Value;
    while Length(Result) < TargetLength do
        Result := Result + ' ';
end;

function MatchObjectKindListName(ObjectKind : String) : String;
begin
    Result := PadRightText(MatchObjectKindName(ObjectKind), 12);
end;

function FileNameOnly(Path : String) : String;
var
    SlashAt : Integer;
    BackslashAt : Integer;
begin
    Result := Path;
    SlashAt := LastDelimiterPos(Path, '/');
    BackslashAt := LastDelimiterPos(Path, '\');
    if BackslashAt > SlashAt then
        SlashAt := BackslashAt;
    if SlashAt > 0 then
        Result := Copy(Path, SlashAt + 1, Length(Path));
end;

function SheetNameListText(Path : String) : String;
var
    SheetName : String;
begin
    SheetName := FileNameOnly(Path);
    if EndsWithTextLocal(SheetName, '.SchDoc') then
        SheetName := Copy(SheetName, 1, Length(SheetName) - Length('.SchDoc'));

    Result := PadRightText(SheetName, HMNI_SHEET_NAME_COLUMN_WIDTH);
end;

function MakeMatchRow(ObjectKind, DocPath, CurrentValue, ReplaceValue : String; KindIndex : Integer) : String;
begin
    Result := ObjectKind + #9 + DocPath + #9 + CurrentValue + #9 + ReplaceValue + #9 + IntToStr(KindIndex);
end;

function RowField(RowText : String; FieldIndex : Integer) : String;
var
    I          : Integer;
    FieldStart : Integer;
    CurrentField : Integer;
begin
    Result := '';
    FieldStart := 1;
    CurrentField := 0;

    for I := 1 to Length(RowText) do
    begin
        if Copy(RowText, I, 1) = #9 then
        begin
            if CurrentField = FieldIndex then
            begin
                Result := Copy(RowText, FieldStart, I - FieldStart);
                Exit;
            end;
            Inc(CurrentField);
            FieldStart := I + 1;
        end;
    end;

    if CurrentField = FieldIndex then
        Result := Copy(RowText, FieldStart, Length(RowText));
end;

function RowKind(RowText : String) : String;
begin
    Result := RowField(RowText, 0);
end;

function RowDocPath(RowText : String) : String;
begin
    Result := RowField(RowText, 1);
end;

function RowCurrentValue(RowText : String) : String;
begin
    Result := RowField(RowText, 2);
end;

function RowReplaceValue(RowText : String) : String;
begin
    Result := RowField(RowText, 3);
end;

function StrToIntOrDefault(Value : String; DefaultValue : Integer) : Integer;
begin
    Result := DefaultValue;
    if Trim(Value) = '' then
        Exit;

    try
        Result := StrToInt(Trim(Value));
    except
        Result := DefaultValue;
    end;
end;

function RowKindIndex(RowText : String) : Integer;
begin
    Result := StrToIntOrDefault(RowField(RowText, 4), -1);
end;

function IsDebugMatchRow(RowText : String) : Boolean;
begin
    Result := RowKind(RowText) = 'D';
end;

function CountRealMatchRows(Matches : TStringList) : Integer;
var
    I : Integer;
begin
    Result := 0;
    if Matches = Nil then
        Exit;

    for I := 0 to Matches.Count - 1 do
    begin
        if not IsDebugMatchRow(Matches.Strings[I]) then
            Inc(Result);
    end;
end;

function FocusedProject(var Project : IProject; var ErrorText : String) : Boolean;
var
    WS : IWorkspace;
begin
    Result := False;
    Project := Nil;
    ErrorText := '';

    WS := GetWorkspace;
    if WS = Nil then
    begin
        ErrorText := 'Workspace Manager is not available.';
        Exit;
    end;

    Project := WS.DM_FocusedProject;
    if Project = Nil then
    begin
        ErrorText := 'Focus the target PCB project in the Projects panel, then run Hello My Name Is again.';
        Exit;
    end;

    Result := True;
end;

function DocumentIsSchematic(Doc : IDocument) : Boolean;
var
    PathText : String;
begin
    Result := False;
    if Doc = Nil then
        Exit;

    PathText := UpperCase(Doc.DM_FullPath);
    if Length(PathText) < 6 then
        Exit;

    Result := Copy(PathText, Length(PathText) - 6 + 1, 6) = 'SCHDOC';
end;

function OpenSchDocumentByPath(DocPath : String; var SchDoc : ISch_Document; var ErrorText : String) : Boolean;
var
    OpenedDoc : IServerDocument;
begin
    Result := False;
    SchDoc := Nil;
    ErrorText := '';

    if SchServer = Nil then
    begin
        ErrorText := 'Schematic server is not available.';
        Exit;
    end;

    if Client = Nil then
    begin
        ErrorText := 'Altium client interface is not available.';
        Exit;
    end;

    SchDoc := SchServer.GetSchDocumentByPath(DocPath);
    if SchDoc = Nil then
    begin
        OpenedDoc := Client.OpenDocument('SCH', DocPath);
        if OpenedDoc <> Nil then
            Client.ShowDocument(OpenedDoc);

        SchDoc := SchServer.GetSchDocumentByPath(DocPath);
    end;

    if SchDoc = Nil then
    begin
        ErrorText := 'Could not load schematic document:' + #13#10 + DocPath;
        Exit;
    end;

    Result := True;
end;

function MatchSortKey(RowText : String) : String;
begin
    Result := UpperCase(RowCurrentValue(RowText)) + #9 +
              UpperCase(RowDocPath(RowText)) + #9 +
              RowKind(RowText) + #9 +
              PadRightText(IntToStr(RowKindIndex(RowText)), 8);
end;

procedure SortMatchesByName(Matches : TStringList);
var
    SortedRows : TStringList;
    DebugRows  : TStringList;
    I          : Integer;
    SeparatorAt : Integer;
begin
    if Matches = Nil then
        Exit;

    SortedRows := TStringList.Create;
    DebugRows := TStringList.Create;
    try
        SortedRows.Sorted := True;
        for I := 0 to Matches.Count - 1 do
        begin
            if IsDebugMatchRow(Matches.Strings[I]) then
                DebugRows.Add(Matches.Strings[I])
            else
                SortedRows.Add(MatchSortKey(Matches.Strings[I]) + #1 + Matches.Strings[I]);
        end;

        Matches.Clear;
        for I := 0 to DebugRows.Count - 1 do
            Matches.Add(DebugRows.Strings[I]);
        for I := 0 to SortedRows.Count - 1 do
        begin
            SeparatorAt := Pos(#1, SortedRows.Strings[I]);
            if SeparatorAt > 0 then
                Matches.Add(Copy(SortedRows.Strings[I], SeparatorAt + 1, Length(SortedRows.Strings[I])));
        end;
    finally
        DebugRows.Free;
        SortedRows.Free;
    end;
end;

function OwnerDocumentSheetText(OwnerDocumentText : String) : String;
var
    SheetText : String;
begin
    SheetText := FileNameOnly(OwnerDocumentText);
    if EndsWithTextLocal(SheetText, '.SchDoc') then
        SheetText := Copy(SheetText, 1, Length(SheetText) - Length('.SchDoc'));
    Result := SheetText;
end;

function ProjectSchematicDocumentCount(Project : IProject) : Integer;
var
    I   : Integer;
    Doc : IDocument;
begin
    Result := 0;
    if Project = Nil then
        Exit;

    for I := 0 to Project.DM_LogicalDocumentCount - 1 do
    begin
        Doc := Project.DM_LogicalDocuments(I);
        if DocumentIsSchematic(Doc) then
            Inc(Result);
    end;
end;

function FindProjectSchDocumentNoOpen(Project : IProject; DocPath : String; var SchDoc : ISch_Document; var ResolveText : String) : Boolean;
var
    I          : Integer;
    Candidate  : IDocument;
    CandidatePath : String;
begin
    Result := False;
    SchDoc := Nil;
    ResolveText := '';

    if SchServer = Nil then
        Exit;

    SchDoc := SchServer.GetSchDocumentByPath(DocPath);
    if SchDoc <> Nil then
    begin
        Result := True;
        Exit;
    end;

    if Project = Nil then
        Exit;

    for I := 0 to Project.DM_PhysicalDocumentCount - 1 do
    begin
        Candidate := Project.DM_PhysicalDocuments(I);
        if not DocumentIsSchematic(Candidate) then
            Continue;

        CandidatePath := Candidate.DM_FullPath;
        if SameTextLocal(CandidatePath, DocPath) or SameTextLocal(FileNameOnly(CandidatePath), FileNameOnly(DocPath)) then
        begin
            SchDoc := SchServer.GetSchDocumentByPath(CandidatePath);
            if SchDoc <> Nil then
            begin
                if not SameTextLocal(CandidatePath, DocPath) then
                    ResolveText := 'Resolved through physical document path: ' + CandidatePath;
                Result := True;
                Exit;
            end;
        end;
    end;
end;

procedure AddFastSearchMatchRow(Matches : TStringList; ObjectKind, DocPath, CurrentValue : String; KindIndex : Integer;
                             FindPrefix, FindSignal, FindSuffix, FindDiffPair, ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair : String);
var
    PrefixValue : String;
    SignalValue : String;
    PairSide    : String;
    NewValue    : String;
begin
    if Matches = Nil then
        Exit;

    if MatchesBusQuery(CurrentValue, FindPrefix, FindSignal, FindSuffix, FindDiffPair, PrefixValue, SignalValue, PairSide) then
        NewValue := BuildBusReplacement(PrefixValue, SignalValue, PairSide, FindPrefix, FindSignal,
                                        ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair)
    else
        NewValue := CurrentValue;

    Matches.Add(MakeMatchRow(ObjectKind, DocPath, CurrentValue, NewValue, KindIndex));
end;

function FastSearchMatchesValue(CurrentValue, FindPrefix, FindSignal, FindSuffix, FindDiffPair : String) : Boolean;
var
    PrefixValue : String;
    SignalValue : String;
    PairSide    : String;
begin
    Result := MatchesBusQuery(CurrentValue, FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                              PrefixValue, SignalValue, PairSide);
end;

procedure AddFastSearchSheetResults(SchDoc : ISch_Document; DocPath : String; Lines, Matches : TStringList; var MatchCount : Integer;
                                       FindPrefix, FindSignal, FindSuffix, FindDiffPair, ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair : String;
                                       SearchNetNames, SearchPorts, SearchSheetEntries : Boolean);
var
    Iterator      : ISch_Iterator;
    ChildIterator : ISch_Iterator;
    LabelObj      : ISch_Label;
    PortObj       : ISch_Port;
    SheetSymbol   : ISch_SheetSymbol;
    SheetEntry    : ISch_SheetEntry;
    NetIndex      : Integer;
    PortIndex     : Integer;
    SheetEntryIndex : Integer;
    SheetSymbolCount : Integer;
    NetMatchCount : Integer;
    PortMatchCount : Integer;
    SheetEntryMatchCount : Integer;
    ValueText     : String;
begin
    MatchCount := 0;
    if (SchDoc = Nil) or (Lines = Nil) then
        Exit;

    NetIndex := 0;
    PortIndex := 0;
    SheetEntryIndex := 0;
    SheetSymbolCount := 0;
    NetMatchCount := 0;
    PortMatchCount := 0;
    SheetEntryMatchCount := 0;

    if SearchNetNames then
    begin
        Iterator := SchDoc.SchIterator_Create;
        if Iterator <> Nil then
        begin
            try
                Iterator.AddFilter_ObjectSet(MkSet(eNetLabel));
                LabelObj := Iterator.FirstSchObject;
                while LabelObj <> Nil do
                begin
                    ValueText := Trim(LabelObj.Text);
                    if FastSearchMatchesValue(ValueText, FindPrefix, FindSignal, FindSuffix, FindDiffPair) then
                    begin
                        Inc(MatchCount);
                        Inc(NetMatchCount);
                        Lines.Add('Net label' + #9 + OwnerDocumentSheetText(DocPath) + #9 + ValueText);
                        AddFastSearchMatchRow(Matches, 'N', DocPath, ValueText, NetIndex,
                                           FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                           ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair);
                    end;
                    Inc(NetIndex);
                    LabelObj := Iterator.NextSchObject;
                end;
            finally
                SchDoc.SchIterator_Destroy(Iterator);
            end;
        end;
    end;

    if SearchPorts then
    begin
        Iterator := SchDoc.SchIterator_Create;
        if Iterator <> Nil then
        begin
            try
                Iterator.AddFilter_ObjectSet(MkSet(ePort));
                PortObj := Iterator.FirstSchObject;
                while PortObj <> Nil do
                begin
                    ValueText := Trim(PortObj.Name);
                    if FastSearchMatchesValue(ValueText, FindPrefix, FindSignal, FindSuffix, FindDiffPair) then
                    begin
                        Inc(MatchCount);
                        Inc(PortMatchCount);
                        Lines.Add('Port' + #9 + OwnerDocumentSheetText(DocPath) + #9 + ValueText);
                        AddFastSearchMatchRow(Matches, 'P', DocPath, ValueText, PortIndex,
                                           FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                           ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair);
                    end;
                    Inc(PortIndex);
                    PortObj := Iterator.NextSchObject;
                end;
            finally
                SchDoc.SchIterator_Destroy(Iterator);
            end;
        end;
    end;

    if SearchSheetEntries then
    begin
        Iterator := SchDoc.SchIterator_Create;
        if Iterator <> Nil then
        begin
            try
                Iterator.AddFilter_ObjectSet(MkSet(eSheetSymbol));
                SheetSymbol := Iterator.FirstSchObject;
                while SheetSymbol <> Nil do
                begin
                    Inc(SheetSymbolCount);
                    ChildIterator := SheetSymbol.SchIterator_Create;
                    if ChildIterator <> Nil then
                    begin
                        try
                            ChildIterator.AddFilter_ObjectSet(MkSet(eSheetEntry));
                            SheetEntry := ChildIterator.FirstSchObject;
                            while SheetEntry <> Nil do
                            begin
                                ValueText := Trim(SheetEntry.Name);
                                if FastSearchMatchesValue(ValueText, FindPrefix, FindSignal, FindSuffix, FindDiffPair) then
                                begin
                                    Inc(MatchCount);
                                    Inc(SheetEntryMatchCount);
                                    Lines.Add('Sheet entry' + #9 + OwnerDocumentSheetText(DocPath) + #9 + ValueText);
                                    AddFastSearchMatchRow(Matches, 'S', DocPath, ValueText, SheetEntryIndex,
                                                       FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                                       ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair);
                                end;
                                Inc(SheetEntryIndex);
                                SheetEntry := ChildIterator.NextSchObject;
                            end;
                        finally
                            SheetSymbol.SchIterator_Destroy(ChildIterator);
                        end;
                    end;
                    SheetSymbol := Iterator.NextSchObject;
                end;
            finally
                SchDoc.SchIterator_Destroy(Iterator);
            end;
        end;
    end;

    Lines.Add('Parsed ' + OwnerDocumentSheetText(DocPath) +
              ': net labels=' + IntToStr(NetIndex) +
              ', ports=' + IntToStr(PortIndex) +
              ', sheet entries=' + IntToStr(SheetEntryIndex) +
              ', matches=' + IntToStr(NetMatchCount + PortMatchCount + SheetEntryMatchCount));
end;

function BuildProjectMatches(Project : IProject; FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                             ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair : String;
                             SearchNetNames, SearchPorts, SearchSheetEntries : Boolean;
                             Matches : TStringList; var DebugText, ErrorText : String) : Boolean;
var
    CurrentSchDoc   : ISch_Document;
    SchDoc          : ISch_Document;
    Lines           : TStringList;
    MatchCount      : Integer;
    SheetMatchCount : Integer;
    ProjectDocCount : Integer;
    ParsedDocCount  : Integer;
    SkippedDocCount : Integer;
    I               : Integer;
    Doc             : IDocument;
    DocPath         : String;
    ResolveText     : String;
    SkippedSheetText : String;
    SkippedSheetName : String;
begin
    Result := False;
    DebugText := '';
    ErrorText := '';

    if SchServer = Nil then
    begin
        ErrorText := 'Schematic server is not available.';
        Exit;
    end;

    CurrentSchDoc := SchServer.GetCurrentSchDocument;
    if CurrentSchDoc = Nil then
    begin
        ErrorText := 'Open a schematic sheet, then run Find Matches again.';
        Exit;
    end;

    if Matches = Nil then
    begin
        ErrorText := 'Match list is not available.';
        Exit;
    end;

    Lines := TStringList.Create;
    try
        Matches.Clear;
        MatchCount := 0;
        ProjectDocCount := ProjectSchematicDocumentCount(Project);
        ParsedDocCount := 0;
        SkippedDocCount := 0;
        SkippedSheetText := '';

        Lines.Add('Fast project iterator search');
        Lines.Add('');
        Lines.Add('Scope: focused project schematic documents available through SchServer');
        Lines.Add('Project schematic documents: ' + IntToStr(ProjectDocCount));
        Lines.Add('Altium filter parser: not used');
        Lines.Add('Schematic filters/masks: not cleared or changed');
        Lines.Add('Hello search parsing: current Find fields');
        Lines.Add('Enabled object types: net names=' + BoolText(SearchNetNames) +
                  ', ports=' + BoolText(SearchPorts) +
                  ', sheet entries=' + BoolText(SearchSheetEntries) +
                  ', net classes=not implemented');
        Lines.Add('');
        Lines.Add('Matched supported objects:');

        if (Project <> Nil) and (ProjectDocCount > 0) then
        begin
            for I := 0 to Project.DM_LogicalDocumentCount - 1 do
            begin
                Doc := Project.DM_LogicalDocuments(I);
                if DocumentIsSchematic(Doc) then
                begin
                    DocPath := Doc.DM_FullPath;
                    if not FindProjectSchDocumentNoOpen(Project, DocPath, SchDoc, ResolveText) then
                    begin
                        Inc(SkippedDocCount);
                        SkippedSheetName := OwnerDocumentSheetText(DocPath);
                        if SkippedSheetText <> '' then
                            SkippedSheetText := SkippedSheetText + ', ';
                        SkippedSheetText := SkippedSheetText + SkippedSheetName;
                        Lines.Add('Skipped ' + FileNameOnly(DocPath) + ': source and physical document lookup returned Nil without opening the sheet.');
                        Lines.Add('Skipped path: ' + DocPath);
                        Continue;
                    end;

                    if ResolveText <> '' then
                        Lines.Add(ResolveText);

                    Inc(ParsedDocCount);
                    AddFastSearchSheetResults(SchDoc, DocPath, Lines, Matches, SheetMatchCount,
                                                 FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                                 ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair,
                                                 SearchNetNames, SearchPorts, SearchSheetEntries);
                    MatchCount := MatchCount + SheetMatchCount;
                end;
            end;
        end;

        if ParsedDocCount = 0 then
        begin
            ParsedDocCount := 1;
            AddFastSearchSheetResults(CurrentSchDoc, '(active schematic sheet)', Lines, Matches, SheetMatchCount,
                                         FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                         ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair,
                                         SearchNetNames, SearchPorts, SearchSheetEntries);
            MatchCount := MatchCount + SheetMatchCount;
        end;

        Lines.Add('Project sheets parsed=' + IntToStr(ParsedDocCount) +
                  ', skipped=' + IntToStr(SkippedDocCount) +
                  ', matches=' + IntToStr(MatchCount));
        if MatchCount = 0 then
            Lines.Add('No matching net labels, ports, or sheet entries were found.');

        if SkippedDocCount > 0 then
        begin
            Lines.Insert(0, '');
            Lines.Insert(0, 'Change the SCH List document selection to All Project Documents, then run Find Matches again.');
            Lines.Insert(0, 'If the sheets still skip, open the skipped sheet(s), or reload the project, then try again.');
            Lines.Insert(0, 'Altium did not expose those document objects through SchServer without opening the sheets.');
            Lines.Insert(0, 'Skipped sheets: ' + SkippedSheetText);
            Lines.Insert(0, 'WARNING: ' + IntToStr(SkippedDocCount) + ' project schematic document(s) were skipped.');
            Matches.Add(MakeMatchRow('D', '', 'WARNING: ' + IntToStr(SkippedDocCount) + ' project schematic document(s) were skipped.', '', -1));
            Matches.Add(MakeMatchRow('D', '', 'Skipped sheets: ' + SkippedSheetText, '', -1));
            Matches.Add(MakeMatchRow('D', '', 'Change the SCH List document selection to All Project Documents, then run Find Matches again.', '', -1));
            Matches.Add(MakeMatchRow('D', '', 'If the sheets still skip, open the skipped sheet(s), or reload the project, then try again.', '', -1));
            Matches.Add(MakeMatchRow('D', '', '', '', -1));
        end;

        SortMatchesByName(Matches);
        DebugText := Lines.Text + #13#10 + 'Matched rename candidates: ' + IntToStr(CountRealMatchRows(Matches)) + #13#10;
        Result := True;
    finally
        Lines.Free;
    end;
end;

procedure CollectNamesFromSheet(SchDoc : ISch_Document; Names : TStringList; SelectedOnly : Boolean);
var
    Iterator      : ISch_Iterator;
    ChildIterator : ISch_Iterator;
    LabelObj      : ISch_Label;
    PortObj       : ISch_Port;
    SheetSymbol   : ISch_SheetSymbol;
    SheetEntry    : ISch_SheetEntry;
begin
    if (SchDoc = Nil) or (Names = Nil) then
        Exit;

    Iterator := SchDoc.SchIterator_Create;
    if Iterator <> Nil then
    begin
        try
            Iterator.AddFilter_ObjectSet(MkSet(eNetLabel));
            LabelObj := Iterator.FirstSchObject;
            while LabelObj <> Nil do
            begin
                if (not SelectedOnly) or LabelObj.Selection then
                    AddNameIfMissing(Names, Trim(LabelObj.Text));
                LabelObj := Iterator.NextSchObject;
            end;
        finally
            SchDoc.SchIterator_Destroy(Iterator);
        end;
    end;

    Iterator := SchDoc.SchIterator_Create;
    if Iterator <> Nil then
    begin
        try
            Iterator.AddFilter_ObjectSet(MkSet(ePort));
            PortObj := Iterator.FirstSchObject;
            while PortObj <> Nil do
            begin
                if (not SelectedOnly) or PortObj.Selection then
                    AddNameIfMissing(Names, Trim(PortObj.Name));
                PortObj := Iterator.NextSchObject;
            end;
        finally
            SchDoc.SchIterator_Destroy(Iterator);
        end;
    end;

    Iterator := SchDoc.SchIterator_Create;
    if Iterator <> Nil then
    begin
        try
            Iterator.AddFilter_ObjectSet(MkSet(eSheetSymbol));
            SheetSymbol := Iterator.FirstSchObject;
            while SheetSymbol <> Nil do
            begin
                ChildIterator := SheetSymbol.SchIterator_Create;
                if ChildIterator <> Nil then
                begin
                    try
                        ChildIterator.AddFilter_ObjectSet(MkSet(eSheetEntry));
                        SheetEntry := ChildIterator.FirstSchObject;
                        while SheetEntry <> Nil do
                        begin
                            if (not SelectedOnly) or SheetEntry.Selection then
                                AddNameIfMissing(Names, Trim(SheetEntry.Name));
                            SheetEntry := ChildIterator.NextSchObject;
                        end;
                    finally
                        SheetSymbol.SchIterator_Destroy(ChildIterator);
                    end;
                end;
                SheetSymbol := Iterator.NextSchObject;
            end;
        finally
            SchDoc.SchIterator_Destroy(Iterator);
        end;
    end;
end;

function CollectSelectedNamesOnCurrentSheet(Names : TStringList; var ErrorText : String) : Boolean;
var
    SchDoc : ISch_Document;
begin
    Result := False;
    ErrorText := '';

    if SchServer = Nil then
    begin
        ErrorText := 'Schematic server is not available.';
        Exit;
    end;

    SchDoc := SchServer.GetCurrentSchDocument;
    if SchDoc = Nil then
    begin
        ErrorText := 'Open a schematic sheet, then run Hello My Name Is again.';
        Exit;
    end;

    if Names <> Nil then
        Names.Clear;

    CollectNamesFromSheet(SchDoc, Names, True);
    Result := True;
end;

function InferGroupedPrefixSignals(BaseNames, PrefixNames, SignalNames : TStringList) : Boolean;
var
    I          : Integer;
    MarkerAt   : Integer;
    BaseName   : String;
    PrefixText : String;
    SignalText : String;
begin
    Result := False;
    if PrefixNames <> Nil then
        PrefixNames.Clear;
    if SignalNames <> Nil then
        SignalNames.Clear;

    if (BaseNames = Nil) or (PrefixNames = Nil) or (SignalNames = Nil) then
        Exit;

    if BaseNames.Count < 3 then
        Exit;

    for I := 0 to BaseNames.Count - 1 do
    begin
        BaseName := Trim(BaseNames.Strings[I]);
        MarkerAt := LastDelimiterPos(BaseName, '_-/');
        if (MarkerAt <= 0) or (MarkerAt >= Length(BaseName)) then
        begin
            PrefixNames.Clear;
            SignalNames.Clear;
            Exit;
        end;

        PrefixText := Copy(BaseName, 1, MarkerAt);
        SignalText := Copy(BaseName, MarkerAt + 1, Length(BaseName));
        AddNameIfMissing(PrefixNames, PrefixText);
        AddNameIfMissing(SignalNames, SignalText);
    end;

    Result := (PrefixNames.Count > 1) and
              (SignalNames.Count > 1) and
              (BaseNames.Count > PrefixNames.Count) and
              (BaseNames.Count > SignalNames.Count);

    if not Result then
    begin
        PrefixNames.Clear;
        SignalNames.Clear;
    end;
end;

procedure InferBusFieldsFromSelected(SelectedNames, ProjectNames : TStringList; var FindPrefix, FindSignal, FindSuffix, FindDiffPair, ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair : String);
var
    BaseNames     : TStringList;
    PrefixNames   : TStringList;
    SignalNames   : TStringList;
    I             : Integer;
    PairSide      : String;
    OtherSide     : String;
    BaseName      : String;
    PrefixText    : String;
    SuffixText    : String;
    MiddleText    : String;
    HasPair       : Boolean;
begin
    FindPrefix := '';
    FindSignal := '';
    FindSuffix := '';
    FindDiffPair := '';
    ReplacePrefix := '';
    ReplaceSignal := '';
    ReplaceSuffix := '';
    ReplaceDiffPair := '';

    if (SelectedNames = Nil) or (SelectedNames.Count = 0) then
        Exit;

    if SelectedNames.Count = 1 then
    begin
        FindSignal := Trim(SelectedNames.Strings[0]);
        ReplaceSignal := FindSignal;
        Exit;
    end;

    BaseNames := TStringList.Create;
    PrefixNames := TStringList.Create;
    SignalNames := TStringList.Create;
    try
        HasPair := False;
        for I := 0 to SelectedNames.Count - 1 do
        begin
            BaseName := BaseWithoutDiffPair(SelectedNames.Strings[I], PairSide);
            if PairSide <> '' then
            begin
                if PairSide = 'P' then
                    OtherSide := BaseName + '_N'
                else
                    OtherSide := BaseName + '_P';

                if HasNameInList(SelectedNames, OtherSide) or HasNameInList(ProjectNames, OtherSide) then
                    HasPair := True;
            end;

            AddNameIfMissing(BaseNames, BaseName);
        end;

        if HasPair then
            FindDiffPair := 'P/N';

        if InferGroupedPrefixSignals(BaseNames, PrefixNames, SignalNames) then
        begin
            FindPrefix := JoinSignals(PrefixNames);
            ReplacePrefix := FindPrefix;

            SuffixText := TrimSuffixToDelimiter(LongestCommonSuffix(SignalNames));
            FindSuffix := SuffixText;
            ReplaceSuffix := SuffixText;

            if SuffixText <> '' then
            begin
                for I := 0 to SignalNames.Count - 1 do
                begin
                    MiddleText := SignalNames.Strings[I];
                    if EndsWithTextLocal(MiddleText, SuffixText) then
                        SignalNames.Strings[I] := Copy(MiddleText, 1, Length(MiddleText) - Length(SuffixText));
                end;
            end;
        end
        else
        begin
            PrefixText := TrimPrefixToDelimiter(LongestCommonPrefix(BaseNames));
            FindPrefix := PrefixText;
            ReplacePrefix := PrefixText;

            for I := 0 to BaseNames.Count - 1 do
            begin
                MiddleText := BaseNames.Strings[I];
                if (PrefixText <> '') and StartsWithTextLocal(MiddleText, PrefixText) then
                    MiddleText := Copy(MiddleText, Length(PrefixText) + 1, Length(MiddleText));
                AddNameIfMissing(SignalNames, MiddleText);
            end;

            SuffixText := TrimSuffixToDelimiter(LongestCommonSuffix(SignalNames));
            FindSuffix := SuffixText;
            ReplaceSuffix := SuffixText;

            if SuffixText <> '' then
            begin
                SignalNames.Clear;
                for I := 0 to BaseNames.Count - 1 do
                begin
                    MiddleText := BaseNames.Strings[I];
                    if (PrefixText <> '') and StartsWithTextLocal(MiddleText, PrefixText) then
                        MiddleText := Copy(MiddleText, Length(PrefixText) + 1, Length(MiddleText));
                    if EndsWithTextLocal(MiddleText, SuffixText) then
                        MiddleText := Copy(MiddleText, 1, Length(MiddleText) - Length(SuffixText));
                    AddNameIfMissing(SignalNames, MiddleText);
                end;
            end;
        end;

        FindSignal := JoinSignals(SignalNames);
        ReplaceSignal := FindSignal;
        ReplaceDiffPair := FindDiffPair;
    finally
        BaseNames.Free;
        PrefixNames.Free;
        SignalNames.Free;
    end;
end;

procedure ApplyNetLabelRename(SchDoc : ISch_Document; LabelObj : ISch_Label; NewValue : String);
begin
    SchServer.ProcessControl.PreProcess(SchDoc, '');
    try
        SchServer.RobotManager.SendMessage(LabelObj.I_ObjectAddress, c_BroadCast, SCHM_BeginModify, c_NoEventData);
        try
            LabelObj.Text := NewValue;
        finally
            SchServer.RobotManager.SendMessage(LabelObj.I_ObjectAddress, c_BroadCast, SCHM_EndModify, c_NoEventData);
        end;
    finally
        SchServer.ProcessControl.PostProcess(SchDoc, '');
    end;

    SchDoc.GraphicallyInvalidate;
end;

procedure ApplyPortRename(SchDoc : ISch_Document; PortObj : ISch_Port; NewValue : String);
begin
    SchServer.ProcessControl.PreProcess(SchDoc, '');
    try
        SchServer.RobotManager.SendMessage(PortObj.I_ObjectAddress, c_BroadCast, SCHM_BeginModify, c_NoEventData);
        try
            PortObj.Name := NewValue;
        finally
            SchServer.RobotManager.SendMessage(PortObj.I_ObjectAddress, c_BroadCast, SCHM_EndModify, c_NoEventData);
        end;
    finally
        SchServer.ProcessControl.PostProcess(SchDoc, '');
    end;

    SchDoc.GraphicallyInvalidate;
end;

procedure ApplySheetEntryRename(SchDoc : ISch_Document; SheetEntry : ISch_SheetEntry; NewValue : String);
begin
    SchServer.ProcessControl.PreProcess(SchDoc, '');
    try
        SchServer.RobotManager.SendMessage(SheetEntry.I_ObjectAddress, c_BroadCast, SCHM_BeginModify, c_NoEventData);
        try
            SheetEntry.Name := NewValue;
        finally
            SchServer.RobotManager.SendMessage(SheetEntry.I_ObjectAddress, c_BroadCast, SCHM_EndModify, c_NoEventData);
        end;
    finally
        SchServer.ProcessControl.PostProcess(SchDoc, '');
    end;

    SchDoc.GraphicallyInvalidate;
end;

function RenameRowObject(RowText : String; var ErrorText : String) : Boolean;
var
    SchDoc        : ISch_Document;
    Iterator      : ISch_Iterator;
    ChildIterator : ISch_Iterator;
    LabelObj      : ISch_Label;
    PortObj       : ISch_Port;
    SheetSymbol   : ISch_SheetSymbol;
    SheetEntry    : ISch_SheetEntry;
    TargetLabel      : ISch_Label;
    TargetPort       : ISch_Port;
    TargetSheetEntry : ISch_SheetEntry;
    ObjectKind    : String;
    DocPath       : String;
    NewValue      : String;
    TargetIndex   : Integer;
    CurrentIndex  : Integer;
begin
    Result := False;
    ErrorText := '';

    ObjectKind := RowKind(RowText);
    DocPath := RowDocPath(RowText);
    NewValue := RowReplaceValue(RowText);
    TargetIndex := RowKindIndex(RowText);

    if IsDebugMatchRow(RowText) then
    begin
        ErrorText := 'Debug rows are not schematic objects.';
        Exit;
    end;

    if TargetIndex < 0 then
    begin
        ErrorText := 'Invalid match index for row:' + #13#10 + RowText;
        Exit;
    end;

    if not OpenSchDocumentByPath(DocPath, SchDoc, ErrorText) then
        Exit;

    CurrentIndex := 0;
    TargetLabel := Nil;
    TargetPort := Nil;
    TargetSheetEntry := Nil;

    if ObjectKind = 'N' then
    begin
        Iterator := SchDoc.SchIterator_Create;
        if Iterator = Nil then
        begin
            ErrorText := 'Could not create net label iterator.';
            Exit;
        end;
        try
            Iterator.AddFilter_ObjectSet(MkSet(eNetLabel));
            LabelObj := Iterator.FirstSchObject;
            while LabelObj <> Nil do
            begin
                if CurrentIndex = TargetIndex then
                begin
                    TargetLabel := LabelObj;
                    Break;
                end;
                Inc(CurrentIndex);
                LabelObj := Iterator.NextSchObject;
            end;
        finally
            SchDoc.SchIterator_Destroy(Iterator);
        end;

        if TargetLabel <> Nil then
        begin
            ApplyNetLabelRename(SchDoc, TargetLabel, NewValue);
            Result := True;
            Exit;
        end;
    end
    else if ObjectKind = 'P' then
    begin
        Iterator := SchDoc.SchIterator_Create;
        if Iterator = Nil then
        begin
            ErrorText := 'Could not create port iterator.';
            Exit;
        end;
        try
            Iterator.AddFilter_ObjectSet(MkSet(ePort));
            PortObj := Iterator.FirstSchObject;
            while PortObj <> Nil do
            begin
                if CurrentIndex = TargetIndex then
                begin
                    TargetPort := PortObj;
                    Break;
                end;
                Inc(CurrentIndex);
                PortObj := Iterator.NextSchObject;
            end;
        finally
            SchDoc.SchIterator_Destroy(Iterator);
        end;

        if TargetPort <> Nil then
        begin
            ApplyPortRename(SchDoc, TargetPort, NewValue);
            Result := True;
            Exit;
        end;
    end
    else if ObjectKind = 'S' then
    begin
        Iterator := SchDoc.SchIterator_Create;
        if Iterator = Nil then
        begin
            ErrorText := 'Could not create sheet symbol iterator.';
            Exit;
        end;
        try
            Iterator.AddFilter_ObjectSet(MkSet(eSheetSymbol));
            SheetSymbol := Iterator.FirstSchObject;
            while SheetSymbol <> Nil do
            begin
                ChildIterator := SheetSymbol.SchIterator_Create;
                if ChildIterator <> Nil then
                begin
                    try
                        ChildIterator.AddFilter_ObjectSet(MkSet(eSheetEntry));
                        SheetEntry := ChildIterator.FirstSchObject;
                        while SheetEntry <> Nil do
                        begin
                            if CurrentIndex = TargetIndex then
                            begin
                                TargetSheetEntry := SheetEntry;
                                Break;
                            end;
                            Inc(CurrentIndex);
                            SheetEntry := ChildIterator.NextSchObject;
                        end;
                    finally
                        SheetSymbol.SchIterator_Destroy(ChildIterator);
                    end;
                end;
                if TargetSheetEntry <> Nil then
                    Break;
                SheetSymbol := Iterator.NextSchObject;
            end;
        finally
            SchDoc.SchIterator_Destroy(Iterator);
        end;

        if TargetSheetEntry <> Nil then
        begin
            ApplySheetEntryRename(SchDoc, TargetSheetEntry, NewValue);
            Result := True;
            Exit;
        end;
    end;

    ErrorText := 'Could not find the matched ' + MatchObjectKindName(ObjectKind) + ' on ' + FileNameOnly(DocPath) + '.';
end;

function PreviewReplaceValue(RowText, FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                             ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair : String) : String;
var
    PrefixValue : String;
    SignalValue : String;
    PairSide    : String;
begin
    if IsDebugMatchRow(RowText) then
    begin
        Result := RowCurrentValue(RowText);
        Exit;
    end;

    if MatchesBusQuery(RowCurrentValue(RowText), FindPrefix, FindSignal, FindSuffix, FindDiffPair, PrefixValue, SignalValue, PairSide) then
        Result := BuildBusReplacement(PrefixValue, SignalValue, PairSide, FindPrefix, FindSignal,
                                      ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair)
    else
        Result := RowReplaceValue(RowText);
end;

function ReplacementLineText(RowText, FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                             ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair : String;
                             CurrentWidth, ArrowWidth, ReplaceWidth, KindWidth : Integer) : String;
var
    NewValue : String;
begin
    if IsDebugMatchRow(RowText) then
    begin
        Result := RowCurrentValue(RowText);
        Exit;
    end;

    NewValue := PreviewReplaceValue(RowText, FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                    ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair);

    Result := PadRightText(RowCurrentValue(RowText), CurrentWidth + 2) +
              PadRightText('-->', ArrowWidth + 2) +
              PadRightText(NewValue, ReplaceWidth + 2) +
              PadRightText(MatchObjectKindName(RowKind(RowText)), KindWidth + 2) +
              SheetNameListText(RowDocPath(RowText)) + '  ';
end;

procedure AddReplacementRichLine(ARichEdit : TRichEdit; LineText : String; TextColor : Integer);
begin
    ARichEdit.SelStart := Length(ARichEdit.Text);
    ARichEdit.SelAttributes.Color := TextColor;
    ARichEdit.SelText := LineText;
end;

procedure SetReplacementStatusText(ARichEdit : TRichEdit; MessageText : String; TextColor : Integer);
begin
    if ARichEdit = Nil then
        Exit;

    ARichEdit.ReadOnly := False;
    ARichEdit.Clear;
    AddReplacementRichLine(ARichEdit, MessageText, TextColor);
    ARichEdit.SelStart := 0;
    ARichEdit.SelLength := 0;
    ARichEdit.ReadOnly := True;
end;

procedure AddReplacementPreviewLine(ARichEdit : TRichEdit; RowText, FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                    ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair : String;
                                    CurrentWidth, ArrowWidth, ReplaceWidth, KindWidth : Integer;
                                    TextColor : Integer);
var
    LineText    : String;
begin
    LineText := ReplacementLineText(RowText, FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                    ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair,
                                    CurrentWidth, ArrowWidth, ReplaceWidth, KindWidth);
    AddReplacementRichLine(ARichEdit, LineText, TextColor);
end;

procedure PopulateReplacementRichEdit(ARichEdit : TRichEdit; Matches : TStringList; CurrentIndex : Integer;
                                      FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                      ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair : String);
var
    I            : Integer;
    RowText      : String;
    ReplaceValue : String;
    CurrentWidth : Integer;
    ArrowWidth   : Integer;
    ReplaceWidth : Integer;
    KindWidth    : Integer;
begin
    if ARichEdit = Nil then
        Exit;

    ARichEdit.ReadOnly := False;
    ARichEdit.Clear;
    if Matches = Nil then
    begin
        ARichEdit.ReadOnly := True;
        Exit;
    end;

    CurrentWidth := 0;
    ArrowWidth := 3;
    ReplaceWidth := 0;
    KindWidth := 0;

    for I := 0 to Matches.Count - 1 do
    begin
        RowText := Matches.Strings[I];
        if IsDebugMatchRow(RowText) then
            Continue;

        ReplaceValue := PreviewReplaceValue(RowText, FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                            ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair);

        if Length(RowCurrentValue(RowText)) > CurrentWidth then
            CurrentWidth := Length(RowCurrentValue(RowText));
        if Length(ReplaceValue) > ReplaceWidth then
            ReplaceWidth := Length(ReplaceValue);
        if Length(MatchObjectKindName(RowKind(RowText))) > KindWidth then
            KindWidth := Length(MatchObjectKindName(RowKind(RowText)));
    end;

    for I := 0 to Matches.Count - 1 do
    begin
        RowText := Matches.Strings[I];
        if I > 0 then
            AddReplacementRichLine(ARichEdit, #13#10, UI_DARK_TEXT);

        if IsDebugMatchRow(RowText) then
            AddReplacementPreviewLine(ARichEdit, RowText, FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                      ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair,
                                      CurrentWidth, ArrowWidth, ReplaceWidth, KindWidth,
                                      UI_DARK_MUTED_TEXT)
        else if I = CurrentIndex then
            AddReplacementPreviewLine(ARichEdit, RowText, FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                      ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair,
                                      CurrentWidth, ArrowWidth, ReplaceWidth, KindWidth,
                                      UI_RED_TEXT)
        else
            AddReplacementPreviewLine(ARichEdit, RowText, FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                      ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair,
                                      CurrentWidth, ArrowWidth, ReplaceWidth, KindWidth,
                                      UI_DARK_TEXT);
    end;

    ARichEdit.SelStart := 0;
    ARichEdit.SelLength := 0;
    ARichEdit.ReadOnly := True;
end;

function PreviewFieldsKey(FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                          ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair : String) : String;
begin
    Result := FindPrefix + #1 +
              FindSignal + #1 +
              FindSuffix + #1 +
              NormalizeDiffPairText(FindDiffPair) + #1 +
              ReplacePrefix + #1 +
              ReplaceSignal + #1 +
              ReplaceSuffix + #1 +
              NormalizeDiffPairText(ReplaceDiffPair);
end;

function PreviewFindFieldsKey(FindPrefix, FindSignal, FindSuffix, FindDiffPair : String) : String;
begin
    Result := FindPrefix + #1 +
              FindSignal + #1 +
              FindSuffix + #1 +
              NormalizeDiffPairText(FindDiffPair);
end;

function SearchScopeKey(SearchNetNames, SearchPorts, SearchSheetEntries : Boolean) : String;
begin
    Result := BoolText(SearchNetNames) + #1 +
              BoolText(SearchPorts) + #1 +
              BoolText(SearchSheetEntries);
end;

function SameMatchIdentity(RowA, RowB : String) : Boolean;
begin
    Result := (RowKind(RowA) = RowKind(RowB)) and
              SameTextLocal(RowDocPath(RowA), RowDocPath(RowB)) and
              SameTextLocal(RowCurrentValue(RowA), RowCurrentValue(RowB)) and
              (RowKindIndex(RowA) = RowKindIndex(RowB));
end;

function MatchingRowIndex(Matches : TStringList; SelectedRow : String) : Integer;
var
    I : Integer;
begin
    Result := -1;
    if (Matches = Nil) or (SelectedRow = '') then
        Exit;

    for I := 0 to Matches.Count - 1 do
    begin
        if SameMatchIdentity(Matches.Strings[I], SelectedRow) then
        begin
            Result := I;
            Exit;
        end;
    end;
end;

function FirstRealMatchIndex(Matches : TStringList) : Integer;
var
    I : Integer;
begin
    Result := -1;
    if Matches = Nil then
        Exit;

    for I := 0 to Matches.Count - 1 do
    begin
        if not IsDebugMatchRow(Matches.Strings[I]) then
        begin
            Result := I;
            Exit;
        end;
    end;
end;

function NextRealMatchIndex(Matches : TStringList; CurrentIndex : Integer) : Integer;
var
    I : Integer;
begin
    Result := -1;
    if Matches = Nil then
        Exit;

    for I := CurrentIndex + 1 to Matches.Count - 1 do
    begin
        if not IsDebugMatchRow(Matches.Strings[I]) then
        begin
            Result := I;
            Exit;
        end;
    end;

    for I := 0 to CurrentIndex do
    begin
        if (I >= 0) and (I < Matches.Count) and (not IsDebugMatchRow(Matches.Strings[I])) then
        begin
            Result := I;
            Exit;
        end;
    end;
end;

function SignalListFromMatches(Matches : TStringList; FindPrefix, FindSuffix, FindDiffPair : String) : String;
var
    SignalNames : TStringList;
    I           : Integer;
    PrefixValue : String;
    SignalValue : String;
    PairSide    : String;
begin
    Result := '';
    if Matches = Nil then
        Exit;

    SignalNames := TStringList.Create;
    try
        for I := 0 to Matches.Count - 1 do
        begin
            if IsDebugMatchRow(Matches.Strings[I]) then
                Continue;

            if MatchesBusQuery(RowCurrentValue(Matches.Strings[I]), FindPrefix, '', FindSuffix, FindDiffPair, PrefixValue, SignalValue, PairSide) then
                AddNameIfMissing(SignalNames, SignalValue);
        end;

        Result := JoinSignals(SignalNames);
    finally
        SignalNames.Free;
    end;
end;

procedure InferBusFieldsFromMatches(Matches : TStringList; var FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                    ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair : String);
var
    MatchedNames      : TStringList;
    OriginalFindPrefix : String;
    OriginalFindSignal : String;
    OriginalFindSuffix : String;
    OriginalFindDiffPair : String;
    InferredFindPrefix : String;
    InferredFindSignal : String;
    InferredFindSuffix : String;
    InferredFindDiffPair : String;
    InferredReplacePrefix : String;
    InferredReplaceSignal : String;
    InferredReplaceSuffix : String;
    InferredReplaceDiffPair : String;
    AutoSignalList   : String;
    I                : Integer;
begin
    if (Matches = Nil) or (Matches.Count = 0) then
        Exit;

    OriginalFindPrefix := FindPrefix;
    OriginalFindSignal := FindSignal;
    OriginalFindSuffix := FindSuffix;
    OriginalFindDiffPair := FindDiffPair;

    MatchedNames := TStringList.Create;
    try
        for I := 0 to Matches.Count - 1 do
        begin
            if IsDebugMatchRow(Matches.Strings[I]) then
                Continue;

            AddNameIfMissing(MatchedNames, RowCurrentValue(Matches.Strings[I]));
        end;

        if MatchedNames.Count <= 0 then
            Exit;

        InferBusFieldsFromSelected(MatchedNames, MatchedNames,
                                   InferredFindPrefix,
                                   InferredFindSignal,
                                   InferredFindSuffix,
                                   InferredFindDiffPair,
                                   InferredReplacePrefix,
                                   InferredReplaceSignal,
                                   InferredReplaceSuffix,
                                   InferredReplaceDiffPair);
    finally
        MatchedNames.Free;
    end;

    if Trim(OriginalFindPrefix) <> '' then
        FindPrefix := OriginalFindPrefix
    else
        FindPrefix := InferredFindPrefix;

    if Trim(OriginalFindSuffix) <> '' then
        FindSuffix := OriginalFindSuffix
    else
        FindSuffix := InferredFindSuffix;

    if Trim(OriginalFindDiffPair) <> '' then
        FindDiffPair := OriginalFindDiffPair
    else
        FindDiffPair := InferredFindDiffPair;

    if Trim(OriginalFindSignal) <> '' then
        FindSignal := OriginalFindSignal
    else
    begin
        AutoSignalList := SignalListFromMatches(Matches, FindPrefix, FindSuffix, FindDiffPair);
        if AutoSignalList <> '' then
            FindSignal := AutoSignalList
        else
            FindSignal := InferredFindSignal;
    end;

    ReplacePrefix := FindPrefix;
    ReplaceSignal := FindSignal;
    ReplaceSuffix := FindSuffix;
    ReplaceDiffPair := FindDiffPair;
end;

procedure UpdateMatchReplacementValues(Matches : TStringList; FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                       ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair : String);
var
    I           : Integer;
    RowText     : String;
    PrefixValue : String;
    SignalValue : String;
    PairSide    : String;
    NewValue    : String;
begin
    if Matches = Nil then
        Exit;

    for I := 0 to Matches.Count - 1 do
    begin
        RowText := Matches.Strings[I];
        if IsDebugMatchRow(RowText) then
            Continue;

        NewValue := RowReplaceValue(RowText);
        if MatchesBusQuery(RowCurrentValue(RowText), FindPrefix, FindSignal, FindSuffix, FindDiffPair, PrefixValue, SignalValue, PairSide) then
            NewValue := BuildBusReplacement(PrefixValue, SignalValue, PairSide, FindPrefix, FindSignal,
                                            ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair);

        Matches.Strings[I] := MakeMatchRow(RowKind(RowText),
                                           RowDocPath(RowText),
                                           RowCurrentValue(RowText),
                                           NewValue,
                                           RowKindIndex(RowText));
    end;
end;

function RenameInputError(FindPrefix, FindSignal, FindSuffix, ReplacePrefix, ReplaceSignal, ReplaceSuffix : String; RequiresReplacement : Boolean) : String;
begin
    Result := '';

    if (Trim(FindPrefix) = '') and (Trim(FindSignal) = '') and (Trim(FindSuffix) = '') then
        Result := 'Find needs at least one PREFIX, SIGNAL, or SUFFIX value.'
    else if RequiresReplacement and
            (Trim(ReplacePrefix) = '') and
            (Trim(ReplaceSignal) = '') and
            (Trim(ReplaceSuffix) = '') then
        Result := 'Replace needs at least one PREFIX, SIGNAL, or SUFFIX value.';
end;

function RunSchListPanelDiagnostic(var StatusText, ErrorText : String) : Boolean;
var
    SchDoc : ISch_Document;
begin
    Result := False;
    StatusText := '';
    ErrorText := '';

    if SchServer = Nil then
    begin
        ErrorText := 'Schematic server is not available.';
        Exit;
    end;

    SchDoc := SchServer.GetCurrentSchDocument;
    if SchDoc = Nil then
    begin
        ErrorText := 'Open a schematic sheet before opening the SCH List panel.';
        Exit;
    end;

    ResetParameters;
    AddStringParameter('Action', 'Show');
    AddStringParameter('ObjectKind', 'Panel');
    AddStringParameter('ID', 'List');
    try
        RunProcess('Client:CustomizeResources');
    except
        ResetParameters;
        ErrorText := 'SCH List panel command failed.';
        Exit;
    end;
    ResetParameters;

    StatusText := 'SCH List panel command returned.' + #13#10 +
                  'Process: Client:CustomizeResources' + #13#10 +
                  'Parameters: Action=Show, ObjectKind=Panel, ID=List' + #13#10 +
                  'Set the SCH List document selection to All Project Documents, then run Find Matches again if sheets still skip.';
    Result := True;
end;

function DebugTextShowsSkippedSheets(DebugText : String) : Boolean;
begin
    Result := Pos('WARNING:', DebugText) = 1;
end;

function BuildProjectMatchesWithSchListRetry(Project : IProject; FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                             ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair : String;
                                             SearchNetNames, SearchPorts, SearchSheetEntries : Boolean;
                                             Matches : TStringList; var DebugText, ErrorText : String;
                                             RenameForm : TForm; ReplacementMemo : TRichEdit; MatchCountLabel : TLabel) : Boolean;
var
    SchListStatusText : String;
    SchListErrorText  : String;
begin
    Result := BuildProjectMatches(Project, FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                  ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair,
                                  SearchNetNames, SearchPorts, SearchSheetEntries,
                                  Matches, DebugText, ErrorText);
    if not Result then
        Exit;

    if not DebugTextShowsSkippedSheets(DebugText) then
        Exit;

    if MatchCountLabel <> Nil then
        MatchCountLabel.Caption := 'Matches: Scanning...';
    SetReplacementStatusText(ReplacementMemo, 'Scanning...' + #13#10 + #13#10 +
                                              'Compiling Schematic Documents...' + #13#10 +
                                              'SCH List must be set to All Project Documents.' + #13#10 +
                                              'Rescanning...', UI_DARK_TEXT);
    if RenameForm <> Nil then
        RenameForm.Update;

    if not RunSchListPanelDiagnostic(SchListStatusText, SchListErrorText) then
    begin
        ErrorText := SchListErrorText;
        Result := False;
        Exit;
    end;

    Result := BuildProjectMatches(Project, FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                  ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair,
                                  SearchNetNames, SearchPorts, SearchSheetEntries,
                                  Matches, DebugText, ErrorText);
end;

function ShowRenameForm(Project : IProject; Matches : TStringList; var CurrentIndex : Integer;
                        var FindPrefix, FindSignal, FindSuffix, FindDiffPair, ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair : String;
                        var SearchNetNames, SearchPorts, SearchSheetEntries : Boolean;
                        AutoScanOnOpen : Boolean; var DebugText, ErrorText : String; var FormLeft, FormTop : Integer) : Integer;
var
    RenameForm       : TForm;
    FindPrefixEdit   : TEdit;
    FindSignalEdit   : TEdit;
    FindSuffixEdit   : TEdit;
    FindDiffPairEdit : TEdit;
    ReplacePrefixEdit : TEdit;
    ReplaceSignalEdit : TEdit;
    ReplaceSuffixEdit : TEdit;
    ReplaceDiffPairEdit : TEdit;
    MatchCountLabel  : TLabel;
    ReplacementMemo  : TRichEdit;
    HintLabel        : TLabel;
    FindNextBtn      : TButton;
    FindPrefixesBtn  : TButton;
    ReplaceBtn       : TButton;
    ReplaceAllBtn    : TButton;
    CancelBtn        : TButton;
    NetNamesCheck    : TCheckBox;
    PortsCheck       : TCheckBox;
    SheetEntriesCheck : TCheckBox;
    MatchCountText   : String;
    PreviewKey       : String;
    LastPreviewKey   : String;
    PreviewFindKey   : String;
    LastPreviewFindKey : String;
    ScopeKey         : String;
    LastScopeKey     : String;
    PreviewMatches   : TStringList;
    SelectedRow      : String;
    PreviewIndex     : Integer;
    PendingPreviewUpdate : Boolean;
    LastPreviewEditTime  : TDateTime;
    CurrentTime          : TDateTime;
    ScanFindPrefix      : String;
    ScanFindSignal      : String;
    ScanFindSuffix      : String;
    ScanFindDiffPair    : String;
    ScanReplacePrefix   : String;
    ScanReplaceSignal   : String;
    ScanReplaceSuffix   : String;
    ScanReplaceDiffPair : String;
    ScanWasUnscanned    : Boolean;
    ScanForceInfer      : Boolean;
    ScanMessageText     : String;
    AutoScanPending     : Boolean;
    RenameCount         : Integer;
    ReplaceIndex        : Integer;
    ReplaceRow          : String;
    ActionResult        : Integer;
begin
    Result := mrCancel;
    MatchCountText := '0';
    SelectedRow := '';

    if CurrentIndex = HMNI_MATCHES_NOT_SCANNED then
        MatchCountText := 'scan deferred'
    else if Matches <> Nil then
    begin
        MatchCountText := IntToStr(CountRealMatchRows(Matches));
        if (CurrentIndex >= 0) and (CurrentIndex < Matches.Count) then
            SelectedRow := Matches.Strings[CurrentIndex];
    end;

    RenameForm := TForm.Create(nil);
    PreviewMatches := TStringList.Create;
    try
        if Matches <> Nil then
            PreviewMatches.Assign(Matches);
        PendingPreviewUpdate := False;
        LastPreviewEditTime := 0;

        RenameForm.Caption := 'Hello My Name Is';
        RenameForm.Position := poDesigned;
        RenameForm.BorderStyle := bsDialog;
        RenameForm.Width := HMNI_RENAME_FORM_WIDTH;
        RenameForm.Height := HMNI_RENAME_FORM_HEIGHT;
        if (FormLeft >= 0) and (FormTop >= 0) then
        begin
            RenameForm.Left := FormLeft;
            RenameForm.Top := FormTop;
        end
        else
        begin
            RenameForm.Left := (Screen.Width - RenameForm.Width) div 2;
            RenameForm.Top := Screen.Height - RenameForm.Height - 120;
            if RenameForm.Top < 40 then
                RenameForm.Top := 40;
        end;
        ApplyDarkFormStyle(RenameForm);

        AddTopLabelEditAt(RenameForm, 'FIND>>  PREFIX', FindPrefix, HMNI_PREFIX_LEFT, 38, HMNI_PREFIX_WIDTH, FindPrefixEdit);
        AddTopLabelEditAt(RenameForm, 'SIGNAL', FindSignal, HMNI_SIGNAL_LEFT, 38, HMNI_SIGNAL_WIDTH, FindSignalEdit);
        AddTopLabelEditAt(RenameForm, 'SUFFIX', FindSuffix, HMNI_SUFFIX_LEFT, 38, HMNI_SUFFIX_WIDTH, FindSuffixEdit);
        AddTopLabelEditAt(RenameForm, 'DIFF PAIR', FindDiffPair, HMNI_DIFF_PAIR_LEFT, 38, HMNI_DIFF_PAIR_WIDTH, FindDiffPairEdit);

        AddTopLabelEditAt(RenameForm, 'REPLACE>> PREFIX', ReplacePrefix, HMNI_PREFIX_LEFT, 126, HMNI_PREFIX_WIDTH, ReplacePrefixEdit);
        AddTopLabelEditAt(RenameForm, 'SIGNAL', ReplaceSignal, HMNI_SIGNAL_LEFT, 126, HMNI_SIGNAL_WIDTH, ReplaceSignalEdit);
        AddTopLabelEditAt(RenameForm, 'SUFFIX', ReplaceSuffix, HMNI_SUFFIX_LEFT, 126, HMNI_SUFFIX_WIDTH, ReplaceSuffixEdit);
        AddTopLabelEditAt(RenameForm, 'DIFF PAIR', ReplaceDiffPair, HMNI_DIFF_PAIR_LEFT, 126, HMNI_DIFF_PAIR_WIDTH, ReplaceDiffPairEdit);

        AddScopeCheckBoxAt(RenameForm, 'Net Names', HMNI_FORM_LEFT, HMNI_SCOPE_TOP, 180, SearchNetNames, NetNamesCheck);
        AddScopeCheckBoxAt(RenameForm, 'Ports', 220, HMNI_SCOPE_TOP, 180, SearchPorts, PortsCheck);
        AddScopeCheckBoxAt(RenameForm, 'Sheet Entries', 420, HMNI_SCOPE_TOP, 180, SearchSheetEntries, SheetEntriesCheck);

        MatchCountLabel := TLabel.Create(RenameForm);
        MatchCountLabel.Parent := RenameForm;
        MatchCountLabel.Left := HMNI_FORM_LEFT;
        MatchCountLabel.Top := HMNI_MATCH_COUNT_TOP;
        MatchCountLabel.Width := 180;
        MatchCountLabel.Height := 30;
        MatchCountLabel.AutoSize := False;
        MatchCountLabel.Caption := 'Matches: ' + MatchCountText;
        ApplyDarkLabelStyle(MatchCountLabel);

        ReplacementMemo := TRichEdit.Create(RenameForm);
        ReplacementMemo.Parent := RenameForm;
        ReplacementMemo.Left := HMNI_FORM_LEFT;
        ReplacementMemo.Top := HMNI_PREVIEW_TOP;
        ReplacementMemo.Width := HMNI_PREVIEW_WIDTH;
        ReplacementMemo.Height := HMNI_PREVIEW_HEIGHT;
        ApplyDarkReplacementRichEditStyle(ReplacementMemo);
        LastPreviewKey := '';

        FindNextBtn := TButton.Create(RenameForm);
        FindNextBtn.Parent := RenameForm;
        FindNextBtn.Left := HMNI_FORM_LEFT;
        FindNextBtn.Top := HMNI_BUTTON_TOP;
        FindNextBtn.Width := 120;
        FindNextBtn.Height := 28;
        FindNextBtn.Caption := 'Find Matches';
        FindNextBtn.ModalResult := HMNI_FIND_NEXT_RESULT;
        ApplyDarkButtonStyle(FindNextBtn);

        FindPrefixesBtn := TButton.Create(RenameForm);
        FindPrefixesBtn.Parent := RenameForm;
        FindPrefixesBtn.Left := 154;
        FindPrefixesBtn.Top := HMNI_BUTTON_TOP;
        FindPrefixesBtn.Width := 120;
        FindPrefixesBtn.Height := 28;
        FindPrefixesBtn.Caption := 'Find Prefixes';
        FindPrefixesBtn.ModalResult := HMNI_FIND_PREFIXES_RESULT;
        ApplyDarkButtonStyle(FindPrefixesBtn);

        ReplaceBtn := TButton.Create(RenameForm);
        ReplaceBtn.Parent := RenameForm;
        ReplaceBtn.Left := 288;
        ReplaceBtn.Top := HMNI_BUTTON_TOP;
        ReplaceBtn.Width := 100;
        ReplaceBtn.Height := 28;
        ReplaceBtn.Caption := 'Replace';
        ReplaceBtn.ModalResult := HMNI_REPLACE_RESULT;
        ApplyDarkButtonStyle(ReplaceBtn);

        ReplaceAllBtn := TButton.Create(RenameForm);
        ReplaceAllBtn.Parent := RenameForm;
        ReplaceAllBtn.Left := 402;
        ReplaceAllBtn.Top := HMNI_BUTTON_TOP;
        ReplaceAllBtn.Width := 100;
        ReplaceAllBtn.Height := 28;
        ReplaceAllBtn.Caption := 'Replace All';
        ReplaceAllBtn.ModalResult := HMNI_REPLACE_ALL_RESULT;
        ApplyDarkButtonStyle(ReplaceAllBtn);

        CancelBtn := TButton.Create(RenameForm);
        CancelBtn.Parent := RenameForm;
        CancelBtn.Left := 516;
        CancelBtn.Top := HMNI_BUTTON_TOP;
        CancelBtn.Width := 100;
        CancelBtn.Height := 28;
        CancelBtn.Caption := 'Cancel';
        CancelBtn.ModalResult := mrCancel;
        ApplyDarkButtonStyle(CancelBtn);

        HintLabel := TLabel.Create(RenameForm);
        HintLabel.Parent := RenameForm;
        HintLabel.Left := HMNI_FORM_LEFT;
        HintLabel.Top := HMNI_HINT_TOP;
        HintLabel.Width := HMNI_PREVIEW_WIDTH;
        HintLabel.Height := HMNI_LABEL_HEIGHT;
        HintLabel.AutoSize := False;
        HintLabel.Caption := 'Hints: use \ to separate PREFIX or SIGNAL values; use P/N in DIFF PAIR for differential pairs.';
        ApplyDarkLabelStyle(HintLabel);

        RenameForm.ActiveControl := FindSignalEdit;
        PreviewKey := PreviewFieldsKey(FindPrefixEdit.Text,
                                       FindSignalEdit.Text,
                                       FindSuffixEdit.Text,
                                       FindDiffPairEdit.Text,
                                       ReplacePrefixEdit.Text,
                                       ReplaceSignalEdit.Text,
                                       ReplaceSuffixEdit.Text,
                                       ReplaceDiffPairEdit.Text);
        LastPreviewKey := PreviewKey;
        PreviewFindKey := PreviewFindFieldsKey(FindPrefixEdit.Text,
                                               FindSignalEdit.Text,
                                               FindSuffixEdit.Text,
                                               FindDiffPairEdit.Text);
        LastPreviewFindKey := PreviewFindKey;
        ScopeKey := SearchScopeKey(NetNamesCheck.Checked, PortsCheck.Checked, SheetEntriesCheck.Checked);
        LastScopeKey := ScopeKey;
        PreviewIndex := MatchingRowIndex(PreviewMatches, SelectedRow);
        PopulateReplacementRichEdit(ReplacementMemo, PreviewMatches, PreviewIndex,
                                    FindPrefixEdit.Text,
                                    FindSignalEdit.Text,
                                    FindSuffixEdit.Text,
                                    NormalizeDiffPairText(FindDiffPairEdit.Text),
                                    ReplacePrefixEdit.Text,
                                    ReplaceSignalEdit.Text,
                                    ReplaceSuffixEdit.Text,
                                    NormalizeDiffPairText(ReplaceDiffPairEdit.Text));
        RenameForm.Show;
        RenameForm.Update;
        AutoScanPending := AutoScanOnOpen;

        while RenameForm.Visible do
        begin
            if AutoScanPending then
            begin
                AutoScanPending := False;
                RenameForm.ModalResult := HMNI_FIND_NEXT_RESULT;
            end
            else
                Application.HandleMessage;

            PreviewKey := PreviewFieldsKey(FindPrefixEdit.Text,
                                           FindSignalEdit.Text,
                                           FindSuffixEdit.Text,
                                           FindDiffPairEdit.Text,
                                           ReplacePrefixEdit.Text,
                                           ReplaceSignalEdit.Text,
                                           ReplaceSuffixEdit.Text,
                                           ReplaceDiffPairEdit.Text);
            PreviewFindKey := PreviewFindFieldsKey(FindPrefixEdit.Text,
                                                   FindSignalEdit.Text,
                                                   FindSuffixEdit.Text,
                                                   FindDiffPairEdit.Text);
            ScopeKey := SearchScopeKey(NetNamesCheck.Checked, PortsCheck.Checked, SheetEntriesCheck.Checked);

            if (PreviewKey <> LastPreviewKey) or (ScopeKey <> LastScopeKey) then
            begin
                LastPreviewKey := PreviewKey;
                if (PreviewFindKey <> LastPreviewFindKey) or (ScopeKey <> LastScopeKey) then
                begin
                    LastPreviewFindKey := PreviewFindKey;
                    LastScopeKey := ScopeKey;
                    PendingPreviewUpdate := False;
                    if Matches <> Nil then
                        Matches.Clear;
                    PreviewMatches.Clear;
                    CurrentIndex := HMNI_MATCHES_NOT_SCANNED;
                    SelectedRow := '';
                    MatchCountLabel.Caption := 'Matches: scan deferred';
                    DebugText := 'Project-wide match scan is deferred until Find Matches.';
                    PreviewIndex := MatchingRowIndex(PreviewMatches, SelectedRow);
                    PopulateReplacementRichEdit(ReplacementMemo, PreviewMatches, PreviewIndex,
                                                FindPrefixEdit.Text,
                                                FindSignalEdit.Text,
                                                FindSuffixEdit.Text,
                                                NormalizeDiffPairText(FindDiffPairEdit.Text),
                                                ReplacePrefixEdit.Text,
                                                ReplaceSignalEdit.Text,
                                                ReplaceSuffixEdit.Text,
                                                NormalizeDiffPairText(ReplaceDiffPairEdit.Text));
                end
                else
                begin
                    PendingPreviewUpdate := True;
                    LastPreviewEditTime := Now;
                end;
            end;

            if PendingPreviewUpdate then
            begin
                CurrentTime := Now;
                if ((CurrentTime - LastPreviewEditTime) * 86400000) >= 1500 then
                begin
                    PendingPreviewUpdate := False;
                    UpdateMatchReplacementValues(PreviewMatches,
                                                 FindPrefixEdit.Text,
                                                 FindSignalEdit.Text,
                                                 FindSuffixEdit.Text,
                                                 NormalizeDiffPairText(FindDiffPairEdit.Text),
                                                 ReplacePrefixEdit.Text,
                                                 ReplaceSignalEdit.Text,
                                                 ReplaceSuffixEdit.Text,
                                                 NormalizeDiffPairText(ReplaceDiffPairEdit.Text));
                    MatchCountLabel.Caption := 'Matches: ' + IntToStr(CountRealMatchRows(PreviewMatches));
                    PreviewIndex := MatchingRowIndex(PreviewMatches, SelectedRow);
                    PopulateReplacementRichEdit(ReplacementMemo, PreviewMatches, PreviewIndex,
                                                FindPrefixEdit.Text,
                                                FindSignalEdit.Text,
                                                FindSuffixEdit.Text,
                                                NormalizeDiffPairText(FindDiffPairEdit.Text),
                                                ReplacePrefixEdit.Text,
                                                ReplaceSignalEdit.Text,
                                                ReplaceSuffixEdit.Text,
                                                NormalizeDiffPairText(ReplaceDiffPairEdit.Text));
                end;
            end;

            Result := RenameForm.ModalResult;
            if Result <> 0 then
            begin
                if (Result = HMNI_FIND_NEXT_RESULT) or (Result = HMNI_FIND_PREFIXES_RESULT) then
                begin
                    ScanForceInfer := Result = HMNI_FIND_PREFIXES_RESULT;
                    RenameForm.ModalResult := 0;
                    Result := 0;

                    if ScanForceInfer then
                    begin
                        FindSignalEdit.Text := '';
                        ReplaceSignalEdit.Text := '';
                    end;

                    if PendingPreviewUpdate then
                    begin
                        PendingPreviewUpdate := False;
                        UpdateMatchReplacementValues(PreviewMatches,
                                                     FindPrefixEdit.Text,
                                                     FindSignalEdit.Text,
                                                     FindSuffixEdit.Text,
                                                     NormalizeDiffPairText(FindDiffPairEdit.Text),
                                                     ReplacePrefixEdit.Text,
                                                     ReplaceSignalEdit.Text,
                                                     ReplaceSuffixEdit.Text,
                                                     NormalizeDiffPairText(ReplaceDiffPairEdit.Text));
                    end;

                    ErrorText := RenameInputError(FindPrefixEdit.Text, FindSignalEdit.Text, FindSuffixEdit.Text,
                                                  ReplacePrefixEdit.Text, ReplaceSignalEdit.Text, ReplaceSuffixEdit.Text,
                                                  False);
                    if ErrorText <> '' then
                    begin
                        MatchCountLabel.Caption := 'Matches: error';
                        SetReplacementStatusText(ReplacementMemo, ErrorText, UI_DARK_MUTED_TEXT);
                        Continue;
                    end;

                    if (not NetNamesCheck.Checked) and (not PortsCheck.Checked) and (not SheetEntriesCheck.Checked) then
                    begin
                        MatchCountLabel.Caption := 'Matches: error';
                        SetReplacementStatusText(ReplacementMemo, 'Select Net Names, Ports, or Sheet Entries to search.', UI_DARK_MUTED_TEXT);
                        Continue;
                    end;

                    ScanFindPrefix := FindPrefixEdit.Text;
                    ScanFindSignal := FindSignalEdit.Text;
                    ScanFindSuffix := FindSuffixEdit.Text;
                    ScanFindDiffPair := NormalizeDiffPairText(FindDiffPairEdit.Text);
                    ScanReplacePrefix := ReplacePrefixEdit.Text;
                    ScanReplaceSignal := ReplaceSignalEdit.Text;
                    ScanReplaceSuffix := ReplaceSuffixEdit.Text;
                    ScanReplaceDiffPair := NormalizeDiffPairText(ReplaceDiffPairEdit.Text);
                    ScanWasUnscanned := CurrentIndex = HMNI_MATCHES_NOT_SCANNED;
                    ScanMessageText := '';

                    FindPrefixEdit.Enabled := False;
                    FindSignalEdit.Enabled := False;
                    FindSuffixEdit.Enabled := False;
                    FindDiffPairEdit.Enabled := False;
                    ReplacePrefixEdit.Enabled := False;
                    ReplaceSignalEdit.Enabled := False;
                    ReplaceSuffixEdit.Enabled := False;
                    ReplaceDiffPairEdit.Enabled := False;
                    NetNamesCheck.Enabled := False;
                    PortsCheck.Enabled := False;
                    SheetEntriesCheck.Enabled := False;
                    FindNextBtn.Enabled := False;
                    FindPrefixesBtn.Enabled := False;
                    ReplaceBtn.Enabled := False;
                    ReplaceAllBtn.Enabled := False;
                    CancelBtn.Enabled := False;
                    MatchCountLabel.Caption := 'Matches: Scanning...';
                    SetReplacementStatusText(ReplacementMemo, 'Scanning...', UI_DARK_TEXT);
                    RenameForm.Update;

                    if BuildProjectMatchesWithSchListRetry(Project, ScanFindPrefix, ScanFindSignal, ScanFindSuffix, ScanFindDiffPair,
                                                           ScanReplacePrefix, ScanReplaceSignal, ScanReplaceSuffix, ScanReplaceDiffPair,
                                                           NetNamesCheck.Checked, PortsCheck.Checked, SheetEntriesCheck.Checked,
                                                           Matches, DebugText, ErrorText,
                                                           RenameForm, ReplacementMemo, MatchCountLabel) then
                    begin
                        if CountRealMatchRows(Matches) = 0 then
                        begin
                            CurrentIndex := -1;
                            if Pos('WARNING:', DebugText) = 1 then
                                ScanMessageText := DebugText
                            else
                                ScanMessageText := 'No matching objects were found.' + #13#10 + #13#10 + DebugText;
                        end
                        else
                        begin
                            if ScanWasUnscanned or ScanForceInfer then
                            begin
                                InferBusFieldsFromMatches(Matches, ScanFindPrefix, ScanFindSignal, ScanFindSuffix, ScanFindDiffPair,
                                                          ScanReplacePrefix, ScanReplaceSignal, ScanReplaceSuffix, ScanReplaceDiffPair);
                                UpdateMatchReplacementValues(Matches, ScanFindPrefix, ScanFindSignal, ScanFindSuffix, ScanFindDiffPair,
                                                             ScanReplacePrefix, ScanReplaceSignal, ScanReplaceSuffix, ScanReplaceDiffPair);
                            end;

                            if CurrentIndex < -1 then
                                CurrentIndex := -1;
                            CurrentIndex := NextRealMatchIndex(Matches, CurrentIndex);
                        end;

                        FindPrefixEdit.Text := ScanFindPrefix;
                        FindSignalEdit.Text := ScanFindSignal;
                        FindSuffixEdit.Text := ScanFindSuffix;
                        FindDiffPairEdit.Text := ScanFindDiffPair;
                        ReplacePrefixEdit.Text := ScanReplacePrefix;
                        ReplaceSignalEdit.Text := ScanReplaceSignal;
                        ReplaceSuffixEdit.Text := ScanReplaceSuffix;
                        ReplaceDiffPairEdit.Text := ScanReplaceDiffPair;

                        PreviewMatches.Assign(Matches);
                        SelectedRow := '';
                        if (CurrentIndex >= 0) and (CurrentIndex < Matches.Count) then
                            SelectedRow := Matches.Strings[CurrentIndex];
                        PreviewIndex := MatchingRowIndex(PreviewMatches, SelectedRow);
                        MatchCountLabel.Caption := 'Matches: ' + IntToStr(CountRealMatchRows(PreviewMatches));
                        if ScanMessageText <> '' then
                            SetReplacementStatusText(ReplacementMemo, ScanMessageText, UI_DARK_MUTED_TEXT)
                        else
                            PopulateReplacementRichEdit(ReplacementMemo, PreviewMatches, PreviewIndex,
                                                        FindPrefixEdit.Text,
                                                        FindSignalEdit.Text,
                                                        FindSuffixEdit.Text,
                                                        NormalizeDiffPairText(FindDiffPairEdit.Text),
                                                        ReplacePrefixEdit.Text,
                                                        ReplaceSignalEdit.Text,
                                                        ReplaceSuffixEdit.Text,
                                                        NormalizeDiffPairText(ReplaceDiffPairEdit.Text));

                        PreviewKey := PreviewFieldsKey(FindPrefixEdit.Text,
                                                       FindSignalEdit.Text,
                                                       FindSuffixEdit.Text,
                                                       FindDiffPairEdit.Text,
                                                       ReplacePrefixEdit.Text,
                                                       ReplaceSignalEdit.Text,
                                                       ReplaceSuffixEdit.Text,
                                                       ReplaceDiffPairEdit.Text);
                        LastPreviewKey := PreviewKey;
                        PreviewFindKey := PreviewFindFieldsKey(FindPrefixEdit.Text,
                                                               FindSignalEdit.Text,
                                                               FindSuffixEdit.Text,
                                                               FindDiffPairEdit.Text);
                        LastPreviewFindKey := PreviewFindKey;
                        ScopeKey := SearchScopeKey(NetNamesCheck.Checked, PortsCheck.Checked, SheetEntriesCheck.Checked);
                        LastScopeKey := ScopeKey;
                    end
                    else
                    begin
                        if CountRealMatchRows(PreviewMatches) > 0 then
                            MatchCountLabel.Caption := 'Matches: ' + IntToStr(CountRealMatchRows(PreviewMatches))
                        else
                            MatchCountLabel.Caption := 'Matches: error';
                        SetReplacementStatusText(ReplacementMemo, ErrorText, UI_DARK_MUTED_TEXT);
                        ScanMessageText := ErrorText;
                    end;

                    FindPrefixEdit.Enabled := True;
                    FindSignalEdit.Enabled := True;
                    FindSuffixEdit.Enabled := True;
                    FindDiffPairEdit.Enabled := True;
                    ReplacePrefixEdit.Enabled := True;
                    ReplaceSignalEdit.Enabled := True;
                    ReplaceSuffixEdit.Enabled := True;
                    ReplaceDiffPairEdit.Enabled := True;
                    NetNamesCheck.Enabled := True;
                    PortsCheck.Enabled := True;
                    SheetEntriesCheck.Enabled := True;
                    FindNextBtn.Enabled := True;
                    FindPrefixesBtn.Enabled := True;
                    ReplaceBtn.Enabled := True;
                    ReplaceAllBtn.Enabled := True;
                    CancelBtn.Enabled := True;

                    Continue;
                end;

                if (Result = HMNI_REPLACE_RESULT) or (Result = HMNI_REPLACE_ALL_RESULT) then
                begin
                    ActionResult := Result;
                    RenameForm.ModalResult := 0;
                    ScanMessageText := '';
                    Result := 0;

                    if PendingPreviewUpdate then
                    begin
                        PendingPreviewUpdate := False;
                        UpdateMatchReplacementValues(PreviewMatches,
                                                     FindPrefixEdit.Text,
                                                     FindSignalEdit.Text,
                                                     FindSuffixEdit.Text,
                                                     NormalizeDiffPairText(FindDiffPairEdit.Text),
                                                     ReplacePrefixEdit.Text,
                                                     ReplaceSignalEdit.Text,
                                                     ReplaceSuffixEdit.Text,
                                                     NormalizeDiffPairText(ReplaceDiffPairEdit.Text));
                    end;

                    ErrorText := RenameInputError(FindPrefixEdit.Text, FindSignalEdit.Text, FindSuffixEdit.Text,
                                                  ReplacePrefixEdit.Text, ReplaceSignalEdit.Text, ReplaceSuffixEdit.Text,
                                                  True);
                    if ErrorText <> '' then
                    begin
                        MatchCountLabel.Caption := 'Matches: error';
                        SetReplacementStatusText(ReplacementMemo, ErrorText, UI_DARK_MUTED_TEXT);
                        Continue;
                    end;

                    if CountRealMatchRows(Matches) = 0 then
                    begin
                        MatchCountLabel.Caption := 'Matches: error';
                        if ActionResult = HMNI_REPLACE_ALL_RESULT then
                            SetReplacementStatusText(ReplacementMemo, 'Click Find Matches before Replace All.', UI_DARK_MUTED_TEXT)
                        else
                            SetReplacementStatusText(ReplacementMemo, 'Click Find Matches before Replace.', UI_DARK_MUTED_TEXT);
                        Continue;
                    end;

                    if (ActionResult = HMNI_REPLACE_RESULT) and
                       ((CurrentIndex < 0) or (CurrentIndex >= Matches.Count) or IsDebugMatchRow(Matches.Strings[CurrentIndex])) then
                    begin
                        MatchCountLabel.Caption := 'Matches: error';
                        SetReplacementStatusText(ReplacementMemo, 'Click Find Matches before Replace.', UI_DARK_MUTED_TEXT);
                        Continue;
                    end;

                    ScanFindPrefix := FindPrefixEdit.Text;
                    ScanFindSignal := FindSignalEdit.Text;
                    ScanFindSuffix := FindSuffixEdit.Text;
                    ScanFindDiffPair := NormalizeDiffPairText(FindDiffPairEdit.Text);
                    ScanReplacePrefix := ReplacePrefixEdit.Text;
                    ScanReplaceSignal := ReplaceSignalEdit.Text;
                    ScanReplaceSuffix := ReplaceSuffixEdit.Text;
                    ScanReplaceDiffPair := NormalizeDiffPairText(ReplaceDiffPairEdit.Text);

                    FindPrefixEdit.Enabled := False;
                    FindSignalEdit.Enabled := False;
                    FindSuffixEdit.Enabled := False;
                    FindDiffPairEdit.Enabled := False;
                    ReplacePrefixEdit.Enabled := False;
                    ReplaceSignalEdit.Enabled := False;
                    ReplaceSuffixEdit.Enabled := False;
                    ReplaceDiffPairEdit.Enabled := False;
                    NetNamesCheck.Enabled := False;
                    PortsCheck.Enabled := False;
                    SheetEntriesCheck.Enabled := False;
                    FindNextBtn.Enabled := False;
                    FindPrefixesBtn.Enabled := False;
                    ReplaceBtn.Enabled := False;
                    ReplaceAllBtn.Enabled := False;
                    CancelBtn.Enabled := False;

                    UpdateMatchReplacementValues(Matches, ScanFindPrefix, ScanFindSignal, ScanFindSuffix, ScanFindDiffPair,
                                                 ScanReplacePrefix, ScanReplaceSignal, ScanReplaceSuffix, ScanReplaceDiffPair);

                    if ActionResult = HMNI_REPLACE_ALL_RESULT then
                    begin
                        MatchCountLabel.Caption := 'Matches: Replacing all...';
                        SetReplacementStatusText(ReplacementMemo, 'Replacing all...', UI_DARK_TEXT);
                        RenameForm.Update;

                        RenameCount := 0;
                        for ReplaceIndex := 0 to Matches.Count - 1 do
                        begin
                            ReplaceRow := Matches.Strings[ReplaceIndex];
                            if IsDebugMatchRow(ReplaceRow) then
                                Continue;

                            if RenameRowObject(ReplaceRow, ErrorText) then
                                Inc(RenameCount)
                            else
                            begin
                                ScanMessageText := 'Replace All stopped after ' + IntToStr(RenameCount) + ' object(s).' + #13#10 + #13#10 + ErrorText;
                                Break;
                            end;
                        end;
                    end
                    else
                    begin
                        MatchCountLabel.Caption := 'Matches: Replacing...';
                        SetReplacementStatusText(ReplacementMemo, 'Replacing...', UI_DARK_TEXT);
                        RenameForm.Update;

                        RenameCount := 0;
                        if RenameRowObject(Matches.Strings[CurrentIndex], ErrorText) then
                            RenameCount := 1
                        else
                            ScanMessageText := ErrorText;
                    end;

                    if ScanMessageText = '' then
                    begin
                        if not BuildProjectMatchesWithSchListRetry(Project, ScanFindPrefix, ScanFindSignal, ScanFindSuffix, ScanFindDiffPair,
                                                                   ScanReplacePrefix, ScanReplaceSignal, ScanReplaceSuffix, ScanReplaceDiffPair,
                                                                   NetNamesCheck.Checked, PortsCheck.Checked, SheetEntriesCheck.Checked,
                                                                   Matches, DebugText, ErrorText,
                                                                   RenameForm, ReplacementMemo, MatchCountLabel) then
                            ScanMessageText := ErrorText;
                    end;

                    if ScanMessageText = '' then
                    begin
                        if CountRealMatchRows(Matches) = 0 then
                            CurrentIndex := -1
                        else if (CurrentIndex >= Matches.Count) or
                                ((CurrentIndex >= 0) and IsDebugMatchRow(Matches.Strings[CurrentIndex])) then
                            CurrentIndex := FirstRealMatchIndex(Matches);

                        PreviewMatches.Assign(Matches);
                        SelectedRow := '';
                        if (CurrentIndex >= 0) and (CurrentIndex < Matches.Count) then
                            SelectedRow := Matches.Strings[CurrentIndex];
                        PreviewIndex := MatchingRowIndex(PreviewMatches, SelectedRow);
                        MatchCountLabel.Caption := 'Matches: ' + IntToStr(CountRealMatchRows(PreviewMatches));

                        if (RenameCount > 0) and (CountRealMatchRows(Matches) = 0) then
                            SetReplacementStatusText(ReplacementMemo, 'Replaced ' + IntToStr(RenameCount) + ' object(s).' + #13#10 +
                                                                      'No matching objects remain.', UI_DARK_MUTED_TEXT)
                        else
                            PopulateReplacementRichEdit(ReplacementMemo, PreviewMatches, PreviewIndex,
                                                        ScanFindPrefix,
                                                        ScanFindSignal,
                                                        ScanFindSuffix,
                                                        ScanFindDiffPair,
                                                        ScanReplacePrefix,
                                                        ScanReplaceSignal,
                                                        ScanReplaceSuffix,
                                                        ScanReplaceDiffPair);
                    end
                    else
                    begin
                        MatchCountLabel.Caption := 'Matches: error';
                        SetReplacementStatusText(ReplacementMemo, ScanMessageText, UI_DARK_MUTED_TEXT);
                    end;

                    PreviewKey := PreviewFieldsKey(FindPrefixEdit.Text,
                                                   FindSignalEdit.Text,
                                                   FindSuffixEdit.Text,
                                                   FindDiffPairEdit.Text,
                                                   ReplacePrefixEdit.Text,
                                                   ReplaceSignalEdit.Text,
                                                   ReplaceSuffixEdit.Text,
                                                   ReplaceDiffPairEdit.Text);
                    LastPreviewKey := PreviewKey;
                    PreviewFindKey := PreviewFindFieldsKey(FindPrefixEdit.Text,
                                                           FindSignalEdit.Text,
                                                           FindSuffixEdit.Text,
                                                           FindDiffPairEdit.Text);
                    LastPreviewFindKey := PreviewFindKey;
                    ScopeKey := SearchScopeKey(NetNamesCheck.Checked, PortsCheck.Checked, SheetEntriesCheck.Checked);
                    LastScopeKey := ScopeKey;

                    FindPrefixEdit.Enabled := True;
                    FindSignalEdit.Enabled := True;
                    FindSuffixEdit.Enabled := True;
                    FindDiffPairEdit.Enabled := True;
                    ReplacePrefixEdit.Enabled := True;
                    ReplaceSignalEdit.Enabled := True;
                    ReplaceSuffixEdit.Enabled := True;
                    ReplaceDiffPairEdit.Enabled := True;
                    NetNamesCheck.Enabled := True;
                    PortsCheck.Enabled := True;
                    SheetEntriesCheck.Enabled := True;
                    FindNextBtn.Enabled := True;
                    FindPrefixesBtn.Enabled := True;
                    ReplaceBtn.Enabled := True;
                    ReplaceAllBtn.Enabled := True;
                    CancelBtn.Enabled := True;

                    Continue;
                end;

                if PendingPreviewUpdate then
                begin
                    PendingPreviewUpdate := False;
                    UpdateMatchReplacementValues(PreviewMatches,
                                                 FindPrefixEdit.Text,
                                                 FindSignalEdit.Text,
                                                 FindSuffixEdit.Text,
                                                 NormalizeDiffPairText(FindDiffPairEdit.Text),
                                                 ReplacePrefixEdit.Text,
                                                 ReplaceSignalEdit.Text,
                                                 ReplaceSuffixEdit.Text,
                                                 NormalizeDiffPairText(ReplaceDiffPairEdit.Text));
                end;
                RenameForm.Hide;
                Break;
            end;
        end;

        if Result = 0 then
            Result := mrCancel;

        FormLeft := RenameForm.Left;
        FormTop := RenameForm.Top;

        FindPrefix := FindPrefixEdit.Text;
        FindSignal := FindSignalEdit.Text;
        FindSuffix := FindSuffixEdit.Text;
        FindDiffPair := NormalizeDiffPairText(FindDiffPairEdit.Text);
        ReplacePrefix := ReplacePrefixEdit.Text;
        ReplaceSignal := ReplaceSignalEdit.Text;
        ReplaceSuffix := ReplaceSuffixEdit.Text;
        ReplaceDiffPair := NormalizeDiffPairText(ReplaceDiffPairEdit.Text);
        SearchNetNames := NetNamesCheck.Checked;
        SearchPorts := PortsCheck.Checked;
        SearchSheetEntries := SheetEntriesCheck.Checked;
    finally
        PreviewMatches.Free;
        RenameForm.Free;
    end;
end;

procedure RunHelloMyNameIs;
var
    Project       : IProject;
    ErrorText     : String;
    FindPrefix    : String;
    FindSignal    : String;
    FindSuffix    : String;
    FindDiffPair  : String;
    ReplacePrefix : String;
    ReplaceSignal : String;
    ReplaceSuffix : String;
    ReplaceDiffPair : String;
    SearchNetNames : Boolean;
    SearchPorts    : Boolean;
    SearchSheetEntries : Boolean;
    Matches       : TStringList;
    SelectedNames : TStringList;
    DebugText     : String;
    FormResult    : Integer;
    CurrentIndex  : Integer;
    FormLeft      : Integer;
    FormTop       : Integer;
    AutoScanOnOpen : Boolean;
begin
    if not FocusedProject(Project, ErrorText) then
    begin
        ShowHmniMessage(ErrorText);
        Exit;
    end;

    Matches := TStringList.Create;
    SelectedNames := TStringList.Create;
    try
        if not CollectSelectedNamesOnCurrentSheet(SelectedNames, ErrorText) then
        begin
            ShowHmniMessage(ErrorText);
            Exit;
        end;

        InferBusFieldsFromSelected(SelectedNames, SelectedNames, FindPrefix, FindSignal, FindSuffix, FindDiffPair, ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair);

        SearchNetNames := True;
        SearchPorts := True;
        SearchSheetEntries := True;
        FormLeft := -1;
        FormTop := -1;
        CurrentIndex := HMNI_MATCHES_NOT_SCANNED;
        DebugText := 'Project-wide match scan is deferred until Find Matches.';
        AutoScanOnOpen := SelectedNames.Count > 0;

        repeat
            FormResult := ShowRenameForm(Project, Matches, CurrentIndex,
                                         FindPrefix, FindSignal, FindSuffix, FindDiffPair,
                                         ReplacePrefix, ReplaceSignal, ReplaceSuffix, ReplaceDiffPair,
                                         SearchNetNames, SearchPorts, SearchSheetEntries,
                                         AutoScanOnOpen, DebugText, ErrorText, FormLeft, FormTop);
            AutoScanOnOpen := False;

            if FormResult = mrCancel then
                Exit;
        until False;
    finally
        SelectedNames.Free;
        Matches.Free;
    end;
end;
