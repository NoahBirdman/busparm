# Hello My Name Is

Project-wide helper for renaming schematic net labels, ports, and sheet entries.

## What It Does

- Starts blank, or pre-fills from selected net labels, ports, or sheet entries on
  the active schematic.
- Finds matching net identifiers across focused-project schematic documents that
  are already available through Altium's schematic server.
- Builds a bus query from `PREFIX`, `SIGNAL`, `SUFFIX`, and `DIFF PAIR` fields.
- Supports bus replacement with the same field shape.
- Lets you choose whether project search includes net names, ports, and sheet
  entries.
- Shows the number of project-wide matches in the bottom-left of the form.
- Shows matched rename candidates in the preview list with current value,
  replacement value, object type, and sheet name.

## How To Run

1. Open the target PCB project in Altium Designer.
2. Optionally select one or more supported schematic objects to pre-fill the bus
   query:
   - Net label
   - Port
   - Sheet entry
3. Run:

```text
HELLO_MY_NAME_IS.pas>RunHelloMyNameIs
```

Or use `Red 6 > Hello My Name Is` after running the Red 6 menu installer.

## Bus Query

The form has Find and Replace rows. Each row has:

- `PREFIX`
- `SIGNAL`
- `SUFFIX`
- `DIFF PAIR`

The object-type checkboxes below the Replace row control which supported
schematic objects are searched and replaced:

- `Net Names`
- `Ports`
- `Sheet Entries`

Use the buttons along the bottom to move through the project:

- `Find Matches`
- `Find Prefixes`
- `Replace`
- `Replace All`
- `Cancel`

Changing any Find field clears the cached matches until `Find Matches` is
clicked. Changing Replace fields keeps the current cached matches and updates
the preview replacement text without rescanning the project. Replace-field
preview updates are delayed by about 1.5 seconds after typing stops.

Matched rows are shown alphabetically by current net name.

If the tool opens with selected net identifiers, it populates the Find and
Replace fields, shows the form, then starts the project scan in the same
in-form scanning state used by `Find Matches`. If nothing is selected, it opens
blank and waits for `Find Matches`.

`Find Matches` keeps the form open. The controls are disabled while the
project-wide scan runs, the preview shows `Scanning...`, then the Find/Replace
fields and preview list are redrawn in place.

If a project scan reports skipped schematic documents, the tool automatically
opens the SCH List panel, shows `Compiling Schematic Documents...` and
`Rescanning...`, then runs the same scan again. The SCH List document selection
must be set to `All Project Documents` for this to hydrate closed project
sheets. If any sheets still cannot be read through Altium's schematic server,
the warning remains at the top of the matches output with the skipped sheet
names.

`Find Prefixes` clears the Find and Replace `SIGNAL` fields, runs the same
project-wide scan, then refreshes the inferred Find/Replace fields from the
matches.

Find/search errors such as empty search fields, no implemented object type
selected, or no matches found are shown in the preview box instead of a popup.

`Replace` and `Replace All` also keep the form open. Controls are disabled while
the schematic objects are updated, and completion or error text appears in the
preview box.

After a fresh `Find Matches`, the matched net names are treated like selected
objects: the tool infers and populates Find `PREFIX`, `SIGNAL`, `SUFFIX`, and
`DIFF PAIR`, then mirrors those values into the Replace fields. Any non-blank
Find fields you typed are kept as the search constraint while the remaining
fields are filled from the matches.

If one net name is selected, the selected name is placed in `SIGNAL`.

If multiple net names are selected, the tool infers the shared prefix and suffix,
then places the signal names in `SIGNAL` separated by ` \ `:

```text
I2C_SNS_SDA + I2C_SNS_SCL
PREFIX = I2C_SNS_
SIGNAL = SDA \ SCL
SUFFIX =
```

When selected names contain repeated signals under multiple delimiter-ended
prefixes, the tool infers grouped prefixes:

```text
ENET0_D0 + ENET0_D1 + ENET1_D0 + ENET1_D1
PREFIX = ENET0_ \ ENET1_
SIGNAL = D0 \ D1
SUFFIX =
```

`PREFIX` also accepts ` \ ` separated lists. If `SIGNAL` is blank when
`Find Matches` runs, a multi-prefix search fills `SIGNAL` and Replace `SIGNAL`
from the matched signals. Replacement prefixes are mapped by list position:

```text
PREFIX = ENET2_ETH0 \ ENET2_ETH1
SIGNAL =

Replace PREFIX = ETH3 \ ETH4

ENET2_ETH0D0 -> ETH3D0
ENET2_ETH1D0 -> ETH4D0
```

If selected/project nets include matching `_P` and `_N` names, `DIFF PAIR` is
set to `P/N`:

```text
PCIE_CPU_RX_0_P + PCIE_CPU_RX_0_N
SIGNAL = PCIE_CPU_RX_0
DIFF PAIR = P/N
```

## Required Altium State

- A schematic sheet must be active.
- The target PCB project must be focused in the Projects panel.
- Project schematic documents are searched through Altium's schematic server.
  The search path does not call `Client.OpenDocument`, does not run Altium's
  schematic filter parser, and does not clear schematic filters or masks.
  If source-path lookup fails, the tool also tries matching compiled/physical
  project documents before reporting a sheet as skipped in the debug text.
- If Altium does not expose a project sheet through those document APIs, the
  matches box shows a warning at the top. Change the SCH List document
  selection to `All Project Documents`, then run `Find Matches` again. If sheets
  still skip, open the skipped sheet or reload the project, then try again.

Final validation for object mutation must be done inside Altium Designer.
