# NextRev

Altium Designer script project for updating out-of-date Workspace component revisions in controlled batches.

Planned workflow:

- Load any existing filtered revision-warning list from the Messages panel.
- Validate the focused project only when `Validate Revisions` is clicked.
- Find the next out-of-date component revision warning or error.
- Cross-probe to that component.
- Clear stale component selections.
- Select similar components by matching `Description`.
- Show the matched count and seed component details.
- Offer `Validate Revisions`, `Select One`, `Select All`, `Skip`, and `Cancel`.
- For selection actions, hand off to Altium's Properties panel so the user can apply the latest revision with the built-in component update button.

Current implementation:

- On startup, loads any existing `Component revision is Out of Date` rows from the Messages panel without revalidating.
- `Validate Revisions` validates the focused project and rebuilds the Messages panel with all out-of-date revision rows and their original cross-probe callbacks.
- Invokes Altium's built-in Messages-panel cross-probe command.
- Reports the seed component, parsed seed description, and count of filtered revision rows with the same description text.
- Shows `All Designators` as a CSV list of matching-description designators from the filtered revision warnings.
- Shows a dark themed action form with top-level fields and selection action buttons.
- Keeps the copyable debug output collapsed by default behind a `Show Debug` toggle.
- `Skip` removes the current first filtered revision row and advances/cross-probes to the next revision row.
- Populates Red 6 Part Number from component parameters.
- `Select One` clears the schematic filter/mask and existing component selection, selects only the current seed component, removes it from the filtered Messages list, opens the Properties panel, then exits.
- `Select All` clears the schematic filter/mask and existing component selection, selects matching components found on the active schematic sheet, removes those selected components from the filtered Messages list, opens the Properties panel, then exits.

Run procedure:

```text
NEXTREV.pas>RunNextRev
```
