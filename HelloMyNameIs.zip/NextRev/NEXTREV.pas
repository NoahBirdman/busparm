{ Altium Designer DelphiScript
  Validates the focused PCB project, finds out-of-date component revisions,
  and helps update matching components to their latest revisions.

  Run procedure: RunNextRev
}

uses
    SysUtils,
    Classes,
    Dialogs,
    Forms,
    Controls,
    StdCtrls;

const
    UI_DARK_BACKGROUND = $00302D2B;
    UI_DARK_CONTROL = $002A2725;
    UI_DARK_FIELD = $001E1E1E;
    UI_DARK_TEXT = $00E3DDD7;
    UI_DARK_MUTED_TEXT = $00BFB6AE;
    NEXTREV_SELECT_ONE_RESULT = 101;
    NEXTREV_SKIP_RESULT = 102;
    NEXTREV_SELECT_ALL_RESULT = 103;
    NEXTREV_VALIDATE_RESULT = 104;
    NEXTREV_DEBUG_TOGGLE_RESULT = 105;
    NEXTREV_FORM_COLLAPSED_HEIGHT = 330;
    NEXTREV_FORM_EXPANDED_HEIGHT = 520;
    NEXTREV_FIELD_TOP = 24;
    NEXTREV_FIELD_HEIGHT = 22;
    NEXTREV_FIELD_VERTICAL_GAP = 12;
    NEXTREV_LABEL_FIELD_GAP = 18;
    NEXTREV_MAIN_LABEL_LEFT = 20;
    NEXTREV_MAIN_LABEL_WIDTH = 145;
    NEXTREV_MAIN_TEXT_WIDTH = 675;
    NEXTREV_BUTTON_HEIGHT = 28;
    NEXTREV_BUTTON_TOP_GAP = 24;
    NEXTREV_DEBUG_TOP_GAP = 34;
    NEXTREV_MEMO_ROW_HEIGHT = 17;
    NEXTREV_MEMO_VERTICAL_PADDING = 8;
    NEXTREV_DESIGNATOR_ROW_COUNT = 4;

var
    NextRevDebugExpanded : Boolean;
    NextRevDebugLabel    : TLabel;
    NextRevDebugMemo     : TMemo;
    NextRevDebugButton   : TButton;
    NextRevDebugForm     : TForm;

procedure ShowCopyableMessage(Title, MessageText : String);
var
    MessageForm : TForm;
    MessageMemo : TMemo;
    OkButton    : TButton;
begin
    MessageForm := TForm.Create(nil);
    try
        MessageForm.Caption := Title;
        MessageForm.Position := poScreenCenter;
        MessageForm.BorderStyle := bsDialog;
        MessageForm.Width := 720;
        MessageForm.Height := 420;

        MessageMemo := TMemo.Create(MessageForm);
        MessageMemo.Parent := MessageForm;
        MessageMemo.Left := 12;
        MessageMemo.Top := 12;
        MessageMemo.Width := MessageForm.ClientWidth - 24;
        MessageMemo.Height := MessageForm.ClientHeight - 56;
        MessageMemo.ReadOnly := True;
        MessageMemo.WordWrap := False;
        MessageMemo.ScrollBars := ssBoth;
        MessageMemo.Text := MessageText;

        OkButton := TButton.Create(MessageForm);
        OkButton.Parent := MessageForm;
        OkButton.Caption := 'OK';
        OkButton.Width := 88;
        OkButton.Height := 26;
        OkButton.Left := MessageForm.ClientWidth - OkButton.Width - 12;
        OkButton.Top := MessageForm.ClientHeight - OkButton.Height - 10;
        OkButton.ModalResult := mrOK;

        MessageForm.ActiveControl := MessageMemo;
        MessageMemo.SelectAll;
        MessageForm.ShowModal;
    finally
        MessageForm.Free;
    end;
end;

procedure ShowNextRevMessage(MessageText : String);
begin
    ShowCopyableMessage('NextRev', MessageText);
end;

procedure ApplyDarkFormStyle(AForm : TForm);
begin
    AForm.Color := UI_DARK_BACKGROUND;
    AForm.Font.Name := 'Segoe UI';
    AForm.Font.Size := 9;
    AForm.Font.Color := UI_DARK_TEXT;
end;

procedure ApplyDarkLabelStyle(ALabel : TLabel);
begin
    ALabel.Transparent := True;
    ALabel.Font.Color := UI_DARK_MUTED_TEXT;
end;

procedure ApplyDarkValueLabelStyle(ALabel : TLabel);
begin
    ALabel.Transparent := True;
    ALabel.Font.Color := UI_DARK_TEXT;
end;

procedure ApplyDarkMemoStyle(AMemo : TMemo);
begin
    AMemo.Color := UI_DARK_FIELD;
    AMemo.Font.Color := UI_DARK_TEXT;
    AMemo.ReadOnly := True;
    AMemo.WordWrap := False;
    AMemo.ScrollBars := ssBoth;
    AMemo.Ctl3D := False;
end;

procedure ApplyDarkButtonStyle(AButton : TButton);
begin
    AButton.Font.Color := UI_DARK_TEXT;
end;

procedure AddPlainTextAt(AOwner : TForm; CaptionText, ValueText : String; LeftValue, TopValue, LabelWidthValue, TextWidthValue : Integer; var TextRef : TLabel);
var
    LabelRef : TLabel;
begin
    LabelRef := TLabel.Create(AOwner);
    LabelRef.Parent := AOwner;
    LabelRef.Left := LeftValue;
    LabelRef.Top := TopValue + 4;
    LabelRef.Width := LabelWidthValue;
    LabelRef.Height := NEXTREV_FIELD_HEIGHT;
    LabelRef.AutoSize := False;
    LabelRef.Alignment := taRightJustify;
    LabelRef.Caption := CaptionText;
    ApplyDarkLabelStyle(LabelRef);

    TextRef := TLabel.Create(AOwner);
    TextRef.Parent := AOwner;
    TextRef.Left := LeftValue + LabelWidthValue + NEXTREV_LABEL_FIELD_GAP;
    TextRef.Top := TopValue + 4;
    TextRef.Width := TextWidthValue;
    TextRef.Height := NEXTREV_FIELD_HEIGHT;
    TextRef.AutoSize := False;
    TextRef.Caption := ValueText;
    ApplyDarkValueLabelStyle(TextRef);
end;

procedure AddPlainText(AOwner : TForm; CaptionText, ValueText : String; TopValue : Integer; var TextRef : TLabel);
begin
    AddPlainTextAt(AOwner, CaptionText, ValueText, 20, TopValue, 130, 720, TextRef);
end;

procedure AddPlainMemoText(AOwner : TForm; CaptionText, ValueText : String; LeftValue, TopValue, LabelWidthValue, MemoWidthValue, HeightValue : Integer; var MemoRef : TMemo);
var
    LabelRef : TLabel;
begin
    LabelRef := TLabel.Create(AOwner);
    LabelRef.Parent := AOwner;
    LabelRef.Left := LeftValue;
    LabelRef.Top := TopValue + 4;
    LabelRef.Width := LabelWidthValue;
    LabelRef.Height := NEXTREV_FIELD_HEIGHT;
    LabelRef.AutoSize := False;
    LabelRef.Alignment := taRightJustify;
    LabelRef.Caption := CaptionText;
    ApplyDarkLabelStyle(LabelRef);

    MemoRef := TMemo.Create(AOwner);
    MemoRef.Parent := AOwner;
    MemoRef.Left := LeftValue + LabelWidthValue + NEXTREV_LABEL_FIELD_GAP;
    MemoRef.Top := TopValue;
    MemoRef.Width := MemoWidthValue;
    MemoRef.Height := HeightValue;
    MemoRef.Text := ValueText;
    ApplyDarkMemoStyle(MemoRef);
    MemoRef.Color := UI_DARK_BACKGROUND;
    MemoRef.ReadOnly := True;
    MemoRef.BorderStyle := bsNone;
    MemoRef.ScrollBars := ssNone;
end;

procedure ApplyNextRevDebugVisibility;
begin
    if NextRevDebugForm = Nil then
        Exit;

    if NextRevDebugLabel <> Nil then
        NextRevDebugLabel.Visible := NextRevDebugExpanded;

    if NextRevDebugMemo <> Nil then
    begin
        NextRevDebugMemo.Visible := NextRevDebugExpanded;
        if NextRevDebugExpanded then
            NextRevDebugMemo.SelectAll;
    end;

    if NextRevDebugButton <> Nil then
    begin
        if NextRevDebugExpanded then
            NextRevDebugButton.Caption := 'Hide Debug'
        else
            NextRevDebugButton.Caption := 'Show Debug';
    end;

    if NextRevDebugExpanded then
        NextRevDebugForm.Height := NEXTREV_FORM_EXPANDED_HEIGHT
    else
        NextRevDebugForm.Height := NEXTREV_FORM_COLLAPSED_HEIGHT;
end;

function ShowNextRevActionForm(Red6PartNumber, DescriptionText, DesignatorText, TotalNumberText, AllDesignatorsText, DebugText : String; HasCurrentRevision : Boolean) : Integer;
var
    NextRevForm       : TForm;
    Red6PartLabel     : TLabel;
    DescriptionLabel  : TLabel;
    DesignatorLabel   : TLabel;
    TotalNumberLabel  : TLabel;
    AllDesignatorsMemo: TMemo;
    SelectAllBtn      : TButton;
    SelectOneBtn      : TButton;
    ValidateBtn       : TButton;
    SkipBtn           : TButton;
    CancelBtn         : TButton;
    DebugToggleBtn    : TButton;
    DebugLabel        : TLabel;
    DebugMemo         : TMemo;
    FormResult        : Integer;
    DebugExpanded     : Boolean;
    DescriptionTop    : Integer;
    AllDesignatorsTop : Integer;
    AllDesignatorsHeight : Integer;
    ButtonTop         : Integer;
    DebugLabelTop     : Integer;
    DebugMemoTop      : Integer;
begin
    Result := mrCancel;
    DebugExpanded := False;
    DescriptionTop := NEXTREV_FIELD_TOP + NEXTREV_FIELD_HEIGHT + NEXTREV_FIELD_VERTICAL_GAP;
    AllDesignatorsTop := DescriptionTop + NEXTREV_FIELD_HEIGHT + NEXTREV_FIELD_VERTICAL_GAP;
    AllDesignatorsHeight := (NEXTREV_DESIGNATOR_ROW_COUNT * NEXTREV_MEMO_ROW_HEIGHT) + NEXTREV_MEMO_VERTICAL_PADDING;
    ButtonTop := AllDesignatorsTop + AllDesignatorsHeight + NEXTREV_BUTTON_TOP_GAP;
    DebugLabelTop := ButtonTop + NEXTREV_BUTTON_HEIGHT + NEXTREV_DEBUG_TOP_GAP;
    DebugMemoTop := DebugLabelTop + NEXTREV_FIELD_HEIGHT;

    repeat
        NextRevForm := TForm.Create(nil);
        try
            NextRevForm.Caption := 'NextRev';
            NextRevForm.Position := poScreenCenter;
            NextRevForm.BorderStyle := bsDialog;
            NextRevForm.Width := 900;
            NextRevForm.Height := NEXTREV_FORM_COLLAPSED_HEIGHT;
            ApplyDarkFormStyle(NextRevForm);

            AddPlainTextAt(NextRevForm, 'Designator:', DesignatorText, NEXTREV_MAIN_LABEL_LEFT, NEXTREV_FIELD_TOP, NEXTREV_MAIN_LABEL_WIDTH, 70, DesignatorLabel);
            AddPlainTextAt(NextRevForm, 'Red 6 Part Number:', Red6PartNumber, 285, NEXTREV_FIELD_TOP, 180, 150, Red6PartLabel);
            AddPlainTextAt(NextRevForm, 'Total Number:', TotalNumberText, 655, NEXTREV_FIELD_TOP, 120, 70, TotalNumberLabel);
            AddPlainTextAt(NextRevForm, 'Description:', DescriptionText, NEXTREV_MAIN_LABEL_LEFT, DescriptionTop, NEXTREV_MAIN_LABEL_WIDTH, NEXTREV_MAIN_TEXT_WIDTH, DescriptionLabel);
            AddPlainMemoText(NextRevForm, 'All Designators:', AllDesignatorsText, NEXTREV_MAIN_LABEL_LEFT, AllDesignatorsTop, NEXTREV_MAIN_LABEL_WIDTH, NEXTREV_MAIN_TEXT_WIDTH, AllDesignatorsHeight, AllDesignatorsMemo);
            AllDesignatorsMemo.WordWrap := True;
            AllDesignatorsMemo.ScrollBars := ssNone;

            ValidateBtn := TButton.Create(NextRevForm);
            ValidateBtn.Parent := NextRevForm;
            ValidateBtn.Left := 40;
            ValidateBtn.Top := ButtonTop;
            ValidateBtn.Width := 150;
            ValidateBtn.Height := NEXTREV_BUTTON_HEIGHT;
            ValidateBtn.Caption := 'Validate Revisions';
            ValidateBtn.ModalResult := NEXTREV_VALIDATE_RESULT;
            ApplyDarkButtonStyle(ValidateBtn);

            SelectOneBtn := TButton.Create(NextRevForm);
            SelectOneBtn.Parent := NextRevForm;
            SelectOneBtn.Left := 200;
            SelectOneBtn.Top := ButtonTop;
            SelectOneBtn.Width := 120;
            SelectOneBtn.Height := NEXTREV_BUTTON_HEIGHT;
            SelectOneBtn.Caption := 'Select One';
            SelectOneBtn.ModalResult := NEXTREV_SELECT_ONE_RESULT;
            SelectOneBtn.Enabled := HasCurrentRevision;
            ApplyDarkButtonStyle(SelectOneBtn);

            SelectAllBtn := TButton.Create(NextRevForm);
            SelectAllBtn.Parent := NextRevForm;
            SelectAllBtn.Left := 328;
            SelectAllBtn.Top := ButtonTop;
            SelectAllBtn.Width := 120;
            SelectAllBtn.Height := NEXTREV_BUTTON_HEIGHT;
            SelectAllBtn.Caption := 'Select All';
            SelectAllBtn.ModalResult := NEXTREV_SELECT_ALL_RESULT;
            SelectAllBtn.Enabled := HasCurrentRevision;
            ApplyDarkButtonStyle(SelectAllBtn);

            SkipBtn := TButton.Create(NextRevForm);
            SkipBtn.Parent := NextRevForm;
            SkipBtn.Left := 456;
            SkipBtn.Top := ButtonTop;
            SkipBtn.Width := 120;
            SkipBtn.Height := NEXTREV_BUTTON_HEIGHT;
            SkipBtn.Caption := 'Skip';
            SkipBtn.ModalResult := NEXTREV_SKIP_RESULT;
            SkipBtn.Enabled := HasCurrentRevision;
            ApplyDarkButtonStyle(SkipBtn);

            CancelBtn := TButton.Create(NextRevForm);
            CancelBtn.Parent := NextRevForm;
            CancelBtn.Left := 584;
            CancelBtn.Top := ButtonTop;
            CancelBtn.Width := 120;
            CancelBtn.Height := NEXTREV_BUTTON_HEIGHT;
            CancelBtn.Caption := 'Cancel';
            CancelBtn.ModalResult := mrCancel;
            ApplyDarkButtonStyle(CancelBtn);

            DebugToggleBtn := TButton.Create(NextRevForm);
            DebugToggleBtn.Parent := NextRevForm;
            DebugToggleBtn.Left := 712;
            DebugToggleBtn.Top := ButtonTop;
            DebugToggleBtn.Width := 120;
            DebugToggleBtn.Height := NEXTREV_BUTTON_HEIGHT;
            DebugToggleBtn.Caption := 'Show Debug';
            DebugToggleBtn.ModalResult := NEXTREV_DEBUG_TOGGLE_RESULT;
            ApplyDarkButtonStyle(DebugToggleBtn);

            DebugLabel := TLabel.Create(NextRevForm);
            DebugLabel.Parent := NextRevForm;
            DebugLabel.Left := 20;
            DebugLabel.Top := DebugLabelTop;
            DebugLabel.Width := 160;
            DebugLabel.Caption := 'Debug output';
            ApplyDarkLabelStyle(DebugLabel);

            DebugMemo := TMemo.Create(NextRevForm);
            DebugMemo.Parent := NextRevForm;
            DebugMemo.Left := 20;
            DebugMemo.Top := DebugMemoTop;
            DebugMemo.Width := 780;
            DebugMemo.Height := 170;
            DebugMemo.Text := DebugText;
            ApplyDarkMemoStyle(DebugMemo);

            NextRevDebugExpanded := DebugExpanded;
            NextRevDebugForm := NextRevForm;
            NextRevDebugLabel := DebugLabel;
            NextRevDebugMemo := DebugMemo;
            NextRevDebugButton := DebugToggleBtn;
            ApplyNextRevDebugVisibility;

            NextRevForm.ActiveControl := ValidateBtn;
            FormResult := NextRevForm.ShowModal;
        finally
            NextRevDebugForm := Nil;
            NextRevDebugLabel := Nil;
            NextRevDebugMemo := Nil;
            NextRevDebugButton := Nil;
            NextRevForm.Free;
        end;

        if FormResult = NEXTREV_DEBUG_TOGGLE_RESULT then
            DebugExpanded := not DebugExpanded
        else
            Result := FormResult;
    until FormResult <> NEXTREV_DEBUG_TOGGLE_RESULT;
end;

function SameTextLocal(A, B : String) : Boolean;
begin
    Result := UpperCase(Trim(A)) = UpperCase(Trim(B));
end;

function ContainsTextLocal(Value, Fragment : String) : Boolean;
begin
    Result := Pos(UpperCase(Fragment), UpperCase(Value)) > 0;
end;

function StartsWithTextLocal(Value, Prefix : String) : Boolean;
begin
    Result := Copy(UpperCase(Trim(Value)), 1, Length(Prefix)) = UpperCase(Prefix);
end;

function TextBefore(Value, Marker : String) : String;
var
    MarkerAt : Integer;
begin
    Result := Value;
    MarkerAt := Pos(UpperCase(Marker), UpperCase(Value));
    if MarkerAt > 0 then
        Result := Copy(Value, 1, MarkerAt - 1);
end;

function TextAfter(Value, Marker : String) : String;
var
    MarkerAt : Integer;
begin
    Result := '';
    MarkerAt := Pos(UpperCase(Marker), UpperCase(Value));
    if MarkerAt > 0 then
        Result := Copy(Value, MarkerAt + Length(Marker), Length(Value));
end;

function FirstWord(Value : String) : String;
var
    SpaceAt : Integer;
    S       : String;
begin
    S := Trim(Value);
    SpaceAt := Pos(' ', S);
    if SpaceAt > 0 then
        Result := Copy(S, 1, SpaceAt - 1)
    else
        Result := S;
end;

function ExtractRevisionMessageBody(MessageText : String) : String;
begin
    Result := TextAfter(MessageText, 'Component ');
    Result := TextBefore(Result, ': Component revision is Out of Date');
    Result := TextBefore(Result, ' at ');
    Result := Trim(Result);
end;

function ExtractRevisionDesignator(MessageText : String) : String;
begin
    Result := FirstWord(ExtractRevisionMessageBody(MessageText));
end;

function ExtractRevisionDescription(MessageText : String) : String;
var
    Body       : String;
    Designator : String;
begin
    Result := '';
    Body := ExtractRevisionMessageBody(MessageText);
    Designator := FirstWord(Body);

    if Designator <> '' then
        Result := Trim(Copy(Body, Length(Designator) + 1, Length(Body)));
end;

function ComponentDesignator(Component : ISch_Component) : String;
var
    Designator : ISch_Designator;
begin
    Result := '';
    if Component = Nil then
        Exit;

    Designator := Component.GetState_SchDesignator;
    if Designator <> Nil then
        Result := Trim(Designator.Text);
end;

function FindComponentOnCurrentSheet(DesignatorText : String) : ISch_Component;
var
    SchDoc    : ISch_Document;
    Iterator  : ISch_Iterator;
    Component : ISch_Component;
begin
    Result := Nil;

    if SchServer = Nil then
        Exit;

    SchDoc := SchServer.GetCurrentSchDocument;
    if SchDoc = Nil then
        Exit;

    Iterator := SchDoc.SchIterator_Create;
    if Iterator = Nil then
        Exit;

    try
        Iterator.AddFilter_ObjectSet(MkSet(eSchComponent));
        Component := Iterator.FirstSchObject;
        while Component <> Nil do
        begin
            if SameTextLocal(ComponentDesignator(Component), DesignatorText) then
            begin
                Result := Component;
                Exit;
            end;

            Component := Iterator.NextSchObject;
        end;
    finally
        SchDoc.SchIterator_Destroy(Iterator);
    end;
end;

procedure ClearComponentSelectionOnCurrentSheet;
var
    SchDoc    : ISch_Document;
    Iterator  : ISch_Iterator;
    Component : ISch_Component;
begin
    if SchServer = Nil then
        Exit;

    SchDoc := SchServer.GetCurrentSchDocument;
    if SchDoc = Nil then
        Exit;

    Iterator := SchDoc.SchIterator_Create;
    if Iterator = Nil then
        Exit;

    try
        Iterator.AddFilter_ObjectSet(MkSet(eSchComponent));
        Component := Iterator.FirstSchObject;
        while Component <> Nil do
        begin
            Component.Selection := False;
            Component := Iterator.NextSchObject;
        end;
    finally
        SchDoc.SchIterator_Destroy(Iterator);
    end;
end;

function ComponentParameterValue(Component : ISch_Component; ParameterName : String) : String;
var
    Iterator  : ISch_Iterator;
    Parameter : ISch_Parameter;
begin
    Result := '';

    if Component = Nil then
        Exit;

    Iterator := Component.SchIterator_Create;
    if Iterator = Nil then
        Exit;

    try
        Iterator.SetState_IterationDepth(eIterateFirstLevel);
        Iterator.AddFilter_ObjectSet(MkSet(eParameter));
        Parameter := Iterator.FirstSchObject;
        while Parameter <> Nil do
        begin
            if SameTextLocal(Parameter.Name, ParameterName) then
            begin
                Result := Trim(Parameter.GetState_Text);
                Exit;
            end;

            Parameter := Iterator.NextSchObject;
        end;
    finally
        Component.SchIterator_Destroy(Iterator);
    end;
end;

function FirstComponentParameterValue(Component : ISch_Component; Name1, Name2, Name3, Name4, Name5 : String) : String;
begin
    Result := '';

    if Name1 <> '' then
        Result := ComponentParameterValue(Component, Name1);
    if (Result = '') and (Name2 <> '') then
        Result := ComponentParameterValue(Component, Name2);
    if (Result = '') and (Name3 <> '') then
        Result := ComponentParameterValue(Component, Name3);
    if (Result = '') and (Name4 <> '') then
        Result := ComponentParameterValue(Component, Name4);
    if (Result = '') and (Name5 <> '') then
        Result := ComponentParameterValue(Component, Name5);
end;

function ComponentParameterDebugText(Component : ISch_Component) : String;
var
    Iterator  : ISch_Iterator;
    Parameter : ISch_Parameter;
    Count     : Integer;
begin
    Result := '';
    Count := 0;

    if Component = Nil then
        Exit;

    Iterator := Component.SchIterator_Create;
    if Iterator = Nil then
        Exit;

    try
        Iterator.SetState_IterationDepth(eIterateFirstLevel);
        Iterator.AddFilter_ObjectSet(MkSet(eParameter));
        Parameter := Iterator.FirstSchObject;
        while Parameter <> Nil do
        begin
            Inc(Count);
            if (Count <= 80) and
               (ContainsTextLocal(Parameter.Name, 'Design') or
                ContainsTextLocal(Parameter.Name, 'Item') or
                ContainsTextLocal(Parameter.Name, 'Item ID') or
                ContainsTextLocal(Parameter.Name, 'ItemID') or
                ContainsTextLocal(Parameter.Name, 'Revision') or
                ContainsTextLocal(Parameter.Name, 'Revision ID') or
                ContainsTextLocal(Parameter.Name, 'RevisionID') or
                ContainsTextLocal(Parameter.Name, 'Part') or
                ContainsTextLocal(Parameter.Name, 'Red') or
                ContainsTextLocal(Parameter.Name, 'Component')) then
            begin
                Result := Result + Parameter.Name + ' = ' + Trim(Parameter.GetState_Text) + #13#10;
            end;

            Parameter := Iterator.NextSchObject;
        end;
    finally
        Component.SchIterator_Destroy(Iterator);
    end;

    if Result = '' then
        Result := 'No matching component parameter names were found in the diagnostic filter.';
end;

procedure CaptureSeedComponentIds(DesignatorText : String; var Red6PartNumber, CaptureDebug : String);
var
    Component : ISch_Component;
begin
    Red6PartNumber := 'Not captured';
    CaptureDebug := '';

    Component := FindComponentOnCurrentSheet(DesignatorText);
    if Component = Nil then
    begin
        CaptureDebug := 'Could not locate cross-probed component on the current schematic sheet for designator ' + DesignatorText + '.';
        Exit;
    end;

    Red6PartNumber := FirstComponentParameterValue(Component, 'Red 6 Part Number', 'RED6_PART_NUMBER', 'R6 Part Number', 'R6_PART_NUMBER', 'Part Number');

    if Red6PartNumber = '' then
        Red6PartNumber := 'Not captured';

    CaptureDebug := 'Captured values from current schematic component ' + ComponentDesignator(Component) + '.' + #13#10 +
                    'Red 6 Part Number: ' + Red6PartNumber + #13#10 + #13#10 +
                    'Component parameter diagnostic:' + #13#10 +
                    ComponentParameterDebugText(Component);
end;

function CompileFocusedProject(var Project : IProject; var ErrorText : String) : Boolean;
var
    WS : IWorkspace;
begin
    Result := False;
    Project := Nil;
    ErrorText := '';

    WS := GetWorkspace;
    if WS = Nil then
    begin
        ErrorText := 'Workspace Manager is not available.';
        Exit;
    end;

    Project := WS.DM_FocusedProject;
    if Project = Nil then
    begin
        ErrorText := 'Focus the target PCB project in the Projects panel, then run NextRev again.';
        Exit;
    end;

    Project.DM_ClearViolations;
    if not Project.DM_Compile then
    begin
        ErrorText := 'Project validation did not complete successfully.';
        Exit;
    end;

    WS.DM_ShowMessageView;
    Result := True;
end;

function ViolationMessageText(Violation : IViolation) : String;
begin
    Result := '';
    if Violation = Nil then
        Exit;

    Result := Trim(Violation.DM_DescriptorString + ' ' + Violation.DM_DetailString);
end;

function IsOutOfDateComponentViolation(Violation : IViolation) : Boolean;
var
    Text : String;
begin
    Text := ViolationMessageText(Violation);
    Result := ContainsTextLocal(Text, 'Component revision is Out of Date');
end;

function FindNextOutOfDateViolation(Project : IProject; var Violation : IViolation) : Boolean;
var
    I : Integer;
begin
    Result := False;
    Violation := Nil;

    if Project = Nil then
        Exit;

    for I := 0 to Project.DM_ViolationCount - 1 do
    begin
        Violation := Project.DM_Violations(I);
        if IsOutOfDateComponentViolation(Violation) then
        begin
            Result := True;
            Exit;
        end;
    end;

    Violation := Nil;
end;

function RebuildMessagesWithOutOfDateOnly(var FirstMessageText, ErrorText : String; var RevisionMessageCount : Integer) : Boolean;
var
    WS          : IWorkspace;
    MM          : IMessagesManager;
    MessageItem : IMessageItem;
    I           : Integer;
    MessageCount: Integer;
    ClassesList : TStringList;
    TextList    : TStringList;
    SourceList  : TStringList;
    DocList     : TStringList;
    ProcList    : TStringList;
    ParamsList  : TStringList;
    ImageList   : TStringList;
begin
    Result := False;
    FirstMessageText := '';
    ErrorText := '';
    RevisionMessageCount := 0;

    WS := GetWorkspace;
    if WS = Nil then
    begin
        ErrorText := 'Workspace Manager is not available.';
        Exit;
    end;

    MM := WS.DM_MessagesManager;
    if MM = Nil then
    begin
        ErrorText := 'Messages Manager is not available.';
        Exit;
    end;

    ClassesList := TStringList.Create;
    TextList := TStringList.Create;
    SourceList := TStringList.Create;
    DocList := TStringList.Create;
    ProcList := TStringList.Create;
    ParamsList := TStringList.Create;
    ImageList := TStringList.Create;
    try
        MessageCount := MM.MessagesCount;
        for I := 0 to MessageCount - 1 do
        begin
            MessageItem := MM.Messages(I);
            if MessageItem <> Nil then
            begin
                if ContainsTextLocal(MessageItem.Text, 'Component revision is Out of Date') or
                   ContainsTextLocal(MessageItem.CallBackParameters2, 'ErrorKindSetToSuppress=Component revision is Out of Date') then
                begin
                    ClassesList.Add(MessageItem.MsgClass);
                    TextList.Add(MessageItem.Text);
                    SourceList.Add(MessageItem.Source);
                    DocList.Add(MessageItem.Document);
                    ProcList.Add(MessageItem.CallBackProcess);
                    ParamsList.Add(MessageItem.CallBackParameters);
                    ImageList.Add(IntToStr(MessageItem.ImageIndex));
                end;
            end;
        end;

        RevisionMessageCount := TextList.Count;
        if RevisionMessageCount = 0 then
        begin
            ErrorText := 'Validation found an out-of-date component revision, but NextRev could not find the matching rows in the Messages panel.';
            Exit;
        end;

        MM.ClearMessages;
        MM.BeginUpdate;
        for I := 0 to TextList.Count - 1 do
            MM.AddMessage(ClassesList.Strings[I], TextList.Strings[I], SourceList.Strings[I], DocList.Strings[I], ProcList.Strings[I], ParamsList.Strings[I], StrToInt(ImageList.Strings[I]), False);
        MM.EndUpdate;

        FirstMessageText := TextList.Strings[0];
        WS.DM_ShowMessageView;
        Result := True;
    finally
        ClassesList.Free;
        TextList.Free;
        SourceList.Free;
        DocList.Free;
        ProcList.Free;
        ParamsList.Free;
        ImageList.Free;
    end;
end;

function LoadExistingFilteredRevisionMessages(var FirstMessageText, ErrorText : String; var RevisionMessageCount : Integer) : Boolean;
var
    WS          : IWorkspace;
    MM          : IMessagesManager;
    MessageItem : IMessageItem;
    I           : Integer;
begin
    Result := False;
    FirstMessageText := '';
    ErrorText := '';
    RevisionMessageCount := 0;

    WS := GetWorkspace;
    if WS = Nil then
    begin
        ErrorText := 'Workspace Manager is not available.';
        Exit;
    end;

    MM := WS.DM_MessagesManager;
    if MM = Nil then
    begin
        ErrorText := 'Messages Manager is not available.';
        Exit;
    end;

    for I := 0 to MM.MessagesCount - 1 do
    begin
        MessageItem := MM.Messages(I);
        if MessageItem <> Nil then
        begin
            if ContainsTextLocal(MessageItem.Text, 'Component revision is Out of Date') or
               ContainsTextLocal(MessageItem.CallBackParameters2, 'ErrorKindSetToSuppress=Component revision is Out of Date') then
            begin
                Inc(RevisionMessageCount);
                if FirstMessageText = '' then
                    FirstMessageText := MessageItem.Text;
            end;
        end;
    end;

    Result := RevisionMessageCount > 0;
    if Result then
        WS.DM_ShowMessageView;
end;

function ValidateAndLoadRevisionMessages(var Project : IProject; var MessageText, ErrorText : String; var RevisionMessageCount : Integer) : Boolean;
var
    Violation : IViolation;
begin
    Result := False;
    MessageText := '';
    ErrorText := '';
    RevisionMessageCount := 0;

    if not CompileFocusedProject(Project, ErrorText) then
        Exit;

    if not FindNextOutOfDateViolation(Project, Violation) then
    begin
        Result := True;
        Exit;
    end;

    MessageText := ViolationMessageText(Violation);
    Result := RebuildMessagesWithOutOfDateOnly(MessageText, ErrorText, RevisionMessageCount);
end;

function SkipFirstFilteredRevisionMessage(var FirstMessageText, ErrorText : String; var RevisionMessageCount : Integer) : Boolean;
var
    WS          : IWorkspace;
    MM          : IMessagesManager;
    MessageItem : IMessageItem;
    I           : Integer;
    SkippedFirst: Boolean;
    ClassesList : TStringList;
    TextList    : TStringList;
    SourceList  : TStringList;
    DocList     : TStringList;
    ProcList    : TStringList;
    ParamsList  : TStringList;
    ImageList   : TStringList;
begin
    Result := False;
    FirstMessageText := '';
    ErrorText := '';
    RevisionMessageCount := 0;
    SkippedFirst := False;

    WS := GetWorkspace;
    if WS = Nil then
    begin
        ErrorText := 'Workspace Manager is not available.';
        Exit;
    end;

    MM := WS.DM_MessagesManager;
    if MM = Nil then
    begin
        ErrorText := 'Messages Manager is not available.';
        Exit;
    end;

    ClassesList := TStringList.Create;
    TextList := TStringList.Create;
    SourceList := TStringList.Create;
    DocList := TStringList.Create;
    ProcList := TStringList.Create;
    ParamsList := TStringList.Create;
    ImageList := TStringList.Create;
    try
        for I := 0 to MM.MessagesCount - 1 do
        begin
            MessageItem := MM.Messages(I);
            if MessageItem <> Nil then
            begin
                if ContainsTextLocal(MessageItem.Text, 'Component revision is Out of Date') or
                   ContainsTextLocal(MessageItem.CallBackParameters2, 'ErrorKindSetToSuppress=Component revision is Out of Date') then
                begin
                    if not SkippedFirst then
                        SkippedFirst := True
                    else
                    begin
                        ClassesList.Add(MessageItem.MsgClass);
                        TextList.Add(MessageItem.Text);
                        SourceList.Add(MessageItem.Source);
                        DocList.Add(MessageItem.Document);
                        ProcList.Add(MessageItem.CallBackProcess);
                        ParamsList.Add(MessageItem.CallBackParameters);
                        ImageList.Add(IntToStr(MessageItem.ImageIndex));
                    end;
                end;
            end;
        end;

        if not SkippedFirst then
        begin
            ErrorText := 'Skip could not find a current out-of-date component revision message to remove.';
            Exit;
        end;

        MM.ClearMessages;
        MM.BeginUpdate;
        for I := 0 to TextList.Count - 1 do
            MM.AddMessage(ClassesList.Strings[I], TextList.Strings[I], SourceList.Strings[I], DocList.Strings[I], ProcList.Strings[I], ParamsList.Strings[I], StrToInt(ImageList.Strings[I]), False);
        MM.EndUpdate;

        RevisionMessageCount := TextList.Count;
        if RevisionMessageCount > 0 then
            FirstMessageText := TextList.Strings[0];

        WS.DM_ShowMessageView;
        Result := True;
    finally
        ClassesList.Free;
        TextList.Free;
        SourceList.Free;
        DocList.Free;
        ProcList.Free;
        ParamsList.Free;
        ImageList.Free;
    end;
end;

function DesignatorListContains(Designators : TStringList; DesignatorText : String) : Boolean;
var
    I : Integer;
begin
    Result := False;
    if Designators = Nil then
        Exit;

    for I := 0 to Designators.Count - 1 do
    begin
        if SameTextLocal(Designators.Strings[I], DesignatorText) then
        begin
            Result := True;
            Exit;
        end;
    end;
end;

procedure AddDesignatorIfMissing(Designators : TStringList; DesignatorText : String);
begin
    if Trim(DesignatorText) = '' then
        Exit;

    if not DesignatorListContains(Designators, DesignatorText) then
        Designators.Add(Trim(DesignatorText));
end;

procedure BuildMatchingDesignatorList(DescriptionText : String; Designators : TStringList);
var
    WS          : IWorkspace;
    MM          : IMessagesManager;
    MessageItem : IMessageItem;
    I           : Integer;
begin
    if Designators = Nil then
        Exit;

    WS := GetWorkspace;
    if WS = Nil then
        Exit;

    MM := WS.DM_MessagesManager;
    if MM = Nil then
        Exit;

    for I := 0 to MM.MessagesCount - 1 do
    begin
        MessageItem := MM.Messages(I);
        if MessageItem <> Nil then
        begin
            if SameTextLocal(ExtractRevisionDescription(MessageItem.Text), DescriptionText) then
                AddDesignatorIfMissing(Designators, ExtractRevisionDesignator(MessageItem.Text));
        end;
    end;
end;

function DesignatorListToCsv(Designators : TStringList) : String;
var
    I : Integer;
begin
    Result := '';

    if Designators = Nil then
        Exit;

    for I := 0 to Designators.Count - 1 do
    begin
        if Result <> '' then
            Result := Result + ', ';

        Result := Result + Trim(Designators.Strings[I]);
    end;
end;

procedure ClearSchematicFilterMask;
begin
    ResetParameters;
    AddStringParameter('Clear', 'True');
    RunProcess('Sch:FilterSelect');
    ResetParameters;
end;

function SelectComponentsForDesignators(Designators, SelectedDesignators : TStringList; var SelectedCount : Integer; var ErrorText : String) : Boolean;
var
    SchDoc    : ISch_Document;
    Iterator  : ISch_Iterator;
    Component : ISch_Component;
begin
    Result := False;
    SelectedCount := 0;
    ErrorText := '';

    if Designators = Nil then
    begin
        ErrorText := 'No designators were provided for selection.';
        Exit;
    end;

    if SelectedDesignators = Nil then
    begin
        ErrorText := 'No selected-designator list was provided.';
        Exit;
    end;

    if SchServer = Nil then
    begin
        ErrorText := 'Schematic server is not available.';
        Exit;
    end;

    SchDoc := SchServer.GetCurrentSchDocument;
    if SchDoc = Nil then
    begin
        ErrorText := 'No schematic sheet is active.';
        Exit;
    end;

    ClearSchematicFilterMask;
    ClearComponentSelectionOnCurrentSheet;

    Iterator := SchDoc.SchIterator_Create;
    if Iterator = Nil then
    begin
        ErrorText := 'Could not create a schematic iterator.';
        Exit;
    end;

    try
        Iterator.AddFilter_ObjectSet(MkSet(eSchComponent));
        Component := Iterator.FirstSchObject;
        while Component <> Nil do
        begin
            if DesignatorListContains(Designators, ComponentDesignator(Component)) then
            begin
                Component.Selection := True;
                AddDesignatorIfMissing(SelectedDesignators, ComponentDesignator(Component));
                Inc(SelectedCount);
            end;

            Component := Iterator.NextSchObject;
        end;
    finally
        SchDoc.SchIterator_Destroy(Iterator);
    end;

    if SelectedCount = 0 then
    begin
        ErrorText := 'None of the expected component designators were found on the active schematic sheet.';
        Exit;
    end;

    Result := True;
end;

function RemoveFilteredRevisionMessagesForDesignators(Designators : TStringList; var FirstMessageText, ErrorText : String; var RevisionMessageCount : Integer) : Boolean;
var
    WS          : IWorkspace;
    MM          : IMessagesManager;
    MessageItem : IMessageItem;
    I           : Integer;
    RemovedCount: Integer;
    ClassesList : TStringList;
    TextList    : TStringList;
    SourceList  : TStringList;
    DocList     : TStringList;
    ProcList    : TStringList;
    ParamsList  : TStringList;
    ImageList   : TStringList;
begin
    Result := False;
    FirstMessageText := '';
    ErrorText := '';
    RevisionMessageCount := 0;
    RemovedCount := 0;

    if Designators = Nil then
    begin
        ErrorText := 'No designators were provided for message removal.';
        Exit;
    end;

    WS := GetWorkspace;
    if WS = Nil then
    begin
        ErrorText := 'Workspace Manager is not available.';
        Exit;
    end;

    MM := WS.DM_MessagesManager;
    if MM = Nil then
    begin
        ErrorText := 'Messages Manager is not available.';
        Exit;
    end;

    ClassesList := TStringList.Create;
    TextList := TStringList.Create;
    SourceList := TStringList.Create;
    DocList := TStringList.Create;
    ProcList := TStringList.Create;
    ParamsList := TStringList.Create;
    ImageList := TStringList.Create;
    try
        for I := 0 to MM.MessagesCount - 1 do
        begin
            MessageItem := MM.Messages(I);
            if MessageItem <> Nil then
            begin
                if ContainsTextLocal(MessageItem.Text, 'Component revision is Out of Date') or
                   ContainsTextLocal(MessageItem.CallBackParameters2, 'ErrorKindSetToSuppress=Component revision is Out of Date') then
                begin
                    if DesignatorListContains(Designators, ExtractRevisionDesignator(MessageItem.Text)) then
                        Inc(RemovedCount)
                    else
                    begin
                        ClassesList.Add(MessageItem.MsgClass);
                        TextList.Add(MessageItem.Text);
                        SourceList.Add(MessageItem.Source);
                        DocList.Add(MessageItem.Document);
                        ProcList.Add(MessageItem.CallBackProcess);
                        ParamsList.Add(MessageItem.CallBackParameters);
                        ImageList.Add(IntToStr(MessageItem.ImageIndex));
                    end;
                end;
            end;
        end;

        if RemovedCount = 0 then
        begin
            ErrorText := 'NextRev could not find matching filtered revision messages to remove.';
            Exit;
        end;

        MM.ClearMessages;
        MM.BeginUpdate;
        for I := 0 to TextList.Count - 1 do
            MM.AddMessage(ClassesList.Strings[I], TextList.Strings[I], SourceList.Strings[I], DocList.Strings[I], ProcList.Strings[I], ParamsList.Strings[I], StrToInt(ImageList.Strings[I]), False);
        MM.EndUpdate;

        RevisionMessageCount := TextList.Count;
        if RevisionMessageCount > 0 then
            FirstMessageText := TextList.Strings[0];

        Result := True;
    finally
        ClassesList.Free;
        TextList.Free;
        SourceList.Free;
        DocList.Free;
        ProcList.Free;
        ParamsList.Free;
        ImageList.Free;
    end;
end;

procedure CrossProbeMessageView;
begin
    ResetParameters;
    AddStringParameter('ObjectKind', 'MessageView');
    AddStringParameter('Action', 'CrossProbe');
    RunProcess('WorkspaceManager:Configure');
    ResetParameters;
end;

procedure ShowSchematicPropertiesPanel;
begin
    ResetParameters;
    AddStringParameter('Action', 'Show');
    AddStringParameter('SetFocus', 'True');
    RunProcess('InteractiveProperties:DisplayInteractivePropertiesPanel');
    ResetParameters;
end;

procedure RunNextRev;
var
    Project        : IProject;
    ErrorText      : String;
    MessageText    : String;
    DebugText      : String;
    RevisionMessageCount : Integer;
    FirstDesignator : String;
    FirstDescription : String;
    SimilarDescriptionCount : Integer;
    AllDesignatorsText : String;
    Red6PartNumber : String;
    CaptureDebug : String;
    FormResult : Integer;
    MatchingDesignators : TStringList;
    TargetDesignators : TStringList;
    SelectedDesignators : TStringList;
    SelectedCount : Integer;
begin
    Project := Nil;
    if not LoadExistingFilteredRevisionMessages(MessageText, ErrorText, RevisionMessageCount) then
    begin
        MessageText := '';
        RevisionMessageCount := 0;
    end;

    repeat
        if RevisionMessageCount = 0 then
        begin
            DebugText := 'No cached out-of-date component revision messages are loaded.' + #13#10 + #13#10 +
                         'Click Validate Revisions to run project validation and rebuild the filtered revision list.' + #13#10 +
                         'NextRev does not validate automatically on startup so it can preserve the manually trimmed Messages list between update passes.';

            FormResult := ShowNextRevActionForm('', '', '', '0', '', DebugText, False);

            if FormResult = NEXTREV_VALIDATE_RESULT then
            begin
                if not ValidateAndLoadRevisionMessages(Project, MessageText, ErrorText, RevisionMessageCount) then
                begin
                    ShowNextRevMessage(ErrorText);
                    Exit;
                end;

                if RevisionMessageCount = 0 then
                begin
                    ShowNextRevMessage('Project validation completed. No out-of-date component revision warnings or errors were found.');
                    Exit;
                end;

                FormResult := NEXTREV_VALIDATE_RESULT;
            end
            else
                Exit;
        end;

        if RevisionMessageCount > 0 then
        begin
            FirstDesignator := ExtractRevisionDesignator(MessageText);
            FirstDescription := ExtractRevisionDescription(MessageText);
            MatchingDesignators := TStringList.Create;
            try
                BuildMatchingDesignatorList(FirstDescription, MatchingDesignators);
                SimilarDescriptionCount := MatchingDesignators.Count;
                AllDesignatorsText := DesignatorListToCsv(MatchingDesignators);
            finally
                MatchingDesignators.Free;
            end;

            CrossProbeMessageView;
            CaptureSeedComponentIds(FirstDesignator, Red6PartNumber, CaptureDebug);

            DebugText := 'NextRev loaded ' + IntToStr(RevisionMessageCount) + ' cached out-of-date component revision message(s).' + #13#10 +
                         'Validation is only run when Validate Revisions is clicked.' + #13#10 +
                         'Invoked Altium built-in Messages-panel cross-probe command.' + #13#10 + #13#10 +
                         'Seed component: ' + FirstDesignator + #13#10 +
                         'Seed description: ' + FirstDescription + #13#10 +
                         'Matching description count: ' + IntToStr(SimilarDescriptionCount) + #13#10 + #13#10 +
                         'All matching designators: ' + AllDesignatorsText + #13#10 + #13#10 +
                         CaptureDebug + #13#10 + #13#10 +
                         'First revision message:' + #13#10 + MessageText + #13#10 + #13#10 +
                         'Select One clears the schematic filter/mask, selects only this component, removes it from the filtered Messages list, opens Properties, then exits.' + #13#10 +
                         'Select All clears the schematic filter/mask, selects matching components found on the active schematic sheet, removes those selected items from the filtered Messages list, opens Properties, then exits.' + #13#10 +
                         'Validate Revisions reruns project validation and rebuilds this list.' + #13#10 +
                         'Skip removes this first filtered revision message and advances to the next one.';

            FormResult := ShowNextRevActionForm(Red6PartNumber, FirstDescription, FirstDesignator, IntToStr(SimilarDescriptionCount), AllDesignatorsText, DebugText, True);
        end;

        if FormResult = NEXTREV_VALIDATE_RESULT then
        begin
            if not ValidateAndLoadRevisionMessages(Project, MessageText, ErrorText, RevisionMessageCount) then
            begin
                ShowNextRevMessage(ErrorText);
                Exit;
            end;

            if RevisionMessageCount = 0 then
            begin
                ShowNextRevMessage('Project validation completed. No out-of-date component revision warnings or errors were found.');
                Exit;
            end;

            FormResult := NEXTREV_VALIDATE_RESULT;
        end;

        if FormResult = NEXTREV_SKIP_RESULT then
        begin
            if not SkipFirstFilteredRevisionMessage(MessageText, ErrorText, RevisionMessageCount) then
            begin
                ShowNextRevMessage(ErrorText);
                Exit;
            end;
        end;

        if (FormResult = NEXTREV_SELECT_ONE_RESULT) or (FormResult = NEXTREV_SELECT_ALL_RESULT) then
        begin
            TargetDesignators := TStringList.Create;
            SelectedDesignators := TStringList.Create;
            try
                if FormResult = NEXTREV_SELECT_ONE_RESULT then
                    AddDesignatorIfMissing(TargetDesignators, FirstDesignator)
                else
                    BuildMatchingDesignatorList(FirstDescription, TargetDesignators);

                if not SelectComponentsForDesignators(TargetDesignators, SelectedDesignators, SelectedCount, ErrorText) then
                begin
                    ShowNextRevMessage(ErrorText);
                    Exit;
                end;

                if not RemoveFilteredRevisionMessagesForDesignators(SelectedDesignators, MessageText, ErrorText, RevisionMessageCount) then
                begin
                    ShowNextRevMessage(ErrorText);
                    Exit;
                end;

                ShowSchematicPropertiesPanel;
                Exit;
            finally
                TargetDesignators.Free;
                SelectedDesignators.Free;
            end;
        end;
    until (FormResult <> NEXTREV_SKIP_RESULT) and (FormResult <> NEXTREV_VALIDATE_RESULT);
end;
