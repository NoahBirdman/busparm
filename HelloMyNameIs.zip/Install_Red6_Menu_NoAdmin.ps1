$ErrorActionPreference = 'Stop'

$scriptRoot = Split-Path -Parent $PSCommandPath

$blockStart = '// BEGIN Red6 internal scripts menu installer'
$blockEnd = '// END Red6 internal scripts menu installer'
$legacyBlockMarkers = @(
    @{ Start = '// BEGIN SixDegreesOfVariation Red 6 no-admin installer'; End = '// END SixDegreesOfVariation Red 6 no-admin installer' },
    @{ Start = '// BEGIN SixDegreesOfVariation Red 6 installer'; End = '// END SixDegreesOfVariation Red 6 installer' },
    @{ Start = '// BEGIN SixDegreesOfVariation menu installer'; End = '// END SixDegreesOfVariation menu installer' }
)

$menuItems = @(
    [PSCustomObject]@{
        Id = 'SixDegreesOfVariation'
        Caption = 'Six Degrees of &Variation'
        ProjectPath = Join-Path $scriptRoot 'SixDegreesOfVariation\SixDegreesOfVariation.PrjScr'
        ProcName = 'VARIATE_ME.pas>ShowVariantParameterEditor'
        Description = 'Run the Six Degrees variant parameter editor'
    },
    [PSCustomObject]@{
        Id = 'ImportMechLayers'
        Caption = 'Import &Mech Layers'
        ProjectPath = Join-Path $scriptRoot 'Import Mech Layers\ImportMechLayers.PrjScr'
        ProcName = 'IMPORT_MECH_LAYERS.pas>ImportMechanicalLayersFromStackup'
        Description = 'Import mechanical layer structure from a stackup file'
    },
    [PSCustomObject]@{
        Id = 'ICEBERG'
        Caption = '&ICEBERG'
        ProjectPath = Join-Path $scriptRoot 'ICEBERG\ICEBERG.PrjScr'
        ProcName = 'ICEBERG.pas>GenerateWindchillImportWorkbook'
        Description = 'Generate a Windchill import workbook for parts and documents'
    },
    [PSCustomObject]@{
        Id = 'NextRev'
        Caption = '&NextRev'
        ProjectPath = Join-Path $scriptRoot 'NextRev\NextRev.PrjScr'
        ProcName = 'NEXTREV.pas>RunNextRev'
        Description = 'Update out-of-date component revisions by matching similar descriptions'
    },
    [PSCustomObject]@{
        Id = 'HelloMyNameIs'
        Caption = '&Hello My Name Is'
        ProjectPath = Join-Path $scriptRoot 'HelloMyNameIs\HelloMyNameIs.PrjScr'
        ProcName = 'HELLO_MY_NAME_IS.pas>RunHelloMyNameIs'
        Description = 'Rename matching schematic net labels, ports, and sheet entries'
    },
    [PSCustomObject]@{
        Id = 'Picasso'
        Caption = '&Picasso'
        ProjectPath = Join-Path $scriptRoot 'Picasso\Picasso.PrjScr'
        ProcName = 'PICASSO.pas>RunPicasso'
        Description = 'View parsed project net color information'
    },
    [PSCustomObject]@{
        Id = 'AboutInfo'
        Caption = '&About Info'
        ProjectPath = Join-Path $scriptRoot 'AboutInfo\AboutInfo.PrjScr'
        ProcName = 'ABOUT_INFO.pas>ShowAboutInfo'
        Description = 'Show Red 6 script README files and launch the updater'
    }
)

$runningAltium = Get-Process -Name X2, AltiumDesigner, DXP -ErrorAction SilentlyContinue
if ($runningAltium) {
    Write-Host 'Altium Designer is still running.'
    Write-Host 'Close Altium completely, then run this installer again.'
    exit 2
}

function Get-FileEncoding {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return [Text.Encoding]::Default
    }

    $bytes = [IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
        return [Text.Encoding]::Unicode
    }
    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
        return [Text.Encoding]::BigEndianUnicode
    }
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        return [Text.Encoding]::UTF8
    }
    return [Text.Encoding]::Default
}

function Read-TextFile {
    param([string]$Path)

    $encoding = Get-FileEncoding -Path $Path
    $text = ''
    if (Test-Path -LiteralPath $Path) {
        $text = [IO.File]::ReadAllText($Path, $encoding)
    }

    return [PSCustomObject]@{
        Text = $text
        Encoding = $encoding
    }
}

function Remove-BlockByMarkers {
    param(
        [string]$Text,
        [string]$Start,
        [string]$End
    )

    $escapedStart = [regex]::Escape($Start)
    $escapedEnd = [regex]::Escape($End)
    return [regex]::Replace($Text, "(?s)\r?\n?$escapedStart.*?$escapedEnd\r?\n?", "`r`n")
}

function Remove-ManagedBlocks {
    param([string]$Text)

    $result = Remove-BlockByMarkers -Text $Text -Start $blockStart -End $blockEnd
    foreach ($marker in $legacyBlockMarkers) {
        $result = Remove-BlockByMarkers -Text $result -Start $marker.Start -End $marker.End
    }
    $result = Remove-GeneratedRed6Entries -Text $result
    return $result
}

function Remove-GeneratedRed6Entries {
    param([string]$Text)

    $result = [regex]::Replace(
        $Text,
        "(?ms)^\s*PL\s+(?:PLSixDegreesOfVariation|PLRed6_[^\s]+)\b.*?\bEnd\s*\r?\n?",
        ''
    )

    return [regex]::Replace(
        $result,
        "(?ms)^\s*Insertion\s+Red6_(?:NoDocumentMenu|PcbMenu|SchMenu|SchLibMenu|PcbLibMenu)\b.*?^\s*End\s*\r?\n\s*End\s*\r?\n?",
        ''
    )
}

function Backup-File {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return $null
    }

    $backupPath = "$Path.red6-user-$(Get-Date -Format 'yyyyMMdd-HHmmss').bak"
    Copy-Item -LiteralPath $Path -Destination $backupPath -Force
    return $backupPath
}

function Add-DefaultCustomTrees {
    param([string]$Text)

    $defaults = @(
        "Tree PCBCustom Caption='[Custom]' TopLevel='True'  End",
        "Tree SchCustom Caption='[Custom]' TopLevel='True'  End",
        "Tree PCBLibCustom Caption='[Custom]' TopLevel='True'  End",
        "Tree OutputJobCustom Caption='[Custom]' TopLevel='True'  End",
        "Tree SchLibCustom Caption='[Custom]' TopLevel='True'  End",
        "Tree CmpLibCustom Caption='[Custom]' TopLevel='True'  End",
        "Tree LsmPcbDocCustom Caption='[Custom]' TopLevel='True'  End",
        "Tree HarnessCustom Caption='[Custom]' TopLevel='True'  End",
        "Tree DefaultEditorCustom Caption='[Custom]' TopLevel='True'  End",
        "Tree EditScriptDSCustom Caption='[Custom]' TopLevel='True'  End",
        "Tree PcbDrawingCustom Caption='[Custom]' TopLevel='True'  End"
    )

    $result = $Text
    $defaultLines = [string[]]$defaults.Clone()
    [array]::Reverse($defaultLines)
    foreach ($line in $defaultLines) {
        $treeId = ($line -split ' ')[1]
        if ($result -notmatch "(?m)^Tree\s+$([regex]::Escape($treeId))\b") {
            $result = $line + "`r`n" + $result
        }
    }

    return $result
}

function Get-ProcessLauncherId {
    param([PSCustomObject]$MenuItem)

    return 'PLRed6_' + $MenuItem.Id
}

function Add-MenuLinks {
    param(
        [System.Text.StringBuilder]$Builder,
        [string]$Prefix
    )

    foreach ($item in $menuItems) {
        $plId = Get-ProcessLauncherId -MenuItem $item
        [void]$Builder.AppendLine("        Link ${Prefix}_$($item.Id) PLID='$plId' End")
    }
}

function New-InstallerBlock {
    $builder = New-Object System.Text.StringBuilder

    [void]$builder.AppendLine($blockStart)
    [void]$builder.AppendLine('// Adds top-level Red 6 menus to the current user''s Altium profile.')

    foreach ($item in $menuItems) {
        if (-not (Test-Path -LiteralPath $item.ProjectPath)) {
            throw "Script project not found: $($item.ProjectPath)"
        }

        $plId = Get-ProcessLauncherId -MenuItem $item
        $runParams = "ProjectName=$($item.ProjectPath)|ProcName=$($item.ProcName)"
        [void]$builder.AppendLine("PL $plId")
        [void]$builder.AppendLine("    Command='ScriptingSystem:RunScript'")
        [void]$builder.AppendLine("    Caption='$($item.Caption)'")
        [void]$builder.AppendLine("    Params='$runParams'")
        [void]$builder.AppendLine("    Description='$($item.Description)'")
        [void]$builder.AppendLine('End')
        [void]$builder.AppendLine()
    }

    [void]$builder.AppendLine("Insertion Red6_NoDocumentMenu TargetID='MNNoDocument' InsertType='After' RefID0='MNNoDocument_Project'")
    [void]$builder.AppendLine("    Tree MNRed6_NoDocument Caption='Red &6' Popup='6'")
    Add-MenuLinks -Builder $builder -Prefix 'MNRed6_NoDocument'
    [void]$builder.AppendLine('    End')
    [void]$builder.AppendLine('End')
    [void]$builder.AppendLine()

    [void]$builder.AppendLine("Insertion Red6_PcbMenu TargetID='MNPCBMenu' InsertType='After' RefID0='MNPCB_Reports10'")
    [void]$builder.AppendLine("    Tree MNRed6_Pcb Caption='Red &6' Popup='6'")
    Add-MenuLinks -Builder $builder -Prefix 'MNRed6_Pcb'
    [void]$builder.AppendLine('    End')
    [void]$builder.AppendLine('End')
    [void]$builder.AppendLine()

    [void]$builder.AppendLine("Insertion Red6_SchMenu TargetID='MNSchematicMenu' InsertType='After' RefID0='MNSchematic_Reports'")
    [void]$builder.AppendLine("    Tree MNRed6_Sch Caption='Red &6' Popup='6'")
    Add-MenuLinks -Builder $builder -Prefix 'MNRed6_Sch'
    [void]$builder.AppendLine('    End')
    [void]$builder.AppendLine('End')
    [void]$builder.AppendLine()

    [void]$builder.AppendLine("Insertion Red6_SchLibMenu TargetID='MNSchLibMenu' InsertType='After' RefID0='MNSchematic_SchLibMenuReports10'")
    [void]$builder.AppendLine("    Tree MNRed6_SchLib Caption='Red &6' Popup='6'")
    Add-MenuLinks -Builder $builder -Prefix 'MNRed6_SchLib'
    [void]$builder.AppendLine('    End')
    [void]$builder.AppendLine('End')
    [void]$builder.AppendLine()

    [void]$builder.AppendLine("Insertion Red6_PcbLibMenu TargetID='MNPCBLibMenu' InsertType='After' RefID0='MNPCBLib_Reports10'")
    [void]$builder.AppendLine("    Tree MNRed6_PcbLib Caption='Red &6' Popup='6'")
    Add-MenuLinks -Builder $builder -Prefix 'MNRed6_PcbLib'
    [void]$builder.AppendLine('    End')
    [void]$builder.AppendLine('End')
    [void]$builder.AppendLine($blockEnd)

    return $builder.ToString()
}

$profileRoot = Join-Path $env:APPDATA 'Altium'
if (-not (Test-Path -LiteralPath $profileRoot)) {
    throw "Altium profile root not found: $profileRoot"
}

$rcsFiles = Get-ChildItem -LiteralPath $profileRoot -Directory -Filter 'Altium Designer *' -ErrorAction SilentlyContinue |
    ForEach-Object { Join-Path $_.FullName 'DXP.RCS' }

$rcsFiles = @($rcsFiles)
if ($rcsFiles.Count -eq 0) {
    throw "No Altium Designer profile folders were found under: $profileRoot"
}

$block = New-InstallerBlock
$changed = 0
foreach ($rcsFile in $rcsFiles) {
    $file = Read-TextFile -Path $rcsFile
    $clean = Remove-ManagedBlocks -Text $file.Text
    $clean = Add-DefaultCustomTrees -Text $clean
    $patched = $clean.TrimEnd() + "`r`n`r`n" + $block.TrimEnd() + "`r`n"

    if ($patched -ne $file.Text) {
        $backup = Backup-File -Path $rcsFile
        [IO.File]::WriteAllText($rcsFile, $patched, $file.Encoding)
        Write-Host "Updated: $rcsFile"
        if ($backup) {
            Write-Host "Backup:  $backup"
        }
        $changed++
    }
}

Write-Host ''
Write-Host "Red 6 menu install complete. User profiles updated: $changed"
Write-Host 'Start Altium Designer and check the top menu bar for: Red 6'
