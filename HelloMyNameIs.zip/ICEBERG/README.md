# ICEBERG

ICEBERG generates Windchill import `.xlsx` workbooks per project variant from the focused Altium PCB project.

Run it from:

```text
Red 6 > ICEBERG
```

The script creates each workbook automatically under the focused project folder:

```text
iceberg_output\<PCBA_PART_NO>_<PROJ_NAME>_<VARIANT_NAME>.xlsx
iceberg_output\<PCBA_PART_NO>_<PROJ_NAME>_<VARIANT_NAME>_BOM.xlsx
```

Temporary `.parts.tsv`, `.documents.tsv`, `.bom.tsv`, `.builder.cmd`, and `.builder.log` sidecar files are cleaned up after each workbook is created successfully. If the workbook builder fails, the sidecar files are left in place for debugging.

The part/document workbook is generated directly with the Windchill import fields and contains:

- `PARTS`: PCB, PCBA, and conformal-coat part rows in the 28-column part import layout. Part assembly mode is `inseparable`; `com.red6ar.SubCategory` is `602` for PCB, `600` for PCBA, and `601` for conformal coat; `com.red6ar.eccn` is blank. The conformal-coat part row is omitted when `CONF_PART_NO` is `N/A`.
- `DOCS`: schematic, PCB, PCBA, conformal-coat, ECAD, and CBDD document rows in the 8-column document import layout. The conformal-coat document row uses `SubCategory` `601` and is omitted when `CONF_DOC_NO` is `N/A`.

The BOM workbook contains a `BOM` sheet with `ImportSheetType=BOM` in `A1` and `Action`, `Level`, `Number`, `Organization ID`, `Quantity`, `Line Number`, `Reference Designators`, and `Type` on row 6. BOM hierarchy is `ALT_PART_NO`, `CONF_PART_NO`, `PCBA_PART_NO`, then `PCB_PART_NO`, omitting `ALT_PART_NO` or `CONF_PART_NO` when blank or `N/A`.

Variants are skipped when either `PCB_PART_NO` or `PCBA_PART_NO` is blank or `N/A` on that variant. The completion message lists each skipped variant and the missing field names.

The first-pass mapping uses the standard variant parameters created by `Six Degrees of Variation`, including `ALT_PART_NO`, `PCB_PART_NO`, `PCBA_PART_NO`, `CONF_PART_NO`, `SCH_DOC_NO`, `PCB_DOC_NO`, `PCBA_DOC_NO`, `CONF_DOC_NO`, `ECAD_DOC_NO`, and `CBDD_DOC_NO`.

The Altium script writes staging TSV files, then launches `ICEBERG_CreateWorkbook.ps1` and `ICEBERG_CreateBomWorkbook.ps1` to package them into real `.xlsx` files. Microsoft Excel is not required.
