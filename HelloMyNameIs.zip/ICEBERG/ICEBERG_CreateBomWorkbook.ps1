param(
    [Parameter(Mandatory = $true)]
    [string]$OutputPath,

    [Parameter(Mandatory = $true)]
    [string]$BomPath
)

$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

function ConvertTo-ColumnName {
    param([int]$Column)

    $name = ''
    while ($Column -gt 0) {
        $remainder = ($Column - 1) % 26
        $name = [char](65 + $remainder) + $name
        $Column = [math]::Floor(($Column - 1) / 26)
    }

    return $name
}

function Escape-XmlText {
    param([AllowNull()][string]$Value)

    if ($null -eq $Value) {
        return ''
    }

    return [System.Security.SecurityElement]::Escape($Value)
}

function Write-Utf8File {
    param(
        [string]$Path,
        [string]$Content
    )

    $utf8 = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $utf8)
}

function New-Directory {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path | Out-Null
    }
}

function New-ColumnsXml {
    param([decimal[]]$Widths)

    $xml = New-Object System.Text.StringBuilder
    [void]$xml.AppendLine('  <cols>')
    for ($index = 0; $index -lt $Widths.Count; $index++) {
        $column = $index + 1
        [void]$xml.AppendLine("    <col min=`"$column`" max=`"$column`" width=`"$($Widths[$index])`" customWidth=`"1`"/>")
    }
    [void]$xml.AppendLine('  </cols>')
    return $xml.ToString()
}

function Add-InlineCell {
    param(
        [System.Text.StringBuilder]$Xml,
        [string]$CellRef,
        [string]$Value,
        [int]$StyleId
    )

    [void]$Xml.AppendLine("      <c r=`"$CellRef`" s=`"$StyleId`" t=`"inlineStr`"><is><t xml:space=`"preserve`">$(Escape-XmlText $Value)</t></is></c>")
}

function New-BomWorksheetXml {
    param([string[]]$Rows)

    $headers = @(
        'Action',
        'Level',
        'Number',
        'Organization ID',
        'Quantity',
        'Line Number',
        'Reference Designators',
        'Type'
    )
    $widths = @(16, 10, 22, 18, 12, 14, 28, 28)
    $Rows = @($Rows)
    $columnCount = $headers.Count
    $lastRow = [math]::Max(6, 6 + $Rows.Count)
    $lastColumn = ConvertTo-ColumnName $columnCount

    $xml = New-Object System.Text.StringBuilder
    [void]$xml.AppendLine('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>')
    [void]$xml.AppendLine('<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">')
    [void]$xml.AppendLine("  <dimension ref=`"A1:$lastColumn$lastRow`"/>")
    [void]$xml.AppendLine('  <sheetViews><sheetView workbookViewId="0"/></sheetViews>')
    [void]$xml.AppendLine('  <sheetFormatPr defaultRowHeight="15"/>')
    [void]$xml.Append((New-ColumnsXml -Widths $widths))
    [void]$xml.AppendLine('  <sheetData>')
    [void]$xml.AppendLine('    <row r="1" spans="1:1">')
    Add-InlineCell -Xml $xml -CellRef 'A1' -Value 'ImportSheetType=BOM' -StyleId 1
    [void]$xml.AppendLine('    </row>')

    [void]$xml.AppendLine("    <row r=`"6`" spans=`"1:$columnCount`">")
    for ($index = 0; $index -lt $headers.Count; $index++) {
        $cellRef = "$(ConvertTo-ColumnName ($index + 1))6"
        Add-InlineCell -Xml $xml -CellRef $cellRef -Value $headers[$index] -StyleId 1
    }
    [void]$xml.AppendLine('    </row>')

    for ($rowIndex = 0; $rowIndex -lt $Rows.Count; $rowIndex++) {
        $rowNumber = $rowIndex + 7
        $cells = $Rows[$rowIndex].Split([char[]]@([char]9), [System.StringSplitOptions]::None)

        [void]$xml.AppendLine("    <row r=`"$rowNumber`" spans=`"1:$columnCount`">")
        for ($columnIndex = 1; $columnIndex -le $columnCount; $columnIndex++) {
            $cellRef = "$(ConvertTo-ColumnName $columnIndex)$rowNumber"
            $value = ''
            if (($columnIndex - 1) -lt $cells.Count) {
                $value = $cells[$columnIndex - 1]
            }

            Add-InlineCell -Xml $xml -CellRef $cellRef -Value $value -StyleId 2
        }
        [void]$xml.AppendLine('    </row>')
    }

    [void]$xml.AppendLine('  </sheetData>')
    [void]$xml.AppendLine('  <pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>')
    [void]$xml.AppendLine('</worksheet>')
    return $xml.ToString()
}

function New-ZipFromDirectory {
    param(
        [string]$SourcePath,
        [string]$DestinationPath
    )

    if (Test-Path -LiteralPath $DestinationPath) {
        Remove-Item -LiteralPath $DestinationPath -Force
    }

    $zipStream = [System.IO.File]::Open($DestinationPath, [System.IO.FileMode]::CreateNew)
    $archive = New-Object System.IO.Compression.ZipArchive($zipStream, [System.IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($file in Get-ChildItem -LiteralPath $SourcePath -Recurse -File) {
            $relativePath = $file.FullName.Substring($SourcePath.Length).TrimStart('\', '/')
            $entryName = $relativePath -replace '\\', '/'
            $entry = $archive.CreateEntry($entryName, [System.IO.Compression.CompressionLevel]::Optimal)
            $entryStream = $entry.Open()
            $fileStream = [System.IO.File]::OpenRead($file.FullName)
            try {
                $fileStream.CopyTo($entryStream)
            }
            finally {
                $fileStream.Dispose()
                $entryStream.Dispose()
            }
        }
    }
    finally {
        $archive.Dispose()
        $zipStream.Dispose()
    }
}

if (-not (Test-Path -LiteralPath $BomPath)) {
    throw "BOM TSV not found: $BomPath"
}

$outputFolder = Split-Path -Parent $OutputPath
New-Directory $outputFolder

$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("iceberg_bom_xlsx_" + [guid]::NewGuid().ToString('N'))
try {
    New-Directory $tempRoot
    New-Directory (Join-Path $tempRoot '_rels')
    New-Directory (Join-Path $tempRoot 'xl')
    New-Directory (Join-Path $tempRoot 'xl\_rels')
    New-Directory (Join-Path $tempRoot 'xl\worksheets')

    $bomRows = @(Get-Content -LiteralPath $BomPath)

    Write-Utf8File (Join-Path $tempRoot '[Content_Types].xml') @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>
'@

    Write-Utf8File (Join-Path $tempRoot '_rels\.rels') @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>
'@

    Write-Utf8File (Join-Path $tempRoot 'xl\workbook.xml') @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="BOM" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>
'@

    Write-Utf8File (Join-Path $tempRoot 'xl\_rels\workbook.xml.rels') @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>
'@

    Write-Utf8File (Join-Path $tempRoot 'xl\styles.xml') @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="2">
    <font><sz val="11"/><name val="Calibri"/></font>
    <font><b/><sz val="11"/><name val="Calibri"/></font>
  </fonts>
  <fills count="3">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFD9EAF7"/><bgColor indexed="64"/></patternFill></fill>
  </fills>
  <borders count="2">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border><left style="thin"><color rgb="FFB7C9D6"/></left><right style="thin"><color rgb="FFB7C9D6"/></right><top style="thin"><color rgb="FFB7C9D6"/></top><bottom style="thin"><color rgb="FFB7C9D6"/></bottom><diagonal/></border>
  </borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="3">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>
  </cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>
'@

    Write-Utf8File (Join-Path $tempRoot 'xl\worksheets\sheet1.xml') (New-BomWorksheetXml -Rows $bomRows)

    New-ZipFromDirectory -SourcePath $tempRoot -DestinationPath $OutputPath
    Write-Host "Created $OutputPath"
}
finally {
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
