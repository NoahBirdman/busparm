{ Altium Designer DelphiScript
  Generates Excel workbooks for Windchill import from the focused PCB project.

  Run procedure: GenerateWindchillImportWorkbook
}

uses
    SysUtils,
    Classes,
    Dialogs;

const
    ICEBERG_SCRIPT_FOLDER = 'C:\Users\Public\Documents\Altium\altiumscripts\ICEBERG';
    PART_COLUMN_COUNT = 28;
    DOCUMENT_COLUMN_COUNT = 8;
    BOM_COLUMN_COUNT = 8;

function SameTextLocal(A, B : String) : Boolean;
begin
    Result := UpperCase(Trim(A)) = UpperCase(Trim(B));
end;

function StartsWithLocal(Value, Prefix : String) : Boolean;
begin
    Result := Copy(UpperCase(Value), 1, Length(Prefix)) = UpperCase(Prefix);
end;

function IsSectionHeader(Line : String) : Boolean;
var
    S : String;
begin
    S := Trim(Line);
    Result := (Length(S) > 2) and (Copy(S, 1, 1) = '[') and (Copy(S, Length(S), 1) = ']');
end;

function GetSectionName(Line : String) : String;
var
    S : String;
begin
    S := Trim(Line);
    if IsSectionHeader(S) then
        Result := Copy(S, 2, Length(S) - 2)
    else
        Result := '';
end;

function IntFromText(Value : String) : Integer;
var
    S        : String;
    I        : Integer;
    DigitPos : Integer;
begin
    Result := 0;

    S := Trim(Value);
    if S = '' then
        Exit;

    for I := 1 to Length(S) do
    begin
        DigitPos := Pos(Copy(S, I, 1), '0123456789');
        if DigitPos = 0 then
        begin
            Result := 0;
            Exit;
        end;

        Result := (Result * 10) + DigitPos - 1;
    end;
end;

function ProjectVariantIndexFromHeader(Line : String) : Integer;
var
    Name   : String;
    Number : String;
begin
    Result := 0;
    Name := GetSectionName(Line);

    if StartsWithLocal(Name, 'ProjectVariant') then
    begin
        Number := Copy(Name, Length('ProjectVariant') + 1, Length(Name));
        Result := IntFromText(Number);
    end;
end;

function ProjectParameterIndexFromHeader(Line : String) : Integer;
var
    Name   : String;
    Number : String;
begin
    Result := 0;
    Name := GetSectionName(Line);

    if StartsWithLocal(Name, 'Parameter') and (Pos('_', Name) = 0) then
    begin
        Number := Copy(Name, Length('Parameter') + 1, Length(Name));
        Result := IntFromText(Number);
    end;
end;

function ProjectVariantParameterGroup(VariantIndex : Integer) : Integer;
begin
    Result := VariantIndex + 1;
end;

function ParameterGroupFromHeader(Line : String) : Integer;
var
    Name         : String;
    Number       : String;
    UnderscoreAt : Integer;
begin
    Result := 0;
    Name := GetSectionName(Line);

    if not StartsWithLocal(Name, 'Parameter') then
        Exit;

    UnderscoreAt := Pos('_', Name);
    if UnderscoreAt <= Length('Parameter') + 1 then
        Exit;

    Number := Copy(Name, Length('Parameter') + 1, UnderscoreAt - Length('Parameter') - 1);
    Result := IntFromText(Number);
end;

function ReadSectionValue(Lines : TStringList; SectionStart : Integer; Key : String) : String;
var
    I       : Integer;
    S       : String;
    EqPos   : Integer;
    ThisKey : String;
begin
    Result := '';

    for I := SectionStart + 1 to Lines.Count - 1 do
    begin
        S := Trim(Lines[I]);
        if IsSectionHeader(S) then
            Exit;

        EqPos := Pos('=', S);
        if EqPos > 0 then
        begin
            ThisKey := Trim(Copy(S, 1, EqPos - 1));
            if SameTextLocal(ThisKey, Key) then
            begin
                Result := Copy(S, EqPos + 1, Length(S));
                Exit;
            end;
        end;
    end;
end;

procedure AddParam(Names, Values : TStringList; ParamName, ParamValue : String);
begin
    Names.Add(ParamName);
    Values.Add(ParamValue);
end;

function FindParamIndex(Names : TStringList; ParamName : String) : Integer;
var
    I : Integer;
begin
    Result := -1;

    for I := 0 to Names.Count - 1 do
    begin
        if SameTextLocal(Names[I], ParamName) then
        begin
            Result := I;
            Exit;
        end;
    end;
end;

function ParamValueByName(Names, Values : TStringList; ParamName : String) : String;
var
    I : Integer;
begin
    Result := '';

    I := FindParamIndex(Names, ParamName);
    if I >= 0 then
        Result := Values[I];
end;

function ParamValueWithFallback(Names, Values, FallbackNames, FallbackValues : TStringList;
                                ParamName : String) : String;
begin
    Result := ParamValueByName(Names, Values, ParamName);
    if Result = '' then
        Result := ParamValueByName(FallbackNames, FallbackValues, ParamName);
end;

procedure ReadProjectParameters(Lines : TStringList; Names, Values : TStringList);
var
    I         : Integer;
    ParamName : String;
begin
    Names.Clear;
    Values.Clear;

    for I := 0 to Lines.Count - 1 do
    begin
        if IsSectionHeader(Lines[I]) and (ProjectParameterIndexFromHeader(Lines[I]) > 0) then
        begin
            ParamName := Trim(ReadSectionValue(Lines, I, 'Name'));
            if ParamName <> '' then
                AddParam(Names, Values, ParamName, ReadSectionValue(Lines, I, 'Value'));
        end;
    end;
end;

procedure ReadParameterSectionsForVariant(Lines : TStringList; VariantIndex : Integer;
                                          Names, Values : TStringList);
var
    I         : Integer;
    GroupIx   : Integer;
    ParamName : String;
begin
    Names.Clear;
    Values.Clear;
    GroupIx := ProjectVariantParameterGroup(VariantIndex);

    for I := 0 to Lines.Count - 1 do
    begin
        if IsSectionHeader(Lines[I]) and (ParameterGroupFromHeader(Lines[I]) = GroupIx) then
        begin
            ParamName := Trim(ReadSectionValue(Lines, I, 'Name'));
            if ParamName <> '' then
                AddParam(Names, Values, ParamName, ReadSectionValue(Lines, I, 'Value'));
        end;
    end;
end;

function LoadFocusedProjectLines(Lines : TStringList; var ProjectPath : String) : Boolean;
var
    Workspace : IWorkspace;
    Project   : IProject;
begin
    Result := False;

    Workspace := GetWorkspace;
    if Workspace = Nil then
    begin
        ShowMessage('Could not access the Altium workspace.');
        Exit;
    end;

    Project := Workspace.DM_FocusedProject;
    if Project = Nil then
    begin
        ShowMessage('Focus a PCB project in the Projects panel, then run ICEBERG again.');
        Exit;
    end;

    ProjectPath := Project.DM_ProjectFullPath;
    if ProjectPath = '' then
    begin
        ShowMessage('The focused project does not have a saved .PrjPcb path.');
        Exit;
    end;

    Lines.LoadFromFile(ProjectPath);
    Result := True;
end;

function DefaultProjectName(ProjectParams, ProjectValues : TStringList; ProjectPath : String) : String;
begin
    Result := Trim(ParamValueByName(ProjectParams, ProjectValues, 'PROJ_TITLE'));
    if Result = '' then
        Result := Trim(ParamValueByName(ProjectParams, ProjectValues, 'PROJ_NAME'));
    if Result = '' then
        Result := ChangeFileExt(ExtractFileName(ProjectPath), '');
end;

function ProjectNameForFile(ProjectParams, ProjectValues : TStringList; ProjectPath : String) : String;
begin
    Result := Trim(ParamValueByName(ProjectParams, ProjectValues, 'PROJ_NAME'));
    if Result = '' then
        Result := Trim(ParamValueByName(ProjectParams, ProjectValues, 'PROJ_TITLE'));
    if Result = '' then
        Result := ChangeFileExt(ExtractFileName(ProjectPath), '');
end;

function OutputFolderForProject(ProjectPath : String) : String;
var
    FolderName : String;
begin
    FolderName := ExtractFilePath(ProjectPath);
    Result := FolderName + 'iceberg_output';

    if not DirectoryExists(Result) then
    begin
        if not CreateDir(Result) then
        begin
            ShowMessage('Could not create ICEBERG output folder:' + #13#10 + Result);
            Result := '';
            Exit;
        end;
    end;
end;

function SafeFileNamePart(Value, Fallback : String) : String;
var
    I             : Integer;
    C             : String;
    CleanValue    : String;
    LastUnderscore: Boolean;
begin
    Result := '';
    CleanValue := Trim(Value);

    if CleanValue = '' then
        CleanValue := Fallback;

    LastUnderscore := False;
    for I := 1 to Length(CleanValue) do
    begin
        C := Copy(CleanValue, I, 1);

        if Pos(C, 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.-') > 0 then
        begin
            Result := Result + C;
            LastUnderscore := False;
        end
        else if not LastUnderscore then
        begin
            Result := Result + '_';
            LastUnderscore := True;
        end;
    end;

    while (Length(Result) > 0) and (Copy(Result, Length(Result), 1) = '_') do
        Result := Copy(Result, 1, Length(Result) - 1);

    while (Length(Result) > 0) and (Copy(Result, 1, 1) = '_') do
        Result := Copy(Result, 2, Length(Result) - 1);

    if Result = '' then
        Result := Fallback;
end;

function VariantWorkbookPath(ProjectPath, PcbaPartNo, ProjectName, VariantName : String) : String;
var
    FileName : String;
begin
    FileName := SafeFileNamePart(PcbaPartNo, 'NO_PCBA_PART_NO') + '_' +
                SafeFileNamePart(ProjectName, 'NO_PROJ_NAME') + '_' +
                SafeFileNamePart(VariantName, 'NO_VARIANT_NAME') + '.xlsx';

    Result := OutputFolderForProject(ProjectPath);
    if Result = '' then
        Exit;

    Result := Result + '\' + FileName;
end;

function VariantBomWorkbookPath(ProjectPath, PcbaPartNo, ProjectName, VariantName : String) : String;
var
    FileName : String;
begin
    FileName := SafeFileNamePart(PcbaPartNo, 'NO_PCBA_PART_NO') + '_' +
                SafeFileNamePart(ProjectName, 'NO_PROJ_NAME') + '_' +
                SafeFileNamePart(VariantName, 'NO_VARIANT_NAME') + '_BOM.xlsx';

    Result := OutputFolderForProject(ProjectPath);
    if Result = '' then
        Exit;

    Result := Result + '\' + FileName;
end;

function CleanCellText(Value : String) : String;
var
    I       : Integer;
    C       : String;
    CharCode: Integer;
begin
    Result := '';

    for I := 1 to Length(Value) do
    begin
        C := Copy(Value, I, 1);
        CharCode := Ord(C[1]);

        if (C = #9) or (C = #10) or (C = #13) then
            C := ' ';

        if CharCode > 126 then
            C := '?';

        Result := Result + C;
    end;
end;

function ValueOrDefault(Value, Fallback : String) : String;
begin
    Result := Trim(Value);
    if Result = '' then
        Result := Fallback;
end;

function LastDelimiterLocal(Delimiter, Value : String) : Integer;
var
    I : Integer;
begin
    Result := 0;
    for I := Length(Value) downto 1 do
    begin
        if Copy(Value, I, 1) = Delimiter then
        begin
            Result := I;
            Exit;
        end;
    end;
end;

function DashConfigFromPartNumber(PartNumber, RevisionText : String) : String;
var
    DashIndex : Integer;
    Candidate : String;
begin
    Result := '';
    DashIndex := LastDelimiterLocal('-', PartNumber);
    if (DashIndex > 0) and (DashIndex < Length(PartNumber)) then
    begin
        Candidate := Copy(PartNumber, DashIndex + 1, Length(PartNumber) - DashIndex);
        if Length(Candidate) <= 3 then
            Result := Candidate;
    end;

    if Result = '' then
        Result := Trim(RevisionText);
end;

function WindchillPartSubCategory(PartTypeText : String) : String;
begin
    if SameTextLocal(PartTypeText, 'PCB') then
        Result := '602'
    else if SameTextLocal(PartTypeText, 'Conformal Coat') then
        Result := '601'
    else
        Result := '600';
end;

function WindchillAssemblyMode(PartTypeText : String) : String;
begin
    Result := 'inseparable';
end;

function WindchillDocumentSubCategory(DocTypeText : String) : String;
var
    DocTypeUpper : String;
begin
    DocTypeUpper := UpperCase(DocTypeText);

    if Pos('SCHEMATIC', DocTypeUpper) > 0 then
        Result := '604'
    else if Pos('CONFORMAL', DocTypeUpper) > 0 then
        Result := '601'
    else if Pos('ECAD', DocTypeUpper) > 0 then
        Result := '605'
    else if Pos('CBDD', DocTypeUpper) > 0 then
        Result := '610'
    else if (Pos('PCB', DocTypeUpper) > 0) and (Pos('PCBA', DocTypeUpper) = 0) then
        Result := '602'
    else
        Result := '600';
end;

function MakePartRow(ActionText, NumberText, NameText, RevisionText, PartTypeText,
                     VariantText, ClassText, SolderText, CoatText, CageCodeText,
                     ExportControlText, SourceProjectText, NotesText : String) : String;
begin
    Result := CleanCellText('WCTYPE|wt.part.WTPart|com.red6ar.ElectronicAssembly') + #9 +
              CleanCellText(NumberText) + #9 +
              CleanCellText(NameText) + #9 +
              'false' + #9 +
              'false' + #9 +
              'X' + #9 +
              'standard' + #9 +
              WindchillAssemblyMode(PartTypeText) + #9 +
              '/Default/WTParts' + #9 +
              'RED6AR' + #9 +
              'Design' + #9 +
              'INWORK' + #9 +
              'RED6AR Lifecycle' + #9 +
              'buy' + #9 +
              'ea' + #9 +
              'false' + #9 +
              'false' + #9 +
              '' + #9 +
              WindchillPartSubCategory(PartTypeText) + #9 +
              '' + #9 +
              '' + #9 +
              CleanCellText(ValueOrDefault(CageCodeText, '14BW4')) + #9 +
              'USA' + #9 +
              'No' + #9 +
              '' + #9 +
              'Mixed' + #9 +
              '' + #9 +
              CleanCellText(DashConfigFromPartNumber(NumberText, RevisionText));
end;

function MakeDocumentRow(ActionText, NumberText, NameText, RevisionText, DocTypeText,
                         RelatedPartText, VariantText, CageCodeText, ExportControlText,
                         SourceProjectText, FileNameText, NotesText : String) : String;
begin
    Result := CleanCellText('WCTYPE|wt.doc.WTDocument|com.red6ar.ElectronicAssemblyDocument') + #9 +
              CleanCellText(NumberText) + #9 +
              CleanCellText(NameText) + #9 +
              '/Default/Documentation' + #9 +
              'RED6AR' + #9 +
              'RED6AR Lifecycle' + #9 +
              '' + #9 +
              WindchillDocumentSubCategory(DocTypeText);
end;

procedure WritePartHeaders(Rows : TStringList);
begin
end;

procedure WriteDocumentHeaders(Rows : TStringList);
begin
end;

function IsNotApplicable(Value : String) : Boolean;
begin
    Result := SameTextLocal(Trim(Value), 'N/A');
end;

function IsValidPartNumber(Value : String) : Boolean;
begin
    Result := (Trim(Value) <> '') and not IsNotApplicable(Value);
end;

function MakeBomRow(ActionText : String; LevelValue : Integer; NumberText, QuantityText,
                    LineNumberText, ReferenceDesignatorsText, TypeText : String) : String;
begin
    Result := CleanCellText(ActionText) + #9 +
              IntToStr(LevelValue) + #9 +
              CleanCellText(NumberText) + #9 +
              'RED6AR' + #9 +
              CleanCellText(QuantityText) + #9 +
              CleanCellText(LineNumberText) + #9 +
              CleanCellText(ReferenceDesignatorsText) + #9 +
              CleanCellText(TypeText);
end;

procedure AddBomPartRow(Rows : TStringList; PartNumber : String; var LevelValue : Integer;
                        var AddedCount : Integer);
begin
    if not IsValidPartNumber(PartNumber) then
        Exit;

    if LevelValue = 0 then
        Rows.Add(MakeBomRow('', LevelValue, PartNumber, '', '', '', ''))
    else
        Rows.Add(MakeBomRow('Add', LevelValue, PartNumber, '1', '1', '', 'wt.part.WTPartUsageLink'));

    Inc(LevelValue);
    Inc(AddedCount);
end;

procedure AddBomRows(Rows, Names, Values, ProjectParams, ProjectValues : TStringList;
                     var BomItemCount : Integer);
var
    AltPartNo  : String;
    ConfPartNo : String;
    PcbaPartNo : String;
    PcbPartNo  : String;
    LevelValue : Integer;
begin
    AltPartNo := ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'ALT_PART_NO');
    ConfPartNo := ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'CONF_PART_NO');
    PcbaPartNo := ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCBA_PART_NO');
    PcbPartNo := ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCB_PART_NO');

    LevelValue := 0;
    AddBomPartRow(Rows, AltPartNo, LevelValue, BomItemCount);
    AddBomPartRow(Rows, ConfPartNo, LevelValue, BomItemCount);
    AddBomPartRow(Rows, PcbaPartNo, LevelValue, BomItemCount);
    AddBomPartRow(Rows, PcbPartNo, LevelValue, BomItemCount);
end;

function SeenKeyAlreadyAdded(Seen : TStringList; Key : String) : Boolean;
begin
    Result := Seen.IndexOf(Key) >= 0;
    if not Result then
        Seen.Add(Key);
end;

procedure AddPartRow(Rows : TStringList; Seen : TStringList;
                     PartNumber, PartName, Revision, PartType, VariantName,
                     ClassValue, SolderValue, CoatValue, CageCode, ExportControl,
                     SourceProject, Notes : String; var AddedCount : Integer);
var
    Key : String;
begin
    PartNumber := Trim(PartNumber);
    if PartNumber = '' then
        Exit;

    Key := UpperCase(PartNumber + '|' + Revision + '|' + PartType);
    if SeenKeyAlreadyAdded(Seen, Key) then
        Exit;

    Rows.Add(MakePartRow('CREATE',
                         PartNumber,
                         PartName,
                         Revision,
                         PartType,
                         VariantName,
                         ClassValue,
                         SolderValue,
                         CoatValue,
                         CageCode,
                         ExportControl,
                         SourceProject,
                         Notes));

    Inc(AddedCount);
end;

procedure AddDocumentRow(Rows : TStringList; Seen : TStringList;
                         DocNumber, DocName, Revision, DocType, RelatedPartNumber,
                         VariantName, CageCode, ExportControl, SourceProject,
                         FileName, Notes : String; var AddedCount : Integer);
var
    Key : String;
begin
    DocNumber := Trim(DocNumber);
    if DocNumber = '' then
        Exit;

    Key := UpperCase(DocNumber + '|' + Revision + '|' + DocType);
    if SeenKeyAlreadyAdded(Seen, Key) then
        Exit;

    Rows.Add(MakeDocumentRow('CREATE',
                             DocNumber,
                             DocName,
                             Revision,
                             DocType,
                             RelatedPartNumber,
                             VariantName,
                             CageCode,
                             ExportControl,
                             SourceProject,
                             FileName,
                             Notes));

    Inc(AddedCount);
end;

function TitleForDocument(ProjectTitle, ExplicitTitle, SuffixText : String) : String;
begin
    Result := Trim(ExplicitTitle);
    if Result = '' then
        Result := Trim(ProjectTitle + ' ' + SuffixText);
end;

procedure AddVariantRows(PartRows, DocumentRows : TStringList;
                         SeenParts, SeenDocuments : TStringList;
                         VariantName, ProjectTitle, ProjectPath, SourceProject,
                         CageCode, ExportControl : String;
                         Names, Values, ProjectParams, ProjectValues : TStringList;
                         var PartCount, DocumentCount : Integer);
var
    PcbPartNo  : String;
    PcbaPartNo : String;
    ConfPartNo : String;
    ConfDocNo  : String;
    PcbClass   : String;
    PcbaClass  : String;
    Solder     : String;
    Coat       : String;
begin
    PcbPartNo := ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCB_PART_NO');
    PcbaPartNo := ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCBA_PART_NO');
    ConfPartNo := ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'CONF_PART_NO');
    ConfDocNo := ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'CONF_DOC_NO');
    PcbClass := ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCB_CLASS');
    PcbaClass := ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCBA_CLASS');
    Solder := ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCBA_SOLDER');
    Coat := ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'CONF_COAT');

    AddPartRow(PartRows, SeenParts,
               PcbPartNo,
               TitleForDocument(ProjectTitle, ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCB_TITLE_1'), 'PCB'),
               ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCB_REV'),
               'PCB',
               VariantName,
               PcbClass,
               '',
               Coat,
               CageCode,
               ExportControl,
               SourceProject,
               '',
               PartCount);

    AddPartRow(PartRows, SeenParts,
               PcbaPartNo,
               TitleForDocument(ProjectTitle, ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCBA_TITLE_1'), 'PCBA'),
               ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCBA_REV'),
               'PCBA',
               VariantName,
               PcbaClass,
               Solder,
               Coat,
               CageCode,
               ExportControl,
               SourceProject,
               '',
               PartCount);

    if not IsNotApplicable(ConfPartNo) then
        AddPartRow(PartRows, SeenParts,
                   ConfPartNo,
                   TitleForDocument(ProjectTitle, ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'CONF_TITLE_1'), 'Conformal Coat'),
                   ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'CONF_REV'),
                   'Conformal Coat',
                   VariantName,
                   '',
                   '',
                   Coat,
                   CageCode,
                   ExportControl,
                   SourceProject,
                   '',
                   PartCount);

    AddDocumentRow(DocumentRows, SeenDocuments,
                   ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'SCH_DOC_NO'),
                   TitleForDocument(ProjectTitle, ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'SCH_TITLE_1'), 'Schematic'),
                   ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'SCH_REV'),
                   'Schematic',
                   '',
                   VariantName,
                   CageCode,
                   ExportControl,
                   SourceProject,
                   '',
                   '',
                   DocumentCount);

    AddDocumentRow(DocumentRows, SeenDocuments,
                   ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCB_DOC_NO'),
                   TitleForDocument(ProjectTitle, ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCB_TITLE_1'), 'PCB Drawing'),
                   ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCB_REV'),
                   'PCB Drawing',
                   PcbPartNo,
                   VariantName,
                   CageCode,
                   ExportControl,
                   SourceProject,
                   '',
                   '',
                   DocumentCount);

    AddDocumentRow(DocumentRows, SeenDocuments,
                   ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCBA_DOC_NO'),
                   TitleForDocument(ProjectTitle, ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCBA_TITLE_1'), 'PCBA Drawing'),
                   ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'PCBA_REV'),
                   'PCBA Drawing',
                   PcbaPartNo,
                   VariantName,
                   CageCode,
                   ExportControl,
                   SourceProject,
                   '',
                   '',
                   DocumentCount);

    if not IsNotApplicable(ConfDocNo) then
        AddDocumentRow(DocumentRows, SeenDocuments,
                       ConfDocNo,
                       TitleForDocument(ProjectTitle, ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'CONF_TITLE_1'), 'Conformal Coat Drawing'),
                       ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'CONF_REV'),
                       'Conformal Coat Drawing',
                       ConfPartNo,
                       VariantName,
                       CageCode,
                       ExportControl,
                       SourceProject,
                       '',
                       '',
                       DocumentCount);

    AddDocumentRow(DocumentRows, SeenDocuments,
                   ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'ECAD_DOC_NO'),
                   'ECAD, ' + ProjectTitle + ', ' + VariantName,
                   ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'ECAD_REV'),
                   'ECAD Data',
                   PcbaPartNo,
                   VariantName,
                   CageCode,
                   ExportControl,
                   SourceProject,
                   ExtractFileName(ProjectPath),
                   '',
                   DocumentCount);

    AddDocumentRow(DocumentRows, SeenDocuments,
                   ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'CBDD_DOC_NO'),
                   'CBDD, ' + ProjectTitle + ', ' + VariantName,
                   ParamValueWithFallback(Names, Values, ProjectParams, ProjectValues, 'CBDD_REV'),
                   'CBDD',
                   PcbaPartNo,
                   VariantName,
                   CageCode,
                   ExportControl,
                   SourceProject,
                   ExtractFileName(ProjectPath),
                   '',
                   DocumentCount);
end;

function MissingRequiredPartNumbers(Names, Values, ProjectParams, ProjectValues : TStringList) : String;
var
    MissingText : String;
begin
    MissingText := '';

    if not IsValidPartNumber(ParamValueByName(Names, Values, 'PCB_PART_NO')) then
        MissingText := 'PCB_PART_NO';

    if not IsValidPartNumber(ParamValueByName(Names, Values, 'PCBA_PART_NO')) then
    begin
        if MissingText <> '' then
            MissingText := MissingText + ', ';

        MissingText := MissingText + 'PCBA_PART_NO';
    end;

    Result := MissingText;
end;

procedure AddSkippedVariant(SkippedVariants : TStringList; VariantName, MissingFields : String);
begin
    SkippedVariants.Add(VariantName + ' (missing ' + MissingFields + ')');
end;

function SidecarPath(OutputPath, Suffix : String) : String;
begin
    Result := ChangeFileExt(OutputPath, Suffix);
end;

procedure SaveRows(Path : String; Rows : TStringList);
begin
    if FileExists(Path) then
        DeleteFile(Path);

    Rows.SaveToFile(Path);
end;

function WriteBuilderCommand(CommandPath, OutputPath, PartRowsPath, DocumentRowsPath : String) : Boolean;
var
    Lines     : TStringList;
    HelperPath: String;
    LogPath   : String;
begin
    Result := False;
    HelperPath := ICEBERG_SCRIPT_FOLDER + '\ICEBERG_CreateWorkbook.ps1';
    LogPath := SidecarPath(OutputPath, '.builder.log');

    if not FileExists(HelperPath) then
    begin
        ShowMessage('ICEBERG workbook helper not found:' + #13#10 + HelperPath);
        Exit;
    end;

    Lines := TStringList.Create;
    try
        Lines.Add('@echo off');
        Lines.Add('powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' + HelperPath +
                  '" -OutputPath "' + OutputPath +
                  '" -PartsPath "' + PartRowsPath +
                  '" -DocumentsPath "' + DocumentRowsPath +
                  '" > "' + LogPath + '" 2>&1');
        Lines.Add('if errorlevel 1 goto ICEBERG_FAILED');
        Lines.Add('del /q "' + PartRowsPath + '"');
        Lines.Add('del /q "' + DocumentRowsPath + '"');
        Lines.Add('del /q "' + LogPath + '"');
        Lines.Add('del /q "%~f0"');
        Lines.Add('goto :eof');
        Lines.Add(':ICEBERG_FAILED');
        Lines.Add('echo ICEBERG workbook builder failed. See log: "' + LogPath + '"');
        Lines.SaveToFile(CommandPath);
        Result := True;
    finally
        Lines.Free;
    end;
end;

procedure StartWorkbookBuilder(OutputPath, PartRowsPath, DocumentRowsPath : String);
var
    CommandPath : String;
begin
    CommandPath := SidecarPath(OutputPath, '.builder.cmd');
    if WriteBuilderCommand(CommandPath, OutputPath, PartRowsPath, DocumentRowsPath) then
        RunApplication(CommandPath);
end;

function WriteBomBuilderCommand(CommandPath, OutputPath, BomRowsPath : String) : Boolean;
var
    Lines     : TStringList;
    HelperPath: String;
    LogPath   : String;
begin
    Result := False;
    HelperPath := ICEBERG_SCRIPT_FOLDER + '\ICEBERG_CreateBomWorkbook.ps1';
    LogPath := SidecarPath(OutputPath, '.builder.log');

    if not FileExists(HelperPath) then
    begin
        ShowMessage('ICEBERG BOM workbook helper not found:' + #13#10 + HelperPath);
        Exit;
    end;

    Lines := TStringList.Create;
    try
        Lines.Add('@echo off');
        Lines.Add('powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' + HelperPath +
                  '" -OutputPath "' + OutputPath +
                  '" -BomPath "' + BomRowsPath +
                  '" > "' + LogPath + '" 2>&1');
        Lines.Add('if errorlevel 1 goto ICEBERG_FAILED');
        Lines.Add('del /q "' + BomRowsPath + '"');
        Lines.Add('del /q "' + LogPath + '"');
        Lines.Add('del /q "%~f0"');
        Lines.Add('goto :eof');
        Lines.Add(':ICEBERG_FAILED');
        Lines.Add('echo ICEBERG BOM workbook builder failed. See log: "' + LogPath + '"');
        Lines.SaveToFile(CommandPath);
        Result := True;
    finally
        Lines.Free;
    end;
end;

procedure StartBomWorkbookBuilder(OutputPath, BomRowsPath : String);
var
    CommandPath : String;
begin
    CommandPath := SidecarPath(OutputPath, '.builder.cmd');
    if WriteBomBuilderCommand(CommandPath, OutputPath, BomRowsPath) then
        RunApplication(CommandPath);
end;

procedure BuildVariantWorkbook(ProjectPath, ProjectTitle, ProjectNameForOutput,
                               SourceProject, CageCode, ExportControl, VariantName : String;
                               VariantNames, VariantValues, ProjectParams, ProjectValues : TStringList;
                               var WorkbookCount, BomWorkbookCount, TotalPartCount,
                                   TotalDocumentCount, TotalBomItemCount : Integer);
var
    SeenParts        : TStringList;
    SeenDocuments    : TStringList;
    PartRows         : TStringList;
    DocumentRows     : TStringList;
    BomRows          : TStringList;
    OutputPath       : String;
    BomOutputPath    : String;
    PartRowsPath     : String;
    DocumentRowsPath : String;
    BomRowsPath      : String;
    PcbaPartNo       : String;
    PartCount        : Integer;
    DocumentCount    : Integer;
    BomItemCount     : Integer;
begin
    SeenParts := TStringList.Create;
    SeenDocuments := TStringList.Create;
    PartRows := TStringList.Create;
    DocumentRows := TStringList.Create;
    BomRows := TStringList.Create;

    try
        WritePartHeaders(PartRows);
        WriteDocumentHeaders(DocumentRows);

        PartCount := 0;
        DocumentCount := 0;
        BomItemCount := 0;
        AddVariantRows(PartRows, DocumentRows,
                       SeenParts, SeenDocuments,
                       VariantName, ProjectTitle, ProjectPath, SourceProject,
                       CageCode, ExportControl,
                       VariantNames, VariantValues, ProjectParams, ProjectValues,
                       PartCount, DocumentCount);
        AddBomRows(BomRows, VariantNames, VariantValues, ProjectParams, ProjectValues,
                   BomItemCount);

        PcbaPartNo := ParamValueWithFallback(VariantNames, VariantValues, ProjectParams, ProjectValues, 'PCBA_PART_NO');
        OutputPath := VariantWorkbookPath(ProjectPath, PcbaPartNo, ProjectNameForOutput, VariantName);
        BomOutputPath := VariantBomWorkbookPath(ProjectPath, PcbaPartNo, ProjectNameForOutput, VariantName);
        if OutputPath = '' then
            Exit;
        if BomOutputPath = '' then
            Exit;

        PartRowsPath := SidecarPath(OutputPath, '.parts.tsv');
        DocumentRowsPath := SidecarPath(OutputPath, '.documents.tsv');
        BomRowsPath := SidecarPath(BomOutputPath, '.bom.tsv');

        SaveRows(PartRowsPath, PartRows);
        SaveRows(DocumentRowsPath, DocumentRows);
        SaveRows(BomRowsPath, BomRows);
        StartWorkbookBuilder(OutputPath, PartRowsPath, DocumentRowsPath);
        StartBomWorkbookBuilder(BomOutputPath, BomRowsPath);

        Inc(WorkbookCount);
        Inc(BomWorkbookCount);
        TotalPartCount := TotalPartCount + PartCount;
        TotalDocumentCount := TotalDocumentCount + DocumentCount;
        TotalBomItemCount := TotalBomItemCount + BomItemCount;
    finally
        SeenParts.Free;
        SeenDocuments.Free;
        PartRows.Free;
        DocumentRows.Free;
        BomRows.Free;
    end;
end;

procedure GenerateWindchillImportWorkbook;
var
    Lines          : TStringList;
    ProjectParams  : TStringList;
    ProjectValues  : TStringList;
    VariantNames   : TStringList;
    VariantValues  : TStringList;
    SkippedVariants: TStringList;
    ProjectPath    : String;
    ProjectTitle   : String;
    ProjectNameForOutput : String;
    OutputFolder   : String;
    SourceProject  : String;
    CageCode       : String;
    ExportControl  : String;
    VariantName    : String;
    I              : Integer;
    VariantIndex   : Integer;
    VariantCount   : Integer;
    WorkbookCount  : Integer;
    BomWorkbookCount : Integer;
    SkippedCount   : Integer;
    TotalPartCount : Integer;
    TotalDocumentCount : Integer;
    TotalBomItemCount : Integer;
    MissingFields  : String;
    SummaryMessage : String;
begin
    Lines := TStringList.Create;
    ProjectParams := TStringList.Create;
    ProjectValues := TStringList.Create;
    VariantNames := TStringList.Create;
    VariantValues := TStringList.Create;
    SkippedVariants := TStringList.Create;

    try
        if not LoadFocusedProjectLines(Lines, ProjectPath) then
            Exit;

        ReadProjectParameters(Lines, ProjectParams, ProjectValues);
        ProjectTitle := DefaultProjectName(ProjectParams, ProjectValues, ProjectPath);
        ProjectNameForOutput := ProjectNameForFile(ProjectParams, ProjectValues, ProjectPath);
        OutputFolder := OutputFolderForProject(ProjectPath);
        if OutputFolder = '' then
            Exit;

        SourceProject := ExtractFileName(ProjectPath);
        CageCode := ParamValueByName(ProjectParams, ProjectValues, 'CAGE_CODE');
        ExportControl := ParamValueByName(ProjectParams, ProjectValues, 'ITAR_HEADER');

        VariantCount := 0;
        WorkbookCount := 0;
        BomWorkbookCount := 0;
        SkippedCount := 0;
        TotalPartCount := 0;
        TotalDocumentCount := 0;
        TotalBomItemCount := 0;

        for I := 0 to Lines.Count - 1 do
        begin
            VariantIndex := ProjectVariantIndexFromHeader(Lines[I]);
            if VariantIndex > 0 then
            begin
                Inc(VariantCount);
                VariantName := Trim(ReadSectionValue(Lines, I, 'Description'));
                if VariantName = '' then
                    VariantName := 'Variant ' + IntToStr(VariantIndex);

                ReadParameterSectionsForVariant(Lines, VariantIndex, VariantNames, VariantValues);
                MissingFields := MissingRequiredPartNumbers(VariantNames, VariantValues, ProjectParams, ProjectValues);
                if MissingFields <> '' then
                begin
                    Inc(SkippedCount);
                    AddSkippedVariant(SkippedVariants, VariantName, MissingFields);
                end
                else
                begin
                    BuildVariantWorkbook(ProjectPath, ProjectTitle, ProjectNameForOutput,
                                         SourceProject, CageCode, ExportControl, VariantName,
                                         VariantNames, VariantValues, ProjectParams, ProjectValues,
                                         WorkbookCount, BomWorkbookCount, TotalPartCount,
                                         TotalDocumentCount, TotalBomItemCount);
                end;
            end;
        end;

        if VariantCount = 0 then
        begin
            MissingFields := MissingRequiredPartNumbers(ProjectParams, ProjectValues, ProjectParams, ProjectValues);
            if MissingFields <> '' then
            begin
                Inc(SkippedCount);
                AddSkippedVariant(SkippedVariants, 'Default', MissingFields);
            end
            else
            begin
                BuildVariantWorkbook(ProjectPath, ProjectTitle, ProjectNameForOutput,
                                     SourceProject, CageCode, ExportControl, 'Default',
                                     ProjectParams, ProjectValues, ProjectParams, ProjectValues,
                                     WorkbookCount, BomWorkbookCount, TotalPartCount,
                                     TotalDocumentCount, TotalBomItemCount);
            end;
        end;

        SummaryMessage := 'ICEBERG staged Windchill import data and started XLSX builders in:' + #13#10 +
                          OutputFolder + #13#10 + #13#10 +
                          'Workbooks: ' + IntToStr(WorkbookCount + BomWorkbookCount) + #13#10 +
                          'Part/document workbooks: ' + IntToStr(WorkbookCount) + #13#10 +
                          'BOM workbooks: ' + IntToStr(BomWorkbookCount) + #13#10 +
                          'Parts: ' + IntToStr(TotalPartCount) + #13#10 +
                          'Documents: ' + IntToStr(TotalDocumentCount) + #13#10 +
                          'BOM items: ' + IntToStr(TotalBomItemCount) + #13#10 +
                          'Skipped variants: ' + IntToStr(SkippedCount);

        if SkippedVariants.Count > 0 then
            SummaryMessage := SummaryMessage + #13#10 + #13#10 +
                              'Skipped:' + #13#10 +
                              SkippedVariants.Text;

        ShowMessage(SummaryMessage);
    finally
        Lines.Free;
        ProjectParams.Free;
        ProjectValues.Free;
        VariantNames.Free;
        VariantValues.Free;
        SkippedVariants.Free;
    end;
end;
